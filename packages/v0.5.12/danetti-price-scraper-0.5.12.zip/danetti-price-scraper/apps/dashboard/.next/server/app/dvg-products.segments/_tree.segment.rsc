:HL["/_next/static/chunks/39w860ykfbt2-.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"dvg-products","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"6tvi3b7F6Jx8o4F3CwJJd"}
