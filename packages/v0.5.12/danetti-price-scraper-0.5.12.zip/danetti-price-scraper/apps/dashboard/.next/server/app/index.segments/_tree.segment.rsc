:HL["/_next/static/chunks/39w860ykfbt2-.css","style"]
:HL["/_next/static/chunks/3dfg4_wb1iiit.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"6tvi3b7F6Jx8o4F3CwJJd"}
