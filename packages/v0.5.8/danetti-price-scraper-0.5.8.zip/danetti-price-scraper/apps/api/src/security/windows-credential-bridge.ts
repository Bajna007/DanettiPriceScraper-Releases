import { Buffer } from "node:buffer";
import { spawn } from "node:child_process";
import { SupplierCredentialError } from "../modules/supplier-credentials/supplier-credentials.types.js";
interface WindowsCredentialManagerRequest {
  action: "read" | "write" | "delete";
  target: string;
  secret?: string;
}

interface WindowsCredentialManagerResponse {
  ok: boolean;
  found?: boolean;
  secret?: string;
}

export async function invokeWindowsCredentialManager(
  request: WindowsCredentialManagerRequest
): Promise<WindowsCredentialManagerResponse> {
  const encodedCommand = Buffer.from(WINDOWS_CREDENTIAL_MANAGER_SCRIPT, "utf16le").toString(
    "base64"
  );

  return new Promise((resolve, reject) => {
    const child = spawn(
      "powershell.exe",
      [
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-EncodedCommand",
        encodedCommand,
      ],
      { stdio: ["pipe", "pipe", "pipe"], windowsHide: true }
    );
    let stdout = "";
    let settled = false;
    const timeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      child.kill();
      rejectCredentialStoreUnavailable(reject);
    }, 15_000);

    child.stdout.setEncoding("utf8");
    child.stdout.on("data", (chunk: string) => {
      stdout += chunk;
    });
    child.stderr.resume();
    child.on("error", () => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      rejectCredentialStoreUnavailable(reject);
    });
    child.on("close", (code) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      if (code !== 0) return rejectCredentialStoreUnavailable(reject);
      try {
        const parsed = JSON.parse(stdout.trim()) as WindowsCredentialManagerResponse;
        if (!parsed.ok) return rejectCredentialStoreUnavailable(reject);
        resolve(parsed);
      } catch {
        rejectCredentialStoreUnavailable(reject);
      }
    });

    child.stdin.end(JSON.stringify(request));
  });
}

function rejectCredentialStoreUnavailable(reject: (reason?: unknown) => void): void {
  reject(
    new SupplierCredentialError(
      "credential_store_unavailable",
      "Windows Credential Manager operation failed.",
      503
    )
  );
}

const WINDOWS_CREDENTIAL_MANAGER_SCRIPT = String.raw`
$ErrorActionPreference = "Stop"
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$ProgressPreference = "SilentlyContinue"
try {
  $inputJson = [Console]::In.ReadToEnd()
  $request = $inputJson | ConvertFrom-Json
  Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class DanettiCredentialManager
{
    public struct CredentialReadResult
    {
        public bool Ok;
        public int ErrorCode;
        public string Secret;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct CREDENTIAL
    {
        public UInt32 Flags;
        public UInt32 Type;
        public string TargetName;
        public string Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
        public UInt32 CredentialBlobSize;
        public IntPtr CredentialBlob;
        public UInt32 Persist;
        public UInt32 AttributeCount;
        public IntPtr Attributes;
        public string TargetAlias;
        public string UserName;
    }

    [DllImport("advapi32.dll", EntryPoint="CredWriteW", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern bool CredWrite(ref CREDENTIAL userCredential, UInt32 flags);

    [DllImport("advapi32.dll", EntryPoint="CredReadW", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern bool CredRead(string target, UInt32 type, UInt32 reservedFlag, out IntPtr credentialPtr);

    [DllImport("advapi32.dll", EntryPoint="CredDeleteW", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern bool CredDelete(string target, UInt32 type, UInt32 flags);

    [DllImport("advapi32.dll", EntryPoint="CredFree", SetLastError=true)]
    public static extern void CredFree(IntPtr cred);

    public static bool WriteGeneric(string target, string secret)
    {
        byte[] bytes = System.Text.Encoding.Unicode.GetBytes(secret);
        IntPtr blob = Marshal.AllocHGlobal(bytes.Length);
        try
        {
            Marshal.Copy(bytes, 0, blob, bytes.Length);
            CREDENTIAL credential = new CREDENTIAL();
            credential.Type = 1;
            credential.TargetName = target;
            credential.CredentialBlobSize = (UInt32)bytes.Length;
            credential.CredentialBlob = blob;
            credential.Persist = 2;
            credential.UserName = "DanettiPriceScraper";
            return CredWrite(ref credential, 0);
        }
        finally
        {
            Marshal.FreeHGlobal(blob);
        }
    }

    public static CredentialReadResult ReadGeneric(string target)
    {
        IntPtr credentialPtr = IntPtr.Zero;
        bool ok = CredRead(target, 1, 0, out credentialPtr);
        int lastError = Marshal.GetLastWin32Error();
        if (!ok)
        {
            return new CredentialReadResult { Ok = false, ErrorCode = lastError, Secret = null };
        }

        try
        {
            CREDENTIAL credential = (CREDENTIAL)Marshal.PtrToStructure(credentialPtr, typeof(CREDENTIAL));
            string secret = Marshal.PtrToStringUni(credential.CredentialBlob, (int)(credential.CredentialBlobSize / 2));
            return new CredentialReadResult { Ok = true, ErrorCode = 0, Secret = secret };
        }
        finally
        {
            CredFree(credentialPtr);
        }
    }

    public static int DeleteGeneric(string target)
    {
        bool ok = CredDelete(target, 1, 0);
        return ok ? 0 : Marshal.GetLastWin32Error();
    }
}
"@

  $target = [string]$request.target

  if ($request.action -eq "write") {
    $secret = [string]$request.secret
    $ok = [DanettiCredentialManager]::WriteGeneric($target, $secret)
    if (-not $ok) { throw "CredWrite failed" }
    @{ ok = $true } | ConvertTo-Json -Compress
  } elseif ($request.action -eq "read") {
    $result = [DanettiCredentialManager]::ReadGeneric($target)
    if (-not $result.Ok) {
      if ($result.ErrorCode -eq 1168) {
        @{ ok = $true; found = $false } | ConvertTo-Json -Compress
      } else {
        throw "CredRead failed"
      }
    } else {
      @{ ok = $true; found = $true; secret = $result.Secret } | ConvertTo-Json -Compress
    }
  } elseif ($request.action -eq "delete") {
    $errorCode = [DanettiCredentialManager]::DeleteGeneric($target)
    if ($errorCode -ne 0 -and $errorCode -ne 1168) { throw "CredDelete failed" }
    @{ ok = $true } | ConvertTo-Json -Compress
  } else {
    throw "Unsupported credential action"
  }
} catch {
  @{ ok = $false; error = "windows_credential_manager_failed" } | ConvertTo-Json -Compress
  exit 1
}
`;
