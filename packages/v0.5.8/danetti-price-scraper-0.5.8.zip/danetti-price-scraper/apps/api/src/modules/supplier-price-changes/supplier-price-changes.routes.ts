import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import {
  SupplierPriceChangesRepository,
  type SupplierPriceChangesRepositoryLike,
} from "./supplier-price-changes.repository.js";
import {
  buildSupplierPriceChangeResponse,
  SupplierPriceChangeDatabaseError,
  SupplierPriceChangeValidationError,
  validateSupplierPriceChangeQuery,
} from "./supplier-price-changes.service.js";

interface SupplierPriceChangeRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  repository?: SupplierPriceChangesRepositoryLike;
  now?: () => Date;
}

export async function registerSupplierPriceChangeRoutes(
  server: FastifyInstance,
  options: SupplierPriceChangeRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;
  const now = options.now ?? (() => new Date());

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getRepository(): SupplierPriceChangesRepositoryLike {
    if (options.repository) return options.repository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new SupplierPriceChangesRepository(dbClient.db);
    } catch (error) {
      throw new SupplierPriceChangeDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/supplier-price-changes", async (request, reply) => {
    try {
      const query = validateSupplierPriceChangeQuery(request.query);
      const repository = getRepository();
      const eurHufRate = query.eurHufRate ?? (await repository.getLatestEurHufRate());
      if (eurHufRate === null) {
        throw new SupplierPriceChangeValidationError(
          "eur_huf_rate_required",
          "EUR/HUF exchange rate is required for supplier price changes"
        );
      }
      const rows = await repository.listRecentCatalogSnapshots(
        query.maxSnapshotScan,
        query.supplierScope
      );
      return buildSupplierPriceChangeResponse({
        rows,
        query: { ...query, eurHufRate },
        now: now(),
      });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof SupplierPriceChangeValidationError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  if (error instanceof SupplierPriceChangeDatabaseError) {
    return reply
      .code(503)
      .send({ error: { code: "database_unavailable", message: error.message } });
  }
  return reply.code(500).send({
    error: { code: "supplier_price_changes_failed", message: "Supplier price changes API failed" },
  });
}
