import { Queue, Worker } from "bullmq";
import { Redis } from "ioredis";
import { and, desc, eq, inArray } from "drizzle-orm";
import {
  eprPeriods,
  eprScanRuns,
  mailboxAccounts,
  sourceDocuments,
  purchaseDocuments,
  businessDocuments,
  purchases,
} from "@danetti/db";
import { EprService } from "./epr.service.js";
import { MailboxService } from "./mailbox.service.js";
import { EprError, safeCode } from "./epr.errors.js";

type Job = { runId: string; periodId: string };
export class EprScanCoordinator {
  private readonly connection: Redis;
  private readonly producerConnection: Redis;
  private readonly queue: Queue;
  private readonly worker: Worker;
  constructor(
    private readonly service: EprService,
    private readonly mailboxes: MailboxService,
    queueName = "epr-scan"
  ) {
    this.connection = new Redis(process.env.REDIS_URL ?? "redis://localhost:6379", {
      maxRetriesPerRequest: null,
      connectTimeout: 3000,
    });
    this.connection.on("error", () => undefined);
    this.producerConnection = new Redis(process.env.REDIS_URL ?? "redis://localhost:6379", {
      maxRetriesPerRequest: 1,
      connectTimeout: 3000,
      retryStrategy: (attempt) => (attempt <= 2 ? 500 : null),
    });
    this.producerConnection.on("error", () => undefined);
    this.queue = new Queue(queueName, { connection: this.producerConnection });
    this.worker = new Worker<Job>(queueName, (job) => this.process(job.data), {
      connection: this.connection,
      concurrency: 1,
    });
    this.worker.on("error", () => undefined);
  }
  async enqueue(periodId: string) {
    const client = this.service.client;
    const run = await client.db.transaction(async (tx) => {
      const [period] = await tx
        .select()
        .from(eprPeriods)
        .where(eq(eprPeriods.id, periodId))
        .for("update");
      if (!period) throw new EprError("period_not_found", 404);
      const [active] = await tx
        .select()
        .from(eprScanRuns)
        .where(
          and(
            eq(eprScanRuns.periodId, periodId),
            inArray(eprScanRuns.status, ["QUEUED", "RUNNING", "PAUSED"])
          )
        )
        .orderBy(desc(eprScanRuns.createdAt));
      if (active) return active;
      const enabled = await tx
        .select()
        .from(mailboxAccounts)
        .where(eq(mailboxAccounts.enabled, true));
      if (!enabled.length) throw new EprError("mailbox_setup_required", 409);
      const [created] = await tx
        .insert(eprScanRuns)
        .values({
          periodId,
          status: "QUEUED",
          progress: {
            mailboxCount: enabled.length,
            mailboxesDone: 0,
            messagesScanned: 0,
            documentsDiscovered: 0,
            documentsProcessed: 0,
            candidatesCreated: 0,
            reviewItemsCreated: 0,
          },
        })
        .returning();
      return created;
    });
    try {
      await this.queue.add(
        "scan",
        { runId: run.id, periodId },
        { jobId: run.id, attempts: 1, removeOnComplete: 200, removeOnFail: 200 }
      );
    } catch {
      await client.db
        .update(eprScanRuns)
        .set({ status: "FAILED", safeErrorCode: "epr_queue_unavailable" })
        .where(eq(eprScanRuns.id, run.id));
      throw new EprError("epr_queue_unavailable", 503);
    }
    return run;
  }
  async recover() {
    const runs = await this.service.client.db
      .select()
      .from(eprScanRuns)
      .where(inArray(eprScanRuns.status, ["QUEUED", "RUNNING", "PAUSED"]));
    for (const run of runs) {
      const existing = await this.queue.getJob(run.id);
      if (existing) {
        const state = await existing.getState();
        if (state === "failed" || state === "completed") {
          await this.service.client.db
            .update(eprScanRuns)
            .set({
              status: "FAILED",
              safeErrorCode: "epr_scan_recovery_required",
              completedAt: new Date(),
            })
            .where(eq(eprScanRuns.id, run.id));
        }
        continue;
      }
      await this.queue.add(
        "scan",
        { runId: run.id, periodId: run.periodId },
        { jobId: run.id, attempts: 1, removeOnComplete: 200, removeOnFail: 200 }
      );
    }
  }
  private async process(job: Job) {
    const db = this.service.client.db;
    const [run] = await db.select().from(eprScanRuns).where(eq(eprScanRuns.id, job.runId));
    if (!run) return;
    const progress = {
      mailboxCount: 0,
      mailboxesDone: 0,
      messagesScanned: 0,
      documentsDiscovered: 0,
      documentsProcessed: 0,
      candidatesCreated: 0,
      reviewItemsCreated: 0,
      ...run.progress,
    };
    await db
      .update(eprScanRuns)
      .set({ status: "RUNNING", startedAt: run.startedAt ?? new Date(), safeErrorCode: null })
      .where(eq(eprScanRuns.id, run.id));
    try {
      const mailboxes = await this.mailboxes.list();
      progress.mailboxCount = mailboxes.filter((m) => m.enabled).length;
      for (const mailbox of mailboxes.filter((m) => m.enabled)) {
        await this.mailboxes.scan(
          mailbox,
          async (messageId, source, metadata) => {
            await this.service.importMessage(job.periodId, messageId, source, metadata);
            progress.documentsDiscovered++;
            progress.documentsProcessed++;
          },
          async (count, checkpoint) => {
            progress.messagesScanned += count;
            await db
              .update(eprScanRuns)
              .set({ progress, checkpoint })
              .where(eq(eprScanRuns.id, run.id));
          },
          (messageId, metadata) =>
            this.service.importOversizedMessage(job.periodId, messageId, metadata)
        );
        progress.mailboxesDone++;
        await db.update(eprScanRuns).set({ progress }).where(eq(eprScanRuns.id, run.id));
      }
      const [period] = await db.select().from(eprPeriods).where(eq(eprPeriods.id, job.periodId));
      if (period.status !== "CLOSED") {
        await this.service.retryUnavailableDocuments(job.periodId);
        await this.service.recalculate(job.periodId);
      }
      const docs = await db
        .select({ id: sourceDocuments.id, status: sourceDocuments.status })
        .from(sourceDocuments)
        .innerJoin(businessDocuments, eq(businessDocuments.sourceDocumentId, sourceDocuments.id))
        .innerJoin(
          purchaseDocuments,
          eq(purchaseDocuments.businessDocumentId, businessDocuments.id)
        )
        .innerJoin(purchases, eq(purchases.id, purchaseDocuments.purchaseId))
        .where(eq(purchases.periodId, job.periodId));
      progress.documentsDiscovered = docs.length;
      progress.documentsProcessed = docs.filter((d) => d.status === "processed").length;
      const items = await this.service.listPurchases(job.periodId);
      progress.candidatesCreated = items.filter((p) => p.status === "potential").length;
      progress.reviewItemsCreated = items.filter(
        (p) => !["ok", "excluded"].includes(p.status)
      ).length;
      await db
        .update(eprScanRuns)
        .set({
          status: progress.reviewItemsCreated ? "COMPLETED_WITH_REVIEW" : "COMPLETED",
          progress,
          completedAt: new Date(),
        })
        .where(eq(eprScanRuns.id, run.id));
      await this.service.scanEvent(run.id, "scan_completed", progress);
    } catch (error) {
      const code = safeCode(error, "epr_scan_failed");
      await db
        .update(eprScanRuns)
        .set({ status: "FAILED", progress, safeErrorCode: code, completedAt: new Date() })
        .where(eq(eprScanRuns.id, run.id));
      await this.service.scanEvent(run.id, code);
      throw new EprError(code, 503);
    }
  }
  async status(id: string) {
    const [run] = await this.service.client.db
      .select()
      .from(eprScanRuns)
      .where(eq(eprScanRuns.id, id));
    if (!run) throw new EprError("scan_not_found", 404);
    return run;
  }
  async latest(periodId: string) {
    const [run] = await this.service.client.db
      .select()
      .from(eprScanRuns)
      .where(eq(eprScanRuns.periodId, periodId))
      .orderBy(desc(eprScanRuns.createdAt))
      .limit(1);
    return run ?? null;
  }
  async close() {
    await this.worker.close(true);
    await this.queue.close();
    this.connection.disconnect();
    this.producerConnection.disconnect();
  }
}
