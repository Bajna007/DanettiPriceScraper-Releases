import type { FastifyInstance } from "fastify";
import {
  handleLabelError,
  paramsRecord,
  queryRecord,
  type LabelRouteContext,
} from "../route-utils.js";

export async function registerLabelExportRoutes(
  server: FastifyInstance,
  context: LabelRouteContext
): Promise<void> {
  server.get("/label-exports", async (request, reply) => {
    try {
      const query = queryRecord(request.query);
      return {
        items: await context
          .getService()
          .listExports(typeof query.orderId === "string" ? query.orderId : undefined),
      };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.get("/label-exports/:id/download", async (request, reply) => {
    try {
      const result = await context.getService().downloadExport(paramsRecord(request.params).id!);
      return reply
        .header("content-type", String(result.row.mime_type))
        .header(
          "content-disposition",
          `attachment; filename*=UTF-8''${encodeURIComponent(String(result.row.filename))}`
        )
        .header("x-content-sha256", String(result.row.sha256))
        .send(result.bytes);
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
}
