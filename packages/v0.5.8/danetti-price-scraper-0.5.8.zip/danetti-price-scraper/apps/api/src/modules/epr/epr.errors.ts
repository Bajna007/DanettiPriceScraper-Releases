export class EprError extends Error {
  constructor(
    public readonly code: string,
    public readonly httpStatus = 400
  ) {
    super(code);
  }
}
export function safeCode(error: unknown, fallback = "epr_operation_failed") {
  if (error instanceof EprError) return error.code;
  if (error instanceof Error) {
    const code = "code" in error ? String(error.code) : error.message;
    if (["credential_store_unavailable", "credential_store_corrupt"].includes(code)) return code;
  }
  return fallback;
}
