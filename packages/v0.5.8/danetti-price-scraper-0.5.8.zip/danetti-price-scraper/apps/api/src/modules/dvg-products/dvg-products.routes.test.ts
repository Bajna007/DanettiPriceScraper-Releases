import assert from "node:assert/strict";
import type {
  DvgManualBatchCallbacks,
  DvgManualBatchCandidate,
  DvgManualBatchRow,
  DvgManualBatchSettings,
  DvgManualBatchState,
} from "@danetti/connectors";
import Fastify from "fastify";
import { registerDvgProductsRoutes } from "./dvg-products.routes.js";

const candidate: DvgManualBatchCandidate = {
  catalogProductId: "11111111-1111-4111-8111-111111111111",
  wooSku: "CS-A2200247_SAE125",
  wooName: "Teszt termek",
  currentPrice: "10000",
  regularPrice: "12000",
  salePrice: null,
  supplierId: "22222222-2222-4222-8222-222222222222",
  supplierMappingId: "33333333-3333-4333-8333-333333333333",
  supplierArticleNumber: "CS-A2200247",
  candidateSource: "saved_mapping",
  matchConfidence: "saved_mapping",
};

function buildRouteTestRow(
  settings: DvgManualBatchSettings,
  status: DvgManualBatchRow["status"],
  warnings: string[] = []
): DvgManualBatchRow {
  return {
    status,
    catalogProductId: candidate.catalogProductId,
    wooSku: candidate.wooSku,
    wooName: candidate.wooName,
    supplierId: candidate.supplierId,
    supplierMappingId: candidate.supplierMappingId,
    supplierArticleNumber: candidate.supplierArticleNumber,
    candidateSource: candidate.candidateSource,
    dvgDetailUrl:
      "https://devecchigiuseppesrl.com/e-commerce/welcome/ordini/dettagli.asp?codice-articolo=CS-A2200247",
    dvgProductName: status === "ok" ? "DVG termek" : null,
    dvgArticle: status === "ok" ? "CS-A2200247" : null,
    dvgOriginalCode: status === "ok" ? "A2200247" : null,
    supplierNetEur: status === "ok" ? 4.95 : null,
    supplierCrossedEur: null,
    currency: status === "ok" ? "EUR" : null,
    unit: status === "ok" ? "pc" : null,
    eurHufRate: settings.eurHufRate,
    markupPercent: settings.markupPercent,
    vatPercent: settings.vatPercent,
    matchConfidence: status === "ok" ? "exact_dvg_article" : "saved_mapping",
    warnings,
    wooPriceHuf: status === "ok" ? 10000 : null,
    wooPriceSource: status === "ok" ? "currentPrice" : null,
    wooGrossHuf: status === "ok" ? 10000 : null,
    wooNetHuf: status === "ok" ? 7874.0157480314965 : null,
    supplierNetHuf: status === "ok" ? 1980 : null,
    targetNetHuf: status === "ok" ? 2574 : null,
    targetGrossHuf: status === "ok" ? 3268.98 : null,
    targetGrossHufRounded: null,
    actualProfitNetHuf: status === "ok" ? 5894.0157480314965 : null,
    actualProfitPercentOnCost: status === "ok" ? 297.67756303189375 : null,
    actualGrossDeltaToTargetHuf: status === "ok" ? 6731.02 : null,
  };
}

const capturedSettings: DvgManualBatchSettings[] = [];
const capturedPricingRows: DvgManualBatchRow[][] = [];
const capturedProgressRows: Array<{ row: DvgManualBatchRow; runId: string; globalIndex: number }> =
  [];
let openBrowserCalled = false;
let cancelCalled = false;
let runnerMode: "success" | "detach_failed" | "session_lost" | "row_update" = "success";
let savedOperatorRunState: DvgManualBatchState | null = null;
const persistedOperatorRunStates: DvgManualBatchState[] = [];
const localLabHeaders = { "x-danetti-local-lab": "true" };
const server = Fastify({ logger: false });

await registerDvgProductsRoutes(server, {
  now: () => new Date("2026-06-02T10:00:00.000Z"),
  repository: {
    async listCandidates(settings) {
      capturedSettings.push(settings);
      return [candidate];
    },
    async saveCatalogProductDvgRunRow(row, input) {
      capturedProgressRows.push({ row, runId: input.runId, globalIndex: input.globalIndex });
      return {
        progressSaved: true,
        pricingSaved:
          input.settings.dryRun === false &&
          input.settings.allowSnapshotWrite === true &&
          row.status === "ok",
      };
    },
    async getLatestDvgRunProgress() {
      const latest = capturedProgressRows.at(-1);
      if (!latest) return null;
      return {
        runId: latest.runId,
        checked: capturedProgressRows.length,
        ok: capturedProgressRows.filter((entry) => entry.row.status === "ok").length,
        failed: capturedProgressRows.filter((entry) => entry.row.status !== "ok").length,
        skipped: 0,
        safetyStopped: 0,
        nextOffset: latest.globalIndex,
        updatedAt: "2026-06-02T10:00:00.000Z",
      };
    },
    async getLatestDvgOperatorRunState() {
      return savedOperatorRunState;
    },
    async saveDvgOperatorRunState(state) {
      savedOperatorRunState = state;
      persistedOperatorRunStates.push(state);
    },
    async updateCatalogProductDvgPricing(rows, _observedAt, settings) {
      capturedPricingRows.push([...rows]);
      return settings.dryRun === false && settings.allowSnapshotWrite === true
        ? rows.filter((row) => row.status === "ok").length
        : 0;
    },
  },
  pricingSettingsRepository: {
    async getLatestExchangeRate() {
      return {
        id: "44444444-4444-4444-8444-444444444444",
        source: "manual_operator",
        eurHufRate: "405.2500",
        effectiveAt: new Date("2026-06-02T09:00:00.000Z"),
        createdBy: "local_operator",
        notes: null,
        createdAt: new Date("2026-06-02T09:00:00.000Z"),
      };
    },
    async createExchangeRate() {
      throw new Error("not used");
    },
  },
  runnerFactory(callbacks: DvgManualBatchCallbacks) {
    return {
      async openBrowser() {
        openBrowserCalled = true;
        callbacks.onStatus?.("opening_browser");
        callbacks.onEvent?.({ type: "browserOpened", message: "Browser opened" });
        callbacks.onStatus?.("waiting_for_manual_login");
      },
      async waitForManualLogin() {
        callbacks.onStatus?.("login_detected");
        callbacks.onEvent?.({ type: "loginDetected", message: "Login detected" });
        if (runnerMode === "detach_failed") {
          callbacks.onStatus?.("detached_session_failed");
          callbacks.onEvent?.({
            type: "runStopped",
            message: "DVG HTTP session detach failed: DvgSessionNeedsLoginError",
          });
          return false;
        }
        return true;
      },
      async runCandidates(candidates, settings) {
        callbacks.onStatus?.("running");
        callbacks.onCurrentItem?.({
          index: 1,
          total: candidates.length,
          wooSku: candidates[0]?.wooSku ?? "",
          wooName: candidates[0]?.wooName ?? "",
          supplierArticleNumber: candidates[0]?.supplierArticleNumber ?? "",
          detailPath: "/e-commerce/welcome/ordini/dettagli.asp",
          status: "price_parsed",
          parsed: { currentPrice: 4.95, crossedPrice: null, currency: "EUR", unit: "pc" },
          calculation: {
            supplierNetHuf: 1980,
            targetGrossHuf: 3268.98,
            actualProfitNetHuf: 5894.02,
            actualProfitPercentOnCost: 297.68,
          },
        });
        callbacks.onEvent?.({
          type: "detailFetchStarted",
          message: `Lean detail fetch: ${candidate.supplierArticleNumber}`,
          article: candidate.supplierArticleNumber,
        });
        callbacks.onEvent?.({
          type: "detailFetchDone",
          message: "Lean fetch done: HTTP 200",
          article: candidate.supplierArticleNumber,
          path: "/e-commerce/welcome/ordini/dettagli.asp",
          httpStatus: 200,
        });
        if (runnerMode === "session_lost") {
          callbacks.onRow?.(
            buildRouteTestRow(settings, "redirected_to_login", [
              "dvg_login_required_after_recovery",
            ])
          );
          callbacks.onStatus?.("session_lost");
          callbacks.onEvent?.({ type: "runStopped", message: "DVG session lost before resume" });
          return;
        }
        if (runnerMode === "row_update") {
          callbacks.onRow?.(buildRouteTestRow(settings, "failed", ["lean_fetch_failed"]));
          callbacks.onRowUpdate?.(1, buildRouteTestRow(settings, "ok"));
          callbacks.onStatus?.("completed");
          callbacks.onEvent?.({ type: "runCompleted", message: "Run completed" });
          return;
        }
        callbacks.onRow?.(buildRouteTestRow(settings, "ok"));
        callbacks.onStatus?.("completed");
        callbacks.onEvent?.({ type: "runCompleted", message: "Run completed" });
      },
      async cancel() {
        cancelCalled = true;
      },
      async close() {},
    };
  },
});

try {
  const missingHeader = await server.inject({
    method: "GET",
    url: "/dvg-products/manual-batch/current",
  });
  assert.equal(missingHeader.statusCode, 403);
  assert.equal(missingHeader.json().error.code, "dvg_manual_batch_header_missing");

  const noCurrent = await server.inject({
    method: "GET",
    url: "/dvg-products/manual-batch/current",
    headers: localLabHeaders,
  });
  assert.equal(noCurrent.statusCode, 200);
  assert.equal(noCurrent.json().run, null);

  const noProgress = await server.inject({
    method: "GET",
    url: "/dvg-products/manual-batch/progress",
    headers: localLabHeaders,
  });
  assert.equal(noProgress.statusCode, 200);
  assert.equal(noProgress.json().progress, null);

  const savedState = await server.inject({
    method: "GET",
    url: "/dvg-products/manual-batch/saved-state",
    headers: localLabHeaders,
  });
  assert.equal(savedState.statusCode, 200);
  assert.equal(savedState.json().run, null);
  assert.equal(savedState.json().preferences.autoResume, true);

  const savedPreferences = await server.inject({
    method: "PUT",
    url: "/dvg-products/manual-batch/preferences",
    headers: localLabHeaders,
    payload: { autoResume: true, vatPercent: 27, targetProfitMultiplier: 1.5 },
  });
  assert.equal(savedPreferences.statusCode, 200);
  assert.equal(savedPreferences.json().preferences.targetProfitMultiplier, 1.5);

  const started = await server.inject({
    method: "POST",
    url: "/dvg-products/manual-batch/start",
    headers: localLabHeaders,
    payload: { markupPercent: 30, vatPercent: 27, limit: 3 },
  });
  assert.equal(started.statusCode, 201);
  assert.equal(openBrowserCalled, true);
  assert.equal(capturedSettings.at(-1)?.eurHufRate, 405.25);
  assert.equal(capturedSettings.at(-1)?.speedMode, "normal");
  assert.equal(capturedSettings.at(-1)?.dryRun, true);
  assert.equal(capturedSettings.at(-1)?.allowSnapshotWrite, false);
  assert.equal(capturedSettings.at(-1)?.onlyMappedDvg, true);
  assert.equal(capturedSettings.at(-1)?.rerunPreviousNonOkOnly, false);
  assert.equal(capturedSettings.at(-1)?.itemTimeoutMs, 8_000);
  assert.equal(capturedSettings.at(-1)?.detailFetchTimeoutMs, 5_000);
  assert.equal(capturedSettings.at(-1)?.fallbackNavigationTimeoutMs, 5_000);
  assert.equal(capturedSettings.at(-1)?.recoverAfterConsecutiveTimeouts, 0);
  assert.equal(started.json().status, "waiting_for_manual_login");
  assert.equal(started.json().totals.candidates, 1);
  assert.equal(started.json().resume.action, "continue_after_login");
  assert.equal(started.json().export.available, false);
  const runId = started.json().runId as string;

  const current = await server.inject({
    method: "GET",
    url: "/dvg-products/manual-batch/current",
    headers: localLabHeaders,
  });
  assert.equal(current.statusCode, 200);
  assert.equal(current.json().run.runId, runId);
  assert.equal(current.json().run.status, "waiting_for_manual_login");

  const continued = await server.inject({
    method: "POST",
    url: `/dvg-products/manual-batch/${runId}/continue-after-login`,
    headers: localLabHeaders,
  });
  assert.equal(continued.statusCode, 202);

  await new Promise((resolve) => setTimeout(resolve, 0));

  const status = await server.inject({
    method: "GET",
    url: `/dvg-products/manual-batch/${runId}`,
    headers: localLabHeaders,
  });
  assert.equal(status.statusCode, 200);
  assert.equal(status.json().status, "completed");
  assert.equal(status.json().totals.checked, 1);
  assert.equal(status.json().totals.ok, 1);
  assert.equal(status.json().summary.checkedPercent, 100);
  assert.equal(status.json().summary.okPercent, 100);
  assert.equal(status.json().summary.totalProfitNetHuf, 5894.0157480314965);
  assert.equal(status.json().telemetry.statusChangedAt, "2026-06-02T10:00:00.000Z");
  assert.equal(status.json().telemetry.detailFetchCompleted, 1);
  assert.equal(status.json().telemetry.httpStatus2xx, 1);
  assert.equal(status.json().telemetry.httpStatus4xx, 0);
  assert.equal(status.json().rows[0].supplierNetEur, 4.95);
  assert.equal(status.json().resume.action, "start_new");
  assert.equal(status.json().resume.nextOffset, 1);
  assert.equal(status.json().export.available, true);
  assert.equal(status.json().export.containsSecrets, false);
  assert.equal(status.json().export.suggestedFilename, `dvg-${runId}-sanitized-results.json`);
  assert.equal(capturedProgressRows.at(-1)?.row.catalogProductId, candidate.catalogProductId);
  assert.equal(capturedProgressRows.at(-1)?.runId, runId);
  assert.equal(capturedProgressRows.at(-1)?.globalIndex, 1);
  assert.equal(capturedPricingRows.length, 0);
  assert.equal(
    status
      .json()
      .events.some(
        (event: { message?: string }) =>
          event.message === "Catalog DVG pricing saved: CS-A2200247_SAE125"
      ),
    false
  );
  const progress = await server.inject({
    method: "GET",
    url: "/dvg-products/manual-batch/progress",
    headers: localLabHeaders,
  });
  assert.equal(progress.statusCode, 200);
  assert.equal(progress.json().progress.runId, runId);
  assert.equal(progress.json().progress.nextOffset, 1);
  assert.equal(progress.json().progress.resume.action, "retry_from_next_offset");
  assert.equal(progress.json().progress.export.rowCount, 1);
  assert.equal(JSON.stringify(status.json()).includes("password"), false);
  assert.equal(JSON.stringify(status.json()).includes("storageState"), false);

  const cancel = await server.inject({
    method: "POST",
    url: `/dvg-products/manual-batch/${runId}/cancel`,
    headers: localLabHeaders,
  });
  assert.equal(cancel.statusCode, 200);
  assert.equal(cancel.json().status, "cancelled");
  assert.equal(cancelCalled, true);

  const highLimit = await server.inject({
    method: "POST",
    url: "/dvg-products/manual-batch/start",
    headers: localLabHeaders,
    payload: {
      eurHufRate: 405.25,
      speedMode: "fast",
      limit: 2046,
      offset: 7,
      onlyMappedDvg: true,
      rerunPreviousNonOkOnly: true,
    },
  });
  assert.equal(highLimit.statusCode, 201);
  assert.equal(capturedSettings.at(-1)?.speedMode, "fast");
  assert.equal(capturedSettings.at(-1)?.itemTimeoutMs, 6_000);
  assert.equal(capturedSettings.at(-1)?.detailFetchTimeoutMs, 4_000);
  assert.equal(capturedSettings.at(-1)?.fallbackNavigationTimeoutMs, 5_000);
  assert.equal(capturedSettings.at(-1)?.limit, 2046);
  assert.equal(capturedSettings.at(-1)?.offset, 7);
  assert.equal(capturedSettings.at(-1)?.onlyMappedDvg, true);
  assert.equal(capturedSettings.at(-1)?.rerunPreviousNonOkOnly, true);
  await server.inject({
    method: "POST",
    url: `/dvg-products/manual-batch/${highLimit.json().runId}/cancel`,
    headers: localLabHeaders,
  });

  const invalidRerunSources = await server.inject({
    method: "POST",
    url: "/dvg-products/manual-batch/start",
    headers: localLabHeaders,
    payload: {
      eurHufRate: 405.25,
      onlyMappedDvg: false,
      rerunPreviousNonOkOnly: true,
      allowSuggestedDvgArticle: true,
    },
  });
  assert.equal(invalidRerunSources.statusCode, 400);
  assert.equal(invalidRerunSources.json().error.code, "dvg_manual_batch_invalid_settings");

  runnerMode = "row_update";
  const rowUpdateProgressStart = capturedProgressRows.length;
  const rowUpdateStart = await server.inject({
    method: "POST",
    url: "/dvg-products/manual-batch/start",
    headers: localLabHeaders,
    payload: { eurHufRate: 405.25, limit: 1 },
  });
  assert.equal(rowUpdateStart.statusCode, 201);
  const rowUpdateRunId = rowUpdateStart.json().runId as string;
  const rowUpdateContinue = await server.inject({
    method: "POST",
    url: `/dvg-products/manual-batch/${rowUpdateRunId}/continue-after-login`,
    headers: localLabHeaders,
  });
  assert.equal(rowUpdateContinue.statusCode, 202);
  await new Promise((resolve) => setTimeout(resolve, 0));
  const rowUpdateStatus = await server.inject({
    method: "GET",
    url: `/dvg-products/manual-batch/${rowUpdateRunId}`,
    headers: localLabHeaders,
  });
  assert.equal(rowUpdateStatus.json().status, "completed");
  assert.equal(rowUpdateStatus.json().rows.length, 1);
  assert.equal(rowUpdateStatus.json().rows[0].status, "ok");
  assert.equal(rowUpdateStatus.json().totals.ok, 1);
  assert.equal(rowUpdateStatus.json().totals.failed, 0);
  const rowUpdateProgressRows = capturedProgressRows.slice(rowUpdateProgressStart);
  assert.deepEqual(
    rowUpdateProgressRows.map((entry) => entry.row.status),
    ["failed", "ok"]
  );
  assert.deepEqual(
    rowUpdateProgressRows.map((entry) => entry.globalIndex),
    [1, 1]
  );
  runnerMode = "success";

  runnerMode = "detach_failed";
  const detachStart = await server.inject({
    method: "POST",
    url: "/dvg-products/manual-batch/start",
    headers: localLabHeaders,
    payload: { eurHufRate: 405.25, limit: 1 },
  });
  assert.equal(detachStart.statusCode, 201);
  const detachRunId = detachStart.json().runId as string;
  const detachContinue = await server.inject({
    method: "POST",
    url: `/dvg-products/manual-batch/${detachRunId}/continue-after-login`,
    headers: localLabHeaders,
  });
  assert.equal(detachContinue.statusCode, 202);
  await new Promise((resolve) => setTimeout(resolve, 0));
  const detachStatus = await server.inject({
    method: "GET",
    url: `/dvg-products/manual-batch/${detachRunId}`,
    headers: localLabHeaders,
  });
  assert.equal(detachStatus.json().status, "detached_session_failed");

  runnerMode = "session_lost";
  const sessionLostStart = await server.inject({
    method: "POST",
    url: "/dvg-products/manual-batch/start",
    headers: localLabHeaders,
    payload: { eurHufRate: 405.25, limit: 1 },
  });
  assert.equal(sessionLostStart.statusCode, 201);
  const sessionLostRunId = sessionLostStart.json().runId as string;
  const sessionLostContinue = await server.inject({
    method: "POST",
    url: `/dvg-products/manual-batch/${sessionLostRunId}/continue-after-login`,
    headers: localLabHeaders,
  });
  assert.equal(sessionLostContinue.statusCode, 202);
  await new Promise((resolve) => setTimeout(resolve, 0));
  const sessionLostStatus = await server.inject({
    method: "GET",
    url: `/dvg-products/manual-batch/${sessionLostRunId}`,
    headers: localLabHeaders,
  });
  assert.equal(sessionLostStatus.json().status, "session_lost");
  assert.equal(sessionLostStatus.json().resume.action, "login_again");
  assert.equal(sessionLostStatus.json().rows[0].status, "redirected_to_login");
  assert.equal(sessionLostStatus.json().summary.redirectedToLogin, 1);
  assert.equal(sessionLostStatus.json().summary.failedPercent, 100);

  const savedRunningState = sessionLostStatus.json() as DvgManualBatchState;
  savedOperatorRunState = {
    ...savedRunningState,
    runId: "dvg-manual-running-before-restart",
    status: "running",
    completedAt: null,
  };
  const interruptedSavedState = await server.inject({
    method: "GET",
    url: "/dvg-products/manual-batch/saved-state",
    headers: localLabHeaders,
  });
  assert.equal(interruptedSavedState.statusCode, 200);
  assert.equal(interruptedSavedState.json().run.status, "interrupted");
  assert.equal(interruptedSavedState.json().run.resume.action, "retry_from_next_offset");
  assert.equal(persistedOperatorRunStates.at(-1)?.status, "interrupted");
  assert.equal(
    interruptedSavedState
      .json()
      .run.events.some(
        (event: { message?: string }) =>
          event.message === "DVG run interrupted after API/runtime restart"
      ),
    true
  );
  savedOperatorRunState = null;
  runnerMode = "success";

  const writeStart = await server.inject({
    method: "POST",
    url: "/dvg-products/manual-batch/start",
    headers: localLabHeaders,
    payload: { eurHufRate: 405.25, limit: 1, dryRun: false, allowSnapshotWrite: true },
  });
  assert.equal(writeStart.statusCode, 201);
  assert.equal(capturedSettings.at(-1)?.dryRun, false);
  assert.equal(capturedSettings.at(-1)?.allowSnapshotWrite, true);
  const writeRunId = writeStart.json().runId as string;
  await server.inject({
    method: "POST",
    url: `/dvg-products/manual-batch/${writeRunId}/continue-after-login`,
    headers: localLabHeaders,
  });
  await new Promise((resolve) => setTimeout(resolve, 0));
  const writeStatus = await server.inject({
    method: "GET",
    url: `/dvg-products/manual-batch/${writeRunId}`,
    headers: localLabHeaders,
  });
  assert.equal(writeStatus.json().status, "completed");
  assert.equal(
    writeStatus
      .json()
      .events.some(
        (event: { message?: string }) =>
          event.message === "Catalog DVG pricing saved: CS-A2200247_SAE125"
      ),
    true
  );

  const sensitive = await server.inject({
    method: "POST",
    url: "/dvg-products/manual-batch/start",
    headers: localLabHeaders,
    payload: { password: "do-not-return" },
  });
  assert.equal(sensitive.statusCode, 400);
  assert.equal(sensitive.json().error.code, "sensitive_field");
  assert.equal(JSON.stringify(sensitive.json()).includes("do-not-return"), false);
} finally {
  await server.close();
}

console.log("DVG products manual batch route tests passed");
