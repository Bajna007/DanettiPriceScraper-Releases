import assert from "node:assert/strict";
import type { DanettiDbClient } from "@danetti/db";
import Fastify from "fastify";
import { registerLocalDatabaseRoutes } from "./local-database.routes.js";

const localLabHeaders = { "x-danetti-local-lab": "true" };

const exportedAt = "2026-06-18T07:00:00.000Z";
const sampleBackup = {
  format: "danetti-local-database-backup",
  formatVersion: 1,
  exportedAt,
  schema: "public",
  source: {
    app: "DanettiPriceScraper",
    purpose: "full_local_database_transfer",
  },
  tables: [
    {
      name: "catalog_products",
      columns: ["id", "sku", "name"],
      rowCount: 1,
      rows: [{ id: "00000000-0000-4000-8000-000000000001", sku: "SKU-1", name: "Termék" }],
    },
  ],
  totals: { tableCount: 1, rowCount: 1 },
};

const imported = {
  importedAt: "2026-06-18T07:01:00.000Z",
  tableCount: 1,
  rowCount: 1,
  skippedTables: [],
};

let importInput: unknown = null;
const server = Fastify({ logger: false });
await server.register(registerLocalDatabaseRoutes, {
  service: {
    exportBackup: async () => sampleBackup,
    importBackup: async (backup: unknown) => {
      importInput = backup;
      return imported;
    },
  },
});

try {
  const blockedExport = await server.inject({ method: "GET", url: "/local-database/export" });
  assert.equal(blockedExport.statusCode, 403);
  assert.equal(blockedExport.json().error.code, "local_database_header_missing");

  const exportResponse = await server.inject({
    method: "GET",
    url: "/local-database/export",
    headers: localLabHeaders,
  });
  assert.equal(exportResponse.statusCode, 200);
  assert.equal(exportResponse.headers["content-type"], "application/json; charset=utf-8");
  assert.match(
    String(exportResponse.headers["content-disposition"]),
    /danetti-local-db-2026-06-18T07-00-00-000Z\.json/
  );
  assert.equal(exportResponse.json().format, "danetti-local-database-backup");
  assert.equal(exportResponse.json().totals.rowCount, 1);

  const blockedImport = await server.inject({
    method: "POST",
    url: "/local-database/import",
    payload: sampleBackup,
  });
  assert.equal(blockedImport.statusCode, 403);

  const importResponse = await server.inject({
    method: "POST",
    url: "/local-database/import",
    headers: localLabHeaders,
    payload: sampleBackup,
  });
  assert.equal(importResponse.statusCode, 200);
  assert.deepEqual(importResponse.json(), { result: imported });
  assert.deepEqual(importInput, sampleBackup);
} finally {
  await server.close();
}

const restoreCalls: Array<{ query: string; parameters?: unknown[] }> = [];
const fakeTx = {
  unsafe: async (query: string, parameters?: unknown[]) => {
    restoreCalls.push({ query, parameters });
    return [];
  },
};
const fakeSql = {
  unsafe: async (query: string, parameters?: unknown[]) => {
    if (query.includes("information_schema.columns")) {
      return [
        { table_name: "suppliers", column_name: "id", data_type: "uuid", udt_name: "uuid" },
        { table_name: "suppliers", column_name: "code", data_type: "text", udt_name: "text" },
        { table_name: "suppliers", column_name: "name", data_type: "text", udt_name: "text" },
        {
          table_name: "suppliers",
          column_name: "allowed_domains",
          data_type: "jsonb",
          udt_name: "jsonb",
        },
        {
          table_name: "suppliers",
          column_name: "supported_lookup_strategies",
          data_type: "jsonb",
          udt_name: "jsonb",
        },
      ];
    }
    restoreCalls.push({ query, parameters });
    return [];
  },
  begin: async (callback: (tx: typeof fakeTx) => Promise<void>) => callback(fakeTx),
};
const fakeDbClient = {
  db: {},
  sql: fakeSql,
  close: async () => {},
} as unknown as DanettiDbClient;

const dbServer = Fastify({ logger: false });
await dbServer.register(registerLocalDatabaseRoutes, { dbClient: fakeDbClient });

try {
  const jsonbImportResponse = await dbServer.inject({
    method: "POST",
    url: "/local-database/import",
    headers: localLabHeaders,
    payload: {
      format: "danetti-local-database-backup",
      formatVersion: 1,
      exportedAt,
      schema: "public",
      source: {
        app: "DanettiPriceScraper",
        purpose: "full_local_database_transfer",
      },
      tables: [
        {
          name: "suppliers",
          columns: ["id", "code", "name", "allowed_domains", "supported_lookup_strategies"],
          rowCount: 1,
          rows: [
            {
              id: "00000000-0000-4000-8000-000000000002",
              code: "test",
              name: "Test Supplier",
              allowed_domains: ["example.com"],
              supported_lookup_strategies: ["direct_url"],
            },
          ],
        },
      ],
      totals: { tableCount: 1, rowCount: 1 },
    },
  });

  assert.equal(jsonbImportResponse.statusCode, 200);
  const insertCall = restoreCalls.find((call) => call.query.includes("INSERT INTO"));
  assert.ok(insertCall, "expected JSONB insert call");
  assert.match(insertCall.query, /\$4::jsonb/);
  assert.match(insertCall.query, /\$5::jsonb/);
  assert.deepEqual(insertCall.parameters, [
    "00000000-0000-4000-8000-000000000002",
    "test",
    "Test Supplier",
    JSON.stringify(["example.com"]),
    JSON.stringify(["direct_url"]),
  ]);
} finally {
  await dbServer.close();
}

const binary = Buffer.from([0, 1, 2, 253, 254, 255]);
const binaryRestoreCalls: Array<{ query: string; parameters?: unknown[] }> = [];
const binaryTx = {
  unsafe: async (query: string, parameters?: unknown[]) => {
    binaryRestoreCalls.push({ query, parameters });
    return [];
  },
};
const binarySql = {
  unsafe: async (query: string) => {
    if (query.includes("information_schema.columns")) {
      return [
        { table_name: "label_assets", column_name: "id", data_type: "uuid", udt_name: "uuid" },
        {
          table_name: "label_assets",
          column_name: "filename",
          data_type: "text",
          udt_name: "text",
        },
        { table_name: "label_assets", column_name: "bytes", data_type: "bytea", udt_name: "bytea" },
      ];
    }
    if (query.includes("SELECT *") && query.includes('"label_assets"')) {
      return [{ id: "00000000-0000-4000-8000-000000000003", filename: "font.ttf", bytes: binary }];
    }
    return [];
  },
  begin: async (callback: (tx: typeof binaryTx) => Promise<void>) => callback(binaryTx),
};
const binaryDbClient = {
  db: {},
  sql: binarySql,
  close: async () => {},
} as unknown as DanettiDbClient;
const binaryServer = Fastify({ logger: false });
await binaryServer.register(registerLocalDatabaseRoutes, {
  dbClient: binaryDbClient,
  now: () => new Date("2026-08-12T08:00:00.000Z"),
});

try {
  const exportResponse = await binaryServer.inject({
    method: "GET",
    url: "/local-database/export",
    headers: localLabHeaders,
  });
  assert.equal(exportResponse.statusCode, 200);
  const backup = exportResponse.json();
  assert.equal(backup.formatVersion, 2);
  assert.equal(backup.integrity.algorithm, "sha256");
  assert.equal(backup.integrity.sha256.length, 64);
  assert.deepEqual(backup.tables[0].rows[0].bytes, {
    $danettiBinary: "base64",
    sha256: "3f2d1552cdc7483f40dd720c80b900225dfecfd5cae7cd168d79ab6ee5959885",
    data: binary.toString("base64"),
  });

  const importResponse = await binaryServer.inject({
    method: "POST",
    url: "/local-database/import",
    headers: localLabHeaders,
    payload: backup,
  });
  assert.equal(importResponse.statusCode, 200);
  const binaryInsert = binaryRestoreCalls.find((call) => call.query.includes("INSERT INTO"));
  assert.ok(binaryInsert);
  assert.ok(Buffer.isBuffer(binaryInsert.parameters?.[2]));
  assert.deepEqual(binaryInsert.parameters?.[2], binary);

  const tampered = structuredClone(backup);
  tampered.tables[0].rows[0].filename = "tampered.ttf";
  const rejected = await binaryServer.inject({
    method: "POST",
    url: "/local-database/import",
    headers: localLabHeaders,
    payload: tampered,
  });
  assert.equal(rejected.statusCode, 400);
  assert.equal(rejected.json().error.code, "local_database_integrity_failed");
} finally {
  await binaryServer.close();
}

console.log("Local database backup route tests passed");
