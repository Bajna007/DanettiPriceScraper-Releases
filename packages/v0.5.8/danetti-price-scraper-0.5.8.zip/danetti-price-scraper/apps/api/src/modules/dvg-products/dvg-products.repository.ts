import {
  isDvgArticleCandidate,
  isDvgPrefixedArticleCandidate,
  type DvgManualBatchCandidate,
  type DvgManualBatchRow,
  type DvgManualBatchSettings,
  type DvgManualBatchState,
} from "@danetti/connectors";
import {
  catalogProducts,
  dvgOperatorRuns,
  dvgOperatorSettings,
  supplierMappings,
  supplierPriceSnapshots,
  suppliers,
  type CatalogProduct,
  type DanettiDatabase,
  type NewCatalogProduct,
  type NewSupplierPriceSnapshot,
  parseWooSku,
  readWooSkuArticleCandidates,
} from "@danetti/db";
import { and, desc, eq, isNotNull, ne } from "drizzle-orm";
import { getOrCreateDvgSupplier } from "../suppliers/dvg-supplier.js";

export interface DvgProductsCandidateRepository {
  listCandidates(settings: DvgManualBatchSettings): Promise<DvgManualBatchCandidate[]>;
  saveCatalogProductDvgRunRow?(
    row: DvgManualBatchRow,
    input: DvgCatalogRunRowPersistenceInput
  ): Promise<DvgCatalogRunRowPersistenceResult>;
  getLatestDvgRunProgress?(): Promise<DvgCatalogRunProgress | null>;
  saveDvgOperatorRunState?(state: DvgManualBatchState, observedAt: Date): Promise<void>;
  getLatestDvgOperatorRunState?(): Promise<DvgManualBatchState | null>;
  saveDvgOperatorPreferences?(preferences: DvgOperatorPreferences, observedAt: Date): Promise<void>;
  getDvgOperatorPreferences?(): Promise<DvgOperatorPreferences | null>;
  updateCatalogProductDvgPricing?(
    rows: readonly DvgManualBatchRow[],
    observedAt: Date,
    settings: DvgPricingWriteControls
  ): Promise<number>;
}

export type DvgPricingWriteControls = Pick<DvgManualBatchSettings, "dryRun" | "allowSnapshotWrite">;

export interface DvgOperatorPreferences {
  autoResume: boolean;
  vatPercent: number;
  targetProfitMultiplier: number | null;
  minimumProfitPercent: number | null;
}

export interface DvgCatalogRunRowPersistenceInput {
  runId: string;
  globalIndex: number;
  observedAt: Date;
  settings: DvgPricingWriteControls;
}

export interface DvgCatalogRunRowPersistenceResult {
  progressSaved: boolean;
  pricingSaved: boolean;
}

export interface DvgCatalogRunProgress {
  runId: string;
  checked: number;
  ok: number;
  failed: number;
  skipped: number;
  safetyStopped: number;
  nextOffset: number;
  updatedAt: string;
}

export type PersistableDvgPricingRow = DvgManualBatchRow & {
  supplierNetEur: number;
  supplierNetHuf: number;
  wooGrossHuf: number;
  wooNetHuf: number;
  actualProfitNetHuf: number;
  actualProfitPercentOnCost: number;
};

export class DvgProductsRepository implements DvgProductsCandidateRepository {
  constructor(private readonly db: DanettiDatabase) {}

  async listCandidates(settings: DvgManualBatchSettings): Promise<DvgManualBatchCandidate[]> {
    const supplier = await this.getDvgSupplier();
    if (supplier === null) return [];

    const candidates: DvgManualBatchCandidate[] = [];
    const seen = new Set<string>();
    const mappedProducts = new Set<string>();
    const targetCount = settings.offset + settings.limit;

    const addCandidate = (candidate: DvgManualBatchCandidate) => {
      if (!isDvgArticleCandidate(candidate.supplierArticleNumber)) return;
      const key = `${candidate.catalogProductId}:${candidate.supplierArticleNumber}`;
      if (seen.has(key)) return;
      seen.add(key);
      candidates.push(candidate);
    };

    const mappedRowsWhere = settings.rerunPreviousNonOkOnly
      ? and(
          eq(suppliers.id, supplier.id),
          eq(suppliers.enabled, true),
          eq(supplierMappings.enabled, true),
          isNotNull(catalogProducts.dvgLastRunStatus),
          ne(catalogProducts.dvgLastRunStatus, "ok")
        )
      : and(
          eq(suppliers.id, supplier.id),
          eq(suppliers.enabled, true),
          eq(supplierMappings.enabled, true)
        );

    const mappedRows = await this.db
      .select({
        catalogProductId: catalogProducts.id,
        wooSku: catalogProducts.sku,
        wooName: catalogProducts.name,
        currentPrice: catalogProducts.currentPrice,
        regularPrice: catalogProducts.regularPrice,
        salePrice: catalogProducts.salePrice,
        supplierId: suppliers.id,
        supplierMappingId: supplierMappings.id,
        supplierArticleNumber: supplierMappings.supplierArticleNumber,
      })
      .from(supplierMappings)
      .innerJoin(catalogProducts, eq(supplierMappings.catalogProductId, catalogProducts.id))
      .innerJoin(suppliers, eq(supplierMappings.supplierId, suppliers.id))
      .where(mappedRowsWhere)
      .orderBy(desc(supplierMappings.isPrimary), desc(supplierMappings.updatedAt))
      .limit(targetCount);

    for (const row of mappedRows) {
      mappedProducts.add(row.catalogProductId);
      addCandidate({
        ...row,
        candidateSource: "saved_mapping",
        matchConfidence: "saved_mapping",
      });
    }

    if (!settings.onlyMappedDvg && candidates.length < targetCount) {
      const patternRows = await this.db
        .select()
        .from(catalogProducts)
        .orderBy(desc(catalogProducts.createdAt))
        .limit(Math.max(targetCount * 20, 100));

      for (const product of patternRows) {
        if (candidates.length >= targetCount) break;
        if (mappedProducts.has(product.id)) continue;
        const article = readDvgPatternArticle(product);
        if (!article) continue;
        addCandidate(productToCandidate(product, supplier.id, article, "dvg_article_pattern"));
      }
    }

    if (
      settings.rerunPreviousNonOkOnly ||
      settings.onlyMappedDvg ||
      candidates.length >= targetCount
    ) {
      return candidates.slice(settings.offset, targetCount);
    }

    if (settings.allowSuggestedDvgArticle) {
      const suggestedRows = await this.db
        .select()
        .from(catalogProducts)
        .where(isNotNull(catalogProducts.suggestedSupplierArticle))
        .orderBy(desc(catalogProducts.createdAt))
        .limit(Math.max(targetCount * 5, 25));

      for (const product of suggestedRows) {
        if (candidates.length >= targetCount) break;
        if (mappedProducts.has(product.id)) continue;
        const article = product.suggestedSupplierArticle?.trim();
        if (!article) continue;
        addCandidate(
          productToCandidate(product, supplier.id, article, "suggested_supplier_article")
        );
      }
    }

    if (settings.allowSkuPrefixCandidate && candidates.length < targetCount) {
      const productRows = await this.db
        .select()
        .from(catalogProducts)
        .orderBy(desc(catalogProducts.createdAt))
        .limit(Math.max(targetCount * 20, 100));

      for (const product of productRows) {
        if (candidates.length >= targetCount) break;
        if (mappedProducts.has(product.id)) continue;
        const article = product.sku.includes("__")
          ? readDvgPatternArticle(product)
          : parseWooSku(product.sku).supplierArticleCandidate;
        if (!article) continue;
        addCandidate(productToCandidate(product, supplier.id, article, "sku_prefix_candidate"));
      }
    }

    return candidates.slice(settings.offset, targetCount);
  }

  async updateCatalogProductDvgPricing(
    rows: readonly DvgManualBatchRow[],
    observedAt: Date,
    settings: DvgPricingWriteControls
  ): Promise<number> {
    if (!canWriteDvgTrustedPricing(settings)) return 0;

    let updatedCount = 0;
    for (const row of rows) {
      if (!canPersistDvgTrustedPricingRow(row, settings)) continue;

      await this.db
        .update(catalogProducts)
        .set({
          dvgPurchasePriceEur: decimalString(row.supplierNetEur, 4),
          dvgPurchasePriceHuf: decimalString(row.supplierNetHuf, 2),
          dvgWooGrossHuf: decimalString(row.wooGrossHuf, 2),
          dvgWooNetHuf: decimalString(row.wooNetHuf, 2),
          dvgProfitNetHuf: decimalString(row.actualProfitNetHuf, 2),
          dvgProfitPercent: decimalString(row.actualProfitPercentOnCost, 2),
          dvgSupplierArticleNumber: row.supplierArticleNumber,
          dvgPricingUpdatedAt: observedAt,
          updatedAt: observedAt,
        })
        .where(eq(catalogProducts.id, row.catalogProductId));
      await this.insertDvgSupplierPriceSnapshot(row, observedAt);
      updatedCount += 1;
    }

    return updatedCount;
  }

  async saveCatalogProductDvgRunRow(
    row: DvgManualBatchRow,
    input: DvgCatalogRunRowPersistenceInput
  ): Promise<DvgCatalogRunRowPersistenceResult> {
    const values: Partial<NewCatalogProduct> = {
      dvgLastRunId: input.runId,
      dvgLastRunIndex: input.globalIndex,
      dvgLastRunStatus: row.status,
      dvgLastRunMessage: buildDvgRunMessage(row),
      dvgLastRunUpdatedAt: input.observedAt,
      updatedAt: input.observedAt,
    };
    const pricingSaved = canPersistDvgTrustedPricingRow(row, input.settings);
    if (pricingSaved) {
      Object.assign(values, {
        dvgPurchasePriceEur: decimalString(row.supplierNetEur, 4),
        dvgPurchasePriceHuf: decimalString(row.supplierNetHuf, 2),
        dvgWooGrossHuf: decimalString(row.wooGrossHuf, 2),
        dvgWooNetHuf: decimalString(row.wooNetHuf, 2),
        dvgProfitNetHuf: decimalString(row.actualProfitNetHuf, 2),
        dvgProfitPercent: decimalString(row.actualProfitPercentOnCost, 2),
        dvgSupplierArticleNumber: row.supplierArticleNumber,
        dvgPricingUpdatedAt: input.observedAt,
      });
    }

    await this.db
      .update(catalogProducts)
      .set(values)
      .where(eq(catalogProducts.id, row.catalogProductId));

    if (pricingSaved) {
      await this.insertDvgSupplierPriceSnapshot(row as PersistableDvgPricingRow, input.observedAt);
    }

    return { progressSaved: true, pricingSaved };
  }

  private async insertDvgSupplierPriceSnapshot(
    row: PersistableDvgPricingRow,
    observedAt: Date
  ): Promise<void> {
    await this.db
      .insert(supplierPriceSnapshots)
      .values(buildDvgSupplierPriceSnapshot(row, observedAt));
  }

  async getLatestDvgRunProgress(): Promise<DvgCatalogRunProgress | null> {
    const [latest] = await this.db
      .select({ runId: catalogProducts.dvgLastRunId })
      .from(catalogProducts)
      .where(isNotNull(catalogProducts.dvgLastRunUpdatedAt))
      .orderBy(desc(catalogProducts.dvgLastRunUpdatedAt))
      .limit(1);
    if (!latest?.runId) return null;

    const rows = await this.db
      .select({
        index: catalogProducts.dvgLastRunIndex,
        status: catalogProducts.dvgLastRunStatus,
        updatedAt: catalogProducts.dvgLastRunUpdatedAt,
      })
      .from(catalogProducts)
      .where(eq(catalogProducts.dvgLastRunId, latest.runId));

    let checked = 0;
    let ok = 0;
    let skipped = 0;
    let safetyStopped = 0;
    let failed = 0;
    let nextOffset = 0;
    let updatedAt: Date | null = null;
    for (const row of rows) {
      if (typeof row.index !== "number" || !row.status) continue;
      if (isDvgRunProgressAdvancingStatus(row.status)) {
        checked += 1;
        nextOffset = Math.max(nextOffset, row.index);
      }
      if (row.status === "ok") ok += 1;
      else if (row.status.startsWith("skipped_")) skipped += 1;
      else failed += 1;
      if (row.status === "safety_stopped") safetyStopped += 1;
      if (row.updatedAt && (updatedAt === null || row.updatedAt > updatedAt))
        updatedAt = row.updatedAt;
    }

    return {
      runId: latest.runId,
      checked,
      ok,
      failed,
      skipped,
      safetyStopped,
      nextOffset,
      updatedAt: (updatedAt ?? new Date(0)).toISOString(),
    };
  }

  async saveDvgOperatorRunState(state: DvgManualBatchState, observedAt: Date): Promise<void> {
    const nextOffset = readDvgOperatorRunNextOffset(state);
    await this.db
      .insert(dvgOperatorRuns)
      .values({
        runId: state.runId,
        status: state.status,
        startedAt: new Date(state.startedAt),
        completedAt: state.completedAt ? new Date(state.completedAt) : null,
        settings: state.settings as unknown as Record<string, unknown>,
        currentItem: state.currentItem as unknown as Record<string, unknown> | null,
        totals: state.totals as unknown as Record<string, unknown>,
        events: state.events as unknown as Record<string, unknown>[],
        rows: state.rows as unknown as Record<string, unknown>[],
        nextOffset,
        autoResume: true,
        updatedAt: observedAt,
      })
      .onConflictDoUpdate({
        target: dvgOperatorRuns.runId,
        set: {
          status: state.status,
          completedAt: state.completedAt ? new Date(state.completedAt) : null,
          settings: state.settings as unknown as Record<string, unknown>,
          currentItem: state.currentItem as unknown as Record<string, unknown> | null,
          totals: state.totals as unknown as Record<string, unknown>,
          events: state.events as unknown as Record<string, unknown>[],
          rows: state.rows as unknown as Record<string, unknown>[],
          nextOffset,
          updatedAt: observedAt,
        },
      });
  }

  async getLatestDvgOperatorRunState(): Promise<DvgManualBatchState | null> {
    const [run] = await this.db
      .select()
      .from(dvgOperatorRuns)
      .orderBy(desc(dvgOperatorRuns.updatedAt))
      .limit(1);
    if (!run) return null;
    return {
      runId: run.runId,
      status: run.status as DvgManualBatchState["status"],
      startedAt: run.startedAt.toISOString(),
      completedAt: run.completedAt?.toISOString() ?? null,
      settings: run.settings as unknown as DvgManualBatchState["settings"],
      currentItem: run.currentItem as unknown as DvgManualBatchState["currentItem"],
      totals: run.totals as unknown as DvgManualBatchState["totals"],
      events: run.events as unknown as DvgManualBatchState["events"],
      rows: run.rows as unknown as DvgManualBatchState["rows"],
    };
  }

  async saveDvgOperatorPreferences(
    preferences: DvgOperatorPreferences,
    observedAt: Date
  ): Promise<void> {
    await this.db
      .insert(dvgOperatorSettings)
      .values({
        key: "operator-preferences",
        value: preferences as unknown as Record<string, unknown>,
        updatedAt: observedAt,
      })
      .onConflictDoUpdate({
        target: dvgOperatorSettings.key,
        set: {
          value: preferences as unknown as Record<string, unknown>,
          updatedAt: observedAt,
        },
      });
  }

  async getDvgOperatorPreferences(): Promise<DvgOperatorPreferences | null> {
    const [setting] = await this.db
      .select({ value: dvgOperatorSettings.value })
      .from(dvgOperatorSettings)
      .where(eq(dvgOperatorSettings.key, "operator-preferences"))
      .limit(1);
    return setting?.value ? normalizeDvgOperatorPreferences(setting.value) : null;
  }

  private async getDvgSupplier(): Promise<{ id: string } | null> {
    const supplier = await getOrCreateDvgSupplier(this.db);
    if (!supplier.enabled) return null;
    return { id: supplier.id };
  }
}

function normalizeDvgOperatorPreferences(value: Record<string, unknown>): DvgOperatorPreferences {
  return {
    autoResume: value.autoResume !== false,
    vatPercent: readNumberPreference(value.vatPercent, 27),
    targetProfitMultiplier: readNullableNumberPreference(value.targetProfitMultiplier),
    minimumProfitPercent: readNullableNumberPreference(value.minimumProfitPercent),
  };
}

function readNumberPreference(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function readNullableNumberPreference(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

export function buildDvgSupplierPriceSnapshot(
  row: PersistableDvgPricingRow,
  observedAt: Date
): NewSupplierPriceSnapshot {
  return {
    supplierId: row.supplierId,
    supplierMappingId: row.supplierMappingId,
    catalogProductId: row.catalogProductId,
    crawlerRunItemId: null,
    supplierArticleNumber: row.supplierArticleNumber,
    supplierProductName: row.dvgProductName,
    priceNetEur: decimalString(row.supplierNetEur, 2),
    priceGrossEur: null,
    currency: row.currency ?? "EUR",
    stockStatus: "unknown",
    availabilityText: null,
    matchConfidence: "exact",
    resultUrl: row.dvgDetailUrl,
    observedAt,
    evidenceArtifactId: null,
  };
}

export function readDvgOperatorRunNextOffset(state: DvgManualBatchState): number {
  const processedRows = state.rows.filter((row) =>
    isDvgRunProgressAdvancingStatus(row.status)
  ).length;
  return state.settings.offset + processedRows;
}

function isPersistableDvgPricingRow(row: DvgManualBatchRow): row is PersistableDvgPricingRow {
  return (
    row.status === "ok" &&
    row.currency === "EUR" &&
    Number.isFinite(row.supplierNetEur) &&
    Number.isFinite(row.supplierNetHuf) &&
    Number.isFinite(row.wooGrossHuf) &&
    Number.isFinite(row.wooNetHuf) &&
    Number.isFinite(row.actualProfitNetHuf) &&
    Number.isFinite(row.actualProfitPercentOnCost)
  );
}

export function canWriteDvgTrustedPricing(settings: DvgPricingWriteControls): boolean {
  return settings.dryRun === false && settings.allowSnapshotWrite === true;
}

export function canPersistDvgTrustedPricingRow(
  row: DvgManualBatchRow,
  settings: DvgPricingWriteControls
): row is PersistableDvgPricingRow & { supplierMappingId: string } {
  return (
    canWriteDvgTrustedPricing(settings) &&
    isPersistableDvgPricingRow(row) &&
    row.supplierMappingId !== null &&
    row.candidateSource === "saved_mapping" &&
    row.matchConfidence === "exact_dvg_article" &&
    normalizeDvgArticle(row.dvgArticle) === normalizeDvgArticle(row.supplierArticleNumber)
  );
}

function normalizeDvgArticle(value: string | null | undefined): string | null {
  const trimmed = value?.trim();
  return trimmed ? trimmed.toUpperCase() : null;
}

function decimalString(value: number, scale: number): string {
  return value.toFixed(scale).replace(/0+$/, "").replace(/\.$/, "");
}

export function buildDvgRunMessage(row: DvgManualBatchRow): string {
  const message = readDvgRunMessage(row);
  return message.slice(0, 500);
}

function readDvgRunMessage(row: DvgManualBatchRow): string {
  if (row.status === "article_changed") {
    return row.dvgArticle && row.dvgArticle !== row.supplierArticleNumber
      ? `DVG cikkszám megváltozott: új cikkszám ${row.dvgArticle}; mapping ellenőrzés kell.`
      : "DVG cikkszám megváltozott; mapping ellenőrzés kell.";
  }
  if (
    hasDvgWarning(
      row,
      "dvg_supplier_article_changed",
      "original_code_match_requires_mapping_review"
    )
  ) {
    return row.dvgArticle && row.dvgArticle !== row.supplierArticleNumber
      ? `DVG cikkszám megváltozott: új cikkszám ${row.dvgArticle}; mapping ellenőrzés kell.`
      : "DVG cikkszám megváltozott; mapping ellenőrzés kell.";
  }
  if (hasDvgWarning(row, "dvg_supplier_not_in_production")) {
    return "DVG szerint a termék már nem gyártott.";
  }
  if (hasDvgWarning(row, "dvg_supplier_article_cancelled")) {
    return "DVG szerint a cikk törölt/cancelled.";
  }
  if (row.status === "item_not_available")
    return "DVG szerint a cikk nem rendelhető vagy kifutott.";
  if (
    hasDvgWarning(
      row,
      "dvg_article_request_info_page",
      "dvg_detail_request_info_redirect",
      "dvg_article_not_found_or_changed",
      "dvg_supplier_article_not_found",
      "dvg_article_not_found_or_access_denied",
      "dvg_detail_empty_or_request_info_redirect"
    )
  ) {
    return "DVG nem találta a cikkszámot, vagy request-info/üres oldalra irányított.";
  }
  if (
    hasDvgWarning(
      row,
      "dvg_detail_login_required_or_price_hidden",
      "dvg_login_required_after_recovery"
    )
  ) {
    return "DVG session/login elveszett; új bejelentkezés kell.";
  }
  if (row.status === "price_missing" || hasDvgWarning(row, "current_price_missing")) {
    return "DVG termékoldal van, de ár nincs; lehet kifutott vagy nem rendelhető.";
  }
  if (row.status === "ambiguous_match")
    return "DVG találat nem egyértelmű; mapping ellenőrzés kell.";
  if (row.status === "needs_mapping_review") return "DVG mapping ellenőrzés kell.";
  if (row.status === "item_timeout") return "DVG tétel időtúllépés miatt kimaradt.";
  if (row.status === "safety_stopped") return "DVG biztonsági megállítás történt.";
  if (row.status === "redirected_to_login")
    return "DVG session/login elveszett; új bejelentkezés kell.";
  if (row.status.startsWith("skipped_")) return "DVG tétel kihagyva: nincs megbízható cikkszám.";
  if (row.status === "ok") return "DVG ár beolvasva.";
  return row.warnings.length > 0 ? row.warnings.join("; ") : row.matchConfidence;
}

function hasDvgWarning(row: DvgManualBatchRow, ...warnings: string[]): boolean {
  return warnings.some((warning) => row.warnings.includes(warning));
}

function isDvgRunProgressAdvancingStatus(status: string): boolean {
  return status !== "redirected_to_login" && status !== "safety_stopped";
}

function productToCandidate(
  product: CatalogProduct,
  supplierId: string,
  supplierArticleNumber: string,
  candidateSource: "dvg_article_pattern" | "suggested_supplier_article" | "sku_prefix_candidate"
): DvgManualBatchCandidate {
  return {
    catalogProductId: product.id,
    wooSku: product.sku,
    wooName: product.name,
    currentPrice: product.currentPrice,
    regularPrice: product.regularPrice,
    salePrice: product.salePrice,
    supplierId,
    supplierMappingId: null,
    supplierArticleNumber,
    candidateSource,
    matchConfidence: candidateSource,
  };
}

export function readDvgPatternArticle(
  product: Pick<CatalogProduct, "sku" | "suggestedSupplierArticle">
): string | null {
  const suggested = product.suggestedSupplierArticle?.trim();
  if (isDvgPrefixedArticleCandidate(suggested)) return suggested ?? null;
  const candidates = readWooSkuArticleCandidates(product.sku).filter(isDvgPrefixedArticleCandidate);
  if (candidates.length === 1) return candidates[0] ?? null;
  return null;
}
