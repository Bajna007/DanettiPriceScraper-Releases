import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFile, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { eq } from "drizzle-orm";
import { generateKeyPair, SignJWT, jwtVerify } from "jose";
import { schema } from "@danetti/db";
import { loadLocalEnv } from "../../config/env.js";
import { MemorySecretStore } from "../../security/secret-store.js";
import { OpenAiChatGptPlanConnection, requiredScopes } from "./openai.connection.js";
import { EprService } from "./epr.service.js";
import { DocumentArchive } from "./document.archive.js";
import type { Invoice } from "./epr.domain.js";
import { MailboxService } from "./mailbox.service.js";
import type { ImapFlow } from "imapflow";
import { EprScanCoordinator } from "./epr.scan.js";
import { Queue } from "bullmq";
import { Redis } from "ioredis";
import Fastify from "fastify";
import { registerEprRoutes } from "./epr.routes.js";
import { Readable } from "node:stream";

loadLocalEnv();
const namespace = `test_epr_${randomUUID().replaceAll("-", "")}`;
if (!/^test_epr_[a-f0-9]{32}$/.test(namespace)) throw new Error("Unsafe test schema");
const admin = postgres(process.env.DATABASE_URL!, { max: 1, onnotice: () => undefined });
await admin.unsafe(`CREATE SCHEMA "${namespace}"`);
const sql = postgres(process.env.DATABASE_URL!, {
  max: 6,
  connection: { search_path: namespace },
  onnotice: () => undefined,
});
const db = drizzle(sql, { schema }),
  client = { sql, db, close: async () => sql.end() };
const temp = await mkdtemp(join(tmpdir(), "danetti-epr-integration-"));
const secrets = new MemorySecretStore();
let now = Date.now(),
  tokenMode = "success",
  refreshes = 0,
  issuer = "https://auth.openai.com",
  audience = "",
  nonce = "",
  subject = "test-sub",
  scopes = requiredScopes.join(" ");
const { privateKey, publicKey } = await generateKeyPair("RS256");
const request: typeof fetch = async (input, init) => {
  const url = String(input);
  if (url.endsWith("openid-configuration"))
    return Response.json({
      issuer: "https://auth.openai.com",
      authorization_endpoint: "https://auth.openai.com/api/accounts/authorize",
      token_endpoint: "https://auth.openai.com/api/accounts/oauth/token",
      jwks_uri: "https://auth.openai.com/.well-known/jwks.json",
      revocation_endpoint: "https://auth.openai.com/oauth/revoke",
    });
  if (url.endsWith("/token")) {
    const params = init?.body as URLSearchParams;
    if (params.get("grant_type") === "refresh_token") {
      refreshes++;
      if (tokenMode === "terminal")
        return Response.json({ error: "invalid_grant" }, { status: 400 });
      if (tokenMode === "temporary")
        return Response.json({ error: "server_error" }, { status: 503 });
    }
    const idToken = await new SignJWT({ nonce, email: "test@example.invalid" })
      .setProtectedHeader({ alg: "RS256" })
      .setIssuer(issuer)
      .setAudience(audience)
      .setSubject(subject)
      .setIssuedAt()
      .setExpirationTime("1h")
      .sign(privateKey);
    return Response.json({
      access_token: `synthetic-access-${refreshes}`,
      refresh_token: `synthetic-refresh-${refreshes}`,
      id_token: idToken,
      scope: scopes,
      token_type: "Bearer",
      expires_in: 3600,
      earliest_refresh_at: 0,
    });
  }
  if (url.endsWith("/revoke")) return new Response(null, { status: 200 });
  if (url.endsWith("/models"))
    return Response.json({
      models: [{ slug: "account-model", display_name: "Account model", visibility: "list" }],
    });
  if (url.endsWith("/responses")) {
    const body = JSON.parse(String(init?.body));
    assert.equal(body.store, false);
    assert.equal(body.stream, true);
    assert.equal(body.model, "account-model");
    assert.ok(Array.isArray(body.input));
    assert.ok(!("tools" in body));
    return new Response(
      'data: {"type":"response.output_text.delta","delta":"DANETTI_OK"}\n\ndata: {"type":"response.completed"}\n\n',
      { headers: { "Content-Type": "text/event-stream" } }
    );
  }
  throw new Error("Unexpected synthetic endpoint");
};
const connection = new OpenAiChatGptPlanConnection(
  client,
  secrets,
  request,
  async (token, clientId, expectedNonce) => {
    const { payload } = await jwtVerify(token, publicKey, {
      issuer: "https://auth.openai.com",
      audience: clientId,
      requiredClaims: ["sub", "exp", "iat"],
    });
    assert.equal(payload.nonce, expectedNonce);
    return payload;
  },
  () => now
);
async function start() {
  const result = await connection.startAuthorization();
  const secret = JSON.parse((await secrets.get(`DanettiPriceScraper:openai-auth:${result.id}`))!);
  audience = secret.clientId === "dynamic_agent_client" ? "oaiapp_synthetic" : secret.clientId;
  nonce = secret.nonce;
  return { result, secret };
}
async function signIn() {
  const { result, secret } = await start();
  await connection.callback({ state: secret.state, code: "synthetic-code", client_id: audience });
  return { result, secret };
}
try {
  for (const filename of [
    "0018_epr_mailbox_intelligence.sql",
    "0019_epr_immutability.sql",
    "0020_epr_accounting_date_policy.sql",
  ]) {
    let migration = await readFile(
      new URL(`../../../../../packages/db/drizzle/${filename}`, import.meta.url),
      "utf8"
    );
    migration = migration.replaceAll('"public".', `"${namespace}".`);
    for (const statement of migration.split("--> statement-breakpoint"))
      if (statement.trim()) await sql.unsafe(statement);
  }
  assert.equal((await connection.getStatus()).connected, false);
  const mismatch = await start();
  await assert.rejects(
    connection.callback({ state: "invalid", code: "x", client_id: audience }),
    /chatgpt_auth_state_invalid/
  );
  assert.equal((await connection.attemptStatus(mismatch.result.id)).status, "pending");
  await connection
    .callback({ state: mismatch.secret.state, error: "access_denied" })
    .catch((error) => assert.match(error.message, /chatgpt_auth_cancelled/));
  assert.equal((await connection.attemptStatus(mismatch.result.id)).status, "failed");
  const expired = await start();
  now += 600_001;
  assert.equal(
    (await connection.attemptStatus(expired.result.id)).errorCode,
    "chatgpt_auth_callback_expired"
  );
  await assert.rejects(
    connection.callback({ state: expired.secret.state, code: "x" }),
    /chatgpt_auth_state_invalid/
  );
  now = Date.now();
  const badNonce = await start();
  nonce = "wrong-nonce";
  await assert.rejects(
    connection.callback({ state: badNonce.secret.state, code: "x", client_id: audience }),
    /chatgpt_id_token_invalid/
  );
  const badIssuer = await start();
  issuer = "https://untrusted.invalid";
  await assert.rejects(
    connection.callback({ state: badIssuer.secret.state, code: "x", client_id: audience }),
    /chatgpt_id_token_invalid/
  );
  issuer = "https://auth.openai.com";
  const badAudience = await start();
  audience = "wrong-client";
  await assert.rejects(
    connection.callback({
      state: badAudience.secret.state,
      code: "x",
      client_id: "oaiapp_synthetic",
    }),
    /chatgpt_id_token_invalid/
  );
  const missingScope = await start();
  scopes = "openid profile email offline_access";
  await assert.rejects(
    connection.callback({ state: missingScope.secret.state, code: "x", client_id: audience }),
    /chatgpt_plan_permission_missing/
  );
  scopes = requiredScopes.join(" ");
  const superseded = await start();
  const replacement = await start();
  assert.equal(
    (await connection.attemptStatus(superseded.result.id)).errorCode,
    "chatgpt_auth_cancelled"
  );
  await assert.rejects(
    connection.callback({ state: superseded.secret.state, code: "x", client_id: audience }),
    /chatgpt_auth_state_invalid/
  );
  await connection
    .callback({ state: replacement.secret.state, error: "access_denied" })
    .catch(() => undefined);
  const signed = await signIn();
  assert.equal((await connection.getStatus()).connected, true);
  assert.ok(!JSON.stringify(await connection.getStatus()).includes("synthetic-access"));
  assert.equal(await secrets.get(`DanettiPriceScraper:openai-auth:${signed.result.id}`), null);
  await assert.rejects(
    connection.callback({ state: signed.secret.state, code: "x", client_id: audience }),
    /chatgpt_auth_state_invalid/
  );
  const host1 = (await db.select().from(schema.eprInstallations))[0].hostId;
  const returning = await start();
  assert.equal(returning.secret.clientId, "oaiapp_synthetic");
  assert.ok(returning.secret.url.includes("id_token_hint"));
  assert.equal((await db.select().from(schema.eprInstallations))[0].hostId, host1);
  const p = (await db.select().from(schema.openaiProfiles))[0],
    key = `DanettiPriceScraper:openai-oauth:${p.id}`;
  assert.equal(await connection.getValidAccessToken(), "synthetic-access-0");
  let saved = JSON.parse((await secrets.get(key))!);
  saved.accessTokenExpiresAt = now - 1;
  await secrets.put(key, JSON.stringify(saved));
  const tokens = await Promise.all(
    Array.from({ length: 5 }, () => connection.getValidAccessToken())
  );
  assert.equal(refreshes, 1);
  assert.ok(tokens.every((t) => t === "synthetic-access-1"));
  assert.equal(JSON.parse((await secrets.get(key))!).refreshToken, "synthetic-refresh-1");
  saved = JSON.parse((await secrets.get(key))!);
  saved.accessTokenExpiresAt = now - 1;
  await secrets.put(key, JSON.stringify(saved));
  tokenMode = "temporary";
  await assert.rejects(connection.getValidAccessToken(), /chatgpt_temporarily_unavailable/);
  assert.ok(await secrets.get(key));
  assert.equal((await connection.getStatus()).connected, true);
  tokenMode = "terminal";
  await assert.rejects(connection.getValidAccessToken(), /chatgpt_reauthorization_required/);
  assert.equal(await secrets.get(key), null);
  assert.equal((await connection.getStatus()).connected, false);
  tokenMode = "success";
  await signIn();
  await connection.selectModel("account-model");
  assert.equal(await connection.infer([{ role: "user", content: "test" }], "test"), "DANETTI_OK");
  const restarted = new OpenAiChatGptPlanConnection(client, secrets, request);
  assert.equal((await restarted.getStatus()).connected, true);
  assert.ok(await restarted.getValidAccessToken());

  const service = new EprService(client, new DocumentArchive(temp), {
    classifyDocument: async () => ({ documentType: "other", reasonCodes: [] }),
    extractInvoice: async () => {
      throw new Error("Synthetic AI unavailable");
    },
  });
  const period = await service.createPeriod("2026-Q3");
  await service.configurePeriod(period.id, {
    accountingBasis: "Operator-approved synthetic test basis",
    accountingEventType: "operator-approved-event",
  });
  const materialRule = await service.createRule({
    key: "test",
    name: "Pouch",
    supplierIdentity: "TAX-1",
    supplierSku: "SKU",
    validFrom: "2026-01-01",
    validTo: null,
    applicability: "PER_ITEM",
    unit: "db",
    source: "measured synthetic",
    notes: null,
    operator: "test",
    components: [
      { name: "body", material: "plastic", grams: "11.85", classification: null },
      { name: "label", material: "paper", grams: "1.10", classification: null },
    ],
  });
  const invoice: Invoice = {
    documentType: "invoice",
    supplier: { name: "Unknown supplier", taxId: "TAX-1" },
    customerIdentity: "BUYER",
    invoiceNumber: "INV-1",
    orderReferences: [],
    issueDate: "2026-09-01",
    performanceDate: null,
    dueDate: null,
    currency: "EUR",
    reasonCodes: ["invoice_number_detected"],
    lines: [
      {
        sourceLineId: "1",
        supplierSku: "SKU",
        description: "pouch",
        quantity: "5000",
        unit: "db",
        unitPrice: null,
        lineNet: null,
        provenance: { page: 1, sourceText: "pouch 5000 db" },
      },
    ],
  };
  const bytes = Buffer.from(JSON.stringify({ format: "danetti-invoice-v1", invoice }));
  const document = await service.importDocument(period.id, {
    bytes,
    filename: "invoice.json",
    mime: "application/json",
  });
  await service.importDocument(period.id, {
    bytes,
    filename: "same-invoice.json",
    mime: "application/json",
  });
  let purchases = await service.listPurchases(period.id);
  assert.equal(purchases.length, 1);
  assert.equal(purchases[0].status, "potential");
  await service.reviewPurchase(purchases[0].id, {
    action: "accept",
    reason: "Verified source",
    operator: "test",
    accountingEventDate: "2026-09-01",
    supplierIdentity: "TAX-1",
    supplier: "Unknown supplier",
  });
  await service.recalculate(period.id);
  let result = (await service.summary(period.id)) as {
    totals: Record<string, string>;
    unresolved: number;
  };
  assert.deepEqual(result.totals, { plastic: "59.25", paper: "5.5" });
  assert.equal(result.unresolved, 0);
  await service.recalculate(period.id);
  assert.equal((await db.select().from(schema.eprEntries)).length, 1);
  const snapshot = await service.close(period.id, "test");
  await assert.rejects(
    service.editLine((await service.detail(purchases[0].id)).lines[0].id, {
      quantity: "1",
      unit: "db",
      supplierSku: "SKU",
      ruleVersionId: materialRule.id,
      reason: "test",
      operator: "test",
    }),
    /period_closed/
  );
  await service.createRule({
    key: "test",
    name: "Pouch",
    supplierIdentity: "TAX-1",
    supplierSku: "SKU",
    validFrom: "2026-01-01",
    validTo: null,
    applicability: "PER_ITEM",
    unit: "db",
    source: "new measurement",
    notes: null,
    operator: "test",
    components: [{ name: "body", material: "plastic", grams: "99", classification: null }],
  });
  await service.importDocument(period.id, {
    bytes: Buffer.from(
      JSON.stringify({
        format: "danetti-invoice-v1",
        invoice: { ...invoice, invoiceNumber: "LATE-1" },
      })
    ),
    filename: "late.json",
    mime: "application/json",
  });
  assert.deepEqual((await service.summary(period.id)).totals, { plastic: "59.25", paper: "5.5" });
  assert.equal((await service.summary(period.id)).digest, snapshot.digest);
  assert.ok(
    (await db.select().from(schema.eprReviewDecisions)).some((d) => d.action === "late_evidence")
  );
  await assert.rejects(
    db
      .update(schema.eprPeriodSnapshots)
      .set({ digest: "tampered" })
      .where(eq(schema.eprPeriodSnapshots.id, snapshot.id))
  );
  await assert.rejects(
    db
      .update(schema.eprMaterialRules)
      .set({ name: "tampered" })
      .where(eq(schema.eprMaterialRules.id, materialRule.id))
  );
  const exported = await service.export(period.id);
  assert.ok(exported.bytes.length > 1000);

  // Operator-chosen date policy unlocks known invoices, while exceptions never become zeroes.
  const automatic = await service.createPeriod("2027-Q2");
  assert.equal(automatic.accountingDateField, "manual");
  await service.createRule({
    key: "auto",
    name: "Verified item",
    supplierIdentity: "AUTO-TAX",
    supplierSku: "AUTO-SKU",
    validFrom: "2027-01-01",
    validTo: null,
    applicability: "PER_ITEM",
    unit: "db",
    source: "Verified synthetic weight",
    operator: "test",
    components: [{ name: "body", material: "plastic", grams: "1.5", classification: null }],
  });
  const autoInvoice: Invoice = {
    ...invoice,
    supplier: { name: "Known supplier", taxId: "AUTO-TAX" },
    invoiceNumber: "AUTO-1",
    issueDate: "2027-04-10",
    performanceDate: "2027-04-11",
    lines: [{ ...invoice.lines[0], supplierSku: "AUTO-SKU", quantity: "4" }],
  };
  async function importAuto(value: Invoice, targetPeriod = automatic.id) {
    const document = await service.importDocument(targetPeriod, {
      bytes: Buffer.from(JSON.stringify({ format: "danetti-invoice-v1", invoice: value })),
      filename: "automatic.json",
      mime: "application/json",
    });
    const [business] = await db
      .select()
      .from(schema.businessDocuments)
      .where(eq(schema.businessDocuments.sourceDocumentId, document.id));
    const [link] = await db
      .select()
      .from(schema.purchaseDocuments)
      .where(eq(schema.purchaseDocuments.businessDocumentId, business.id));
    return service.detail(link.purchaseId);
  }
  let autoDetail = await importAuto(autoInvoice);
  assert.equal(autoDetail.purchase.status, "potential");
  assert.equal(autoDetail.entries.length, 0);
  await assert.rejects(
    service.configurePeriod(automatic.id, {
      accountingBasis: "Test",
      accountingEventType: "Test",
      accountingDateField: "receivedDate",
    }),
    /accounting_configuration_required/
  );
  await service.configurePeriod(automatic.id, {
    accountingBasis: "Operator approved invoice issue date",
    accountingEventType: "approved event",
    accountingDateField: "issueDate",
  });
  await service.recalculate(automatic.id);
  autoDetail = await service.detail(autoDetail.purchase.id);
  assert.equal(autoDetail.purchase.status, "ok");
  assert.equal(autoDetail.purchase.accountingEventDate, "2027-04-10");
  assert.equal(autoDetail.entries[0].grams, "6.0000000000");
  assert.equal(autoDetail.entries[0].trace.totalGrams, "6");
  assert.equal(autoDetail.decisions.filter((d) => d.action === "automatic_accept").length, 1);
  await importAuto(autoInvoice);
  await service.recalculate(automatic.id);
  assert.equal((await service.detail(autoDetail.purchase.id)).entries.length, 1);
  assert.equal(
    (await service.detail(autoDetail.purchase.id)).decisions.filter(
      (d) => d.action === "automatic_accept"
    ).length,
    1
  );
  for (const exception of [
    {
      ...autoInvoice,
      invoiceNumber: "AUTO-UNKNOWN",
      supplier: { name: "Unknown", taxId: "NO-RULES" },
    },
    { ...autoInvoice, invoiceNumber: "AUTO-MISSING-DATE", issueDate: null },
    { ...autoInvoice, invoiceNumber: "AUTO-OLD", issueDate: "2027-03-31" },
    { ...autoInvoice, invoiceNumber: "AUTO-CREDIT", documentType: "credit_note" as const },
    { ...autoInvoice, invoiceNumber: "AUTO-CANCEL", documentType: "cancellation" as const },
  ]) {
    const detail = await importAuto(exception);
    assert.equal(detail.purchase.status, "potential");
    assert.equal(detail.entries.length, 0);
  }
  const missingRule = await importAuto({
    ...autoInvoice,
    invoiceNumber: "AUTO-UNMAPPED",
    lines: [{ ...autoInvoice.lines[0], supplierSku: "UNKNOWN-SKU" }],
  });
  assert.equal(missingRule.purchase.status, "review");
  assert.equal(missingRule.entries.length, 0);
  assert.equal(missingRule.lines[0].safeErrorCode, "material_rule_missing");
  assert.ok(
    (await service.unresolvedProducts()).some((l) => l.purchaseId === missingRule.purchase.id)
  );
  const missingQuantity = await importAuto({
    ...autoInvoice,
    invoiceNumber: "AUTO-NO-QUANTITY",
    lines: [{ ...autoInvoice.lines[0], quantity: null }],
  });
  assert.equal(missingQuantity.purchase.status, "review");
  assert.equal(missingQuantity.entries.length, 0);
  const grouped = await importAuto({
    ...autoInvoice,
    invoiceNumber: "AUTO-GROUP-1",
    orderReferences: ["ORDER-1"],
  });
  assert.equal(grouped.purchase.status, "ok");
  const differentDate = await importAuto({
    ...autoInvoice,
    invoiceNumber: "AUTO-GROUP-2",
    issueDate: "2027-04-12",
    orderReferences: ["ORDER-1"],
  });
  assert.equal(differentDate.purchase.id, grouped.purchase.id);
  assert.equal(differentDate.purchase.status, "potential");
  assert.equal(differentDate.purchase.accountingEventDate, null);
  assert.equal(differentDate.entries.length, 0);
  const otherBuyer = await importAuto({
    ...autoInvoice,
    customerIdentity: "ANOTHER-BUYER",
    invoiceNumber: "AUTO-GROUP-3",
    orderReferences: ["ORDER-1"],
  });
  assert.notEqual(otherBuyer.purchase.id, grouped.purchase.id);
  assert.equal(otherBuyer.purchase.status, "ok");
  await service.configurePeriod(automatic.id, {
    accountingBasis: "Operator approved performance date",
    accountingEventType: "approved event",
    accountingDateField: "performanceDate",
  });
  const performance = await importAuto({ ...autoInvoice, invoiceNumber: "AUTO-PERFORMANCE" });
  assert.equal(performance.purchase.accountingEventDate, "2027-04-11");
  const rejected = await importAuto({ ...autoInvoice, invoiceNumber: "AUTO-REJECTED" });
  await service.reviewPurchase(rejected.purchase.id, {
    action: "reject",
    reason: "Not reportable",
    operator: "test",
  });
  await service.recalculate(automatic.id);
  assert.equal((await service.detail(rejected.purchase.id)).purchase.status, "excluded");
  const conflictingAuto = await importAuto({ ...autoInvoice, reasonCodes: ["different-bytes"] });
  assert.equal(conflictingAuto.entries.length, 0);
  assert.equal((await service.detail(autoDetail.purchase.id)).entries.length, 0);
  assert.equal((await service.detail(autoDetail.purchase.id)).purchase.status, "review");
  assert.ok((await service.archiveStatus()).documentCount > 0);

  const cancellation = await importAuto({
    ...autoInvoice,
    invoiceNumber: "AUTO-CANCEL",
    documentType: "cancellation",
  });
  await service.reviewPurchase(cancellation.purchase.id, {
    action: "accept",
    reason: "Cancellation source verified",
    operator: "test",
    accountingEventDate: "2027-04-11",
  });
  const cancelReview = await service.detail(cancellation.purchase.id);
  assert.equal(cancelReview.entries.length, 0);
  assert.equal(cancelReview.lines[0].safeErrorCode, "credit_material_review_required");
  await service.editLine(cancelReview.lines[0].id, {
    quantity: "-4",
    unit: "db",
    supplierSku: "AUTO-SKU",
    ruleVersionId: null,
    creditApproved: true,
    reason: "Verified material reversal of four units",
    operator: "test",
  });
  assert.equal((await service.detail(cancellation.purchase.id)).entries[0].grams, "-6.0000000000");

  const autoClosed = await service.createPeriod("2027-Q3");
  await service.configurePeriod(autoClosed.id, {
    accountingBasis: "Verified automatic date policy",
    accountingEventType: "approved event",
    accountingDateField: "issueDate",
  });
  const closedInvoice = { ...autoInvoice, invoiceNumber: "AUTO-CLOSED", issueDate: "2027-07-10" };
  const closedDetail = await importAuto(closedInvoice, autoClosed.id);
  assert.equal(closedDetail.purchase.status, "ok");
  const autoSnapshot = await service.close(autoClosed.id, "test");
  await assert.rejects(
    service.configurePeriod(autoClosed.id, {
      accountingBasis: "Changed",
      accountingEventType: "Changed",
      accountingDateField: "performanceDate",
    }),
    /period_closed/
  );
  await importAuto({ ...closedInvoice, invoiceNumber: "AUTO-CLOSED-LATE" }, autoClosed.id);
  assert.equal((await service.summary(autoClosed.id)).digest, autoSnapshot.digest);
  assert.deepEqual((await service.summary(autoClosed.id)).totals, { plastic: "0.006" });

  const aiFree = await service.createPeriod("2026-Q4");
  const unknown = await service.importDocument(aiFree.id, {
    bytes: Buffer.from("Unknown invoice text"),
    filename: "unknown.txt",
    mime: "text/plain",
  });
  assert.equal(unknown.status, "review");
  assert.equal((await service.listPurchases(aiFree.id)).length, 1);
  let uidValidity = 1n;
  let lockReadOnly = false;
  const mime = Buffer.from(
    `From: unknown@example.invalid\r\nTo: operator@example.invalid\r\nSubject: invoice INV-MIME\r\nMessage-ID: <same-message-id@example.invalid>\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary="synthetic-boundary"\r\n\r\n--synthetic-boundary\r\nContent-Type: application/json\r\nContent-Disposition: attachment; filename="invoice.json"\r\nContent-Transfer-Encoding: base64\r\n\r\n${Buffer.from(JSON.stringify({ format: "danetti-invoice-v1", invoice: { ...invoice, invoiceNumber: "INV-MIME" } })).toString("base64")}\r\n--synthetic-boundary--\r\n`
  );
  const fakeImap = () =>
    ({
      on: () => undefined,
      connect: async () => undefined,
      mailbox: { uidValidity, uidNext: 2 },
      getMailboxLock: async (_path: string, opts: { readOnly: boolean }) => {
        lockReadOnly = opts.readOnly;
        return { release: () => undefined };
      },
      fetchAll: async () => [
        {
          uid: 1,
          envelope: {
            subject: "invoice INV-MIME",
            messageId: "<same-message-id@example.invalid>",
            from: [{ address: "unknown@example.invalid" }],
            date: new Date("2026-10-01"),
          },
          internalDate: new Date("2026-10-01"),
          size: mime.length,
          bodyStructure: {
            type: "application/json",
            dispositionParameters: { filename: "invoice.json" },
          },
        },
      ],
      download: async () => ({ content: Readable.from([mime]) }),
      logout: async () => undefined,
      close: () => undefined,
    }) as unknown as ImapFlow;
  const scanMailbox = new MailboxService(client, secrets, (opts) => {
    assert.equal(opts.tls.rejectUnauthorized, true);
    assert.equal(opts.doSTARTTLS, true);
    return fakeImap();
  });
  const configured = await scanMailbox.save({
    name: "Scan test",
    host: "imap.example.invalid",
    port: 143,
    security: "STARTTLS",
    username: "scan@example.invalid",
    password: "synthetic",
    folders: ["INBOX", "Invoices"],
  });
  let calls = 0;
  const ingest = async (messageId: string, source: Buffer, metadata: Record<string, unknown>) => {
    calls++;
    await service.importMessage(aiFree.id, messageId, source, metadata);
  };
  await assert.rejects(
    scanMailbox.scan(
      configured,
      async (...args) => {
        await ingest(...args);
        throw new Error("synthetic interruption");
      },
      async () => undefined
    )
  );
  await scanMailbox.scan(configured, ingest, async () => undefined);
  assert.equal(lockReadOnly, true);
  assert.equal((await db.select().from(schema.mailboxMessages)).length, 2);
  const countAfterFirst = (await service.listPurchases(aiFree.id)).length;
  assert.equal(countAfterFirst, 2);
  calls = 0;
  await scanMailbox.scan(configured, ingest, async () => undefined);
  assert.equal(calls, 0);
  assert.equal((await service.listPurchases(aiFree.id)).length, countAfterFirst);
  uidValidity = 2n;
  await scanMailbox.scan(configured, ingest, async () => undefined);
  assert.equal((await db.select().from(schema.mailboxMessages)).length, 4);
  assert.equal((await service.listPurchases(aiFree.id)).length, countAfterFirst);
  const queueName = `epr-test-${namespace}`,
    coordinator = new EprScanCoordinator(service, scanMailbox, queueName);
  try {
    const runs = await Promise.all([
      coordinator.enqueue(aiFree.id),
      coordinator.enqueue(aiFree.id),
    ]);
    assert.equal(runs[0].id, runs[1].id);
    let completed = false;
    for (let i = 0; i < 100; i++) {
      const status = await coordinator.status(runs[0].id);
      if (status.status === "COMPLETED_WITH_REVIEW") {
        completed = true;
        assert.ok(Number(status.progress.reviewItemsCreated) >= 1);
        break;
      }
      if (status.status === "FAILED") throw new Error(status.safeErrorCode ?? "queue_failed");
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    assert.equal(completed, true);
    assert.equal((await service.listPurchases(aiFree.id)).length, countAfterFirst);
  } finally {
    await coordinator.close();
    const redis = new Redis(process.env.REDIS_URL ?? "redis://localhost:6379", {
        maxRetriesPerRequest: 1,
      }),
      queue = new Queue(queueName, { connection: redis });
    await queue.obliterate({ force: true });
    await queue.close();
    redis.disconnect();
  }
  await scanMailbox.remove(configured.id);
  assert.equal((await db.select().from(schema.mailboxMessages)).length, 4);
  assert.ok(
    (
      await service.detail(
        (await service.listPurchases(aiFree.id)).find((p) => p.reference === "INV-MIME")!.id
      )
    ).messages.length
  );
  const mailbox = new MailboxService(client, secrets);
  const m = await mailbox.save({
    name: "synthetic",
    host: "imap.example.invalid",
    port: 143,
    security: "STARTTLS",
    username: "test@example.invalid",
    password: "synthetic",
    folders: ["INBOX"],
  });
  assert.ok(await secrets.get(`DanettiPriceScraper:mailbox:${m.id}`));
  await mailbox.remove(m.id);
  assert.equal(await secrets.get(`DanettiPriceScraper:mailbox:${m.id}`), null);
  assert.deepEqual(await service.archive.read(document.hash), bytes);
  const unknownPurchase = (await service.listPurchases(aiFree.id)).find(
    (p) => p.reference === null
  )!;
  await service.manualExtraction(unknown.id, aiFree.id, {
    ...invoice,
    invoiceNumber: "MANUAL-1",
    issueDate: "2026-10-01",
  });
  assert.equal((await service.detail(unknownPurchase.id)).lines.length, 1);
  await service.configurePeriod(aiFree.id, {
    accountingBasis: "Verified test basis",
    accountingEventType: "test-event",
  });
  await service.reviewPurchase(unknownPurchase.id, {
    action: "accept",
    reason: "Source checked",
    operator: "test",
    accountingEventDate: "2026-10-01",
    supplierIdentity: "TAX-1",
    supplier: "Unknown supplier",
  });
  assert.equal((await service.detail(unknownPurchase.id)).entries.length, 1);
  const conflicting = await service.importDocument(aiFree.id, {
    bytes: Buffer.from(
      JSON.stringify({
        format: "danetti-invoice-v1",
        invoice: {
          ...invoice,
          invoiceNumber: "MANUAL-1",
          issueDate: "2026-10-01",
          reasonCodes: ["different_source"],
        },
      })
    ),
    filename: "conflicting.json",
    mime: "application/json",
  });
  assert.ok((await service.detail(unknownPurchase.id)).documents[0].business.conflict);
  assert.equal((await service.detail(unknownPurchase.id)).entries.length, 0);
  assert.equal((await service.detail(unknownPurchase.id)).purchase.status, "review");
  await service.resolveDocumentConflict(conflicting.id, "Verified alternate source is incorrect");
  assert.equal((await service.detail(unknownPurchase.id)).documents[0].business.conflict, false);
  assert.equal((await service.detail(unknownPurchase.id)).entries.length, 1);
  const target = await service.createPeriod("2027-Q1");
  await service.movePurchase(unknownPurchase.id, target.id, "Correct accounting period");
  assert.equal((await service.detail(unknownPurchase.id)).purchase.periodId, target.id);
  assert.equal((await service.detail(unknownPurchase.id)).purchase.accountingEventDate, null);
  await service.excludeLine(
    (await service.detail(unknownPurchase.id)).lines[0].id,
    "Non-reportable line verified"
  );
  assert.equal((await service.detail(unknownPurchase.id)).lines[0].factors?.excluded, "true");
  await assert.rejects(
    service.movePurchase(purchases[0].id, target.id, "Cannot move closed snapshot"),
    /period_closed/
  );
  const [oversizedMessage] = await db
    .insert(schema.mailboxMessages)
    .values({
      mailboxId: null,
      folder: "synthetic",
      uidValidity: "1",
      uid: 1,
      metadata: { subject: "Oversized invoice" },
      status: "oversized_review",
    })
    .returning();
  const countBeforeOversized = (await service.listPurchases(target.id)).length;
  await service.importOversizedMessage(target.id, oversizedMessage.id, {
    subject: "Oversized invoice",
    size: 30_000_001,
  });
  await service.importOversizedMessage(target.id, oversizedMessage.id, {
    subject: "Oversized invoice",
    size: 30_000_001,
  });
  assert.equal((await service.listPurchases(target.id)).length, countBeforeOversized + 1);
  const oversizedSource = (await db.select().from(schema.sourceDocuments)).find(
    (d) => d.provider === "metadata-only"
  )!;
  assert.equal(oversizedSource.safeErrorCode, "document_size_invalid");
  assert.ok(oversizedSource.bytes < 1000);
  const api = Fastify();
  await api.register(registerEprRoutes, { client, secrets });
  try {
    const listed = await api.inject({ method: "GET", url: "/epr/periods" });
    assert.equal(listed.statusCode, 200);
    assert.ok(listed.json().items.some((p: { id: string }) => p.id === target.id));
    const summaryRoute = await api.inject({
      method: "GET",
      url: `/epr/periods/${period.id}/summary`,
    });
    assert.equal(summaryRoute.json().digest, snapshot.digest);
    const invalid = await api.inject({ method: "GET", url: "/epr/purchases/not-a-uuid" });
    assert.equal(invalid.statusCode, 400);
    assert.equal(invalid.json().error.code, "invalid_uuid");
    const policy = await api.inject({ method: "GET", url: "/epr/processing-policy" });
    assert.equal(policy.json().automaticLearning, false);
    assert.ok(policy.json().systemPrompt.includes("untrusted DATA"));
  } finally {
    await api.close();
  }
  const pendingDisconnect = await start();
  const disconnect = await connection.disconnect();
  assert.equal(
    (await connection.attemptStatus(pendingDisconnect.result.id)).errorCode,
    "chatgpt_auth_cancelled"
  );
  assert.equal(disconnect.remoteRevocationConfirmed, true);
  assert.equal((await connection.getStatus()).connected, false);
  assert.equal((await service.summary(period.id)).digest, snapshot.digest);
  console.log(
    "EPR isolated PostgreSQL OAuth, rotation, replay, persistence, idempotency, snapshot and export integration tests passed"
  );
} finally {
  await sql.end({ timeout: 5 });
  // Only this freshly created randomized test namespace is removed. No application rows are touched.
  await admin.unsafe(`DROP SCHEMA "${namespace}" CASCADE`);
  await admin.end({ timeout: 5 });
  await rm(temp, { recursive: true, force: true });
}
