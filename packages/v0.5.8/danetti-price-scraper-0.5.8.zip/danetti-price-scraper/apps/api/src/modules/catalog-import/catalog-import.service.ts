import {
  detectWooCsvColumnMapping,
  normalizeCsvHeader,
  normalizeWooCsvRow,
  parseWooSku,
  type CsvColumnMappingAnalysis,
  type CsvColumnMappingOverride,
  type NewCatalogProduct,
} from "@danetti/db";
import { parse } from "csv-parse/sync";
import { CSV_IMPORT_SAMPLE_ROWS } from "./catalog-import.constants.js";
import type { CatalogImportRepository } from "./catalog-import.repository.js";
import {
  CatalogImportValidationError,
  type CatalogImportMode,
  type CatalogImportResult,
  type CatalogImportSampleRow,
  type CatalogImportSummary,
  type CatalogImportValidationIssue,
  type ClassifiedCatalogImportRow,
  type ExistingCatalogProductMatch,
  type ParsedCatalogCsv,
  type ParsedCatalogCsvRow,
  type UploadedCatalogCsv,
} from "./catalog-import.types.js";

interface CsvParseRecord {
  record: Record<string, unknown>;
  info?: {
    lines?: number;
  };
}

interface DecimalValue {
  value: string | null;
  errorCode: string | null;
  errorMessage: string | null;
}

interface ProductBuildResult {
  productInput: NewCatalogProduct | null;
  errorCode: string | null;
  errorMessage: string | null;
  warnings: CatalogImportValidationIssue[];
}

const CSV_REQUIRED_COLUMNS = ["Name"];
const PRODUCT_NAME_FALLBACK_HEADERS = new Set(
  [
    "Name",
    "Név",
    "Terméknév",
    "Termék név",
    "Termék neve",
    "Product",
    "Product name",
    "Product title",
    "Title",
    "Post title",
    "post_title",
  ].map(normalizeCsvHeader)
);
const SUPPORTED_WOO_PRODUCT_TYPES = new Set([
  "simple",
  "variable",
  "variation",
  "grouped",
  "external",
]);

export class CatalogImportService {
  constructor(private readonly repository: CatalogImportRepository) {}

  async importCsv(input: {
    mode: CatalogImportMode;
    uploadedCsv: UploadedCatalogCsv;
    parsedCsv: ParsedCatalogCsv;
  }): Promise<CatalogImportResult> {
    return this.repository.transaction(async (repository) => {
      const startedAt = new Date();
      const importRun = await repository.createImportRun({
        mode: input.mode,
        status: input.mode === "preview_only" ? "parsing" : "importing",
        originalFilename: input.uploadedCsv.filename,
        fileSha256: input.uploadedCsv.fileSha256,
        fileSizeBytes: input.uploadedCsv.fileSizeBytes,
        delimiter: ",",
        detectedMapping: input.parsedCsv.columnMapping as unknown as Record<string, unknown>,
        mappingWarnings: input.parsedCsv.columnMapping.warnings,
        unknownColumnCount: input.parsedCsv.columnMapping.unknownColumnCount,
        importProfileName: "woocommerce_csv_auto",
        startedAt,
      });

      const candidateSkus = collectCandidateSkus(
        input.parsedCsv.rows,
        input.parsedCsv.columnMapping
      );
      const existingProducts = await repository.listExistingProductsBySku(candidateSkus);
      const existingProductsBySku = new Map(
        existingProducts.map((product) => [product.sku, product])
      );
      const classifiedRows = classifyCatalogImportRows({
        mode: input.mode,
        parsedRows: input.parsedCsv.rows,
        columnMapping: input.parsedCsv.columnMapping,
        existingProducts,
      });

      for (const row of classifiedRows) {
        if ((row.status === "skipped_existing" || row.status === "updated") && row.sku !== null) {
          row.catalogProductId = existingProductsBySku.get(row.sku)?.id ?? null;
        }
      }

      const finalStatus: "preview_ready" | "completed" =
        input.mode === "preview_only" ? "preview_ready" : "completed";
      if (input.mode === "preview_only") {
        const summary = summarizeClassifiedRows(classifiedRows, input.mode, 0);
        await repository.createImportRows(toImportRows(importRun.id, classifiedRows));
        await repository.updateImportRunSummary(importRun.id, {
          ...summary,
          status: finalStatus,
          finishedAt: new Date(),
        });

        return {
          importRunId: importRun.id,
          mode: input.mode,
          ...summary,
          sampleRows: toSampleRows(classifiedRows),
          validation: buildValidationReport(classifiedRows, input.parsedCsv.columnMapping),
        };
      }

      if (input.mode === "add_only") {
        await insertClassifiedProducts(repository, importRun.id, classifiedRows);
      } else {
        await upsertClassifiedProducts(repository, importRun.id, classifiedRows);
      }

      const summary = summarizeClassifiedRows(classifiedRows, input.mode, 0);

      await repository.createImportRows(toImportRows(importRun.id, classifiedRows));

      await repository.updateImportRunSummary(importRun.id, {
        ...summary,
        status: finalStatus,
        finishedAt: new Date(),
        errorSummary: null,
      });

      return {
        importRunId: importRun.id,
        mode: input.mode,
        ...summary,
        sampleRows: toSampleRows(classifiedRows),
        validation: buildValidationReport(classifiedRows, input.parsedCsv.columnMapping),
      };
    });
  }
}

export function parseWooCsv(
  buffer: Buffer,
  columnMapping: CsvColumnMappingOverride = {}
): ParsedCatalogCsv {
  if (buffer.length === 0 || buffer.toString("utf8").trim().length === 0) {
    throw new CatalogImportValidationError("empty_csv", "CSV file is empty");
  }

  let parsed: CsvParseRecord[];

  try {
    parsed = parse(buffer, {
      bom: true,
      columns: true,
      info: true,
      relax_column_count: true,
      skip_empty_lines: true,
      trim: true,
    }) as CsvParseRecord[];
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown CSV parse error";
    throw new CatalogImportValidationError("parse_failure", `CSV parse failure: ${message}`);
  }

  if (parsed.length === 0) {
    throw new CatalogImportValidationError("empty_csv", "CSV file has no data rows");
  }

  const headers = Object.keys(parsed[0]?.record ?? {}).map((header) =>
    header.replace(/^\uFEFF/, "").trim()
  );
  const detectedMapping = detectWooCsvColumnMapping(headers, columnMapping);

  return {
    rows: parsed.map((row, index) => ({
      rowNumber: row.info?.lines ?? index + 2,
      rawRow: trimRawRecord(row.record),
    })),
    headers,
    columnMapping: detectedMapping,
  };
}

export function classifyCatalogImportRows(input: {
  mode: CatalogImportMode;
  parsedRows: ParsedCatalogCsvRow[];
  columnMapping?: CsvColumnMappingAnalysis;
  existingProducts: ExistingCatalogProductMatch[];
}): ClassifiedCatalogImportRow[] {
  const existingSkus = new Set(input.existingProducts.map((product) => product.sku));
  const normalizedRows = input.parsedRows.map((row) => ({
    ...row,
    normalized: normalizeWooCsvRow(row.rawRow, input.columnMapping),
  }));
  const skuCounts = new Map<string, number>();
  const lastSkuRowNumber = new Map<string, number>();

  for (const row of normalizedRows) {
    const sku = row.normalized.sku;
    if (sku === null) continue;
    skuCounts.set(sku, (skuCounts.get(sku) ?? 0) + 1);
    lastSkuRowNumber.set(sku, row.rowNumber);
  }

  return normalizedRows.map((row) => {
    const { normalized } = row;
    const sku = normalized.sku;

    if (sku === null) {
      return buildClassifiedRow({
        rowNumber: row.rowNumber,
        status: "skipped_missing_sku",
        wouldInsert: false,
        normalized,
        warnings: [
          buildValidationIssue({
            rowNumber: row.rowNumber,
            normalized,
            status: "skipped_missing_sku",
            code: "missing_sku",
            message: "A cikkszám hiányzik, ezért ez a sor kimarad.",
          }),
        ],
      });
    }

    const duplicateSkuCount = skuCounts.get(sku) ?? 0;
    const hasDuplicateSku = duplicateSkuCount > 1;
    const isLastDuplicateSkuRow = lastSkuRowNumber.get(sku) === row.rowNumber;
    const duplicateWarnings = hasDuplicateSku
      ? [
          buildValidationIssue({
            rowNumber: row.rowNumber,
            normalized,
            status: isLastDuplicateSkuRow ? null : "skipped_duplicate",
            code: "duplicate_sku",
            message: isLastDuplicateSkuRow
              ? "Ez a cikkszám többször szerepel. Az utolsó CSV sor adata kerül importálásra."
              : "Ez a cikkszám később is szerepel. Ez a korábbi sor kimarad.",
          }),
        ]
      : [];

    if (hasDuplicateSku && !isLastDuplicateSkuRow) {
      return buildClassifiedRow({
        rowNumber: row.rowNumber,
        status: "skipped_duplicate",
        wouldInsert: false,
        normalized,
        warnings: duplicateWarnings,
      });
    }

    const productBuild = buildCatalogProductInput(normalized, row.rowNumber);

    if (productBuild.productInput === null) {
      return buildClassifiedRow({
        rowNumber: row.rowNumber,
        status: "invalid",
        wouldInsert: false,
        normalized,
        errorCode: productBuild.errorCode,
        errorMessage: productBuild.errorMessage,
        warnings: [...duplicateWarnings, ...productBuild.warnings],
      });
    }

    if (existingSkus.has(sku)) {
      if (input.mode === "add_only") {
        return buildClassifiedRow({
          rowNumber: row.rowNumber,
          status: "skipped_existing",
          wouldInsert: false,
          normalized,
          productInput: productBuild.productInput,
          errorCode: "existing_sku",
          errorMessage: "SKU already exists in catalog_products",
          warnings: [...duplicateWarnings, ...productBuild.warnings],
        });
      }

      return buildClassifiedRow({
        rowNumber: row.rowNumber,
        status: "updated",
        wouldInsert: false,
        normalized,
        productInput: productBuild.productInput,
        warnings: [...duplicateWarnings, ...productBuild.warnings],
      });
    }

    return buildClassifiedRow({
      rowNumber: row.rowNumber,
      status: "inserted",
      wouldInsert: true,
      normalized,
      productInput: productBuild.productInput,
      warnings: [...duplicateWarnings, ...productBuild.warnings],
    });
  });
}

export function summarizeClassifiedRows(
  rows: ClassifiedCatalogImportRow[],
  mode: CatalogImportMode,
  deletedCount = 0
): CatalogImportSummary {
  void mode;
  return {
    totalRows: rows.length,
    insertedCount: rows.filter((row) => row.status === "inserted").length,
    updatedCount: rows.filter((row) => row.status === "updated").length,
    deletedCount,
    skippedExistingCount: rows.filter((row) => row.status === "skipped_existing").length,
    skippedDuplicateCount: rows.filter((row) => row.status === "skipped_duplicate").length,
    skippedMissingSkuCount: rows.filter((row) => row.status === "skipped_missing_sku").length,
    invalidCount: rows.filter((row) => row.status === "invalid").length,
    failedCount: rows.filter((row) => row.status === "failed").length,
  };
}

export function toSampleRows(
  rows: ClassifiedCatalogImportRow[],
  limit = CSV_IMPORT_SAMPLE_ROWS
): CatalogImportSampleRow[] {
  return rows.slice(0, limit).map((row) => ({
    rowNumber: row.rowNumber,
    status: row.status,
    wouldInsert: row.wouldInsert,
    sku: row.sku,
    name: readCatalogProductDisplayName(row.normalized),
    barcodeOrGlobalId: row.normalized.barcodeOrGlobalId,
    suggestedSupplierArticle: row.suggestedSupplierArticle,
    internalSkuSuffix: row.internalSkuSuffix,
    regularPrice: row.normalized.regularPrice,
    salePrice: row.normalized.salePrice,
    catalogProductId: row.catalogProductId,
    errorCode: row.errorCode,
    errorMessage: row.errorMessage,
    warningCode: row.warningCode,
    warningMessage: row.warningMessage,
  }));
}

export function buildValidationReport(
  rows: ClassifiedCatalogImportRow[],
  columnMapping: CsvColumnMappingAnalysis
) {
  const missingRequiredColumns = ["name"].filter((field) =>
    columnMapping.missingImportantColumns.includes(
      field as CsvColumnMappingAnalysis["missingImportantColumns"][number]
    )
  );

  return {
    requiredColumns: CSV_REQUIRED_COLUMNS,
    missingRequiredColumns,
    headers: columnMapping.headers,
    columnMapping,
    recognizedColumns: columnMapping.recognizedColumns,
    unknownColumns: columnMapping.unknownColumns,
    unknownColumnCount: columnMapping.unknownColumnCount,
    ambiguousColumns: columnMapping.ambiguousColumns,
    warnings: [
      ...columnMapping.warnings.map((message) => ({
        rowNumber: null,
        sku: null,
        name: null,
        sourceProductId: null,
        status: null,
        code: "column_mapping_warning",
        message,
      })),
      ...rows.flatMap((row) => row.warnings),
    ],
    errorRows: rows
      .filter((row) => row.errorCode !== null)
      .map((row) => ({
        rowNumber: row.rowNumber,
        sku: row.sku,
        name: readCatalogProductDisplayName(row.normalized),
        sourceProductId: row.normalized.sourceProductId,
        status: row.status,
        code: row.errorCode ?? "invalid",
        message: row.errorMessage ?? "CSV row invalid",
      })),
  };
}

function buildClassifiedRow(input: {
  rowNumber: number;
  status: ClassifiedCatalogImportRow["status"];
  wouldInsert: boolean;
  normalized: ClassifiedCatalogImportRow["normalized"];
  productInput?: NewCatalogProduct | null;
  errorCode?: string | null;
  errorMessage?: string | null;
  warnings?: CatalogImportValidationIssue[];
}): ClassifiedCatalogImportRow {
  const parsedSku = input.normalized.sku !== null ? parseWooSku(input.normalized.sku) : null;
  const skuWarning = getSkuFormatWarning(input.normalized.sku);
  const warnings = [...(input.warnings ?? [])];

  if (skuWarning.warningCode !== null) {
    warnings.push(
      buildValidationIssue({
        rowNumber: input.rowNumber,
        normalized: input.normalized,
        status: input.status,
        code: skuWarning.warningCode,
        message: skuWarning.warningMessage ?? "CSV row warning",
      })
    );
  }

  return {
    rowNumber: input.rowNumber,
    status: input.status,
    wouldInsert: input.wouldInsert,
    sku: input.normalized.sku,
    normalized: input.normalized,
    parsedSku,
    suggestedSupplierArticle: parsedSku?.supplierArticleCandidate ?? null,
    internalSkuSuffix: parsedSku?.internalSuffix ?? null,
    productInput: input.productInput ?? null,
    catalogProductId: null,
    errorCode: input.errorCode ?? null,
    errorMessage: input.errorMessage ?? null,
    warningCode: warnings[0]?.code ?? null,
    warningMessage: warnings[0]?.message ?? null,
    warnings,
    rawRow: null,
  };
}

function buildCatalogProductInput(
  normalized: ClassifiedCatalogImportRow["normalized"],
  rowNumber: number
): ProductBuildResult {
  if (normalized.sku === null) {
    return {
      productInput: null,
      errorCode: "missing_sku",
      errorMessage: "SKU is required for catalog import",
      warnings: [],
    };
  }

  const warnings: CatalogImportValidationIssue[] = [];

  const rawNameFallback = readRawProductNameFallback(normalized);
  const name = normalized.name ?? rawNameFallback ?? buildFallbackCatalogProductName(normalized);
  if (normalized.name === null && rawNameFallback === null) {
    warnings.push(
      buildValidationIssue({
        rowNumber,
        normalized,
        status: null,
        code: "missing_name",
        message: "A terméknév hiányzik. A sor SKU-alapú helyettesítő névvel importálódik.",
      })
    );
  }

  if (normalized.type !== null && !SUPPORTED_WOO_PRODUCT_TYPES.has(normalized.type)) {
    warnings.push(
      buildValidationIssue({
        rowNumber,
        normalized,
        status: null,
        code: "unsupported_type",
        message: `Ismeretlen WooCommerce terméktípus: ${normalized.type}. A sor így is importálódik.`,
      })
    );
  }

  if (
    normalized.type === "variation" &&
    normalized.sourceParentId === null &&
    normalized.parentSku === null
  ) {
    warnings.push(
      buildValidationIssue({
        rowNumber,
        normalized,
        status: null,
        code: "missing_variation_parent",
        message: "Variáció szülő termék nélkül. A sor így is importálódik.",
      })
    );
  }

  const regularPrice = normalizeDecimalString(normalized.regularPrice, "regular_price");
  const salePrice = normalizeDecimalString(normalized.salePrice, "sale_price");
  const currentPrice = normalizeDecimalString(normalized.currentPrice, "current_price");
  const stockQuantity = normalizeDecimalString(normalized.stockQuantity, "stock_quantity");
  const invalidDecimals = [regularPrice, salePrice, currentPrice, stockQuantity].filter(
    (field) => field.errorCode !== null
  );
  warnings.push(
    ...invalidDecimals.map((field) =>
      buildValidationIssue({
        rowNumber,
        normalized,
        status: null,
        code: field.errorCode ?? "invalid_decimal",
        message: `${labelDecimalField(field.errorCode)} hibás szám, ezért ez az érték üresen marad.`,
      })
    )
  );

  const parsedSku = parseWooSku(normalized.sku);

  return {
    productInput: {
      sourcePlatform: "woocommerce_csv",
      sourceProductId: normalized.sourceProductId,
      sourceParentId: normalized.sourceParentId,
      sourceVariationId:
        normalized.sourceVariationId ??
        (normalized.type === "variation" ? normalized.sourceProductId : null),
      sku: normalized.sku,
      barcodeOrGlobalId: normalized.barcodeOrGlobalId,
      suggestedSupplierArticle: parsedSku.supplierArticleCandidate,
      internalSkuSuffix: parsedSku.internalSuffix,
      type: normalized.type,
      name,
      publishedStatus: normalized.publishedStatus,
      catalogVisibility: normalized.catalogVisibility,
      permalink: normalized.permalink,
      categories: normalized.categories,
      tags: normalized.tags,
      attributes: normalized.attributes,
      regularPrice: regularPrice.value,
      salePrice: salePrice.value,
      currentPrice: currentPrice.value ?? salePrice.value ?? regularPrice.value,
      stockStatus: normalized.stockStatus,
      stockQuantity: stockQuantity.value,
      parentSku: normalized.parentSku,
      rawRow: null,
    },
    errorCode: null,
    errorMessage: null,
    warnings,
  };
}

function buildFallbackCatalogProductName(
  normalized: ClassifiedCatalogImportRow["normalized"]
): string {
  return `Név nélküli termék (${normalized.sku ?? normalized.sourceProductId ?? "ismeretlen"})`;
}

function buildValidationIssue(input: {
  rowNumber: number;
  normalized: ClassifiedCatalogImportRow["normalized"];
  status: CatalogImportValidationIssue["status"];
  code: string;
  message: string;
}): CatalogImportValidationIssue {
  return {
    rowNumber: input.rowNumber,
    sku: input.normalized.sku,
    name: readCatalogProductDisplayName(input.normalized),
    sourceProductId: input.normalized.sourceProductId,
    status: input.status,
    code: input.code,
    message: input.message,
  };
}

function readCatalogProductDisplayName(
  normalized: ClassifiedCatalogImportRow["normalized"]
): string | null {
  return normalized.name ?? readRawProductNameFallback(normalized) ?? null;
}

function readRawProductNameFallback(
  normalized: ClassifiedCatalogImportRow["normalized"]
): string | null {
  for (const [header, value] of Object.entries(normalized.rawRow)) {
    if (!PRODUCT_NAME_FALLBACK_HEADERS.has(normalizeCsvHeader(header))) continue;
    const trimmed = typeof value === "string" ? value.trim() : String(value ?? "").trim();
    if (trimmed.length > 0) return trimmed;
  }
  return null;
}

function labelDecimalField(errorCode: string | null): string {
  switch (errorCode) {
    case "invalid_regular_price":
      return "A normál ár";
    case "invalid_sale_price":
      return "Az akciós ár";
    case "invalid_current_price":
      return "Az aktuális ár";
    case "invalid_stock_quantity":
      return "A készlet mennyiség";
    default:
      return "Egy szám mező";
  }
}

function normalizeDecimalString(value: string | null | undefined, fieldName: string): DecimalValue {
  if (value === null || value === undefined) {
    return { value: null, errorCode: null, errorMessage: null };
  }

  const normalized = value.trim().replace(/\s+/g, "").replace(",", ".");

  if (!/^-?\d+(\.\d+)?$/.test(normalized)) {
    return {
      value: null,
      errorCode: `invalid_${fieldName}`,
      errorMessage: `${fieldName} must be a decimal number`,
    };
  }

  return { value: normalized, errorCode: null, errorMessage: null };
}

function trimRawRecord(record: Record<string, unknown>): Record<string, unknown> {
  const trimmed: Record<string, unknown> = {};

  for (const [key, value] of Object.entries(record)) {
    const trimmedKey = key.trim();
    trimmed[trimmedKey] = typeof value === "string" ? value.trim() : value;
  }

  return trimmed;
}

function getSkuFormatWarning(sku: string | null): {
  warningCode: string | null;
  warningMessage: string | null;
} {
  if (sku === null) return { warningCode: null, warningMessage: null };

  const underscoreCount = [...sku].filter((character) => character === "_").length;
  if (underscoreCount !== 1 || sku.startsWith("_") || sku.endsWith("_")) {
    return {
      warningCode: "sku_format_warning",
      warningMessage: "SKU should follow supplier_article_internal_suffix pattern",
    };
  }

  return { warningCode: null, warningMessage: null };
}

function collectCandidateSkus(
  rows: ParsedCatalogCsvRow[],
  columnMapping: CsvColumnMappingAnalysis
): string[] {
  return Array.from(
    new Set(
      rows
        .map((row) => normalizeWooCsvRow(row.rawRow, columnMapping).sku)
        .filter((sku): sku is string => sku !== null)
    )
  );
}

async function insertClassifiedProducts(
  repository: CatalogImportRepository,
  importRunId: string,
  rows: ClassifiedCatalogImportRow[]
): Promise<void> {
  const now = new Date();

  for (const row of rows) {
    if (row.status !== "inserted" || row.productInput === null) {
      continue;
    }

    const insertedProduct = await repository.insertCatalogProductAddOnly({
      ...row.productInput,
      firstImportRunId: importRunId,
      lastImportRunId: importRunId,
      lastSeenInImportAt: now,
    });

    if (insertedProduct === null) {
      row.status = "skipped_existing";
      row.wouldInsert = false;
      row.catalogProductId = null;
      row.errorCode = "existing_sku_conflict";
      row.errorMessage = "SKU already exists in catalog_products";
      continue;
    }

    row.catalogProductId = insertedProduct.id;
    row.wouldInsert = false;
  }
}

async function upsertClassifiedProducts(
  repository: CatalogImportRepository,
  importRunId: string,
  rows: ClassifiedCatalogImportRow[]
): Promise<void> {
  const now = new Date();

  for (const row of rows) {
    if ((row.status !== "inserted" && row.status !== "updated") || row.productInput === null) {
      continue;
    }

    const product = await repository.upsertCatalogProductFromCsv({
      ...row.productInput,
      firstImportRunId: importRunId,
      lastImportRunId: importRunId,
      lastSeenInImportAt: now,
      updatedAt: now,
    });

    row.catalogProductId = product.id;
    row.wouldInsert = false;
  }
}

function toImportRows(importRunId: string, rows: ClassifiedCatalogImportRow[]) {
  return rows.map((row) => ({
    catalogImportRunId: importRunId,
    rowNumber: row.rowNumber,
    status: row.status,
    sku: row.sku,
    sourceProductId: row.normalized.sourceProductId,
    parsedName: readCatalogProductDisplayName(row.normalized),
    parsedType: row.normalized.type,
    suggestedSupplierArticle: row.suggestedSupplierArticle,
    internalSkuSuffix: row.internalSkuSuffix,
    catalogProductId: row.catalogProductId,
    errorCode: row.errorCode,
    errorMessage: row.errorMessage,
    warningCode: row.warningCode,
    warningMessage: row.warningMessage,
    rawRow: null,
  }));
}
