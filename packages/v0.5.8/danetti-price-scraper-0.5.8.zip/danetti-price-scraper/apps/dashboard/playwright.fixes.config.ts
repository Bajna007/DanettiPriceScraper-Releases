import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./e2e",
  testMatch: ["label-diagram-fixes.spec.ts", "label-controls.spec.ts"],
  workers: 1,
  retries: 0,
  timeout: 60_000,
  expect: { timeout: 10_000 },
  use: {
    baseURL: process.env.DANETTI_FIXES_URL ?? "http://localhost:3001",
    trace: "off",
    actionTimeout: 10000,
  },
});
