"use client";

import { useEffect, useLayoutEffect, useMemo, useRef, useState, type Ref } from "react";
import { ErrorState, LoadingState } from "../../../src/components/States";
import {
  ColumnResizer,
  SortButton,
  useColumnResize,
  useStoredColumnWidths,
} from "../../../src/components/SheetHeader";
import { compareTableValues } from "@danetti/shared";
import { TablePagination } from "../../../src/components/TablePagination";
import {
  formatSupplierWarnings,
  normalizeSupplierDisplayStatus,
  type SupplierDisplayStatus,
} from "@danetti/shared";
import {
  autoPairDvgProducts,
  cancelDvgManualBatch,
  continueDvgManualBatch,
  formatApiErrorMessage,
  getCurrentDvgManualBatch,
  getDvgManualBatch,
  getDvgManualBatchProgress,
  getSavedDvgManualBatchState,
  listSupplierMappings,
  listSuppliers,
  saveDvgOperatorPreferences,
  startDvgManualBatch,
  type DvgAutoPairResponse,
  type DvgOperatorPreferences,
  type DvgManualBatchRow,
  type DvgManualBatchSpeedMode,
  type DvgManualBatchProgress,
  type DvgManualBatchState,
  type Supplier,
  type SupplierMapping,
} from "../../../src/lib/api";

const ALL_DVG_BATCH_LIMIT = 10_000;
const MAPPING_PAGE_SIZE = 200;
const RUN_STORAGE_KEY = "danetti:dvg-operator-active-run-id";
const DVG_RESULT_COLUMN_STORAGE_KEY = "danetti:dvg-results:columns";
const DVG_RECOVERY_AFTER_TIMEOUTS = 0;
const INITIAL_API_LOAD_ATTEMPTS = 6;
const INITIAL_API_RETRY_WAIT_MS = 1_250;
const CLOAKBROWSER_MANAGER_URL =
  process.env.NEXT_PUBLIC_CLOAKBROWSER_MANAGER_URL ?? "http://127.0.0.1:18080";
const DVG_TABLE_PAGE_SIZE = 50;
type OperatorNotice = { message: string; tone: "info" | "success" | "warning" | "error" };

const speedModeOptions: Array<{
  value: DvgManualBatchSpeedMode;
  label: string;
  help?: string;
}> = [
  {
    value: "normal",
    label: "Normál",
    help: "Rövid biztonsági tempó; hibás tételnél gyorsan továbblép.",
  },
  {
    value: "fast",
    label: "Gyors",
    help: "Nincs szándékos várakozás két DVG tétel között.",
  },
  {
    value: "very_fast",
    label: "Nagyon gyors",
    help: "Nincs szándékos várakozás két termék között.",
  },
];

const dvgResultColumns = [
  { id: "status", label: "Státusz", width: 156, minWidth: 124 },
  { id: "sku", label: "SKU", width: 170, minWidth: 120 },
  { id: "name", label: "Termék", width: 360, minWidth: 220 },
  { id: "article", label: "DVG cikkszám", width: 160, minWidth: 120 },
  { id: "supplierNetEur", label: "DVG nettó EUR", width: 132, minWidth: 112, numeric: true },
  { id: "supplierNetHuf", label: "Beszerzés nettó HUF", width: 170, minWidth: 130, numeric: true },
  { id: "wooGrossHuf", label: "Jelenlegi Woo bruttó", width: 170, minWidth: 130, numeric: true },
  { id: "wooNetHuf", label: "Jelenlegi Woo nettó", width: 160, minWidth: 124, numeric: true },
  { id: "profitHuf", label: "Tiszta profit HUF", width: 158, minWidth: 124, numeric: true },
  { id: "profitPercent", label: "Haszon %", width: 112, minWidth: 92, numeric: true },
  { id: "warnings", label: "Figyelmeztetés", width: 280, minWidth: 180 },
] as const;

type DvgResultColumnId = (typeof dvgResultColumns)[number]["id"];

type LiveStatus = {
  headline: string;
  phase: string;
  badgeTone: string;
  detail: string;
  fields: Array<{ label: string; value: string }>;
};

type OperatorGuidance = {
  title: string;
  body: string;
  badge: string;
  tone: "success" | "warning" | "danger" | "muted";
};

type WorkbenchStatusTile = {
  label: string;
  value: number;
  detail: string;
  tone: "success" | "warning" | "danger" | "muted";
};

const defaultDvgResultColumnWidths = dvgResultColumns.reduce(
  (widths, column) => ({ ...widths, [column.id]: column.width }),
  {} as Record<DvgResultColumnId, number>
);

const defaultDvgResultColumnVisibility = dvgResultColumns.reduce(
  (visibility, column) => ({ ...visibility, [column.id]: true }),
  {} as Record<DvgResultColumnId, boolean>
);

const fixedDvgResultColumnIds = new Set<DvgResultColumnId>(["status", "name"]);

const terminalStatuses = new Set([
  "completed",
  "cancelled",
  "login_timeout",
  "detached_session_failed",
  "failed",
  "security_stopped",
  "session_lost",
  "interrupted",
]);

const fallbackDvgSupplier: Supplier = {
  id: "dvg-devecchi",
  code: "DVG",
  name: "DVG De Vecchi",
  baseUrl: "https://devecchigiuseppesrl.com",
  enabled: true,
  allowedDomains: ["devecchigiuseppesrl.com"],
  supportedLookupStrategies: ["direct_url_authenticated"],
  defaultRateLimitPerMinute: 6,
  healthStatus: "unknown",
  lastSuccessAt: null,
  lastFailureAt: null,
  createdAt: "",
  updatedAt: "",
};

export default function DvgOperatorPage() {
  const [supplier, setSupplier] = useState<Supplier>(fallbackDvgSupplier);
  const [mappings, setMappings] = useState<SupplierMapping[]>([]);
  const savedPreferencesRef = useRef<DvgOperatorPreferences>({ autoResume: true, vatPercent: 27 });
  const [speedMode, setSpeedMode] = useState<DvgManualBatchSpeedMode>("very_fast");
  const [rerunPreviousNonOkOnly, setRerunPreviousNonOkOnly] = useState(false);
  const [autoResume, setAutoResume] = useState(true);
  const [preferencesLoaded, setPreferencesLoaded] = useState(false);
  const [preferenceStatus, setPreferenceStatus] = useState<"saved" | "saving" | "error" | null>(
    null
  );
  const [state, setState] = useState<DvgManualBatchState | null>(null);
  const [savedProgress, setSavedProgress] = useState<DvgManualBatchProgress | null>(null);
  const [action, setAction] = useState<"start" | "continue" | "cancel" | null>(null);
  const [pairingAction, setPairingAction] = useState(false);
  const [operatorNotice, setOperatorNotice] = useState<OperatorNotice | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const liveTrackingCardRef = useRef<HTMLDivElement | null>(null);
  const terminalCardRef = useRef<HTMLDivElement | null>(null);
  const reconnectRecoveryInFlightRef = useRef(false);
  const startActionInFlightRef = useRef(false);
  const cloakBrowserManagerWindowRef = useRef<Window | null>(null);

  const active = state ? !terminalStatuses.has(state.status) : false;
  const totalMapped = mappings.length;
  const runOffset = state?.settings.offset ?? 0;
  const displayedTotal = state?.settings.rerunPreviousNonOkOnly
    ? state.settings.offset + state.totals.candidates
    : totalMapped;
  const runChecked = state ? countProgressAdvancingRows(state.rows) : 0;
  const stateProcessedOverall = Math.min(displayedTotal, runOffset + runChecked);
  const savedProcessedOverall = Math.min(displayedTotal, savedProgress?.nextOffset ?? 0);
  const processedOverall = active
    ? stateProcessedOverall
    : Math.max(stateProcessedOverall, savedProcessedOverall);
  const remainingOverall = Math.max(displayedTotal - processedOverall, 0);
  const progressPercent = displayedTotal > 0 ? (processedOverall / displayedTotal) * 100 : 0;
  const currentGlobalIndex = state?.currentItem ? runOffset + state.currentItem.index : null;
  const canStart = action === null && !active && totalMapped > 0;
  const canRestartLogin =
    action === null &&
    state !== null &&
    totalMapped > 0 &&
    runChecked === 0 &&
    ["opening_browser", "waiting_for_manual_login", "login_detected"].includes(state.status);
  const canResume =
    canStart && !rerunPreviousNonOkOnly && processedOverall > 0 && processedOverall < totalMapped;
  const canContinueCurrent =
    action === null && state !== null && state.status === "waiting_for_manual_login";
  const resultRows = state?.rows ?? [];
  const latestEvents = useMemo(() => (state?.events ?? []).slice().reverse(), [state?.events]);
  const terminalEvents = useMemo(() => state?.events ?? [], [state?.events]);
  const runTelemetry = state?.telemetry ?? null;
  const averageItemDuration = formatAverageItemDuration({ state, telemetry: runTelemetry });
  const estimatedFullRunDuration = formatEstimatedFullRunDuration({
    state,
    telemetry: runTelemetry,
    totalItems: displayedTotal,
  });
  const workbenchStatusTiles = useMemo(
    () =>
      buildWorkbenchStatusTiles({
        rows: resultRows,
        state,
        savedProgress,
      }),
    [resultRows, savedProgress, state]
  );
  const preferences = useMemo<DvgOperatorPreferences>(
    () => ({ ...savedPreferencesRef.current, autoResume }),
    [autoResume, preferencesLoaded]
  );
  const liveStatus = useMemo(
    () =>
      buildLiveStatus({
        state,
        totalMapped: displayedTotal,
        runOffset,
        currentGlobalIndex,
        latestEvents,
        resultRows,
      }),
    [currentGlobalIndex, displayedTotal, latestEvents, resultRows, runOffset, state]
  );
  const guidance = useMemo(
    () =>
      buildOperatorGuidance({
        action,
        active,
        state,
        savedProgress,
        processedOverall,
        totalMapped: displayedTotal,
      }),
    [action, active, displayedTotal, processedOverall, savedProgress, state]
  );
  useEffect(() => {
    let mounted = true;
    loadInitialDataWithRetry()
      .catch((err) => {
        if (mounted) setError(formatDvgOperatorErrorMessage(err));
      })
      .finally(() => {
        if (mounted) {
          setLoading(false);
          setOperatorNotice(null);
        }
      });

    async function loadInitialDataWithRetry() {
      let lastError: unknown = null;
      for (let attempt = 1; attempt <= INITIAL_API_LOAD_ATTEMPTS; attempt += 1) {
        try {
          await loadInitialData();
          return;
        } catch (err) {
          lastError = err;
          if (!mounted || attempt === INITIAL_API_LOAD_ATTEMPTS) break;
          showOperatorNotice(
            `Helyi API ellenőrzése... újrapróbálás ${attempt}/${INITIAL_API_LOAD_ATTEMPTS - 1}`,
            "warning"
          );
          await wait(INITIAL_API_RETRY_WAIT_MS);
        }
      }
      throw lastError;
    }

    async function loadInitialData() {
      const [supplierResponse, savedState, progress, current] = await Promise.all([
        listSuppliers({ limit: 100 }),
        getSavedDvgManualBatchState(),
        getDvgManualBatchProgress(),
        getCurrentDvgManualBatch(),
      ]);
      if (!mounted) return;

      const nextSupplier = supplierResponse.items.find(isDvgSupplier) ?? fallbackDvgSupplier;
      setSupplier(nextSupplier);
      applyOperatorPreferences(savedState.preferences);

      const nextMappings = isUuid(nextSupplier.id)
        ? await listAllSupplierMappings(nextSupplier.id)
        : [];
      if (!mounted) return;
      setMappings(nextMappings);

      setSavedProgress(progress.progress);
      if (current.run) {
        storeRunId(current.run.runId);
        setState(current.run);
        return;
      }
      if (savedState.run) {
        storeRunId(savedState.run.runId);
        setState(normalizeInactiveSavedRun(savedState.run));
        return;
      }

      const storedRunId = readStoredRunId();
      if (!storedRunId) return;
      try {
        const restored = await getDvgManualBatch(storedRunId);
        if (mounted) setState(restored);
      } catch {
        clearStoredRunId();
      }
    }

    return () => {
      mounted = false;
    };
  }, []);

  useLayoutEffect(() => {
    const trackingCard = liveTrackingCardRef.current;
    const terminalCard = terminalCardRef.current;
    if (!trackingCard || !terminalCard) return;

    let frame = 0;

    const syncTrackingHeight = () => {
      const nextHeight = terminalCard.offsetHeight;
      if (nextHeight <= 0) return;
      const height = `${nextHeight}px`;
      trackingCard.style.height = height;
      trackingCard.style.maxHeight = height;
    };

    const scheduleSync = () => {
      window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(syncTrackingHeight);
    };

    scheduleSync();

    const observer = new ResizeObserver(scheduleSync);
    observer.observe(terminalCard);
    window.addEventListener("resize", scheduleSync);

    return () => {
      window.cancelAnimationFrame(frame);
      window.removeEventListener("resize", scheduleSync);
      observer.disconnect();
      trackingCard.style.height = "";
      trackingCard.style.maxHeight = "";
    };
  }, []);

  useEffect(() => {
    if (!preferencesLoaded || preferences === null) return;
    const timer = window.setTimeout(() => {
      setPreferenceStatus("saving");
      saveDvgOperatorPreferences(preferences)
        .then(() => setPreferenceStatus("saved"))
        .catch(() => setPreferenceStatus("error"));
    }, 600);
    return () => window.clearTimeout(timer);
  }, [preferences, preferencesLoaded]);

  useEffect(() => {
    if (!state?.runId || !active) return;
    const timer = window.setInterval(() => {
      Promise.all([getDvgManualBatch(state.runId), getDvgManualBatchProgress()])
        .then(([nextState, progress]) => {
          setState(nextState);
          setSavedProgress(progress.progress);
          setError(null);
          setOperatorNotice(null);
        })
        .catch((err) => {
          if (isLocalApiUnavailableError(err)) {
            showOperatorNotice(
              "Helyi API kapcsolat megszakadt. Ellenőrzöm az aktív DVG futást; új login csak kézi folytatáskor indul.",
              "warning"
            );
          } else {
            setError(formatDvgOperatorErrorMessage(err));
          }
          void recoverAfterReconnect("poll_error");
        });
    }, 1500);
    return () => window.clearInterval(timer);
  }, [active, state?.runId]);

  useEffect(() => {
    function recoverWhenVisible() {
      if (document.visibilityState === "visible") void recoverAfterReconnect("visible");
    }
    function recoverWhenOnline() {
      showOperatorNotice("Kapcsolat visszatért. DVG futás ellenőrzése...", "info");
      void recoverAfterReconnect("online");
    }
    function recoverWhenFocused() {
      void recoverAfterReconnect("focus");
    }

    window.addEventListener("online", recoverWhenOnline);
    window.addEventListener("focus", recoverWhenFocused);
    window.addEventListener("pageshow", recoverWhenFocused);
    document.addEventListener("visibilitychange", recoverWhenVisible);
    return () => {
      window.removeEventListener("online", recoverWhenOnline);
      window.removeEventListener("focus", recoverWhenFocused);
      window.removeEventListener("pageshow", recoverWhenFocused);
      document.removeEventListener("visibilitychange", recoverWhenVisible);
    };
  }, [autoResume, processedOverall, state?.runId, totalMapped]);

  function applyOperatorPreferences(nextPreferences: DvgOperatorPreferences) {
    setAutoResume(nextPreferences.autoResume);
    savedPreferencesRef.current = nextPreferences;
    setPreferencesLoaded(true);
  }

  function showOperatorNotice(message: string, tone: OperatorNotice["tone"] = "info") {
    setOperatorNotice({ message, tone });
  }

  async function pairDvgProducts() {
    if (pairingAction || active || action !== null) return;
    setPairingAction(true);
    setError(null);
    showOperatorNotice("DVG termékek párosítása a teljes katalóguson...", "info");
    try {
      const result = await autoPairDvgProducts();
      const supplierResponse = await listSuppliers({ limit: 100 });
      const nextSupplier = supplierResponse.items.find(isDvgSupplier) ?? supplier;
      setSupplier(nextSupplier);
      const mappingSupplierId = isUuid(nextSupplier.id) ? nextSupplier.id : result.supplierId;
      setMappings(await listAllSupplierMappings(mappingSupplierId));
      showOperatorNotice(
        formatDvgAutoPairNotice(result),
        result.conflictCount > 0 ? "warning" : "success"
      );
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setPairingAction(false);
    }
  }

  async function startFullRun() {
    if (canRestartLogin && state) {
      await restartFullRun(state.runId);
      return;
    }
    await startRunAtOffset(0);
  }

  async function resumeRun() {
    await startRunAtOffset(processedOverall);
  }

  async function startRunAtOffset(offset: number) {
    if (action !== null || startActionInFlightRef.current) return;
    const runOffset = rerunPreviousNonOkOnly ? 0 : offset;
    const remaining = Math.max(totalMapped - runOffset, 0);
    if (remaining === 0) {
      setError("Nincs hátralévő DVG mapping.");
      return;
    }

    startActionInFlightRef.current = true;
    setAction(runOffset === 0 ? "start" : "continue");
    setError(null);
    setOperatorNotice(null);
    showOperatorNotice("Danetti DVG profil indítása a CloakBrowserben...", "info");
    const cloakBrowserWindowReserved = reserveCloakBrowserManagerWindow(
      cloakBrowserManagerWindowRef,
      (message) => showOperatorNotice(message, "warning")
    );
    try {
      const started = await startDvgManualBatch({
        markupPercent: 0,
        vatPercent: savedPreferencesRef.current.vatPercent,
        wooPricesIncludeVat: true,
        speedMode,
        limit: Math.min(remaining, ALL_DVG_BATCH_LIMIT),
        offset: runOffset,
        onlyMappedDvg: true,
        rerunPreviousNonOkOnly,
        allowSuggestedDvgArticle: false,
        allowSkuPrefixCandidate: false,
        dryRun: true,
        allowSnapshotWrite: false,
        recoverAfterConsecutiveTimeouts: DVG_RECOVERY_AFTER_TIMEOUTS,
        manualLoginTimeoutMs: 900_000,
      });
      storeRunId(started.runId);
      setState(started);
      showOperatorNotice(
        rerunPreviousNonOkOnly
          ? "DVG futás indítva csak az előző nem OK tételekre."
          : runOffset > 0
            ? `DVG futás kézi folytatása mentett ponttól: ${runOffset}.`
            : "DVG futás indítva. A Danetti DVG profil login oldala nyílik; sikeres login után a futás automatikusan továbbmegy.",
        "success"
      );
      openCloakBrowserManagerWindow(cloakBrowserManagerWindowRef, (message, tone) =>
        showOperatorNotice(message, tone)
      );

      void continueDvgManualBatch(started.runId)
        .then(setState)
        .catch((err) => setError(formatDvgOperatorErrorMessage(err)));
    } catch (err) {
      setError(formatDvgOperatorErrorMessage(err));
      if (isCloakBrowserError(err)) {
        openCloakBrowserManagerWindow(
          cloakBrowserManagerWindowRef,
          (message, tone) => showOperatorNotice(message, tone),
          "warning",
          "CloakBrowser Manager megnyitva. Válaszd a Danetti DVG profilt, ha nem indult el automatikusan."
        );
      } else if (cloakBrowserWindowReserved) {
        closeCloakBrowserManagerWindow(cloakBrowserManagerWindowRef);
      }
    } finally {
      startActionInFlightRef.current = false;
      setAction(null);
    }
  }

  async function recoverAfterReconnect(reason: string) {
    if (reconnectRecoveryInFlightRef.current) return;
    reconnectRecoveryInFlightRef.current = true;
    try {
      const [current, progress, savedState] = await Promise.all([
        getCurrentDvgManualBatch(),
        getDvgManualBatchProgress(),
        getSavedDvgManualBatchState(),
      ]);
      setSavedProgress(progress.progress);

      if (current.run) {
        storeRunId(current.run.runId);
        setState(current.run);
        setError(null);
        return;
      }

      const savedRun = savedState.run ? normalizeInactiveSavedRun(savedState.run) : null;
      if (savedRun) {
        storeRunId(savedRun.runId);
        setState(savedRun);
      }

      const nextOffset = readRecoveredOffset(progress.progress, savedRun, state, processedOverall);
      if (!autoResume || nextOffset >= totalMapped || nextOffset < 0) return;
      if (savedRun?.status === "security_stopped" || savedRun?.status === "completed") return;

      showOperatorNotice(
        `DVG futás megszakadt, mentett pont elérhető: ${nextOffset}. Új login/session csak a Folytatás mentett ponttól gombbal indul. (${reason})`,
        "warning"
      );
    } catch (err) {
      if (isLocalApiUnavailableError(err)) {
        showOperatorNotice(
          "Helyi API kapcsolat ellenőrzése folyamatban. A futás mentett pontból folytatható.",
          "warning"
        );
      } else {
        setError(formatDvgOperatorErrorMessage(err));
      }
    } finally {
      reconnectRecoveryInFlightRef.current = false;
    }
  }

  async function restartFullRun(runId: string) {
    setAction("start");
    setError(null);
    showOperatorNotice("Beragadt DVG futás leállítása, majd új login indítása...", "warning");
    try {
      await cancelDvgManualBatch(runId).catch(() => undefined);
      await startRunAtOffset(0);
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setAction(null);
    }
  }

  async function continueCurrentRun() {
    if (!state) return;
    setAction("continue");
    setError(null);
    try {
      setState(await continueDvgManualBatch(state.runId));
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setAction(null);
    }
  }

  useEffect(() => {
    if (!state || !["login_detected", "running", "completed"].includes(state.status)) return;
    closeCloakBrowserManagerWindow(cloakBrowserManagerWindowRef);
  }, [state?.status]);

  async function cancelRun() {
    if (!state) return;
    if (
      !window.confirm(
        "Leállítod az aktív DVG futást? A mentett pont megmarad, de folytatáshoz új DVG login kellhet."
      )
    ) {
      return;
    }
    setAction("cancel");
    setError(null);
    try {
      setState(await cancelDvgManualBatch(state.runId));
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setAction(null);
    }
  }

  if (loading) return <LoadingState message="DVG operátor betöltése..." />;

  return (
    <div className="page dvg-operator-page">
      {error ? <ErrorState message={error} /> : null}
      {operatorNotice ? (
        <div className={`notice ${operatorNotice.tone} dvg-operator-notice`}>
          {operatorNotice.message}
        </div>
      ) : null}

      <section className="dvg-cockpit" aria-labelledby="dvg-cockpit-title">
        <div className="dvg-cockpit-header">
          <div className="dvg-cockpit-title-block">
            <p className="dvg-kicker">DVG operátor</p>
            <h1 className="page-title" id="dvg-cockpit-title">
              DVG profit futás
            </h1>
          </div>
        </div>

        <div className="dvg-operator-card dvg-settings-band">
          <div className="dvg-card-heading">
            <span>Indítási beállítások</span>
          </div>
          <div className="form-grid dvg-settings-grid">
            <label className="field-label">
              Sebesség
              <select
                className="input"
                value={speedMode}
                onChange={(event) => setSpeedMode(event.target.value as DvgManualBatchSpeedMode)}
                disabled={active || action !== null}
              >
                {speedModeOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              {speedModeOptions.find((option) => option.value === speedMode)?.help ? (
                <span className="field-help">
                  {speedModeOptions.find((option) => option.value === speedMode)?.help}
                </span>
              ) : null}
            </label>
            <div className="field-label">
              Újrafuttatás
              <label className="supplier-changes-toggle">
                <input
                  type="checkbox"
                  checked={rerunPreviousNonOkOnly}
                  disabled={active || action !== null}
                  onChange={(event) => setRerunPreviousNonOkOnly(event.target.checked)}
                />
                <span>Csak előző nem OK tételek</span>
              </label>
              <span className="field-help">OK státuszú és még sosem futott mapping kimarad.</span>
            </div>
            <div className="supplier-pairing-field">
              <div className="supplier-pairing-panel">
                <div className="supplier-pairing-copy">
                  <span className="supplier-pairing-eyebrow">Termékpárosító</span>
                  <strong>DVG termékek párosítása</strong>
                  <span>
                    Szám-betű-szám cikkszámokra direct DVG URL-t és beszállítói mappinget ment.
                  </span>
                </div>
                <div className="supplier-pairing-actions">
                  <button
                    className="button"
                    type="button"
                    onClick={pairDvgProducts}
                    disabled={pairingAction || active || action !== null}
                  >
                    {pairingAction ? "Párosítás..." : "DVG termékek párosítása"}
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className="dvg-settings-actions">
            <span>
              {preferenceStatus === "saving"
                ? "Beállítás mentése..."
                : preferenceStatus === "error"
                  ? "Beállítás mentés hiba"
                  : "Módosítás után automatikusan mentve"}
            </span>
          </div>
        </div>

        <div className="dvg-action-grid">
          <div className="dvg-operator-card dvg-next-action-card">
            <div className="dvg-card-heading">
              <span>Következő lépés</span>
              <strong>{guidance.title}</strong>
            </div>
            <p>{guidance.body}</p>
            {rerunPreviousNonOkOnly ? (
              <p className="dvg-run-note">
                Bekapcsolva: indításkor csak az előző DVG futásban nem OK státuszú mentett mappingek
                kerülnek sorra.
              </p>
            ) : null}
            <div className="dvg-action-row dvg-action-row--primary">
              <button
                className="button"
                onClick={startFullRun}
                disabled={!canStart && !canRestartLogin}
              >
                {action === "start"
                  ? "CloakBrowser nyitása..."
                  : canRestartLogin
                    ? "DVG login újranyitása"
                    : "DVG bejelentkezés + összes futtatás"}
              </button>
              <button className="button secondary" onClick={resumeRun} disabled={!canResume}>
                {action === "continue" ? "Folytatás indítása..." : "Folytatás mentett ponttól"}
              </button>
              {canContinueCurrent ? (
                <button
                  className="button secondary"
                  onClick={continueCurrentRun}
                  disabled={action !== null}
                >
                  Login után folytatás
                </button>
              ) : null}
              {active ? (
                <button className="button secondary" onClick={cancelRun} disabled={action !== null}>
                  {action === "cancel" ? "Leállítás..." : "Futás leállítása"}
                </button>
              ) : null}
            </div>
          </div>

          <div className="dvg-operator-card dvg-login-state-card">
            <span className={`badge ${guidance.tone}`}>{guidance.badge}</span>
            <strong>{labelRunStatus(state?.status ?? "not_started")}</strong>
            <span>
              {processedOverall}/{displayedTotal || 0} mentve
            </span>
            <small>{liveStatus.detail}</small>
          </div>
        </div>

        <div className="dvg-live-terminal-grid">
          <div className="dvg-operator-card dvg-live-tracking-card" ref={liveTrackingCardRef}>
            <div className="dvg-live-tracking-content">
              <div className="dvg-workbench-topline">
                <div>
                  <span>Futás állapota</span>
                  <strong>{progressPercent.toFixed(1)}%</strong>
                </div>
                <div className="dvg-workbench-counters" aria-label="DVG futás számlálók">
                  <span>
                    {processedOverall}/{displayedTotal || 0} mentve
                  </span>
                  <span>{remainingOverall} hátra</span>
                  <span>offset {savedProgress?.nextOffset ?? runOffset}</span>
                  <span>mentve {formatDateTime(savedProgress?.updatedAt ?? null)}</span>
                </div>
              </div>
              <div
                className="dvg-progress-track"
                role="progressbar"
                aria-label="DVG feldolgozási arány"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Math.round(Math.min(progressPercent, 100))}
              >
                <div
                  className="dvg-progress-fill"
                  style={{ width: `${Math.min(progressPercent, 100)}%` }}
                />
                <span className="dvg-progress-scan" />
              </div>
              <div className="dvg-workbench-command">
                <span className={`badge ${liveStatus.badgeTone}`}>{liveStatus.phase}</span>
                <strong>{liveStatus.headline}</strong>
                <code>{labelRunStatus(state?.status ?? "not_started")}</code>
              </div>

              <div className="dvg-workbench-main">
                <section className="dvg-active-target" aria-label="Aktuális DVG célpont">
                  <div className="dvg-active-target-identity">
                    <span>Aktuális célpont</span>
                    <strong>
                      {state?.currentItem?.supplierArticleNumber ?? "nincs aktív tétel"}
                    </strong>
                    <code>{state?.currentItem?.wooSku ?? "-"}</code>
                    <p>
                      {state?.currentItem?.wooName ??
                        "Indítás után itt látszik az éppen olvasott DVG termék."}
                    </p>
                  </div>
                  <div className="dvg-active-target-runtime">
                    <CockpitFact label="Run" value={readLiveField(liveStatus, "Run idő")} />
                    <CockpitFact label="Tétel" value={readLiveField(liveStatus, "Tétel idő")} />
                    <CockpitFact label="Átlag/tétel" value={averageItemDuration} />
                    <CockpitFact label="Teljes becslés" value={estimatedFullRunDuration} />
                    <CockpitFact label="Következő" value={readLiveField(liveStatus, "Következő")} />
                  </div>
                </section>

                <section className="dvg-status-board" aria-label="DVG státusz bontás">
                  <div className="dvg-status-board-header">
                    <span>Státusz bontás</span>
                    <strong>{runChecked || savedProgress?.checked || 0} sor</strong>
                  </div>
                  <div className="dvg-status-tiles">
                    {workbenchStatusTiles.map((tile) => (
                      <WorkbenchStatusTileView key={tile.label} tile={tile} />
                    ))}
                  </div>
                </section>
              </div>

              <div className="dvg-workbench-telemetry" aria-label="DVG futás telemetria">
                <CockpitMetric label="Fetch" value={runTelemetry?.detailFetchCompleted ?? 0} />
                <CockpitMetric
                  label="Átlag"
                  value={formatMilliseconds(runTelemetry?.avgDetailFetchMs ?? null)}
                />
                <CockpitMetric
                  label="P95"
                  value={formatMilliseconds(runTelemetry?.p95DetailFetchMs ?? null)}
                />
                <CockpitMetric
                  label="/perc"
                  value={formatRate(runTelemetry?.itemsPerMinute ?? null)}
                />
                <CockpitMetric label="Recovery" value={runTelemetry?.sessionRecoveries ?? 0} />
                <CockpitMetric label="Pacing" value={runTelemetry?.rateLimitWaits ?? 0} />
              </div>
            </div>
          </div>

          <TerminalLog events={terminalEvents} cardRef={terminalCardRef} />
        </div>
      </section>

      {resultRows.length > 0 ? <ResultsTable rows={resultRows} /> : null}
    </div>
  );
}

function WorkbenchStatusTileView({ tile }: { tile: WorkbenchStatusTile }) {
  return (
    <div className={`dvg-status-tile ${tile.tone}`}>
      <span>{tile.label}</span>
      <strong>{tile.value}</strong>
      <small>{tile.detail}</small>
    </div>
  );
}

function CockpitMetric({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="dvg-cockpit-metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function CockpitFact({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="dvg-current-fact">
      <span>{label}</span>
      <strong className={tone ? `badge ${tone}` : undefined}>{value}</strong>
    </div>
  );
}

function ResultsTable({ rows }: { rows: DvgManualBatchRow[] }) {
  const [columnWidths, setColumnWidths] = useStoredColumnWidths(
    "danetti:dvg:column-widths",
    dvgResultColumns
  );
  const [columnVisibility, setColumnVisibility] = useState(readStoredDvgResultColumnVisibility);
  const [columnMenuOpen, setColumnMenuOpen] = useState(false);
  const [offset, setOffset] = useState(0);
  const columnOptions = useMemo(
    () => dvgResultColumns.filter((column) => !fixedDvgResultColumnIds.has(column.id)),
    []
  );
  const visibleColumns = useMemo(
    () => dvgResultColumns.filter((column) => columnVisibility[column.id] !== false),
    [columnVisibility]
  );
  const visibleOptionalColumnCount = useMemo(
    () => columnOptions.filter((column) => columnVisibility[column.id] !== false).length,
    [columnOptions, columnVisibility]
  );
  const totalTableWidth = useMemo(
    () => visibleColumns.reduce((total, column) => total + columnWidths[column.id], 0),
    [columnWidths, visibleColumns]
  );
  const [sort, setSort] = useState<{ id: DvgResultColumnId; direction: "asc" | "desc" } | null>(
    null
  );
  const sortedRows = useMemo(
    () =>
      sort
        ? [...rows].sort((a, b) =>
            compareTableValues(
              readDvgSortValue(a, sort.id),
              readDvgSortValue(b, sort.id),
              sort.direction
            )
          )
        : rows,
    [rows, sort]
  );
  const pageRows = sortedRows.slice(offset, offset + DVG_TABLE_PAGE_SIZE);
  const canGoBack = offset > 0;
  const canGoNext = offset + pageRows.length < rows.length;
  const paginationLabel = buildLocalPaginationLabel(rows.length, offset, pageRows.length);

  useEffect(() => {
    if (rows.length === 0 && offset !== 0) {
      setOffset(0);
      return;
    }
    if (rows.length > 0 && offset >= rows.length) {
      setOffset(Math.floor((rows.length - 1) / DVG_TABLE_PAGE_SIZE) * DVG_TABLE_PAGE_SIZE);
    }
  }, [offset, rows.length]);

  const beginColumnResize = useColumnResize(columnWidths, setColumnWidths, dvgResultColumns);

  function toggleColumn(columnId: DvgResultColumnId, visible: boolean) {
    setColumnVisibility((current) => {
      const next = { ...current, [columnId]: visible };
      storeDvgResultColumnVisibility(next);
      return next;
    });
  }

  function showAllColumns() {
    setColumnVisibility(defaultDvgResultColumnVisibility);
    storeDvgResultColumnVisibility(defaultDvgResultColumnVisibility);
  }

  return (
    <section className="card table-card dvg-results-card">
      <div className="table-toolbar product-table-toolbar dvg-table-header">
        <div>
          <p className="card-title">Profit táblázat</p>
          <h2 className="section-title">DVG eredmények</h2>
        </div>
        <TablePagination
          canGoBack={canGoBack}
          canGoNext={canGoNext}
          label={paginationLabel}
          onBack={() => setOffset(Math.max(0, offset - DVG_TABLE_PAGE_SIZE))}
          onNext={() => setOffset(offset + DVG_TABLE_PAGE_SIZE)}
          compact
        />
        <div
          className="product-view-controls dvg-table-actions"
          role="group"
          aria-label="DVG eredmény nézet"
        >
          <span className="badge muted">{rows.length} sor</span>
          <div className="column-menu-wrap dvg-column-menu-wrap">
            <button
              className="button secondary product-column-menu-button"
              type="button"
              aria-expanded={columnMenuOpen}
              onClick={() => setColumnMenuOpen((current) => !current)}
            >
              Oszlopok ({visibleOptionalColumnCount}/{columnOptions.length})
            </button>
            {columnMenuOpen ? (
              <div className="column-menu" role="menu">
                <div className="column-menu-header">
                  <strong>Oszlopok megjelenítése</strong>
                  <button className="button small secondary" type="button" onClick={showAllColumns}>
                    Mind vissza
                  </button>
                </div>
                {columnOptions.map((column) => (
                  <label className="column-toggle" key={column.id}>
                    <input
                      type="checkbox"
                      checked={columnVisibility[column.id] !== false}
                      onChange={(event) => toggleColumn(column.id, event.target.checked)}
                    />
                    <span>{column.label}</span>
                  </label>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      </div>
      <div className="table-scroll dvg-table-scroll">
        <table
          className="table data-table data-table--wide dvg-profit-table data-table--sheet"
          style={{ width: totalTableWidth, minWidth: totalTableWidth }}
        >
          <colgroup>
            {visibleColumns.map((column) => (
              <col key={column.id} style={{ width: columnWidths[column.id] }} />
            ))}
          </colgroup>
          <thead>
            <tr>
              {visibleColumns.map((column) => (
                <th
                  className={`resizable-header cell-nowrap ${"numeric" in column && column.numeric ? "numeric" : ""}`}
                  key={column.id}
                  aria-sort={
                    sort?.id === column.id
                      ? sort.direction === "asc"
                        ? "ascending"
                        : "descending"
                      : "none"
                  }
                >
                  <SortButton
                    label={column.label}
                    direction={sort?.id === column.id ? sort.direction : undefined}
                    onClick={() => {
                      setOffset(0);
                      setSort({
                        id: column.id,
                        direction:
                          sort?.id === column.id && sort.direction === "asc" ? "desc" : "asc",
                      });
                    }}
                  />
                  <ColumnResizer
                    label={column.label}
                    width={columnWidths[column.id]}
                    minWidth={column.minWidth}
                    onResize={(event) => beginColumnResize(column.id, event)}
                    onWidth={(width) =>
                      setColumnWidths((current) => ({ ...current, [column.id]: width }))
                    }
                  />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((row) => (
              <tr key={`${row.catalogProductId}-${row.supplierArticleNumber}`}>
                {visibleColumns.map((column) => renderDvgResultCell(row, column.id))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <TablePagination
        canGoBack={canGoBack}
        canGoNext={canGoNext}
        label={paginationLabel}
        onBack={() => setOffset(Math.max(0, offset - DVG_TABLE_PAGE_SIZE))}
        onNext={() => setOffset(offset + DVG_TABLE_PAGE_SIZE)}
      />
    </section>
  );
}

function renderDvgResultCell(row: DvgManualBatchRow, columnId: DvgResultColumnId) {
  switch (columnId) {
    case "status": {
      const statusInfo = dvgRowStatusInfo(row);
      return (
        <td key={columnId}>
          <span className={`badge ${statusInfo.tone}`}>{statusInfo.label}</span>
        </td>
      );
    }
    case "sku":
      return (
        <td className="cell-mono cell-nowrap" key={columnId}>
          {row.wooSku}
        </td>
      );
    case "name":
      return (
        <td className="cell-wrap" key={columnId}>
          {row.wooName}
        </td>
      );
    case "article":
      return (
        <td className="cell-mono cell-nowrap" key={columnId}>
          {row.supplierArticleNumber}
        </td>
      );
    case "supplierNetEur":
      return (
        <td className="numeric" key={columnId}>
          {formatMoney(row.supplierNetEur, row.currency)}
        </td>
      );
    case "supplierNetHuf":
      return (
        <td className="numeric" key={columnId}>
          {formatHuf(row.supplierNetHuf)}
        </td>
      );
    case "wooGrossHuf":
      return (
        <td className="numeric" key={columnId}>
          {formatHuf(row.wooGrossHuf)}
        </td>
      );
    case "wooNetHuf":
      return (
        <td className="numeric" key={columnId}>
          {formatHuf(row.wooNetHuf)}
        </td>
      );
    case "profitHuf":
      return (
        <td className="numeric" key={columnId}>
          {formatHuf(row.actualProfitNetHuf)}
        </td>
      );
    case "profitPercent":
      return (
        <td className="numeric" key={columnId}>
          {formatPercent(row.actualProfitPercentOnCost)}
        </td>
      );
    case "warnings":
      return (
        <td className="cell-wrap" key={columnId}>
          {formatSupplierWarnings(row.warnings, row.matchConfidence || "-")}
        </td>
      );
  }
}

function TerminalLog({
  events,
  cardRef,
}: {
  events: NonNullable<DvgManualBatchState["events"]>;
  cardRef: Ref<HTMLDivElement>;
}) {
  const visibleEvents = events.slice(-80);
  const lastVisibleEventId = visibleEvents[visibleEvents.length - 1]?.id ?? "empty";
  const screenRef = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    const screen = screenRef.current;
    if (!screen) return;
    const frame = window.requestAnimationFrame(() => {
      screen.scrollTop = screen.scrollHeight;
    });
    return () => window.cancelAnimationFrame(frame);
  }, [lastVisibleEventId]);

  return (
    <div className="dvg-operator-card dvg-terminal-card" ref={cardRef}>
      <div className="dvg-terminal-header">
        <div>
          <span>Live preview</span>
          <strong>DVG futási események</strong>
        </div>
      </div>
      <div className="dvg-terminal-screen" ref={screenRef} role="log" aria-label="DVG live preview">
        {visibleEvents.length === 0 ? (
          <div className="dvg-terminal-line is-muted">
            <time>--:--:--</time>
            <code>idle</code>
            <span>-</span>
            <strong>Indítás után itt jelenik meg minden DVG lépés.</strong>
          </div>
        ) : (
          visibleEvents.map((event) => (
            <div className="dvg-terminal-line" key={event.id}>
              <time>{formatTime(event.createdAt)}</time>
              <code>{event.type}</code>
              <span>{event.article ?? event.path ?? "-"}</span>
              <strong>{event.message}</strong>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

async function listAllSupplierMappings(supplierId: string): Promise<SupplierMapping[]> {
  const items: SupplierMapping[] = [];
  let offset = 0;

  while (true) {
    const response = await listSupplierMappings({
      supplierId,
      enabled: true,
      limit: MAPPING_PAGE_SIZE,
      offset,
    });
    const pageItems = response.items ?? [];
    items.push(...pageItems);
    if (pageItems.length < MAPPING_PAGE_SIZE) break;
    if (response.total !== undefined && items.length >= response.total) break;
    offset += pageItems.length;
    if (pageItems.length === 0) break;
  }

  return items;
}

function openCloakBrowserManagerWindow(
  managerWindowRef: { current: Window | null },
  setNotice: (message: string, tone: OperatorNotice["tone"]) => void,
  openedTone: OperatorNotice["tone"] = "success",
  openedMessage = "CloakBrowser megnyitva. Ha a DVG login oldal még nem látszik, kattints a Danetti DVG profilra."
): void {
  if (typeof window === "undefined") return;
  const existingWindow = managerWindowRef.current;
  if (existingWindow && !existingWindow.closed) {
    existingWindow.location.href = CLOAKBROWSER_MANAGER_URL;
    existingWindow.focus();
    setNotice(openedMessage, openedTone);
    return;
  }

  const opened = window.open(CLOAKBROWSER_MANAGER_URL, "danetti-cloakbrowser-manager");
  if (opened) {
    managerWindowRef.current = opened;
    opened.focus();
    setNotice(openedMessage, openedTone);
    return;
  }
  setNotice(
    `A böngésző blokkolta az automatikus Manager tabot. Nyisd meg kézzel: ${CLOAKBROWSER_MANAGER_URL}`,
    "warning"
  );
}

function reserveCloakBrowserManagerWindow(
  managerWindowRef: { current: Window | null },
  setNotice: (message: string) => void
): boolean {
  if (typeof window === "undefined") return false;
  const existingWindow = managerWindowRef.current;
  if (existingWindow && !existingWindow.closed) {
    existingWindow.focus();
    return true;
  }

  const opened = window.open("about:blank", "danetti-cloakbrowser-manager");
  if (!opened) {
    setNotice(
      `A böngésző blokkolta a CloakBrowser ablakot. Ha nem nyílik meg, engedélyezd a popupot vagy nyisd meg kézzel: ${CLOAKBROWSER_MANAGER_URL}`
    );
    return false;
  }

  managerWindowRef.current = opened;
  try {
    opened.document.title = "Danetti DVG indítás";
    opened.document.body.textContent = "Danetti DVG profil indítása...";
  } catch {
    // The reserved popup still protects the later navigation from popup blockers.
  }
  opened.focus();
  return true;
}

function closeCloakBrowserManagerWindow(managerWindowRef: { current: Window | null }): void {
  const managerWindow = managerWindowRef.current;
  if (!managerWindow || managerWindow.closed) return;
  managerWindow.close();
  managerWindowRef.current = null;
}

function isCloakBrowserError(error: unknown): boolean {
  const text = error instanceof Error ? `${error.name} ${error.message}` : String(error ?? "");
  return /cloakbrowser|cloak browser|cdp_unavailable|profile_launch/i.test(text);
}

function readStoredDvgResultColumnVisibility(): Record<DvgResultColumnId, boolean> {
  if (typeof window === "undefined") return defaultDvgResultColumnVisibility;
  try {
    const parsed = JSON.parse(
      window.localStorage.getItem(DVG_RESULT_COLUMN_STORAGE_KEY) ?? "{}"
    ) as Partial<Record<DvgResultColumnId, boolean>>;
    return normalizeDvgResultColumnVisibility(parsed);
  } catch {
    return defaultDvgResultColumnVisibility;
  }
}

function storeDvgResultColumnVisibility(visibility: Record<DvgResultColumnId, boolean>): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(DVG_RESULT_COLUMN_STORAGE_KEY, JSON.stringify(visibility));
}

function normalizeDvgResultColumnVisibility(
  value: Partial<Record<DvgResultColumnId, boolean>>
): Record<DvgResultColumnId, boolean> {
  return dvgResultColumns.reduce(
    (visibility, column) => ({
      ...visibility,
      [column.id]: fixedDvgResultColumnIds.has(column.id) ? true : value[column.id] !== false,
    }),
    {} as Record<DvgResultColumnId, boolean>
  );
}

function normalizeInactiveSavedRun(run: DvgManualBatchState): DvgManualBatchState {
  if (terminalStatuses.has(run.status)) return run;
  return {
    ...run,
    status: "interrupted",
    completedAt: run.completedAt ?? run.startedAt,
  };
}

function readRecoveredOffset(
  progress: DvgManualBatchProgress | null,
  savedRun: DvgManualBatchState | null,
  currentState: DvgManualBatchState | null,
  fallbackOffset: number
): number {
  if (progress?.nextOffset !== undefined) return progress.nextOffset;
  const source = savedRun ?? currentState;
  if (!source) return fallbackOffset;
  return source.settings.offset + countProgressAdvancingRows(source.rows);
}

function countProgressAdvancingRows(rows: DvgManualBatchRow[]): number {
  return rows.filter(
    (row) => row.status !== "redirected_to_login" && row.status !== "safety_stopped"
  ).length;
}

function buildOperatorGuidance(input: {
  action: "start" | "continue" | "cancel" | null;
  active: boolean;
  state: DvgManualBatchState | null;
  savedProgress: DvgManualBatchProgress | null;
  processedOverall: number;
  totalMapped: number;
}): OperatorGuidance {
  const { action, active, state, savedProgress, processedOverall, totalMapped } = input;
  const status = state?.status ?? "not_started";
  const hasSavedResume = processedOverall > 0 && processedOverall < totalMapped;

  if (totalMapped === 0) {
    return {
      title: "Nincs feldolgozható DVG mapping",
      body: "Előbb CSV import vagy a Termékek oldalon mentett DVG mapping kell.",
      badge: "Nincs adat",
      tone: "muted",
    };
  }

  if (action === "start") {
    return {
      title: "CloakBrowser ablak nyílik",
      body: "Várj pár másodpercet.",
      badge: "Indítás",
      tone: "warning",
    };
  }

  if (action === "continue") {
    return {
      title: "Folytatás előkészítése",
      body: `Mentett ponttól indul: ${processedOverall}.`,
      badge: "Folytatás",
      tone: "warning",
    };
  }

  if (status === "waiting_for_manual_login") {
    return {
      title: "Jelentkezz be a megnyílt DVG ablakban",
      body: "Sikeres login után kattints a Login után folytatás gombra.",
      badge: "Te jössz",
      tone: "warning",
    };
  }

  if (active || status === "running" || status === "login_detected") {
    return {
      title: "A DVG futás dolgozik",
      body: "Soronként ment. Megszakadás után folytatja.",
      badge: "Futásban",
      tone: "success",
    };
  }

  if (status === "security_stopped") {
    return {
      title: "Biztonsági megállás történt",
      body: "Ellenőrizd, csak utána folytasd.",
      badge: "Ellenőrzés kell",
      tone: "danger",
    };
  }

  if (status === "detached_session_failed") {
    return {
      title: "A DVG login megvolt, de a HTTP session nem indult el",
      body: "Indíts új DVG logint. Credential nem kell a Danetti appba.",
      badge: "Session detach hiba",
      tone: "warning",
    };
  }

  if (status === "session_lost") {
    return {
      title: hasSavedResume
        ? "DVG session elveszett, mentett pontról folytatható"
        : "DVG session elveszett",
      body: hasSavedResume
        ? `Új login után innen folytatható: ${savedProgress?.nextOffset ?? processedOverall}.`
        : "Indíts új DVG logint, majd futtasd újra.",
      badge: hasSavedResume ? "Új login kell" : "Session lost",
      tone: "warning",
    };
  }

  if (status === "interrupted") {
    return {
      title: hasSavedResume ? "Runtime restart után folytatható" : "A futás megszakadt",
      body: hasSavedResume
        ? `Mentett pont: ${savedProgress?.nextOffset ?? processedOverall}. Új login után folytatható.`
        : "Indíts új DVG futást.",
      badge: hasSavedResume ? "Interrupted" : "Megszakadt",
      tone: "warning",
    };
  }

  if (status === "failed") {
    return {
      title: hasSavedResume ? "Megállt, de mentett pontról folytatható" : "A futás hibával megállt",
      body: hasSavedResume
        ? `Mentett pont innen folytatható: ${savedProgress?.nextOffset ?? processedOverall}.`
        : "Indítsd újra a DVG bejelentkezést.",
      badge: hasSavedResume ? "Folytatható" : "Hiba",
      tone: hasSavedResume ? "warning" : "danger",
    };
  }

  if (status === "login_timeout") {
    return {
      title: hasSavedResume ? "Login timeout után folytatható" : "DVG login időtúllépés",
      body: hasSavedResume
        ? `${processedOverall}/${totalMapped} kész. Új login után innen megy tovább.`
        : "Indítsd újra a DVG bejelentkezést.",
      badge: hasSavedResume ? "Mentett pont van" : "Login timeout",
      tone: hasSavedResume ? "warning" : "danger",
    };
  }

  if (status === "cancelled") {
    return {
      title: hasSavedResume ? "Folytatható mentett státuszból" : "Indítható új DVG futás",
      body: hasSavedResume
        ? `${processedOverall}/${totalMapped} kész. Innen megy tovább.`
        : "Nyisd meg, jelentkezz be, kész.",
      badge: hasSavedResume ? "Mentett pont van" : "Készen áll",
      tone: hasSavedResume ? "warning" : "success",
    };
  }

  if (status === "completed") {
    return {
      title: "A DVG futás kész",
      body: "Az OK sorok mentve vannak.",
      badge: "Kész",
      tone: "success",
    };
  }

  return {
    title: hasSavedResume
      ? "Folytasd a legutóbbi mentett ponttól"
      : "Indítsd el a DVG bejelentkezést",
    body: hasSavedResume
      ? `${processedOverall}/${totalMapped} már kész.`
      : "Megnyit, belépsz, végigfut.",
    badge: hasSavedResume ? "Folytatható" : "Készen áll",
    tone: hasSavedResume ? "warning" : "success",
  };
}

function readLiveField(status: LiveStatus, label: string): string {
  return status.fields.find((field) => field.label === label)?.value ?? "-";
}

function buildLiveStatus(input: {
  state: DvgManualBatchState | null;
  totalMapped: number;
  runOffset: number;
  currentGlobalIndex: number | null;
  latestEvents: NonNullable<DvgManualBatchState["events"]>;
  resultRows: DvgManualBatchRow[];
}): LiveStatus {
  const { state, totalMapped, runOffset, currentGlobalIndex, latestEvents, resultRows } = input;
  const current = state?.currentItem ?? null;
  const latestEvent = latestEvents[0] ?? null;
  const lastOk =
    resultRows
      .slice()
      .reverse()
      .find((row) => row.status === "ok") ?? null;
  const lastProblem =
    resultRows
      .slice()
      .reverse()
      .find((row) => row.status !== "ok") ?? null;
  const itemStartedAt = findLatestItemStartedAt(
    latestEvents,
    current?.supplierArticleNumber ?? null
  );
  const phase = current
    ? labelCurrentItemStatus(current.status)
    : labelRunStatus(state?.status ?? "not_started");
  const headline = current
    ? `${current.supplierArticleNumber} feldolgozása`
    : state
      ? `Run állapot: ${labelRunStatus(state.status)}`
      : "Nincs aktív DVG futás";
  const latestMessage = latestEvent
    ? `${formatTime(latestEvent.createdAt)} - ${latestEvent.message}`
    : "Még nincs esemény.";

  return {
    headline,
    phase,
    badgeTone: liveStatusTone(state?.status ?? "not_started", current?.status ?? null),
    detail: `Utolsó esemény: ${latestMessage}`,
    fields: [
      { label: "Run", value: state?.runId ?? "nincs" },
      { label: "Állapot", value: labelRunStatus(state?.status ?? "not_started") },
      {
        label: "Aktuális",
        value: currentGlobalIndex
          ? `${currentGlobalIndex}/${totalMapped || current?.total || "-"}`
          : "-",
      },
      { label: "Offset", value: String(runOffset) },
      { label: "SKU", value: current?.wooSku ?? "-" },
      { label: "DVG cikkszám", value: current?.supplierArticleNumber ?? "-" },
      { label: "Termék", value: current?.wooName ?? "-" },
      { label: "Run idő", value: state?.startedAt ? formatElapsedSince(state.startedAt) : "-" },
      { label: "Tétel idő", value: itemStartedAt ? formatElapsedSince(itemStartedAt) : "-" },
      {
        label: "Utolsó OK",
        value: lastOk ? `${lastOk.supplierArticleNumber} / ${lastOk.wooSku}` : "-",
      },
      {
        label: "Utolsó hiba",
        value: lastProblem
          ? `${labelItemStatus(lastProblem.status)} / ${lastProblem.supplierArticleNumber}`
          : "-",
      },
      {
        label: "Következő",
        value: nextStepForCurrentStatus(current?.status ?? state?.status ?? null),
      },
    ],
  };
}

function buildWorkbenchStatusTiles(input: {
  rows: DvgManualBatchRow[];
  state: DvgManualBatchState | null;
  savedProgress: DvgManualBatchProgress | null;
}): WorkbenchStatusTile[] {
  const { rows, state, savedProgress } = input;
  const summary = state?.summary ?? null;
  const totals = state?.totals ?? null;
  const displayCounts = countRowsByDisplayStatus(rows);
  const hasRows = rows.length > 0;
  const priceMissing = hasRows ? displayCounts.missing_price : (summary?.priceMissing ?? 0);
  const ambiguousMatch = hasRows
    ? displayCounts.ambiguous_match
    : (summary?.needsMappingReview ?? 0);
  const timeoutOrLogin = hasRows
    ? displayCounts.timeout + displayCounts.login_required
    : (summary?.itemTimeouts ?? 0) + (summary?.redirectedToLogin ?? 0);
  const failed = hasRows ? displayCounts.failed : (totals?.failed ?? savedProgress?.failed ?? 0);
  const safetyStopped = totals?.safetyStopped ?? savedProgress?.safetyStopped ?? 0;
  const skipped = totals?.skipped ?? savedProgress?.skipped ?? 0;
  const ok = hasRows ? displayCounts.ok : (totals?.ok ?? savedProgress?.ok ?? 0);

  return [
    { label: "OK", value: ok, detail: "árral mentve", tone: "success" },
    {
      label: "Ár hiányzik",
      value: priceMissing,
      detail: "nem hiba, külön státusz",
      tone: "warning",
    },
    {
      label: "Cikkszám változott",
      value: displayCounts.article_changed,
      detail: "DVG más cikkszámot jelez",
      tone: "warning",
    },
    {
      label: "Nincs termékoldal",
      value: displayCounts.no_product_page,
      detail: "nincs megnyitható DVG oldal",
      tone: "warning",
    },
    {
      label: "Nem rendelhető",
      value: displayCounts.unavailable,
      detail: "kifutott vagy törölt cikk",
      tone: "warning",
    },
    {
      label: "Nem egyértelmű",
      value: ambiguousMatch,
      detail: "mapping döntés kell",
      tone: "warning",
    },
    {
      label: "Login / timeout",
      value: timeoutOrLogin,
      detail: "új login vagy újrafutás kell",
      tone: "danger",
    },
    { label: "Safety stop", value: safetyStopped, detail: "védelmi megállás", tone: "danger" },
    { label: "Egyéb", value: failed + skipped, detail: "failed / kihagyott", tone: "muted" },
  ];
}

function countRowsByDisplayStatus(
  rows: DvgManualBatchRow[]
): Record<SupplierDisplayStatus, number> {
  const counts = createEmptyDisplayStatusCounts();
  for (const row of rows) counts[dvgRowStatusInfo(row).status] += 1;
  return counts;
}

function findLatestItemStartedAt(
  events: NonNullable<DvgManualBatchState["events"]>,
  article: string | null
): string | null {
  if (!article) return null;
  return (
    events.find((event) => event.type === "itemStarted" && event.article === article)?.createdAt ??
    null
  );
}

function formatElapsedSince(value: string): string {
  const elapsedMs = Date.now() - Date.parse(value);
  if (!Number.isFinite(elapsedMs) || elapsedMs < 0) return "-";
  const totalSeconds = Math.floor(elapsedMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes > 0 ? `${minutes}p ${seconds}mp` : `${seconds}mp`;
}

function liveStatusTone(runStatus: string, currentStatus: string | null): string {
  if (runStatus === "security_stopped" || currentStatus === "safety_stopped") return "danger";
  if (
    runStatus === "failed" ||
    runStatus === "login_timeout" ||
    runStatus === "detached_session_failed" ||
    runStatus === "session_lost" ||
    runStatus === "interrupted" ||
    currentStatus === "item_timeout"
  ) {
    return "warning";
  }
  if (runStatus === "completed") return "success";
  if (runStatus === "running" || currentStatus) return "warning";
  return "muted";
}

function labelCurrentItemStatus(status: string): string {
  const labels: Record<string, string> = {
    opening_detail_url: "detail URL nyitása",
    lean_fetch_detail: "gyors HTML lekérés",
    fallback_navigation: "fallback oldalnyitás",
    reading_page: "oldal olvasása",
    parsing_detail: "ár és cikkszám elemzése",
    price_parsed: "ár beolvasva",
    price_missing: "ár hiányzik",
    article_changed: "DVG cikkszám változott",
    item_not_available: "nem rendelhető",
    ambiguous_match: "nem egyértelmű találat",
    article_not_found: "nincs DVG termékoldal",
    redirected_to_login: "loginra dobott",
    needs_mapping_review: "nem egyértelmű találat",
    skipped_not_dvg_candidate: "kihagyva",
    item_timeout: "tétel timeout",
    recovering_browser: "session recovery",
    safety_stopped: "safety stop",
  };
  return labels[status] ?? status;
}

function nextStepForCurrentStatus(status: string | null): string {
  const labels: Record<string, string> = {
    waiting_for_manual_login: "kézi DVG login várása",
    login_detected: "terméklista indítása",
    login_timeout: "új kézi DVG login indítása",
    detached_session_failed: "új kézi DVG login indítása",
    running: "következő mentett DVG mapping olvasása",
    opening_detail_url: "oldal HTML olvasása",
    lean_fetch_detail: "ármező és cikkszám parse",
    fallback_navigation: "teljes oldal fallback ellenőrzés",
    reading_page: "HTML parse",
    parsing_detail: "profit számítás",
    price_parsed: "sor mentése és várakozás",
    price_missing: "ár nélküli státusz mentése",
    article_changed: "cikkszámcsere ellenőrzése",
    item_not_available: "nem rendelhető státusz mentése",
    ambiguous_match: "mapping döntés előkészítése",
    item_timeout: "következő termékre lépés",
    recovering_browser: "új oldal nyitása ugyanabban a sessionben",
    session_lost: "új kézi DVG login után mentett ponttól folytatás",
    interrupted: "mentett pont visszaállítása",
    completed: "eredmények mentése a termékekhez",
  };
  return status ? (labels[status] ?? status) : "nincs aktív lépés";
}

function isDvgSupplier(supplier: Supplier): boolean {
  return /dvg|de\s*vecchi/i.test(`${supplier.code} ${supplier.name}`);
}

function formatDvgAutoPairNotice(result: DvgAutoPairResponse): string {
  return [
    `DVG párosítás kész: ${result.dvgCandidateCount}/${result.totalProducts} DVG jelölt.`,
    `Új: ${result.createdCount}.`,
    `Javított: ${result.updatedCount}.`,
    `Ellenőrzött: ${result.verifiedCount}.`,
    `Konfliktus: ${result.conflictCount}.`,
    `Kihagyva: ${result.skippedNotDvgCandidateCount}.`,
  ].join(" ");
}

function isUuid(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function buildLocalPaginationLabel(total: number, offset: number, pageLength: number): string {
  const start = total === 0 ? 0 : offset + 1;
  const end = Math.min(offset + pageLength, total);
  return `Megjelenítve: ${start}-${end} / ${total}`;
}

function readStoredRunId(): string | null {
  try {
    return window.localStorage.getItem(RUN_STORAGE_KEY);
  } catch {
    return null;
  }
}

function storeRunId(runId: string) {
  try {
    window.localStorage.setItem(RUN_STORAGE_KEY, runId);
  } catch {
    // Run persistence is a UI convenience; API state remains the source of truth.
  }
}

function clearStoredRunId() {
  try {
    window.localStorage.removeItem(RUN_STORAGE_KEY);
  } catch {
    // Ignore localStorage failures.
  }
}

function formatMoney(value: number | null, currency: string | null): string {
  if (value === null) return "-";
  return `${value.toFixed(2)} ${currency ?? ""}`.trim();
}

function formatHuf(value: number | null): string {
  if (value === null) return "-";
  return `${Math.round(value).toLocaleString("hu-HU")} HUF`;
}

function formatPercent(value: number | null): string {
  if (value === null) return "-";
  return `${value.toFixed(1)}%`;
}

function formatMilliseconds(value: number | null): string {
  if (value === null) return "-";
  if (value >= 1000) return `${(value / 1000).toFixed(1)}s`;
  return `${Math.round(value)}ms`;
}

function formatRate(value: number | null): string {
  if (value === null) return "-";
  return value.toFixed(1);
}

function formatMinutes(value: number | null): string {
  if (value === null) return "-";
  if (value < 1) return "<1p";
  return `${Math.round(value)}p`;
}

function formatAverageItemDuration(input: {
  state: DvgManualBatchState | null;
  telemetry: DvgManualBatchState["telemetry"] | null;
}): string {
  return formatMilliseconds(readAverageItemDurationMs(input));
}

function formatEstimatedFullRunDuration(input: {
  state: DvgManualBatchState | null;
  telemetry: DvgManualBatchState["telemetry"] | null;
  totalItems: number;
}): string {
  const averageItemMs = readAverageItemDurationMs(input);
  if (averageItemMs === null || input.totalItems <= 0) return "-";
  return formatDurationEstimate(averageItemMs * input.totalItems);
}

function readAverageItemDurationMs(input: {
  state: DvgManualBatchState | null;
  telemetry: DvgManualBatchState["telemetry"] | null;
}): number | null {
  const itemsPerMinute = input.telemetry?.itemsPerMinute ?? null;
  if (itemsPerMinute !== null && Number.isFinite(itemsPerMinute) && itemsPerMinute > 0) {
    return 60_000 / itemsPerMinute;
  }

  const checked = input.state?.totals.checked ?? 0;
  const durationMs = input.telemetry?.durationMs ?? null;
  if (durationMs !== null && Number.isFinite(durationMs) && durationMs > 0 && checked > 0) {
    return durationMs / checked;
  }

  return null;
}

function formatDurationEstimate(valueMs: number): string {
  if (!Number.isFinite(valueMs) || valueMs <= 0) return "-";
  const totalMinutes = Math.max(1, Math.round(valueMs / 60_000));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0) return `${totalMinutes}p`;
  return minutes > 0 ? `${hours}ó ${minutes}p` : `${hours}ó`;
}

function formatDvgOperatorErrorMessage(error: unknown): string {
  const message = formatApiErrorMessage(error);
  if (message === "Helyi API nem érhető el.") {
    return "Helyi API nem érhető el. A háttérszolgáltatás még indulhat vagy újraindult. Frissítsd az oldalt, ha pár másodperc után is marad.";
  }
  return message;
}

function isLocalApiUnavailableError(error: unknown): boolean {
  return formatApiErrorMessage(error) === "Helyi API nem érhető el.";
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function formatTime(value: string): string {
  return new Intl.DateTimeFormat("hu-HU", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(new Date(value));
}

function formatDateTime(value: string | null): string {
  if (!value) return "-";
  return new Intl.DateTimeFormat("hu-HU", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(value));
}

function labelRunStatus(status: string): string {
  const labels: Record<string, string> = {
    not_started: "nincs futás",
    opening_browser: "böngésző nyílik",
    waiting_for_manual_login: "loginra vár",
    login_detected: "login megvan",
    running: "fut",
    completed: "kész",
    cancelled: "leállítva",
    login_timeout: "login timeout",
    detached_session_failed: "session detach hiba",
    security_stopped: "safety stop",
    session_lost: "session elveszett",
    interrupted: "megszakadt",
    failed: "hiba",
  };
  return labels[status] ?? status;
}

function labelItemStatus(status: string): string {
  return normalizeSupplierDisplayStatus({ supplier: "dvg", status }).label;
}

function dvgRowStatusInfo(row: Pick<DvgManualBatchRow, "status" | "warnings" | "matchConfidence">) {
  return normalizeSupplierDisplayStatus({
    supplier: "dvg",
    status: row.status,
    warnings: row.warnings,
    matchConfidence: row.matchConfidence,
  });
}

function createEmptyDisplayStatusCounts(): Record<SupplierDisplayStatus, number> {
  return {
    ok: 0,
    no_product_page: 0,
    missing_price: 0,
    article_changed: 0,
    unavailable: 0,
    not_supplier_own_article: 0,
    ambiguous_match: 0,
    login_required: 0,
    timeout: 0,
    safety_stopped: 0,
    failed: 0,
    skipped: 0,
    no_run: 0,
  };
}

function readDvgSortValue(
  row: DvgManualBatchRow,
  id: DvgResultColumnId
): string | number | null | undefined {
  switch (id) {
    case "status":
      return dvgRowStatusInfo(row).label;
    case "sku":
      return row.wooSku;
    case "name":
      return row.wooName;
    case "article":
      return row.supplierArticleNumber;
    case "supplierNetEur":
      return row.supplierNetEur;
    case "supplierNetHuf":
      return row.supplierNetHuf;
    case "wooGrossHuf":
      return row.wooGrossHuf;
    case "wooNetHuf":
      return row.wooNetHuf;
    case "profitHuf":
      return row.actualProfitNetHuf;
    case "profitPercent":
      return row.actualProfitPercentOnCost;
    case "warnings":
      return formatSupplierWarnings(row.warnings, row.matchConfidence || "-");
  }
}
