import { notFound } from "next/navigation";
import { LabelBrandNav } from "../../../../src/labels/LabelBrandNav";
import { LabelOrderBuilder } from "../../../../src/labels/LabelOrderBuilder";
import styles from "../../../../src/labels/LabelStudio.module.css";
export default async function LabelOrdersPage({ params }: { params: Promise<{ brand: string }> }) {
  const { brand } = await params;
  if (brand !== "utopia" && brand !== "bean-on" && brand !== "custom") notFound();
  const labelBrand = brand === "bean-on" ? "bean_on" : brand === "custom" ? "custom" : "utopia";
  return (
    <div className={styles.workspace}>
      <header className={styles.workspaceHeader}>
        <div>
          <p className={styles.brandTag}>
            {brand === "bean-on" ? "Bean On" : brand === "custom" ? "Egyedi címkék" : "Utopia"}
          </p>
          <h1>Címkerendelés</h1>
          <p>Állítsd össze a tételeket, ellenőrizd a méreteket, és töltsd le a nyomdai PDF-et.</p>
        </div>
      </header>
      <LabelBrandNav brand={labelBrand} active="orders" />
      <LabelOrderBuilder brand={labelBrand} />
    </div>
  );
}
