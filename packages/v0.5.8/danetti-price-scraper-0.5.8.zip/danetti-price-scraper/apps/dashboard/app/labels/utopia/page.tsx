import { Suspense } from "react";
import { LabelWorkspace } from "../../../src/labels/LabelWorkspace";
export default function UtopiaLabelsPage() {
  return (
    <Suspense fallback={<p>Címketár betöltése…</p>}>
      <LabelWorkspace brand="utopia" />
    </Suspense>
  );
}
