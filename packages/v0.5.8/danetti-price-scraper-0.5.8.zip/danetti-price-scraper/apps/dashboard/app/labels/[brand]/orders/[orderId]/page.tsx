import { notFound } from "next/navigation";
import { LabelBrandNav } from "../../../../../src/labels/LabelBrandNav";
import { LabelOrderBuilder } from "../../../../../src/labels/LabelOrderBuilder";
import styles from "../../../../../src/labels/LabelStudio.module.css";
export default async function LabelOrderPage({
  params,
}: {
  params: Promise<{ brand: string; orderId: string }>;
}) {
  const { brand, orderId } = await params;
  if (brand !== "utopia" && brand !== "bean-on" && brand !== "custom") notFound();
  const labelBrand = brand === "bean-on" ? "bean_on" : brand === "custom" ? "custom" : "utopia";
  return (
    <div className={styles.workspace}>
      <LabelBrandNav brand={labelBrand} active="orders" />
      <LabelOrderBuilder brand={labelBrand} orderId={orderId} />
    </div>
  );
}
