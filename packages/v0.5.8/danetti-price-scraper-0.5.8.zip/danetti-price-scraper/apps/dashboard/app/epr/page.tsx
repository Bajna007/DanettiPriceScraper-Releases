"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { eprApiBase, eprError, eprRequest } from "../../src/epr/api";
import {
  periodStatus,
  purchaseStatus,
  type Period,
  type Purchase,
  type Summary,
  type Scan,
} from "../../src/epr/types";

function quarterChoices() {
  const now = new Date(),
    year = now.getFullYear(),
    current = Math.floor(now.getMonth() / 3) + 1;
  return Array.from({ length: 12 }, (_, i) => {
    const n = year * 4 + current - 1 - i;
    return `${Math.floor(n / 4)}-Q${(n % 4) + 1}`;
  });
}
function label(code: string) {
  return code.replace(/^(\d+)-Q(\d)$/, "$1. $2. negyedév");
}
export default function EprPage() {
  const [periods, setPeriods] = useState<Period[]>([]),
    [periodId, setPeriodId] = useState(""),
    [code, setCode] = useState(quarterChoices()[1]);
  const [summary, setSummary] = useState<Summary | null>(null),
    [items, setItems] = useState<Purchase[]>([]),
    [scan, setScan] = useState<Scan | null>(null);
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [search, setSearch] = useState(""),
    [filter, setFilter] = useState(""),
    [supplier, setSupplier] = useState("");
  const [ai, setAi] = useState(false),
    [mailboxes, setMailboxes] = useState(0),
    [closing, setClosing] = useState(false);
  const load = useCallback(async (id: string) => {
    const [s, p, r] = await Promise.all([
      eprRequest<Summary>(`/epr/periods/${id}/summary`),
      eprRequest<{ items: Purchase[] }>(`/epr/periods/${id}/purchases`),
      eprRequest<Scan | null>(`/epr/periods/${id}/scan`),
    ]);
    setSummary(s);
    setItems(p.items);
    setScan(r);
  }, []);
  useEffect(() => {
    Promise.all([
      eprRequest<{ items: Period[] }>("/epr/periods"),
      eprRequest<{ connected: boolean }>("/epr/ai/status"),
      eprRequest<{ items: { enabled: boolean }[] }>("/epr/mailboxes"),
    ])
      .then(([p, a, m]) => {
        setPeriods(p.items);
        if (p.items.length) {
          setPeriodId(p.items[0].id);
          setCode(p.items[0].code);
        }
        setAi(a.connected);
        setMailboxes(m.items.filter((x) => x.enabled).length);
      })
      .catch((e) => setError(eprError(e)));
  }, []);
  useEffect(() => {
    if (periodId) load(periodId).catch((e) => setError(eprError(e)));
  }, [periodId, load]);
  useEffect(() => {
    if (!periodId || !scan || !["QUEUED", "RUNNING", "PAUSED"].includes(scan.status)) return;
    let cancelled = false;
    const timer = setTimeout(() => {
      if (!cancelled) load(periodId).catch((e) => setError(eprError(e)));
    }, 2000);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [scan, periodId, load]);
  async function create() {
    setBusy(true);
    setError("");
    try {
      const p = await eprRequest<Period>("/epr/periods", "POST", { code });
      setPeriods((old) => [p, ...old.filter((x) => x.id !== p.id)]);
      setPeriodId(p.id);
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  async function action(path: string) {
    setBusy(true);
    setError("");
    try {
      await eprRequest(path, "POST");
      setClosing(false);
      await load(periodId);
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  const visible = items.filter(
    (p) =>
      (!filter || p.status === filter) &&
      (!supplier || p.supplier === supplier) &&
      `${p.supplier} ${p.reference ?? ""}`
        .toLocaleLowerCase("hu")
        .includes(search.toLocaleLowerCase("hu"))
  );
  return (
    <>
      <div className="epr-heading">
        <h1>EPR</h1>
        <div className="epr-actions">
          <label>
            Időszak
            <select
              aria-label="EPR negyedév"
              value={code}
              onChange={(e) => {
                setCode(e.target.value);
                const p = periods.find((p) => p.code === e.target.value);
                setPeriodId(p?.id ?? "");
                setSummary(null);
                setItems([]);
                setScan(null);
              }}
            >
              {[...new Set([...quarterChoices(), ...periods.map((p) => p.code)])]
                .sort()
                .reverse()
                .map((c) => (
                  <option key={c} value={c}>
                    {label(c)}
                  </option>
                ))}
            </select>
          </label>
          {periodId ? (
            <span>
              {summary?.period.startsAt} – {summary?.period.endsAt}
            </span>
          ) : (
            <button className="button" disabled={busy} onClick={create}>
              Időszak létrehozása
            </button>
          )}
        </div>
      </div>
      <div className="epr-actions epr-connections">
        <Link href="/epr/settings">
          Mailboxok: {mailboxes ? `${mailboxes} beállítva` : "nincs beállítva"}
        </Link>
        <Link href="/epr/settings">AI: {ai ? "Csatlakoztatva" : "Nincs csatlakoztatva"}</Link>
      </div>
      {error ? (
        <p role="alert" className="epr-error">
          {error}
        </p>
      ) : null}
      {!periodId ? (
        <section className="epr-section">
          <h2>Negyedéves EPR-előkészítés</h2>
          <p>
            Válassz negyedévet és hozd létre az időszakot. Első alkalommal állítsd be a mailboxokat,
            a ChatGPT-kapcsolatot és az elszámolási alapot.
          </p>
          <Link className="button secondary" href="/epr/settings">
            Beállítások megnyitása
          </Link>
        </section>
      ) : (
        <>
          <div className="epr-actions epr-period-actions">
            <button
              className="button"
              disabled={
                busy ||
                !mailboxes ||
                (!!scan && ["QUEUED", "RUNNING", "PAUSED"].includes(scan.status))
              }
              onClick={() => action(`/epr/periods/${periodId}/scan`)}
            >
              Időszak feldolgozása
            </button>
            <a className="button secondary" href={`${eprApiBase}/epr/periods/${periodId}/export`}>
              Audit munkafüzet export
            </a>
            <Link className="button secondary" href="/epr/settings">
              Beállítások
            </Link>
            {summary?.period.status !== "CLOSED" ? (
              <button
                className="button secondary"
                disabled={busy}
                onClick={() => action(`/epr/periods/${periodId}/recalculate`)}
              >
                Számítás frissítése
              </button>
            ) : null}
          </div>
          {scan ? (
            <section className="epr-section" aria-live="polite">
              <h2>Feldolgozás</h2>
              <p>
                {scan.status === "COMPLETED"
                  ? "Feldolgozás kész"
                  : scan.status === "COMPLETED_WITH_REVIEW"
                    ? "Feldolgozás kész, ellenőrzés szükséges"
                    : scan.status === "FAILED"
                      ? "A feldolgozás megállt. Újraindítással a mentett ponttól folytatható."
                      : "Feldolgozás folyamatban…"}
              </p>
              <div className="epr-progress">
                <span>
                  Mailboxok: {scan.progress.mailboxesDone ?? 0} / {scan.progress.mailboxCount ?? 0}
                </span>
                <span>Levelek: {scan.progress.messagesScanned ?? 0}</span>
                <span>Dokumentumok: {scan.progress.documentsProcessed ?? 0}</span>
                <span>Teendők: {scan.progress.reviewItemsCreated ?? 0}</span>
              </div>
              {scan.safeErrorCode ? (
                <p className="epr-error">{eprError(new Error(scan.safeErrorCode))}</p>
              ) : null}
            </section>
          ) : null}
          <section className="epr-section">
            <div className="epr-heading">
              <h2>Anyagösszesítés</h2>
              <span>{periodStatus[summary?.period.status ?? "OPEN"]}</span>
            </div>
            {summary?.unresolved ? (
              <p className="epr-partial">
                <strong>RÉSZÖSSZEG</strong> · {summary.unresolved} beszerzés még nincs elszámolva.
              </p>
            ) : null}
            {summary && Object.keys(summary.totals).length ? (
              <dl className="epr-totals">
                {Object.entries(summary.totals).map(([material, kg]) => (
                  <div key={material}>
                    <dt>{material}</dt>
                    <dd>{kg} kg</dd>
                  </div>
                ))}
              </dl>
            ) : (
              <p>
                Még nincs jóváhagyott anyagszámítás. A hiányzó adatok ellenőrizendő tételként
                jelennek meg.
              </p>
            )}
            {summary?.closed ? (
              <p>
                Lezárt, változatlan pillanatkép. Az új bizonyítékok külön ellenőrzést igényelnek.
              </p>
            ) : (
              <button
                className="button secondary"
                disabled={
                  busy || !summary || summary.unresolved > 0 || !summary.period.accountingBasis
                }
                onClick={() => setClosing(true)}
              >
                Időszak lezárása
              </button>
            )}
            {closing ? (
              <div className="epr-confirm">
                <h3>Időszak lezárása</h3>
                <p>
                  A jelenlegi bizonylatok, szabályverziók és számítások változatlan pillanatképként
                  kerülnek megőrzésre.
                </p>
                <div className="epr-actions">
                  <button
                    className="button secondary"
                    disabled={busy}
                    onClick={() => setClosing(false)}
                  >
                    Mégse
                  </button>
                  <button
                    className="button"
                    disabled={busy}
                    onClick={() => action(`/epr/periods/${periodId}/close`)}
                  >
                    Lezárás
                  </button>
                </div>
              </div>
            ) : null}
          </section>
          <section className="epr-section">
            <h2>Beszerzések · {items.length}</h2>
            <div className="epr-filters">
              <label>
                Beszállító
                <select value={supplier} onChange={(e) => setSupplier(e.target.value)}>
                  <option value="">Mind</option>
                  {[...new Set(items.map((p) => p.supplier))].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </label>
              <label>
                Állapot
                <select value={filter} onChange={(e) => setFilter(e.target.value)}>
                  <option value="">Mind</option>
                  {Object.entries(purchaseStatus).map(([key, text]) => (
                    <option key={key} value={key}>
                      {text}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Keresés
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Beszállító vagy azonosító"
                />
              </label>
            </div>
            <div className="table-scroll">
              <table className="table data-table data-table--wide">
                <colgroup>
                  <col style={{ width: "14%" }} />
                  <col style={{ width: "26%" }} />
                  <col style={{ width: "20%" }} />
                  <col style={{ width: "12%" }} />
                  <col style={{ width: "14%" }} />
                  <col style={{ width: "14%" }} />
                </colgroup>
                <thead>
                  <tr>
                    <th>Dátum</th>
                    <th>Beszállító</th>
                    <th>Azonosító</th>
                    <th>Bizonylatok</th>
                    <th>Állapot</th>
                    <th>Részletek</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((p) => (
                    <tr key={p.id}>
                      <td>{p.accountingEventDate ?? "Ellenőrizendő"}</td>
                      <td>{p.supplier}</td>
                      <td>{p.reference ?? "—"}</td>
                      <td>
                        {summary?.details.find((d) => d.purchase.id === p.id)?.documents.length ??
                          "—"}
                      </td>
                      <td>{purchaseStatus[p.status] ?? p.status}</td>
                      <td>
                        <Link className="button secondary" href={`/epr/purchases/${p.id}`}>
                          Megnyitás
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {!visible.length ? (
              <p>
                {items.length
                  ? "Nincs a szűrésnek megfelelő beszerzés."
                  : "Még nincs beszerzés. Indíts feldolgozást, vagy tölts fel egy bizonylatot."}
              </p>
            ) : null}
            <label className="epr-field">
              Bizonylat kézi feltöltése
              <input
                type="file"
                accept=".pdf,.json,.xml,.txt"
                disabled={busy || summary?.closed}
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setBusy(true);
                  setError("");
                  try {
                    if (file.size > 20_000_000) throw new Error("document_size_invalid");
                    const bytes = new Uint8Array(await file.arrayBuffer());
                    let binary = "";
                    for (let i = 0; i < bytes.length; i += 8192)
                      binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
                    await eprRequest("/epr/documents/import", "POST", {
                      periodId,
                      filename: file.name,
                      mime: file.name.toLowerCase().endsWith(".pdf")
                        ? "application/pdf"
                        : file.name.endsWith(".json")
                          ? "application/json"
                          : file.name.endsWith(".xml")
                            ? "application/xml"
                            : "text/plain",
                      base64: btoa(binary),
                    });
                    await load(periodId);
                  } catch (err) {
                    setError(eprError(err));
                  } finally {
                    setBusy(false);
                    e.target.value = "";
                  }
                }}
              />
            </label>
          </section>
        </>
      )}
    </>
  );
}
