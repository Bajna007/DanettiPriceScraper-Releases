"use client";
import { use, useCallback, useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { eprApiBase, eprError, eprRequest, eprReason } from "../../../../src/epr/api";
import {
  purchaseStatus,
  type Detail,
  type Rule,
  type Period,
  type Purchase,
  type Line,
} from "../../../../src/epr/types";
type ManualLine = {
  supplierSku: string;
  description: string;
  quantity: string;
  unit: string;
  page: string;
};
export default function PurchasePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params),
    [detail, setDetail] = useState<Detail | null>(null),
    [rules, setRules] = useState<Rule[]>([]),
    [period, setPeriod] = useState<Period | null>(null),
    [periods, setPeriods] = useState<Period[]>([]),
    [neighbors, setNeighbors] = useState<Purchase[]>([]),
    [documentId, setDocumentId] = useState(""),
    [editing, setEditing] = useState<Line | null>(null),
    [manual, setManual] = useState(false),
    [manualLines, setManualLines] = useState<ManualLine[]>([
      { supplierSku: "", description: "", quantity: "", unit: "", page: "1" },
    ]),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    const d = await eprRequest<Detail>(`/epr/purchases/${id}`);
    setDetail(d);
    setDocumentId((old) =>
      d.documents.some((document) => document.source.id === old)
        ? old
        : d.documents[0]?.source.id || ""
    );
    const [r, p, n] = await Promise.all([
      eprRequest<{ items: Rule[] }>("/epr/rules"),
      eprRequest<{ items: Period[] }>("/epr/periods"),
      eprRequest<{ items: Purchase[] }>(`/epr/periods/${d.purchase.periodId}/purchases`),
    ]);
    setRules(r.items);
    setPeriods(p.items);
    setPeriod(p.items.find((p) => p.id === d.purchase.periodId) ?? null);
    setNeighbors(n.items);
  }, [id]);
  useEffect(() => {
    setEditing(null);
    setManual(false);
    setError("");
    load().catch((e) => setError(eprError(e)));
  }, [load]);
  async function review(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const d = new FormData(event.currentTarget);
    setBusy(true);
    setError("");
    try {
      await eprRequest(`/epr/purchases/${id}/review`, "POST", {
        action: d.get("action"),
        reason: d.get("reason"),
        operator: "local-operator",
        accountingEventDate: d.get("date") || null,
        supplierIdentity: d.get("identity") || null,
        supplier: d.get("supplier") || null,
      });
      await load();
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  async function saveLine(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!editing) return;
    const d = new FormData(event.currentTarget);
    setBusy(true);
    setError("");
    try {
      await eprRequest(`/epr/lines/${editing.id}`, "PUT", {
        supplierSku: d.get("sku") || null,
        quantity: d.get("quantity") || null,
        unit: d.get("unit") || null,
        ruleVersionId: d.get("rule") || null,
        basisQuantity: d.get("basis") || null,
        creditApproved: d.get("credit") === "on",
        rememberMapping: d.get("remember") === "on",
        reason: d.get("reason"),
        operator: "local-operator",
      });
      setEditing(null);
      await load();
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  async function manualSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!detail) return;
    const d = new FormData(event.currentTarget);
    setBusy(true);
    setError("");
    try {
      await eprRequest(`/epr/documents/${documentId}/extraction`, "POST", {
        periodId: detail.purchase.periodId,
        invoice: {
          documentType: d.get("type"),
          supplier: { name: d.get("supplier") || null, taxId: d.get("taxId") || null },
          customerIdentity: d.get("customer") || null,
          invoiceNumber: d.get("invoice") || null,
          orderReferences: [],
          issueDate: d.get("date") || null,
          performanceDate: null,
          dueDate: null,
          currency: d.get("currency") || null,
          reasonCodes: ["operator_extracted"],
          lines: manualLines.map((line, i) => ({
            sourceLineId: String(i + 1),
            supplierSku: line.supplierSku || null,
            description: line.description,
            quantity: line.quantity || null,
            unit: line.unit || null,
            unitPrice: null,
            lineNet: null,
            provenance: { page: line.page ? Number(line.page) : null, sourceText: null },
          })),
        },
      });
      setManual(false);
      await load();
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  async function action(path: string, body: unknown) {
    setBusy(true);
    setError("");
    try {
      await eprRequest(path, "POST", body);
      await load();
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  const current = detail?.documents.find((d) => d.source.id === documentId),
    index = neighbors.findIndex((p) => p.id === id),
    closed = period?.status === "CLOSED";
  return (
    <>
      <div className="epr-heading">
        <h1>{detail?.purchase.supplier ?? "Beszerzés betöltése…"}</h1>
        <div className="epr-actions">
          <Link className="button secondary" href="/epr">
            Időszakhoz
          </Link>
          {neighbors[index - 1] ? (
            <Link className="button secondary" href={`/epr/purchases/${neighbors[index - 1].id}`}>
              Előző
            </Link>
          ) : null}
          {neighbors[index + 1] ? (
            <Link className="button secondary" href={`/epr/purchases/${neighbors[index + 1].id}`}>
              Következő
            </Link>
          ) : null}
        </div>
      </div>
      {error ? (
        <p className="epr-error" role="alert">
          {error}
        </p>
      ) : null}
      {detail ? (
        <div className="epr-detail">
          <section className="epr-section epr-document">
            <h2>Eredeti dokumentum</h2>
            <label className="epr-field">
              Bizonylat
              <select
                value={documentId}
                onChange={(e) => {
                  setDocumentId(e.target.value);
                  setManual(false);
                }}
              >
                {detail.documents.map((d) => (
                  <option key={d.source.id} value={d.source.id}>
                    {d.source.filename} · {d.business.documentType}
                  </option>
                ))}
              </select>
            </label>
            {current?.source.safeErrorCode ? (
              <p className="epr-error">{eprError(new Error(current.source.safeErrorCode))}</p>
            ) : null}
            {current?.source.mime === "application/pdf" ? (
              <iframe
                title="Eredeti számla PDF"
                src={`${eprApiBase}/epr/documents/${documentId}/content`}
                className="epr-pdf"
              />
            ) : (
              <p>Az eredeti dokumentum letölthető és megtekinthető.</p>
            )}
            <a
              className="button secondary"
              href={`${eprApiBase}/epr/documents/${documentId}/content`}
              target="_blank"
              rel="noreferrer"
            >
              Dokumentum megnyitása
            </a>
            {current?.business.conflict && !closed ? (
              <form
                className="epr-confirm"
                onSubmit={(event) => {
                  event.preventDefault();
                  const data = new FormData(event.currentTarget);
                  void action(`/epr/documents/${documentId}/exclude`, {
                    reason: data.get("reason"),
                  });
                }}
              >
                <h3>Eltérő dokumentumváltozatok</h3>
                <p>Ezt a változatot kizárhatod az elszámolásból. Az eredeti bizonyíték megmarad.</p>
                <label className="epr-field">
                  Kizárás indoka
                  <textarea name="reason" required maxLength={2000} />
                </label>
                <button className="button secondary" disabled={busy}>
                  Dokumentumváltozat kizárása
                </button>
              </form>
            ) : null}
            {current ? (
              <details>
                <summary>Dokumentumazonosság</summary>
                <p className="epr-hash">SHA-256: {current.source.hash}</p>
              </details>
            ) : null}
            {detail.messages.length ? (
              <details>
                <summary>Eredeti levelek · {detail.messages.length}</summary>
                {detail.messages.map((m, i) => (
                  <div key={`${m.id}-${i}`}>
                    <p>
                      {m.metadata.subject ?? "(Nincs tárgy)"}
                      <br />
                      {m.internalDate} · {m.folder}
                    </p>
                    {m.metadata.originalEmailDocumentId ? (
                      <a
                        className="button secondary"
                        href={`${eprApiBase}/epr/documents/${m.metadata.originalEmailDocumentId}/content`}
                      >
                        Eredeti email letöltése
                      </a>
                    ) : null}
                  </div>
                ))}
              </details>
            ) : null}
          </section>
          <div>
            <section className="epr-section">
              <h2>Beszerzés</h2>
              <p>
                <strong>{purchaseStatus[detail.purchase.status]}</strong> ·{" "}
                {detail.purchase.reference ?? "Nincs azonosító"}
              </p>
              <p>
                Elszámolási dátum: {detail.purchase.accountingEventDate ?? "Jóváhagyás szükséges"}
              </p>
              {detail.purchase.reasonCodes.length ? (
                <details open={detail.purchase.status === "potential"}>
                  <summary>Miért került ide?</summary>
                  <ul>
                    {detail.purchase.reasonCodes.map((reason, i) => (
                      <li key={i}>{eprReason(reason)}</li>
                    ))}
                  </ul>
                </details>
              ) : null}
              {!closed ? (
                <form onSubmit={review} key={`${detail.purchase.id}-${detail.purchase.status}`}>
                  <label className="epr-field">
                    Beszállító neve
                    <input
                      name="supplier"
                      defaultValue={detail.purchase.supplier}
                      maxLength={300}
                    />
                  </label>
                  <label className="epr-field">
                    Jóváhagyott beszállító-azonosító
                    <input
                      name="identity"
                      defaultValue={detail.purchase.supplierIdentity ?? ""}
                      maxLength={300}
                      placeholder="Adószám vagy jóváhagyott azonosító"
                    />
                  </label>
                  <label className="epr-field">
                    Elszámolási esemény dátuma
                    <input
                      name="date"
                      type="date"
                      min={period?.startsAt}
                      max={period?.endsAt}
                      defaultValue={detail.purchase.accountingEventDate ?? ""}
                    />
                  </label>
                  <label className="epr-field">
                    Döntés
                    <select name="action">
                      <option value="accept">Beszerzésként elfogadom</option>
                      <option value="reject">Kizárom</option>
                    </select>
                  </label>
                  <label className="epr-field">
                    Indok
                    <textarea name="reason" required maxLength={2000} rows={2} />
                  </label>
                  {!period?.accountingBasis ? (
                    <p>
                      <Link href="/epr/settings">
                        Előbb rögzítsd az elszámolási alapot a beállításokban.
                      </Link>
                    </p>
                  ) : null}
                  <button className="button" disabled={busy}>
                    Döntés mentése
                  </button>
                </form>
              ) : (
                <p>Lezárt időszak: a jóváhagyott pillanatkép nem változik.</p>
              )}
              {periods.some((p) => p.id !== period?.id && p.status !== "CLOSED") ? (
                <details>
                  <summary>Másik időszakba sorolás</summary>
                  <form
                    onSubmit={(event) => {
                      event.preventDefault();
                      const data = new FormData(event.currentTarget);
                      void action(`/epr/purchases/${id}/move`, {
                        targetPeriodId: data.get("target"),
                        reason: data.get("reason"),
                      });
                    }}
                  >
                    <p>
                      Az áthelyezés után az elszámolási dátumot és az elfogadást újra ellenőrizni
                      kell. Lezárt pillanatképben szereplő beszerzés nem mozgatható.
                    </p>
                    <label className="epr-field">
                      Célidőszak
                      <select name="target">
                        {periods
                          .filter((p) => p.id !== period?.id && p.status !== "CLOSED")
                          .map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.code}
                            </option>
                          ))}
                      </select>
                    </label>
                    <label className="epr-field">
                      Áthelyezés indoka
                      <textarea name="reason" required maxLength={2000} />
                    </label>
                    <button className="button secondary" disabled={busy}>
                      Áthelyezés
                    </button>
                  </form>
                </details>
              ) : null}
            </section>
            <section className="epr-section">
              <h2>Számlatételek és anyagszámítás</h2>
              {detail.lines.map((line) => {
                const entry = detail.entries.find((e) => e.purchaseLineId === line.id),
                  source = detail.extractedLines.find((l) => l.id === line.businessDocumentLineId)
                    ?.data.provenance;
                return (
                  <div className="epr-line" key={line.id}>
                    <h3>{line.description}</h3>
                    <p>
                      {line.supplierSku ?? "Ismeretlen cikkszám"} ·{" "}
                      {line.quantity ?? "Hiányzó mennyiség"} {line.unit ?? ""}
                    </p>
                    <p>Forrás: {source?.page ? `${source.page}. oldal` : "Oldal nincs rögzítve"}</p>
                    {line.safeErrorCode ? (
                      <p className="epr-error">{eprError(new Error(line.safeErrorCode))}</p>
                    ) : null}
                    {entry ? (
                      <details>
                        <summary>Számítás részletei · {entry.trace.totalGrams} g</summary>
                        <p>
                          Szabály:{" "}
                          {rules.find((r) => r.id === entry.ruleVersionId)?.name ??
                            entry.ruleVersionId}{" "}
                          · v{rules.find((r) => r.id === entry.ruleVersionId)?.version ?? "?"}
                        </p>
                        <p>
                          Normalizált mennyiség: {entry.trace.normalizedQuantity} · szorzó:{" "}
                          {entry.trace.factor}
                        </p>
                        {entry.trace.components.map((c, i) => (
                          <p key={i}>
                            {c.name}: {entry.trace.normalizedQuantity} × {c.gramsPerUnit} g ={" "}
                            {c.grams} g {c.material}
                          </p>
                        ))}
                      </details>
                    ) : (
                      <p>Még nincs igazolt anyagszámítás.</p>
                    )}
                    {line.factors?.excluded === "true" ? (
                      <p>Kizárt számlasor · nem számít bele az összesítésbe.</p>
                    ) : null}
                    {!closed ? (
                      <button className="button secondary" onClick={() => setEditing(line)}>
                        Sor javítása / hozzárendelés
                      </button>
                    ) : null}
                  </div>
                );
              })}
              {!detail.lines.length ? (
                <>
                  <p>
                    A számlatételek ellenőrzést igényelnek. Az eredeti bizonylat alapján kézzel
                    rögzíthetők, vagy az AI-kapcsolat létrehozása után újrafeldolgozhatók.
                  </p>
                  {!closed ? (
                    <div className="epr-actions">
                      <button
                        className="button secondary"
                        disabled={busy}
                        onClick={() => setManual(true)}
                      >
                        Számlaadatok rögzítése
                      </button>
                      <button
                        className="button secondary"
                        disabled={busy}
                        onClick={async () => {
                          setBusy(true);
                          setError("");
                          try {
                            await eprRequest(`/epr/documents/${documentId}/reprocess`, "POST", {
                              periodId: detail.purchase.periodId,
                            });
                            await load();
                          } catch (e) {
                            setError(eprError(e));
                          } finally {
                            setBusy(false);
                          }
                        }}
                      >
                        Újrafeldolgozás AI-val
                      </button>
                    </div>
                  ) : null}
                </>
              ) : null}
              {editing ? (
                <form onSubmit={saveLine} key={editing.id} className="epr-confirm">
                  <h3>{editing.description} · javítás</h3>
                  <label className="epr-field">
                    Beszállítói cikkszám
                    <input name="sku" defaultValue={editing.supplierSku ?? ""} />
                  </label>
                  <label className="epr-field">
                    Mennyiség
                    <input
                      name="quantity"
                      defaultValue={editing.quantity ?? ""}
                      inputMode="decimal"
                    />
                  </label>
                  <label className="epr-field">
                    Számlaegység
                    <input name="unit" defaultValue={editing.unit ?? ""} />
                  </label>
                  <label className="epr-field">
                    Anyagszabály
                    <select name="rule" defaultValue={editing.ruleVersionId ?? ""}>
                      <option value="">Pontos, jóváhagyott szabály keresése</option>
                      {rules.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name} · v{r.version} · {r.supplierSku}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="epr-field">
                    Csomag / szállítmány jóváhagyott mennyisége
                    <input
                      name="basis"
                      defaultValue={editing.factors?.basisQuantity ?? ""}
                      inputMode="decimal"
                    />
                  </label>
                  <label className="epr-checkbox">
                    <input
                      name="credit"
                      type="checkbox"
                      defaultChecked={editing.factors?.creditApproved === "true"}
                    />
                    A jóváírás mennyiségi / anyaghatását ellenőriztem
                  </label>
                  <label className="epr-checkbox">
                    <input name="remember" type="checkbox" />
                    Pontos cikkszám-hozzárendelést megjegyzem
                  </label>
                  <label className="epr-field">
                    Javítás indoka
                    <textarea name="reason" required rows={2} />
                  </label>
                  <div className="epr-actions">
                    <button className="button" disabled={busy}>
                      Javítás mentése
                    </button>
                    <button
                      type="button"
                      className="button secondary"
                      disabled={busy}
                      onClick={(event) => {
                        const form = event.currentTarget.form!;
                        if (!form.reportValidity()) return;
                        void action(`/epr/lines/${editing.id}/exclude`, {
                          reason: new FormData(form).get("reason"),
                        }).then(() => setEditing(null));
                      }}
                    >
                      Sor kizárása
                    </button>
                    <button
                      type="button"
                      className="button secondary"
                      onClick={() => setEditing(null)}
                    >
                      Mégse
                    </button>
                  </div>
                </form>
              ) : null}
            </section>
            <section className="epr-section">
              <h2>Döntési napló</h2>
              {detail.decisions.length ? (
                detail.decisions.map((d) => (
                  <p key={d.id}>
                    {d.createdAt} · {d.operator}
                    <br />
                    {d.reason}
                  </p>
                ))
              ) : (
                <p>Még nincs operátori döntés.</p>
              )}
            </section>
          </div>
          {manual ? (
            <section className="epr-section epr-wide">
              <h2>Számlaadatok rögzítése</h2>
              <form onSubmit={manualSave} className="epr-form-grid">
                <label className="epr-field">
                  Dokumentumtípus
                  <select name="type">
                    <option value="invoice">Számla</option>
                    <option value="credit_note">Jóváírás</option>
                    <option value="corrective_invoice">Helyesbítő számla</option>
                    <option value="cancellation">Stornó</option>
                    <option value="proforma">Díjbekérő</option>
                    <option value="delivery_note">Szállítólevél</option>
                    <option value="other">Egyéb</option>
                  </select>
                </label>
                {[
                  ["supplier", "Beszállító"],
                  ["taxId", "Beszállító jóváhagyott adószáma"],
                  ["customer", "Vevő / jogi személy azonosítója"],
                  ["invoice", "Számlaszám"],
                  ["currency", "Pénznem"],
                ].map(([key, text]) => (
                  <label className="epr-field" key={key}>
                    {text}
                    <input name={key} />
                  </label>
                ))}
                <label className="epr-field">
                  Kiállítás dátuma
                  <input name="date" type="date" />
                </label>
                <div className="epr-wide">
                  {manualLines.map((line, i) => (
                    <fieldset className="epr-component" key={i}>
                      <legend>{i + 1}. számlasor</legend>
                      {(
                        [
                          ["supplierSku", "Cikkszám"],
                          ["description", "Megnevezés"],
                          ["quantity", "Mennyiség"],
                          ["unit", "Egység"],
                          ["page", "Forrásoldal"],
                        ] as const
                      ).map(([key, text]) => (
                        <label className="epr-field" key={key}>
                          {text}
                          <input
                            value={line[key]}
                            required={key === "description"}
                            onChange={(e) =>
                              setManualLines((old) =>
                                old.map((v, n) => (n === i ? { ...v, [key]: e.target.value } : v))
                              )
                            }
                          />
                        </label>
                      ))}
                    </fieldset>
                  ))}
                  <button
                    className="button secondary"
                    type="button"
                    onClick={() =>
                      setManualLines((old) => [
                        ...old,
                        { supplierSku: "", description: "", quantity: "", unit: "", page: "" },
                      ])
                    }
                  >
                    Számlasor hozzáadása
                  </button>
                </div>
                <div className="epr-actions epr-wide">
                  <button className="button" disabled={busy}>
                    Számlaadatok mentése
                  </button>
                  <button
                    className="button secondary"
                    type="button"
                    onClick={() => setManual(false)}
                  >
                    Mégse
                  </button>
                </div>
              </form>
            </section>
          ) : null}
        </div>
      ) : null}
    </>
  );
}
