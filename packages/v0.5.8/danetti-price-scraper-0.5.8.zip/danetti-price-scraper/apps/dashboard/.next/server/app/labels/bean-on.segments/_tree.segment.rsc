:HL["/_next/static/chunks/0s7fv8p0n860f.css","style"]
:HL["/_next/static/chunks/2d5yakrqa9wkz.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"labels","param":null,"prefetchHints":4192,"slots":{"children":{"name":"bean-on","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"5IrFo6J675Qglnr3h_8JR"}
