import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const shellSource = readFileSync(
  new URL("./components/DashboardShell.tsx", import.meta.url),
  "utf8"
);
const navigationSource = readFileSync(
  new URL("./components/Navigation.tsx", import.meta.url),
  "utf8"
);

assert.match(shellSource, /sanitizeApiErrorDetail/);
assert.match(shellSource, /Biztonságos technikai részletek/);
assert.match(shellSource, /safeMessage/);
assert.match(shellSource, /AppUpdateControl/);
assert.doesNotMatch(shellSource, /<code>\{message\}<\/code>/);
assert.doesNotMatch(navigationSource, /Párosítások|\/mappings/);

console.log("Dashboard shell UI tests passed");
