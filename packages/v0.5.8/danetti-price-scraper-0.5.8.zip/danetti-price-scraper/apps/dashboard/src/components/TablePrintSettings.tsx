import type { TablePrintOptions } from "../products/table-print";

export function TablePrintSettings({
  value,
  onChange,
}: {
  value: TablePrintOptions;
  onChange: (value: TablePrintOptions) => void;
}) {
  return (
    <div className="table-print-settings">
      <label className="field-label">
        Papírméret
        <select
          className="input"
          value={value.paper}
          onChange={(event) =>
            onChange({ ...value, paper: event.target.value === "A3" ? "A3" : "A4" })
          }
        >
          <option value="A4">A4 fekvő</option>
          <option value="A3">A3 fekvő</option>
        </select>
      </label>
      <label className="field-label">
        PDF elrendezés
        <select
          className="input"
          value={value.layout}
          onChange={(event) =>
            onChange({ ...value, layout: event.target.value === "records" ? "records" : "columns" })
          }
        >
          <option value="columns">Oszlopcsoportok több lapon</option>
          <option value="records">Termékenkénti adatlap</option>
        </select>
      </label>
      <p className="helper-text">
        Sok oszlopnál több lapcsoport készül, olvasható betűmérettel és ismételt
        termékazonosítókkal. Az adatlap minden termék részleteit egy blokkban mutatja.
      </p>
    </div>
  );
}
