"use client";

import {
  useEffect,
  useRef,
  useState,
  type Dispatch,
  type SetStateAction,
  type PointerEvent,
} from "react";

export function useStoredColumnWidths<K extends string>(
  key: string,
  columns: readonly { id: K; width: number; minWidth: number }[]
) {
  const [widths, setWidths] = useState(
    () =>
      Object.fromEntries(columns.map((column) => [column.id, column.width])) as Record<K, number>
  );
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try {
      const stored = JSON.parse(localStorage.getItem(key) ?? "{}");
      if (stored && typeof stored === "object")
        setWidths(
          (current) =>
            Object.fromEntries(
              columns.map((column) => [
                column.id,
                typeof stored[column.id] === "number" && Number.isFinite(stored[column.id])
                  ? Math.max(column.minWidth, Math.min(1600, stored[column.id]))
                  : current[column.id],
              ])
            ) as Record<K, number>
        );
    } catch {
      /* Storage may be unavailable or contain an older preference. */
    }
    setReady(true);
  }, [key, columns]);
  useEffect(() => {
    if (ready)
      try {
        localStorage.setItem(key, JSON.stringify(widths));
      } catch {
        /* Keep resizing usable without storage. */
      }
  }, [key, ready, widths]);
  return [widths, setWidths] as const;
}

export function useColumnResize<K extends string>(
  widths: Record<K, number>,
  setWidths: Dispatch<SetStateAction<Record<K, number>>>,
  columns: readonly { id: K; minWidth: number }[]
) {
  const cleanup = useRef<(() => void) | null>(null);
  useEffect(() => () => cleanup.current?.(), []);
  return (id: K, event: PointerEvent<HTMLElement>) => {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    cleanup.current?.();
    const handle = event.currentTarget;
    const header = handle.closest("th")!;
    const table = header.closest("table")!;
    const col = table.querySelectorAll("col")[header.cellIndex] as HTMLElement;
    const startX = event.clientX;
    const startWidth = header.getBoundingClientRect().width;
    const startTableWidth = table.getBoundingClientRect().width;
    const min = columns.find((column) => column.id === id)?.minWidth ?? 90;
    let nextWidth = startWidth;
    let frame = 0;
    const cursor = document.body.style.cursor;
    const selection = document.body.style.userSelect;
    const originalTableWidth = table.style.width;
    const originalMinWidth = table.style.minWidth;
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
    table.classList.add("is-resizing");
    handle.setPointerCapture(event.pointerId);
    const paint = () => {
      frame = 0;
      col.style.width = `${nextWidth}px`;
      table.style.width = `${startTableWidth + nextWidth - startWidth}px`;
      table.style.minWidth = table.style.width;
    };
    const move = (e: globalThis.PointerEvent) => {
      nextWidth = Math.max(min, Math.min(1600, startWidth + e.clientX - startX));
      if (!frame) frame = requestAnimationFrame(paint);
    };
    const stop = (commit = true) => {
      cancelAnimationFrame(frame);
      handle.removeEventListener("pointermove", move);
      handle.removeEventListener("pointerup", finish);
      handle.removeEventListener("pointercancel", cancel);
      handle.removeEventListener("lostpointercapture", cancel);
      window.removeEventListener("blur", cancel);
      if (handle.hasPointerCapture(event.pointerId)) handle.releasePointerCapture(event.pointerId);
      table.classList.remove("is-resizing");
      document.body.style.cursor = cursor;
      document.body.style.userSelect = selection;
      cleanup.current = null;
      if (commit) {
        paint();
        setWidths((current) => ({ ...current, [id]: Math.round(nextWidth) }));
      } else {
        col.style.width = `${widths[id]}px`;
        table.style.width = originalTableWidth;
        table.style.minWidth = originalMinWidth;
      }
    };
    const finish = () => stop();
    const cancel = () => stop(false);
    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", finish);
    handle.addEventListener("pointercancel", cancel);
    handle.addEventListener("lostpointercapture", cancel);
    window.addEventListener("blur", cancel);
    cleanup.current = cancel;
  };
}

export function ColumnResizer({
  label,
  width,
  minWidth,
  onResize,
  onWidth,
}: {
  label: string;
  width: number;
  minWidth: number;
  onResize: (event: PointerEvent<HTMLElement>) => void;
  onWidth: (width: number) => void;
}) {
  return (
    <span
      className="column-resizer"
      role="separator"
      aria-label={`${label} oszlopszélesség`}
      aria-orientation="vertical"
      aria-valuemin={minWidth}
      aria-valuemax={1600}
      aria-valuenow={width}
      tabIndex={0}
      onPointerDown={onResize}
      title="Húzd a méretezéshez. Dupla kattintás: tartalomhoz igazítás. Nyilak: méretezés."
      onKeyDown={(event) => {
        if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
        event.preventDefault();
        event.stopPropagation();
        onWidth(
          Math.max(
            minWidth,
            Math.min(
              1600,
              width + (event.key === "ArrowRight" ? 1 : -1) * (event.shiftKey ? 50 : 10)
            )
          )
        );
      }}
      onDoubleClick={(event) => {
        event.preventDefault();
        event.stopPropagation();
        const header = event.currentTarget.closest("th")!;
        const cells = Array.from(header.closest("table")!.rows)
          .map((row) => row.cells[header.cellIndex])
          .filter(Boolean);
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d");
        if (!context) return;
        let size = minWidth;
        for (const cell of cells) {
          context.font = getComputedStyle(cell).font;
          const inputs = cell.querySelectorAll("input, select");
          const text = inputs.length
            ? Array.from(inputs)
                .map((input) =>
                  input instanceof HTMLSelectElement
                    ? (input.selectedOptions[0]?.text ?? "")
                    : (input as HTMLInputElement).value
                )
                .join(" ")
            : cell.innerText;
          for (const line of text.split("\n"))
            size = Math.max(size, context.measureText(line).width + 56);
        }
        onWidth(Math.min(900, Math.ceil(size)));
      }}
    />
  );
}

export function SortButton({
  label,
  direction,
  onClick,
  disabled = false,
}: {
  label: string;
  direction?: "asc" | "desc";
  onClick: () => void;
  disabled?: boolean;
}) {
  if (disabled) return <span>{label}</span>;
  return (
    <button
      className="table-sort-button"
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={`${label}: ${direction === "asc" ? "csökkenő" : "növekvő"} rendezés`}
    >
      {label}
      <svg
        className={`table-sort-icon ${direction ? "is-active" : ""}`}
        width="14"
        height="16"
        viewBox="0 0 14 16"
        aria-hidden="true"
      >
        {direction !== "desc" && (
          <path d="M3 6 7 2l4 4M7 2v11" fill="none" stroke="currentColor" strokeWidth="1.5" />
        )}
        {direction !== "asc" && (
          <path d="m3 10 4 4 4-4M7 14V3" fill="none" stroke="currentColor" strokeWidth="1.5" />
        )}
      </svg>
    </button>
  );
}
