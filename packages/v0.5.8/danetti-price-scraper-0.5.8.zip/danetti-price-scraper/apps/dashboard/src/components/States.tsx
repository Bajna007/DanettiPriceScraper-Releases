import type { ReactNode } from "react";
import { ErrorDetails, SummaryMetric } from "./DashboardShell";

export function LoadingState({ message }: { message?: string }) {
  return (
    <p className="status" aria-live="polite">
      {message ?? "Betöltés..."}
    </p>
  );
}

export function ErrorState({ message }: { message: string }) {
  const databaseHint = message.includes("DATABASE_URL") || /database|adatbázis/i.test(message);
  const credentialHint =
    /belépési adat|Credential Manager|DVG|cikkszám|Hibakód|mentett belépési adat/i.test(message);
  const localApiHint = message === "Helyi API nem érhető el.";
  const title = credentialHint
    ? "Belépési adat művelet sikertelen"
    : localApiHint
      ? "Helyi API nem érhető el"
      : "Nem sikerült betölteni";
  return (
    <div className="notice error" role="alert">
      <p className="card-title">{title}</p>
      {databaseHint ? (
        <>
          <p>Az API válaszolhat, de a helyi adatbázis vagy futtatási környezet hiányzik.</p>
          <p className="helper-text">
            Ajánlott indítás: <code>npm.cmd run local:web</code>. Ez előkészíti a helyi webes
            folyamatokat.
          </p>
        </>
      ) : credentialHint || localApiHint ? (
        <p className="helper-text">{message}</p>
      ) : (
        <p className="helper-text">Ellenőrizd, hogy a helyi API fut-e, majd próbáld újra.</p>
      )}
      <ErrorDetails message={message} />
    </div>
  );
}

export function EmptyState({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="notice info">
      <p className="card-title">{title}</p>
      {children ? <p>{children}</p> : null}
    </div>
  );
}

export function SummaryCard({
  title,
  value,
  helper,
}: {
  title: string;
  value: string | number;
  helper?: string;
}) {
  return <SummaryMetric title={title} value={value} helper={helper} />;
}
