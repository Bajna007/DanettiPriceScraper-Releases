"use client";

import { useCallback, useEffect, useState } from "react";
import {
  checkAppUpdate,
  formatApiErrorMessage,
  getAppUpdateInstallStatus,
  getAppUpdateStatus,
  installAppUpdate,
  type AppUpdateStatus,
} from "../lib/api";

const dismissalKey = "danetti-dismissed-update-version";
const installPollIntervalMs = 2_000;
const installMonitorTimeoutMs = 15 * 60_000;

function wait(milliseconds: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
}

export function AppUpdateControl() {
  const [update, setUpdate] = useState<AppUpdateStatus | null>(null);
  const [open, setOpen] = useState(false);
  const [checking, setChecking] = useState(false);
  const [installing, setInstalling] = useState(false);

  const check = useCallback(async (force: boolean) => {
    setChecking(true);
    try {
      const next = force ? await checkAppUpdate() : await getAppUpdateStatus();
      setUpdate(next);
      if (next.status === "available") {
        const dismissed = window.sessionStorage.getItem(dismissalKey);
        if (force || dismissed !== next.availableVersion) setOpen(true);
      } else if (force) {
        setOpen(true);
      }
    } catch (error) {
      setUpdate({
        status: "unavailable",
        currentVersion: "",
        message: formatApiErrorMessage(error),
      });
      if (force) setOpen(true);
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => {
    void check(false);
  }, [check]);

  async function install(): Promise<void> {
    if (!update?.availableVersion) return;
    const expectedVersion = update.availableVersion;
    setInstalling(true);
    try {
      setUpdate(await installAppUpdate(expectedVersion));
      void monitorInstall(expectedVersion);
    } catch (error) {
      setUpdate({ ...update, message: formatApiErrorMessage(error) });
      setInstalling(false);
    }
  }

  async function monitorInstall(expectedVersion: string): Promise<void> {
    const deadline = Date.now() + installMonitorTimeoutMs;
    while (Date.now() < deadline) {
      try {
        const status = await getAppUpdateInstallStatus();
        if (status.version === expectedVersion) {
          setUpdate((current) => (current ? { ...current, message: status.message } : current));
          if (status.state === "failed") {
            setInstalling(false);
            return;
          }
          if (status.state === "complete") {
            window.location.reload();
            return;
          }
        }
      } catch {
        // The API is expected to be unavailable briefly while the updater replaces files.
      }
      await wait(installPollIntervalMs);
    }
    setUpdate((current) =>
      current
        ? {
            ...current,
            message:
              "A frissítés nem fejeződött be 15 percen belül. Indítsd újra a Danettit, majd ellenőrizd újra a frissítést.",
          }
        : current
    );
    setInstalling(false);
  }

  const isAvailable = update?.status === "available";
  return (
    <div className="app-update-control">
      <button
        type="button"
        className="button ghost small app-update-button"
        onClick={() => void check(true)}
        disabled={checking || installing}
        aria-label="Danetti frissítés ellenőrzése"
      >
        {checking ? "Ellenőrzés…" : "Frissítés"}
        {isAvailable && update.availableVersion ? (
          <span className="app-update-version">v{update.availableVersion}</span>
        ) : null}
      </button>
      {open ? (
        <div className="app-update-backdrop" role="presentation">
          <section
            className="app-update-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="app-update-title"
          >
            <h2 id="app-update-title">
              {isAvailable && update?.availableVersion
                ? `Frissítés: v${update.availableVersion}`
                : "Danetti frissítés"}
            </h2>
            <p>{update?.message ?? "Frissítés ellenőrzése folyamatban."}</p>
            {isAvailable && update?.changelog ? (
              <p className="app-update-changelog">{update.changelog}</p>
            ) : null}
            <div className="app-update-actions">
              {isAvailable ? (
                <button
                  type="button"
                  className="button"
                  onClick={() => void install()}
                  disabled={installing}
                >
                  {installing ? "Frissítés indul…" : "Frissítés és újraindítás"}
                </button>
              ) : null}
              <button
                type="button"
                className="button secondary"
                onClick={() => {
                  if (update?.availableVersion)
                    window.sessionStorage.setItem(dismissalKey, update.availableVersion);
                  setOpen(false);
                }}
              >
                {installing ? "Ablak bezárása" : isAvailable ? "Később" : "Bezárás"}
              </button>
            </div>
          </section>
        </div>
      ) : null}
    </div>
  );
}
