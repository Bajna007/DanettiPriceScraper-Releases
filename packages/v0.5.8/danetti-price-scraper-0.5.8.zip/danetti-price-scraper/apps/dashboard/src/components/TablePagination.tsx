export function TablePagination({
  canGoBack,
  canGoNext,
  label,
  onBack,
  onNext,
  compact = false,
}: {
  canGoBack: boolean;
  canGoNext: boolean;
  label: string;
  onBack: () => void;
  onNext: () => void;
  compact?: boolean;
}) {
  return (
    <div className={`pagination ${compact ? "pagination--compact" : ""}`}>
      <button className="button secondary" type="button" onClick={onBack} disabled={!canGoBack}>
        Előző
      </button>
      <button className="button secondary" type="button" onClick={onNext} disabled={!canGoNext}>
        Következő
      </button>
      <span className="status">{label}</span>
    </div>
  );
}
