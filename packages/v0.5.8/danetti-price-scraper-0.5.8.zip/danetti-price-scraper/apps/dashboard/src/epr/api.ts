import { normalizeLocalApiBaseUrl } from "../lib/api";
const apiBase = normalizeLocalApiBaseUrl(
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:4000"
);
export const eprApiBase = apiBase;
export async function eprRequest<T>(path: string, method = "GET", body?: unknown): Promise<T> {
  const response = await fetch(`${apiBase}${path}`, {
    method,
    cache: "no-store",
    headers: {
      "x-danetti-epr": "1",
      ...(body === undefined ? {} : { "Content-Type": "application/json" }),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.code ?? "epr_operation_failed");
  return data as T;
}
export const errors: Record<string, string> = {
  chatgpt_auth_cancelled: "A csatlakoztatás megszakadt. Újraindíthatod a bejelentkezést.",
  chatgpt_auth_callback_expired: "A bejelentkezési idő lejárt. Indíts új csatlakozást.",
  chatgpt_oauth_client_not_eligible:
    "Az OpenAI nem engedélyezte ennek a helyi alkalmazásnak a csatlakozását.",
  chatgpt_plan_permission_missing:
    "A ChatGPT-plan használata nem lett engedélyezve. Csatlakozz újra és engedélyezd.",
  chatgpt_reauthorization_required:
    "A ChatGPT kapcsolat lejárt vagy vissza lett vonva. Csatlakozz újra.",
  chatgpt_temporarily_unavailable: "A ChatGPT átmenetileg nem elérhető. Próbáld újra később.",
  chatgpt_model_selection_required: "Válassz feldolgozási modellt a kapcsolat tesztelése előtt.",
  mailbox_setup_required: "Adj hozzá és tesztelj legalább egy IMAP-postafiókot a beállításokban.",
  mailbox_auth_failed:
    "A postafiók elutasította a belépést. Ellenőrizd a felhasználónevet és a jelszót vagy alkalmazásjelszót.",
  mailbox_starttls_required:
    "A szerver nem biztosít kötelező STARTTLS-kapcsolatot. Ellenőrizd a hostot, portot és a biztonsági módot.",
  mailbox_tls_certificate_invalid:
    "A postafiók TLS-tanúsítványa nem érvényes. A kapcsolat nem indult el.",
  mailbox_connection_failed:
    "Az IMAP-szerver nem érhető el. Ellenőrizd a hostot, portot és a hálózatot.",
  mailbox_identity_change_requires_new_account:
    "Másik postafiókhoz új konfigurációt kell hozzáadni, hogy a levélazonosítók elkülönüljenek.",
  period_closed:
    "A lezárt időszak adatai védettek. A későbbi bizonyítékot nyitott időszakban ellenőrizd.",
  period_scan_in_progress: "A feldolgozás még fut. Lezárás előtt várd meg a végét.",
  period_review_required:
    "A lezárás előtt ellenőrizd vagy zárd ki az összes teendőt és potenciális beszerzést.",
  accounting_configuration_required:
    "Rögzítsd az elszámolási alapot és eseményt a beállításokban, majd válassz elszámolási dátumot.",
  accounting_date_outside_period:
    "Az elszámolási dátum nem esik a kiválasztott negyedévbe. Helyezd át a beszerzést a megfelelő időszakba.",
  material_rule_missing: "Ehhez a cikkszámhoz még nincs érvényes, jóváhagyott anyagszabály.",
  unit_conversion_missing:
    "A számlaegység eltér a szabály egységétől. Rögzíts igazolt egységátváltást.",
  quantity_missing:
    "A mennyiség vagy az egység hiányzik. Az eredeti számla alapján javítsd a sort.",
  quantity_invalid: "A mennyiséget tizedesponttal, szóköz nélkül add meg.",
  packaging_quantity_missing: "Rögzítsd a csomagok vagy szállítmányok ellenőrzött mennyiségét.",
  credit_material_review_required:
    "A jóváírás anyaghatását külön jóvá kell hagyni a sor javításánál.",
  shipment_packaging_duplicate:
    "Ugyanaz a szállítmánycsomagolás már szerepel ebben a beszerzésben. Ellenőrizd és zárd ki a kettős sort.",
  document_conflict:
    "Eltérő változatok tartoznak ugyanahhoz a bizonylathoz. Ellenőrizd és zárd ki a hibás változatot.",
  document_accounting_review_required:
    "Ez a bizonylat nem igazolt elszámolási számla. Ellenőrizd és szükség esetén zárd ki a sort.",
  document_already_reviewed:
    "A dokumentum már tartalmaz ellenőrizendő számlasorokat. A sorok javítását használd.",
  document_extraction_schema_invalid:
    "A számlaadatok hiányosak vagy hibás formátumúak. Ellenőrizd a mezőket.",
  material_rule_invalid:
    "A szabályhoz pontos cikkszám, dátum, pozitív mért súly és igazolt forrás szükséges.",
  epr_queue_unavailable:
    "A feldolgozási sor nem érhető el. Ellenőrizd a helyi Redis-szolgáltatást.",
  epr_scan_recovery_required:
    "A korábbi feldolgozás megszakadt. Újraindíthatod; az elmentett levelek nem duplázódnak.",
  document_size_invalid:
    "A bizonylat mérethatárt lépett túl. Az eredeti nem került letöltésre; kézi ellenőrzés és kisebb dokumentum szükséges.",
  document_too_large: "A dokumentum túl nagy. Legfeljebb 20 MB-os bizonylat tölthető fel.",
  credential_store_unavailable:
    "A Windows biztonságos titoktárolója nem elérhető. Ellenőrizd a Windows-felhasználói munkamenetet.",
};
export function eprError(error: unknown) {
  const code = error instanceof Error ? error.message : "";
  return (
    errors[code] ?? `A művelet nem fejeződött be (${code || "ismeretlen hiba"}). Próbáld újra.`
  );
}

export function eprReason(code: string) {
  const descriptions: Record<string, string> = {
    invoice_number_detected: "Számlaszámot tartalmazó dokumentum.",
    commercial_attachment_candidate: "Lehetséges üzleti melléklet.",
    commercial_subject: "Beszerzésre vagy számlára utaló levéltárgy.",
    extraction_review_required: "A számlaadatok kinyerése kézi ellenőrzést igényel.",
    original_not_downloaded: "Az eredeti tartalom a mérethatár miatt nem került letöltésre.",
    operator_extracted: "Operátor által rögzített számlaadatok.",
  };
  return descriptions[code] ?? errors[code] ?? code.replaceAll("_", " ");
}
