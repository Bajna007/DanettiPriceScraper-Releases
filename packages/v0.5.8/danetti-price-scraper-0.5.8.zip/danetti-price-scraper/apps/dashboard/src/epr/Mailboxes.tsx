"use client";
import { useEffect, useState, type FormEvent } from "react";
import { eprError, eprRequest } from "./api";
type Mailbox = {
  id: string;
  name: string;
  host: string;
  port: number;
  security: string;
  folders: string[];
  maskedIdentity: string;
  status: string;
  enabled: boolean;
};
export function Mailboxes() {
  const [items, setItems] = useState<Mailbox[]>([]),
    [error, setError] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(true);
  const [editing, setEditing] = useState<Mailbox | "new" | null>(null),
    [removing, setRemoving] = useState<Mailbox | null>(null);
  const [folders, setFolders] = useState<
      { path: string; selected: boolean; excludedByDefault: boolean }[]
    >([]),
    [folderMailbox, setFolderMailbox] = useState<Mailbox | null>(null);
  async function load() {
    setItems((await eprRequest<{ items: Mailbox[] }>("/epr/mailboxes")).items);
  }
  useEffect(() => {
    load()
      .catch((e) => setError(eprError(e)))
      .finally(() => setBusy(false));
  }, []);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget,
      data = new FormData(form);
    setBusy(true);
    setError("");
    try {
      const result = await eprRequest<Mailbox>(
        editing !== "new" && editing ? `/epr/mailboxes/${editing.id}` : "/epr/mailboxes",
        editing !== "new" && editing ? "PUT" : "POST",
        {
          name: data.get("name"),
          host: data.get("host"),
          port: Number(data.get("port")),
          security: data.get("security"),
          username: data.get("username"),
          password: data.get("password"),
          folders: editing && editing !== "new" ? editing.folders : ["INBOX"],
          enabled: true,
        }
      );
      form.reset();
      setEditing(null);
      await load();
      await test(result);
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  async function test(mailbox: Mailbox) {
    setBusy(true);
    setError("");
    try {
      const result = await eprRequest<{ folders: typeof folders }>(
        `/epr/mailboxes/${mailbox.id}/test`,
        "POST"
      );
      setFolders(result.folders);
      setFolderMailbox(mailbox);
      setMessage("Kapcsolat rendben. Válaszd ki a feldolgozandó mappákat.");
      await load();
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="epr-section" aria-labelledby="mailbox-title">
      <h2 id="mailbox-title">Mailboxok</h2>
      {items.length === 0 ? (
        <p>Még nincs mailbox. Adj hozzá egy saját IMAP-postafiókot a számlák feldolgozásához.</p>
      ) : (
        <ul className="epr-mailboxes">
          {items.map((m) => (
            <li key={m.id}>
              <div>
                <strong>{m.name}</strong>
                <p>
                  {m.maskedIdentity} · {m.host} ·{" "}
                  {m.status === "ok" ? "Kapcsolat rendben" : "Kapcsolat tesztelése szükséges"}
                </p>
                <p>Mappák: {m.folders.join(", ")}</p>
              </div>
              <div className="epr-actions">
                <button className="button secondary" disabled={busy} onClick={() => test(m)}>
                  Tesztelés és mappák
                </button>
                <button className="button secondary" disabled={busy} onClick={() => setEditing(m)}>
                  Szerkesztés
                </button>
                <button className="button secondary" disabled={busy} onClick={() => setRemoving(m)}>
                  Eltávolítás
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
      {editing ? (
        <form onSubmit={submit} className="epr-form">
          <h3>{editing === "new" ? "Mailbox hozzáadása" : "Mailbox szerkesztése"}</h3>
          <label className="epr-field">
            Név
            <input
              name="name"
              defaultValue={editing === "new" ? "" : editing.name}
              maxLength={100}
              required
            />
          </label>
          <label className="epr-field">
            IMAP host
            <input
              name="host"
              defaultValue={editing === "new" ? "" : editing.host}
              maxLength={253}
              required
            />
          </label>
          <label className="epr-field">
            Port
            <input
              name="port"
              type="number"
              min={1}
              max={65535}
              defaultValue={editing === "new" ? 143 : editing.port}
              required
            />
          </label>
          <label className="epr-field">
            Biztonság
            <select
              name="security"
              defaultValue={editing === "new" ? "STARTTLS" : editing.security}
            >
              <option value="STARTTLS">STARTTLS kötelező</option>
              <option value="TLS">TLS (általában 993-as port)</option>
            </select>
          </label>
          <label className="epr-field">
            Felhasználónév
            <input name="username" autoComplete="off" maxLength={500} required />
          </label>
          <label className="epr-field">
            Jelszó
            <input
              name="password"
              type="password"
              autoComplete="new-password"
              maxLength={1500}
              required
            />
          </label>
          <p>
            A hozzáférési adatok a Windows biztonságos titoktárolójába kerülnek. A levelek olvasása
            nem módosítja a postafiókot.
          </p>
          <div className="epr-actions">
            <button className="button" disabled={busy} type="submit">
              Mentés és kapcsolat tesztelése
            </button>
            <button
              className="button secondary"
              disabled={busy}
              type="button"
              onClick={() => setEditing(null)}
            >
              Mégse
            </button>
          </div>
        </form>
      ) : (
        <button className="button secondary" disabled={busy} onClick={() => setEditing("new")}>
          Mailbox hozzáadása
        </button>
      )}
      {folderMailbox ? (
        <div className="epr-confirm">
          <h3>Feldolgozandó mappák · {folderMailbox.name}</h3>
          {folders.map((f, i) => (
            <label className="epr-checkbox" key={f.path}>
              <input
                type="checkbox"
                checked={f.selected}
                onChange={(e) =>
                  setFolders((old) =>
                    old.map((v, n) => (n === i ? { ...v, selected: e.target.checked } : v))
                  )
                }
              />
              {f.path}
              {f.excludedByDefault ? " (levélszemét/törölt)" : ""}
            </label>
          ))}
          <button
            className="button"
            disabled={busy || !folders.some((f) => f.selected)}
            onClick={async () => {
              setBusy(true);
              try {
                await eprRequest(`/epr/mailboxes/${folderMailbox.id}/folders`, "PUT", {
                  folders: folders.filter((f) => f.selected).map((f) => f.path),
                  enabled: true,
                });
                setFolderMailbox(null);
                await load();
                setMessage("Mappák mentve.");
              } catch (e) {
                setError(eprError(e));
              } finally {
                setBusy(false);
              }
            }}
          >
            Mappák mentése
          </button>
        </div>
      ) : null}
      {removing ? (
        <div className="epr-confirm">
          <h3>Mailbox eltávolítása · {removing.name}</h3>
          <p>
            A mentett hozzáférés és mailbox-konfiguráció törlődik. A számlák, beszerzések és lezárt
            időszakok megmaradnak.
          </p>
          <div className="epr-actions">
            <button className="button secondary" onClick={() => setRemoving(null)} disabled={busy}>
              Mégse
            </button>
            <button
              className="button"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  await eprRequest(`/epr/mailboxes/${removing.id}`, "DELETE");
                  setRemoving(null);
                  await load();
                } catch (e) {
                  setError(eprError(e));
                } finally {
                  setBusy(false);
                }
              }}
            >
              Eltávolítás
            </button>
          </div>
        </div>
      ) : null}
      {error ? (
        <p role="alert" className="epr-error">
          {error}
        </p>
      ) : null}
      {message ? <p role="status">{message}</p> : null}
    </section>
  );
}
