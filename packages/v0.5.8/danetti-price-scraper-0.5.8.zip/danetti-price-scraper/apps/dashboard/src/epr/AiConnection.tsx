"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { eprError, eprRequest } from "./api";
type Status = {
  connected: boolean;
  emailDisplay: string | null;
  planUsageEnabled: boolean;
  lastErrorCode: string | null;
  model: string | null;
};
export function AiConnection() {
  const [status, setStatus] = useState<Status | null>(null);
  const [models, setModels] = useState<{ slug: string; display_name: string }[]>([]);
  const [attempt, setAttempt] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [confirmDisconnect, setConfirmDisconnect] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const load = useCallback(async () => {
    const value = await eprRequest<Status>("/epr/ai/status");
    setStatus(value);
    if (value.connected)
      setModels((await eprRequest<{ items: typeof models }>("/epr/ai/models")).items);
  }, []);
  useEffect(() => {
    load().catch((error) => setError(eprError(error)));
  }, [load]);
  useEffect(() => {
    if (!attempt) return;
    let cancelled = false;
    async function poll() {
      try {
        const result = await eprRequest<{ status: string; errorCode: string | null }>(
          `/epr/ai/auth/attempt/${attempt}`
        );
        if (cancelled) return;
        if (result.status === "completed") {
          setAttempt(null);
          await load();
          setMessage("ChatGPT kapcsolat létrejött.");
          return;
        }
        if (result.status === "failed") {
          setAttempt(null);
          setError(eprError(new Error(result.errorCode ?? "chatgpt_auth_cancelled")));
          return;
        }
      } catch (error) {
        if (!cancelled) setError(eprError(error));
      }
      if (!cancelled) timer.current = setTimeout(poll, 2000);
    }
    void poll();
    return () => {
      cancelled = true;
      if (timer.current) clearTimeout(timer.current);
    };
  }, [attempt, load]);
  async function connect() {
    // Open synchronously so browsers do not block the authorization window.
    const popup = window.open("about:blank", "_blank");
    if (popup) popup.opener = null;
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const result = await eprRequest<{ id: string; openUrl: string }>(
        "/epr/ai/auth/start",
        "POST"
      );
      if (!popup)
        throw new Error(
          "A böngésző letiltotta a bejelentkezési ablakot. Engedélyezd a felugró ablakokat."
        );
      popup.location.href = result.openUrl;
      setAttempt(result.id);
    } catch (error) {
      popup?.close();
      setError(eprError(error));
    } finally {
      setBusy(false);
    }
  }
  async function action(path: string) {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const result = await eprRequest<{ remoteRevocationConfirmed?: boolean }>(path, "POST");
      setMessage(
        path.endsWith("disconnect")
          ? result.remoteRevocationConfirmed
            ? "A kapcsolat leválasztva."
            : "A helyi kapcsolat leválasztva. A távoli visszavonás nem igazolt; ellenőrizheted a ChatGPT beállításaiban."
          : "A ChatGPT inference kapcsolat működik."
      );
      setConfirmDisconnect(false);
      await load();
    } catch (error) {
      setError(eprError(error));
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="epr-section" aria-labelledby="ai-title">
      <h2 id="ai-title">AI kapcsolat</h2>
      {status === null ? (
        <p>Kapcsolat ellenőrzése…</p>
      ) : (
        <>
          <p>
            <strong>{status.connected ? "Csatlakoztatva" : "Nincs csatlakoztatva"}</strong>
            {status.emailDisplay && status.connected ? ` · ${status.emailDisplay}` : ""}
          </p>
          {status.connected ? (
            <>
              <p>
                ChatGPT-plan használat:{" "}
                {status.planUsageEnabled ? "Engedélyezve" : "Nincs engedélyezve"}
              </p>
              <label className="epr-field">
                Feldolgozási modell
                <select
                  value={status.model ?? ""}
                  disabled={busy}
                  onChange={async (event) => {
                    setBusy(true);
                    setError("");
                    try {
                      await eprRequest("/epr/ai/model", "PUT", { model: event.target.value });
                      await load();
                    } catch (error) {
                      setError(eprError(error));
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  <option value="" disabled>
                    Válassz modellt…
                  </option>
                  {models.map((model) => (
                    <option key={model.slug} value={model.slug}>
                      {model.display_name}
                    </option>
                  ))}
                </select>
              </label>
              <div className="epr-actions">
                <button
                  className="button secondary"
                  disabled={busy || !status.model}
                  onClick={() => action("/epr/ai/test")}
                >
                  Kapcsolat tesztelése
                </button>
                <button
                  className="button secondary"
                  disabled={busy}
                  onClick={() => setConfirmDisconnect(true)}
                >
                  Leválasztás
                </button>
                <a href="https://chatgpt.com/settings/usage" target="_blank" rel="noreferrer">
                  Használat kezelése
                </a>
              </div>
            </>
          ) : (
            <button className="button epr-chatgpt" disabled={busy || !!attempt} onClick={connect}>
              {attempt ? "Bejelentkezés folyamatban…" : "Continue with ChatGPT"}
            </button>
          )}
          {status.lastErrorCode && !status.connected ? (
            <p role="status">{eprError(new Error(status.lastErrorCode))}</p>
          ) : null}
        </>
      )}
      {error ? (
        <p className="epr-error" role="alert">
          {error}
        </p>
      ) : null}
      {message ? <p role="status">{message}</p> : null}
      {confirmDisconnect ? (
        <div className="epr-confirm" role="group" aria-label="ChatGPT kapcsolat leválasztása">
          <h3>ChatGPT kapcsolat leválasztása</h3>
          <p>
            Ez eltávolítja a helyben tárolt OAuth hozzáférést. A számlák, beszerzések, számítások és
            lezárt időszakok megmaradnak.
          </p>
          <div className="epr-actions">
            <button
              className="button secondary"
              disabled={busy}
              onClick={() => setConfirmDisconnect(false)}
            >
              Mégse
            </button>
            <button className="button" disabled={busy} onClick={() => action("/epr/ai/disconnect")}>
              Leválasztás
            </button>
          </div>
        </div>
      ) : null}
    </section>
  );
}
