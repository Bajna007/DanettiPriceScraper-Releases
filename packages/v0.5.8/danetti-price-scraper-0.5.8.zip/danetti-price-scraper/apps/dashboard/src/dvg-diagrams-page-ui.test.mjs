import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const routeSource = readFileSync(new URL("../app/dvg-diagrams/page.tsx", import.meta.url), "utf8");
const cssSource = readFileSync(new URL("../app/globals.css", import.meta.url), "utf8");
const navSource = readFileSync(new URL("./components/Navigation.tsx", import.meta.url), "utf8");
const apiSource = readFileSync(new URL("./lib/api.ts", import.meta.url), "utf8");

assert.match(navSource, /\/dvg-diagrams/);
assert.match(navSource, /DVG Robbantott ábrák/);

assert.match(routeSource, /DvgDiagramsPage/);
assert.match(routeSource, /Kávégépek/);
assert.match(routeSource, /Őrlők \/ darálók/);
assert.match(routeSource, /listDvgDiagramBrands/);
assert.match(routeSource, /listDvgDiagrams/);
assert.match(routeSource, /convertDvgDiagram/);
assert.match(routeSource, /WooCommerce írás nélkül/);
assert.match(routeSource, /Márka keresése/);
assert.match(routeSource, /Konvertálás/);
assert.match(routeSource, /HTML másolása/);
assert.match(routeSource, /diagramName/);
assert.match(routeSource, /Kép URL/);
assert.match(routeSource, /Kép URL ehhez a cikkhez/);
assert.match(routeSource, /imageUrls/);
assert.match(routeSource, /onImageUrlChange/);
assert.match(routeSource, /buildDisplayedHtml/);
assert.match(routeSource, /resolveOutputImageSrc/);
assert.match(routeSource, /Kép megnyitása/);
assert.match(routeSource, /Kép vágólapra másolása/);
assert.match(routeSource, /copyDiagramImageToClipboard/);
assert.match(routeSource, /DVG oldal/);
assert.doesNotMatch(routeSource, /allowSnapshotWrite|WooCommerce write|password|token/i);
assert.doesNotMatch(routeSource, /Összes kijelölése|data-table--compact|<colgroup>/);
assert.doesNotMatch(routeSource, /Kész kép URL|placeholderBaseUrl|baseImageUrl/);
assert.doesNotMatch(routeSource, /Kép URL másolása/);

assert.match(apiSource, /DvgDiagramFamily/);
assert.match(apiSource, /listDvgDiagramBrands/);
assert.match(apiSource, /listDvgDiagrams/);
assert.match(apiSource, /convertDvgDiagram/);
assert.match(apiSource, /generateDvgDiagrams/);
assert.match(apiSource, /\/dvg-diagrams\/brands/);
assert.match(apiSource, /\/dvg-diagrams\/diagrams/);
assert.match(apiSource, /\/dvg-diagrams\/convert/);
assert.match(apiSource, /\/dvg-diagrams\/generate/);
assert.match(apiSource, /formData\.append\("logo"/);

assert.match(cssSource, /\.dvg-diagrams-page/);
assert.match(cssSource, /\.dvg-diagram-workflow/);
assert.match(cssSource, /\.dvg-brand-picker/);
assert.match(cssSource, /\.dvg-brand-chip/);
assert.match(cssSource, /\.dvg-diagram-row/);
assert.match(cssSource, /\.dvg-diagram-html-output/);
assert.match(cssSource, /\.dvg-diagram-branded-preview/);
assert.match(cssSource, /\.dvg-diagram-image-row/);
assert.match(cssSource, /\.dvg-diagram-image-url-field/);
assert.match(cssSource, /\.dvg-diagram-product-name/);

console.log("DVG diagrams page UI tests passed");
