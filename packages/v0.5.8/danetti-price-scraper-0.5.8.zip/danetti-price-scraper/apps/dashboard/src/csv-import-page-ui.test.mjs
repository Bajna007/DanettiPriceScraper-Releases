import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const routeSource = readFileSync(new URL("../app/csv-import/page.tsx", import.meta.url), "utf8");
const cssSource = readFileSync(new URL("../app/globals.css", import.meta.url), "utf8");

assert.match(routeSource, /WooCommerce CSV feltöltése/);
assert.match(routeSource, /Előnézet készítése/);
assert.match(routeSource, /Teljes lista importálása/);
assert.match(routeSource, /Figyelmeztetések teljes listája/);
assert.match(routeSource, /Mi történik\?/);
assert.match(routeSource, /Kész: helyi katalógus frissítve/);
assert.match(routeSource, /CSV fejléc segítség/);
assert.match(routeSource, /CSV ellenőrzése kész/);
assert.match(routeSource, /A jelzések csak figyelmeztetések/);
assert.match(routeSource, /Név nélkül, importálva/);
assert.match(routeSource, /Azonosító/);
assert.match(routeSource, /Cikkszám/);
assert.match(routeSource, /Név/);
assert.match(routeSource, /Típus/);
assert.match(routeSource, /Normál ár/);
assert.match(routeSource, /Akciós ár/);
assert.match(routeSource, /Szülő/);
assert.match(routeSource, /Magyar fejléc/);
assert.match(routeSource, /Woo fejléc/);
assert.match(routeSource, /navigator\.clipboard\.writeText/);
assert.match(routeSource, /csv-copy-button/);
assert.match(routeSource, /viewBox="0 0 16 16"/);
assert.doesNotMatch(routeSource, /Felismert CSV oszlopok|ColumnMappingReport/);
assert.match(routeSource, /Új cikkszám bekerül/);
assert.match(routeSource, /DVG ár és haszon megmarad/);
assert.match(routeSource, /CSV-ből hiányzó termék nem törlődik/);
assert.match(routeSource, /missing_name/);
assert.match(routeSource, /missing_sku/);
assert.match(routeSource, /duplicate_sku/);
assert.match(routeSource, /invalid_regular_price/);
assert.match(routeSource, /SKU-alapú helyettesítő névvel/);
assert.match(routeSource, /SKU: \$\{issue\.sku\}/);
assert.match(routeSource, /issues\.map/);
assert.match(routeSource, /disabled=\{isImporting\}/);
assert.doesNotMatch(
  routeSource,
  /ISSUE_PREVIEW_LIMIT|További \{hiddenIssueCount\}|blockingIssues|hasBlockingNameError|isBlockingIssue/
);
assert.doesNotMatch(routeSource, /deleteConfirmation|Törlés megerősítése|helyben törlődik/);
assert.doesNotMatch(routeSource, /Oszlop párosítás/);
assert.doesNotMatch(routeSource, /columnMapping\] = useState/);
assert.doesNotMatch(routeSource, /mappingFields/);
assert.doesNotMatch(routeSource, /WooCommerce termék CSV beolvasása a helyi katalógusba/);
assert.doesNotMatch(routeSource, /A fájlt először csak ellenőrizzük/);
assert.doesNotMatch(
  routeSource,
  /Vonalkód|Aktuális ár|Készlet állapot|Készleten\?|Készlet mennyiség|Szülő cikkszám/
);

assert.match(cssSource, /\.csv-import-page/);
assert.match(cssSource, /\.csv-field-row/);
assert.match(cssSource, /\.csv-copy-token/);
assert.match(cssSource, /\.csv-copy-button/);
assert.match(cssSource, /\.csv-copy-feedback/);
assert.doesNotMatch(cssSource, /\.csv-technical-details/);
assert.match(cssSource, /\.csv-result-banner/);
assert.match(cssSource, /\.csv-metric-strip/);
assert.match(cssSource, /\.csv-issues-table/);
assert.match(cssSource, /\.csv-issues-scroll/);
assert.match(cssSource, /\.csv-import-action/);
assert.match(cssSource, /\.csv-help-summary/);
assert.match(cssSource, /\.csv-field-intro/);
assert.match(cssSource, /overflow:\s*auto/);
assert.match(cssSource, /\.table\.data-table\.csv-issues-table[\s\S]*width:\s*100%/);
assert.doesNotMatch(routeSource, /<details|<summary|Lenyitás|csv-help-summary-action/);
assert.doesNotMatch(cssSource, /csv-help-details\[open\]|csv-help-summary-action/);
assert.doesNotMatch(routeSource, /csv-help-summary-icon/);
assert.doesNotMatch(cssSource, /\.csv-help-summary-icon/);

console.log("CSV import page UI tests passed");
