import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./e2e",
  testMatch: "label-preview-parity.spec.ts",
  workers: 1,
  retries: 0,
  timeout: 180000,
  expect: { timeout: 15000 },
  use: { baseURL: "http://localhost:3000", trace: "off" },
});
