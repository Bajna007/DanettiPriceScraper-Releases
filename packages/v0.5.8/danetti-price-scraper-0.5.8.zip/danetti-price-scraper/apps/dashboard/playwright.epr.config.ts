import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  testMatch: "epr.spec.ts",
  workers: 1,
  retries: 0,
  timeout: 45_000,
  outputDir: "../../tmp/epr-browser",
  use: {
    channel: process.env.EPR_BROWSER_CHANNEL ?? "chrome",
    baseURL: "http://localhost:3000",
    trace: "retain-on-failure",
  },
});
