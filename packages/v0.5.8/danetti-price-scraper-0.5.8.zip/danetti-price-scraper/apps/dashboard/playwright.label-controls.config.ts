import { defineConfig } from "@playwright/test";

// Only fixture data is used: this test never starts the API or writes an operator database.
export default defineConfig({
  testDir: "./e2e",
  testMatch: "label-controls.spec.ts",
  workers: 1,
  retries: 0,
  timeout: 120_000,
  expect: { timeout: 15_000 },
  use: { baseURL: "http://localhost:3006", trace: "retain-on-failure", actionTimeout: 15_000 },
  webServer: {
    command:
      "npm.cmd run build --workspace @danetti/label-engine && node ../../node_modules/next/dist/bin/next dev -p 3006",
    url: "http://localhost:3006",
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
