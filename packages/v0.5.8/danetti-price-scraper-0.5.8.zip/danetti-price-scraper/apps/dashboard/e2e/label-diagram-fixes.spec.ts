import { test, expect, type Page } from "@playwright/test";
import { createBeanOnSeeds, type LabelScene } from "@danetti/label-engine";
import { mkdir, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const evidence = fileURLToPath(
  new URL("../../../.impeccable/review/label-diagram-pricing-20261015", import.meta.url)
);
const headers = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "content-type",
  "access-control-allow-methods": "GET,POST,PATCH,OPTIONS",
};
test.beforeEach(async ({ page }) => {
  await mkdir(evidence, { recursive: true });
  await page.route("http://localhost:4000/**", (route) =>
    route.fulfill({ json: { items: [] }, headers })
  );
});

async function labelFixture(page: Page) {
  const seed = createBeanOnSeeds().find(
    (seed) => seed.scene.metadata.name === "Brazil Choco Samba"
  )!;
  let scene: LabelScene = structuredClone(seed.scene);
  scene.nodes = scene.nodes.filter((node) => node.id === "name");
  const font = await readFile("C:/Windows/Fonts/georgia.ttf");
  const node = scene.nodes[0]!;
  if (node.type !== "text") throw Error("Missing title");
  const asset = {
    id: node.fontAssetId,
    family: node.fontFamily,
    weight: 400,
    style: "Regular",
    filename: "georgia.ttf",
    active: true,
    metadata: { isCompleteLatinAlphabet: true },
    usages: [],
  };
  let revision = 1;
  await page.route("**/label-assets**", (route) =>
    new URL(route.request().url()).pathname.endsWith("/download")
      ? route.fulfill({ body: font, contentType: "font/ttf", headers })
      : route.fulfill({ json: { items: [asset] }, headers })
  );
  await page.route("**/labels/box-fixture", (route) => {
    if (route.request().method() === "OPTIONS") return route.fulfill({ status: 204, headers });
    if (route.request().method() === "PATCH") {
      scene = route.request().postDataJSON().scene;
      revision++;
    }
    return route.fulfill({
      json: { item: { ...seed, id: "box-fixture", scene, revision } },
      headers,
    });
  });
  await page.goto("/labels/bean-on/box-fixture");
  await expect(page.getByRole("toolbar", { name: "Címkeszerkesztő eszköztár" })).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
  return () => scene;
}

test("Brazil: a kijelölés minden sort befog, nem változtat a címkén, méretezése nem ugrik", async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  const readScene = await labelFixture(page);
  const original = structuredClone(readScene());
  const canvas = page.locator('svg[role="img"]').first();
  await canvas.locator('[data-node-id="name"] text').last().click();
  const overlay = canvas.locator('[data-selection-id="name"]');
  const box = overlay.locator("rect").first();
  await expect
    .poll(async () => {
      const frame = (await box.boundingBox())!;
      const lines = await canvas.locator('[data-node-id="name"] text').all();
      return (
        await Promise.all(
          lines.map(async (line) => {
            const ink = (await line.boundingBox())!;
            return (
              ink.x >= frame.x - 0.6 &&
              ink.y >= frame.y - 0.6 &&
              ink.x + ink.width <= frame.x + frame.width + 0.6 &&
              ink.y + ink.height <= frame.y + frame.height + 0.6
            );
          })
        )
      ).every(Boolean);
    })
    .toBe(true);
  expect(readScene()).toEqual(original);
  await page.screenshot({ path: path.join(evidence, "brazil-box-after.png") });
  const beforeHeight = Number(await box.getAttribute("height"));
  const handle = (await overlay.locator('[data-resize-handle="s"]').boundingBox())!;
  await page.mouse.move(handle.x + handle.width / 2, handle.y + handle.height / 2);
  await page.mouse.down();
  await page.mouse.move(handle.x + handle.width / 2, handle.y + handle.height / 2 + 10);
  await page.mouse.up();
  await expect.poll(() => readScene().nodes[0]!.height).toBeGreaterThan(beforeHeight);
  expect(readScene().nodes[0]!.height).toBeLessThan(beforeHeight + 5);
});

async function diagramFixture(page: Page, slowFirst = false) {
  let coffee = 0;
  await page.route("**/dvg-diagrams/brands?*", async (route) => {
    const family = new URL(route.request().url()).searchParams.get("family")!;
    if (family === "coffee" && coffee++ === 0 && slowFirst)
      await new Promise((r) => setTimeout(r, 350));
    await route
      .fulfill({
        json: {
          items: [
            { family, label: "Alpha", value: "Alpha" },
            { family, label: "Beta", value: "Beta" },
          ],
        },
        headers,
      })
      .catch(() => {});
  });
  await page.route("**/dvg-diagrams/diagrams?*", async (route) => {
    const url = new URL(route.request().url());
    const brand = url.searchParams.get("brand")!;
    if (brand === "Alpha") await new Promise((r) => setTimeout(r, 400));
    await route
      .fulfill({
        json: {
          items: [
            {
              family: url.searchParams.get("family"),
              brand,
              diagramCode: brand,
              diagramName: brand + " diagram",
              sourcePageUrl: "https://example.com/diagram",
            },
          ],
          warnings: [],
        },
        headers,
      })
      .catch(() => {});
  });
}

test("Ábrák: gyors kategóriaváltás után is befejeződik a márkák betöltése", async ({ page }) => {
  await diagramFixture(page, true);
  await page.goto("/dvg-diagrams");
  await page.getByRole("combobox", { name: "1. Kategória" }).selectOption("grinders");
  await page.getByRole("combobox", { name: "1. Kategória" }).selectOption("coffee");
  await expect(page.getByRole("button", { name: "Alpha", exact: true })).toBeVisible();
  await expect(page.getByText("DVG márkák betöltése...", { exact: true })).toHaveCount(0);
});

test("Ábrák: a lassú korábbi válasz nem írja felül az új márkát", async ({ page }) => {
  await diagramFixture(page);
  await page.goto("/dvg-diagrams");
  await page.getByRole("button", { name: "Alpha", exact: true }).click();
  await page.getByRole("button", { name: "Beta", exact: true }).click();
  await expect(page.getByText("Beta diagram", { exact: true })).toBeVisible();
  await page.waitForTimeout(500);
  await expect(page.getByText("Alpha diagram", { exact: true })).toHaveCount(0);
  await page.screenshot({ path: path.join(evidence, "diagrams-after.png") });
});

test("Ábrák: márka- és lista-hiba után működik a kézi újrapróbálás", async ({ page }) => {
  let failBrands = true,
    lists = 0;
  await page.route("**/dvg-diagrams/brands?*", (r) =>
    r.fulfill({
      status: failBrands ? 503 : 200,
      json: failBrands
        ? { error: { message: "Átmeneti hiba" } }
        : { items: [{ family: "coffee", label: "Alpha", value: "Alpha" }] },
      headers,
    })
  );
  await page.route("**/dvg-diagrams/diagrams?*", (r) =>
    r.fulfill({
      status: lists++ === 0 ? 503 : 200,
      json:
        lists === 1
          ? { error: { message: "Átmeneti lista hiba" } }
          : {
              items: [
                {
                  family: "coffee",
                  brand: "Alpha",
                  diagramCode: "A1",
                  diagramName: "Alpha diagram",
                  sourcePageUrl: "https://example.com",
                },
              ],
              warnings: [],
            },
      headers,
    })
  );
  await page.goto("/dvg-diagrams");
  await expect(page.getByRole("button", { name: "Márkák újratöltése" })).toBeVisible();
  failBrands = false;
  await page.getByRole("button", { name: "Márkák újratöltése" }).click();
  await page.getByRole("button", { name: "Alpha", exact: true }).click();
  await page.getByRole("button", { name: "Ábrák újratöltése" }).click();
  await expect(page.getByText("Alpha diagram", { exact: true })).toBeVisible();
});

test("Árváltozások: látható árfolyam, fix profit és azonos exportbeállítások", async ({
  page,
  context,
}) => {
  await page.route("**/pricing-settings/**", (r) =>
    r.fulfill({ json: { eurHufRate: 400 }, headers })
  );
  const queries: URL[] = [];
  await page.route("**/supplier-price-changes?*", (r) => {
    const url = new URL(r.request().url());
    queries.push(url);
    const fixed = url.searchParams.get("pricingMode") === "fixed";
    return r.fulfill({
      json: {
        items: [
          {
            newSnapshotId: "S1",
            sku: "TEST",
            productName: "Minta",
            supplierName: "DVG",
            oldSupplierNetEur: 4,
            newSupplierNetEur: 5,
            supplierChangePercent: 25,
            preservedProfitPercent: 275,
            appliedProfitPercent: fixed ? 30 : 275,
            suggestedGrossPriceRoundedHuf: fixed ? 3400 : 9600,
          },
        ],
        total: 1,
        summary: {
          changedCount: 1,
          increaseCount: 1,
          decreaseCount: 0,
          noPreviousPriceCount: 0,
          marginWouldDropCount: 1,
        },
      },
      headers,
    });
  });
  await context.addInitScript(() => {
    window.print = () => {};
  });
  await page.goto("/supplier-price-changes");
  await expect(page.getByRole("spinbutton", { name: "EUR/HUF árfolyam" })).toBeVisible();
  await page.getByRole("radio", { name: "Fix profit megadása" }).check();
  await expect(page.getByText("Adj meg fix profitot", { exact: true })).toBeVisible();
  await page.getByRole("spinbutton", { name: "Fix profit (%)", exact: true }).fill("30");
  await expect(page.locator("table tbody tr")).toHaveCount(1);
  await page.getByRole("button", { name: "Export / nyomtatás", exact: true }).click();
  const popupPromise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Nyomtatás / PDF", exact: true }).click();
  const popup = await popupPromise;
  await expect(popup.locator("body")).toContainText("30 %");
  await expect(popup.locator("body")).toContainText("3400 Ft");
  expect(
    queries
      .filter((q) => q.searchParams.get("pricingMode") === "fixed")
      .every((q) => q.searchParams.get("fixedProfitPercent") === "30")
  ).toBe(true);
  expect(
    await popup
      .locator("th.numeric")
      .first()
      .evaluate((e) => getComputedStyle(e).textAlign)
  ).toBe("left");
  await popup.close();
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 1000 });
    await page.evaluate(() => scrollTo(0, 0));
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(
      true
    );
    await page.screenshot({ path: path.join(evidence, `fixed-profit-${width}.png`) });
  }
  await page.getByRole("radio", { name: "Eddigi profit megtartása" }).check();
  await expect(page.getByRole("spinbutton", { name: "Fix profit (%)", exact: true })).toHaveCount(
    0
  );
});
