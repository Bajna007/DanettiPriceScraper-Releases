import { expect, test, type Page } from "@playwright/test";
import { mkdir, readFile } from "node:fs/promises";
import path from "node:path";
import postgres from "postgres";
import { PDFDocument, PDFArray, PDFName, PDFNumber, PDFRawStream } from "pdf-lib";
import { getLocalRuntimeEnv } from "../../../scripts/local-runtime.mjs";

const API = "http://localhost:4000";
const evidence = path.resolve("../../.impeccable/review");
async function capture(page: Page, name: string, mobile = false) {
  await page.setViewportSize(mobile ? { width: 390, height: 844 } : { width: 1440, height: 1000 });
  await page.evaluate(() => document.fonts.ready);
  await expect
    .poll(() =>
      page.locator('.app-nav [aria-current="page"]').evaluate((element) => {
        const item = element.getBoundingClientRect();
        const container = element.parentElement!.getBoundingClientRect();
        return item.left >= container.left - 1 && item.right <= container.right + 1;
      })
    )
    .toBe(true);
  await expect
    .poll(() => page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1))
    .toBe(true);
  const mobileProductTable = mobile && name === "products-double-article";
  if (mobileProductTable) {
    await page.getByLabel("Cikkszám felépítése").scrollIntoViewIfNeeded();
    await page.screenshot({
      path: path.join(evidence, `${name}-mobile-filters.png`),
      animations: "disabled",
    });
    await page.locator(".table-card").scrollIntoViewIfNeeded();
  } else {
    await page.evaluate(() => scrollTo(0, 0));
  }
  await page.screenshot({
    path: path.join(evidence, `${name}-${mobile ? "mobile" : "desktop"}.png`),
    fullPage: !mobileProductTable,
    animations: "disabled",
  });
}

test("Áttekintés, szerkesztők, egyedi méret és kétlépéses rendelés", async ({ page, request }) => {
  await mkdir(evidence, { recursive: true });
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  const db = postgres(getLocalRuntimeEnv().DATABASE_URL, { max: 1 });
  const designs: string[] = [];
  let orderId: string | null = null;
  try {
    await page.goto("/");
    await expect(page.getByRole("heading", { name: "Áttekintés", exact: true })).toBeVisible();
    await expect(page.getByRole("button", { name: "Frissítés", exact: true })).toBeEnabled();
    await expect(page.getByRole("heading", { name: "Beszállítói árfigyelés" })).toBeVisible();
    await expect(
      page.getByRole("link", { name: "Egyedi címkék", exact: true }).last()
    ).toBeVisible();
    await expect(page.locator("main [role='alert']")).toHaveCount(0);
    await capture(page, "overview");
    await capture(page, "overview", true);

    for (const [brand, slug] of [
      ["utopia", "utopia"],
      ["bean_on", "bean-on"],
    ]) {
      const response = await request.get(`${API}/labels?brand=${brand}`);
      expect(response.ok()).toBe(true);
      const label = (await response.json()).items[0];
      await page.setViewportSize({ width: 1440, height: 1000 });
      await page.goto(`/labels/${slug}/${label.id}`);
      await expect(page.getByRole("toolbar", { name: "Címkeszerkesztő eszköztár" })).toBeVisible();
      await expect(page.getByRole("button", { name: "Milliméterrács", exact: true })).toBeVisible();
      await expect(page.getByRole("button", { name: "Segédvonalak", exact: true })).toBeVisible();
      await page.locator('[data-node-id="name"]').first().click({ force: true });
      await expect(page.getByLabel("Szöveg tartalma")).toBeVisible();
      await capture(page, `${slug}-editor`);
      await capture(page, `${slug}-editor`, true);
      await page.setViewportSize({ width: 1440, height: 1000 });
      await page
        .locator("fieldset")
        .filter({ has: page.locator("legend", { hasText: "CMYK" }) })
        .scrollIntoViewIfNeeded();
      await capture(page, `${slug}-colors`);
    }

    // The test owns this inactive order. Only order selection is redirected; saves/exports use the real API.
    orderId = (
      await db`insert into label_orders (brand, active) values ('custom', false) returning id`
    )[0]!.id;
    await page.route(`${API}/label-orders/active?brand=custom`, async (route) => {
      const response = await request.get(`${API}/label-orders/${orderId}`);
      await route.fulfill({ response });
    });
    await page.setViewportSize({ width: 1440, height: 1000 });
    await page.goto("/labels/custom");
    await page.getByRole("button", { name: "Új címke", exact: true }).click();
    await page.getByLabel("Címke neve").fill("Egyedi méret – ellenőrzési címke");
    await page.getByLabel("Szélesség (mm)").fill("80");
    await page.getByLabel("Magasság (mm)").fill("40");
    const input = page.getByLabel("Meglévő címke importálása");
    await input.setInputFiles({
      name: "tiltott.svg",
      mimeType: "image/svg+xml",
      buffer: Buffer.from(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 40"><script>alert(1)</script></svg>'
      ),
    });
    await expect(page.locator("main [role='alert']")).toContainText("nem importálható");
    await input.setInputFiles({
      name: "sajat-cimke.svg",
      mimeType: "image/svg+xml",
      buffer: Buffer.from(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 40"><rect width="80" height="40" fill="#F3F6F0"/><g transform="translate(4 4)"><path d="M0 0H72V7H0Z" fill="#255F49"/><rect y="11" width="26" height="3" fill="#BA8255"/></g></svg>'
      ),
    });
    await expect(page.getByText(/sajat-cimke.svg betöltve/)).toBeVisible();
    await capture(page, "custom-create");
    await capture(page, "custom-create", true);
    const created = page.waitForResponse(
      (r) => r.url() === `${API}/labels` && r.request().method() === "POST"
    );
    await page.getByRole("button", { name: "Létrehozás és szerkesztés" }).click();
    const creation = await created;
    expect(creation.ok()).toBe(true);
    const label = (await creation.json()).item;
    designs.push(label.id);
    expect(label.scene.nodes).toHaveLength(3);
    await expect(page.getByRole("toolbar")).toBeVisible();
    await page.setViewportSize({ width: 1440, height: 1000 });
    await page.getByLabel("Szélesség (mm)").fill("120");
    await page.getByLabel("Magasság (mm)").fill("60");
    await page.getByRole("button", { name: "Méret alkalmazása" }).click();
    await page.getByRole("button", { name: "Szöveg hozzáadása" }).click();
    await page.getByRole("spinbutton", { name: "Szélesség mm", exact: true }).fill("42");
    await page.getByLabel("Szöveg tartalma").fill("SAJÁT CÍMKE\nElső mentés");
    await page.route(`${API}/labels/${label.id}`, async (route) => {
      if (route.request().method() === "PATCH")
        await new Promise((resolve) => setTimeout(resolve, 350));
      await route.continue();
    });
    const saving = page.waitForRequest(
      (r) => r.url() === `${API}/labels/${label.id}` && r.method() === "PATCH"
    );
    await page.keyboard.press("Control+s");
    await saving;
    await page
      .getByLabel("Szöveg tartalma")
      .fill("SAJÁT CÍMKE\nMéretre igazított, mentett grafika");
    await page.keyboard.press("Control+s");
    await expect(page.getByText("Minden módosítás mentve", { exact: true })).toBeVisible();
    await page.unroute(`${API}/labels/${label.id}`);
    const saved = (await (await request.get(`${API}/labels/${label.id}`)).json()).item;
    expect([saved.scene.widthMm, saved.scene.heightMm]).toEqual([120, 60]);
    expect(saved.scene.nodes[0].width).toBeCloseTo(120);
    expect(saved.scene.nodes.at(-1).text).toContain("SAJÁT CÍMKE");
    await page.reload();
    await expect(page.getByRole("toolbar")).toBeVisible();
    await page.locator(`[data-node-id="${saved.scene.nodes.at(-1).id}"]`).click({ force: true });
    await expect(page.getByLabel("Szöveg tartalma")).toHaveValue(
      "SAJÁT CÍMKE\nMéretre igazított, mentett grafika"
    );
    expect(
      await page
        .locator(`[data-node-id="${saved.scene.nodes.at(-1).id}"]`)
        .evaluate((element) => (element as SVGGraphicsElement).getBBox().width)
    ).toBeLessThanOrEqual(42.01);
    await capture(page, "custom-editor");
    await capture(page, "custom-editor", true);
    const downloadPromise = page.waitForEvent("download");
    await page.getByRole("button", { name: "Szerkeszthető címke letöltése" }).click();
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toBe("egyedi-cimke.json");

    await page.getByRole("button", { name: "Rendeléshez adás", exact: true }).click();
    await expect
      .poll(
        async () =>
          (await (await request.get(`${API}/label-orders/${orderId}`)).json()).item.items.length
      )
      .toBe(1);
    const jsonPath = await download.path();
    if (!jsonPath) throw new Error("A szerkeszthető JSON nem menthető.");
    const downloadedScene = JSON.parse(await readFile(jsonPath, "utf8"));
    expect(downloadedScene.widthMm).toBe(120);
    await page.goto("/labels/custom");
    await page.getByRole("button", { name: "Új címke", exact: true }).click();
    await page.getByLabel("Címke neve").fill("JSON-ból visszatöltött címke");
    await page.getByLabel("Meglévő címke importálása").setInputFiles({
      name: "egyedi-cimke.json",
      mimeType: "application/json",
      buffer: await readFile(jsonPath),
    });
    await expect(page.getByText(/egyedi-cimke.json betöltve/)).toBeVisible();
    await page.getByLabel("Szélesség (mm)").fill("55");
    await page.getByLabel("Magasság (mm)").fill("25");
    const createdAgain = page.waitForResponse(
      (r) => r.url() === `${API}/labels` && r.request().method() === "POST"
    );
    await page.getByRole("button", { name: "Létrehozás és szerkesztés" }).click();
    const recreated = await createdAgain;
    expect(recreated.ok()).toBe(true);
    const second = (await recreated.json()).item;
    designs.push(second.id);
    expect([second.scene.widthMm, second.scene.heightMm]).toEqual([55, 25]);
    await expect(page.getByRole("toolbar")).toBeVisible();
    await page.getByRole("button", { name: "Rendeléshez adás", exact: true }).click();
    await expect
      .poll(
        async () =>
          (await (await request.get(`${API}/label-orders/${orderId}`)).json()).item.items.length
      )
      .toBe(2);
    await page.goto(`/labels/custom/orders/${orderId}`);
    await expect(
      page.getByRole("button", { name: "Ellenőrzés és letöltés", exact: true })
    ).toBeEnabled();
    await page
      .getByRole("spinbutton", { name: /mennyisége$/ })
      .first()
      .fill("25");
    await page
      .getByRole("spinbutton", { name: /mennyisége$/ })
      .first()
      .press("Tab");
    await expect
      .poll(
        async () =>
          (await (await request.get(`${API}/label-orders/${orderId}`)).json()).item.items[0]
            .quantity
      )
      .toBe(25);
    await page.getByRole("button", { name: "Ellenőrzés és letöltés", exact: true }).click();
    await expect(page.getByText("120 × 60 mm").first()).toBeVisible();
    await page.setViewportSize({ width: 1440, height: 1000 });
    await capture(page, "custom-order");
    await capture(page, "custom-order", true);
    const exportResponse = page.waitForResponse(
      (r) => r.url().endsWith(`/label-orders/${orderId}/export`) && r.request().method() === "POST"
    );
    await page.getByRole("button", { name: "Nyomdai fájl elkészítése" }).click();
    const exported = await exportResponse;
    expect(exported.ok()).toBe(true);
    const exportItem = (await exported.json()).item;
    await expect(page.getByRole("link", { name: "Vektoros PDF letöltése" })).toBeVisible();
    const pdfResponse = await request.get(`${API}/label-exports/${exportItem.id}/download`);
    expect(pdfResponse.ok()).toBe(true);
    const pdf = await PDFDocument.load(await pdfResponse.body());
    expect(pdf.getPageCount()).toBe(1);
    const artworkWidths = pdf.context
      .enumerateIndirectObjects()
      .flatMap(([, object]) => {
        if (
          !(object instanceof PDFRawStream) ||
          object.dict.get(PDFName.of("Subtype"))?.toString() !== "/Form"
        )
          return [];
        const box = object.dict.lookup(PDFName.of("BBox"), PDFArray);
        return [((box.get(2) as PDFNumber).asNumber() * 25.4) / 72];
      })
      .sort((a, b) => a - b);
    expect(artworkWidths).toHaveLength(2);
    expect(artworkWidths[0]).toBeCloseTo(60, 2);
    expect(artworkWidths[1]).toBeCloseTo(125, 2);
    expect(pdf.getPages()[0].getWidth()).toBeCloseTo((210 * 72) / 25.4, 2);
    const closed = (await (await request.get(`${API}/label-orders/${orderId}`)).json()).item;
    expect(closed.status).toBe("exported");
    const rejected = await request.patch(
      `${API}/label-orders/${orderId}/items/${closed.items[0].id}`,
      { data: { quantity: 99 } }
    );
    expect(rejected.status()).toBe(409);
    expect(errors).toEqual([]);
  } finally {
    await page.close();
    try {
      if (orderId) {
        await db`delete from label_exports where order_id=${orderId}`;
        await db`delete from label_orders where id=${orderId}`;
      }
      for (const id of designs) await db`delete from label_designs where id=${id}`;
    } finally {
      await db.end();
    }
  }
});

test("Részleges áttekintési hiba és dupla cikkszámos szűrés", async ({ page, request }) => {
  await page.route(`${API}/labels/overview`, (route) =>
    route.fulfill({
      status: 503,
      contentType: "application/json",
      body: JSON.stringify({ error: "fixture unavailable" }),
    })
  );
  await page.goto("/");
  await expect(page.locator("main [role='alert']")).toContainText("A címketár nem tölthető be.");
  await expect(page.getByRole("heading", { name: "Beszállítói árfigyelés" })).toBeVisible();
  await expect(page.getByRole("link", { name: "Termékek megnyitása" })).toBeVisible();
  await page.goto("/products");
  await page.getByLabel("Cikkszám felépítése").selectOption("multiple");
  await expect
    .poll(
      async () =>
        (
          await (
            await request.get(`${API}/catalog/products?articleStructure=multiple&limit=50`)
          ).json()
        ).products.length
    )
    .toBeGreaterThan(0);
  await expect(page.locator(".product-article-candidates").first()).toBeVisible();
  const rows = page.locator("tbody tr");
  await expect.poll(() => rows.count()).toBeGreaterThan(0);
  for (const row of await rows.all())
    expect(await row.locator(".product-article-candidates code").count()).toBeGreaterThanOrEqual(2);
  await page.reload();
  await expect(page.getByLabel("Cikkszám felépítése")).toHaveValue("multiple");
  await expect.poll(() => rows.count()).toBeGreaterThan(0);
  await expect(page.locator(".product-article-candidates").first()).toBeVisible();
  await capture(page, "products-double-article");
  await capture(page, "products-double-article", true);
  const literalSearch = await request.get(`${API}/catalog/products?search=__&limit=50`);
  expect(literalSearch.ok()).toBe(true);
  const literalProducts = (await literalSearch.json()).products;
  expect(literalProducts.length).toBeGreaterThan(0);
  for (const product of literalProducts) expect(product.sku).toContain("__");
  const secondArticle = await request.get(
    `${API}/catalog/products?search=8W17201&articleStructure=multiple&limit=50`
  );
  expect((await secondArticle.json()).products.map((item: { sku: string }) => item.sku)).toContain(
    "1755603__8W17201_W051"
  );
});
