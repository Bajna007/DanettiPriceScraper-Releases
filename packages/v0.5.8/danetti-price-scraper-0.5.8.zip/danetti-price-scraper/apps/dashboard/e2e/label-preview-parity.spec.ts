import { test, expect, type Locator, type Page } from "@playwright/test";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

const evidence = path.resolve("../../.impeccable/review/tables-20261014/labels");
async function signature(svg: Locator) {
  return svg.evaluate((element) => ({
    viewBox: element.getAttribute("viewBox"),
    nodes: Array.from(element.querySelectorAll("[data-node-id]"))
      .map((node) => ({ id: node.getAttribute("data-node-id"), html: node.outerHTML }))
      .sort((a, b) => a.id!.localeCompare(b.id!)),
  }));
}
async function raster(page: Page, svg: Locator) {
  await svg.evaluate((element) => {
    const copy = element.cloneNode(true) as SVGSVGElement;
    const box = copy.viewBox.baseVal;
    copy.removeAttribute("class");
    copy.style.cssText = `display:block;width:${box.width * 8}px;height:${box.height * 8}px;background:white;`;
    const proof = document.createElement("div");
    proof.id = "label-parity-proof";
    proof.style.cssText = `position:fixed;z-index:9999;left:0;top:0;background:white;width:${box.width * 8}px;height:${box.height * 8}px;`;
    proof.append(copy);
    document.body.append(proof);
  });
  try {
    return await page.locator("#label-parity-proof").screenshot();
  } finally {
    await page.locator("#label-parity-proof").evaluate((element) => element.remove());
  }
}

for (const [brand, slug] of [
  ["utopia", "utopia"],
  ["bean_on", "bean-on"],
])
  test(`${slug}: minden külső címke és szerkesztő 1:1 rajzolat`, async ({ page, request }) => {
    await mkdir(evidence, { recursive: true });
    await page.setViewportSize({ width: 1440, height: 1000 });
    await page.route("http://localhost:4000/**", async (route) => {
      expect(route.request().method()).toBe("GET");
      await route.fallback();
    });
    const labels = (await (await request.get(`http://localhost:4000/labels?brand=${brand}`)).json())
      .items;
    const snapshots = new Map<string, Awaited<ReturnType<typeof signature>>>();
    const images = new Map<string, Buffer>();
    await page.goto(`/labels/${slug}`);
    for (const status of ["active", "hidden", "archived"]) {
      await page.getByRole("combobox", { name: "Állapot", exact: true }).selectOption(status);
      const visibleLabels = labels.filter((item: { status: string; visible: boolean }) =>
        status === "archived"
          ? item.status === "archived"
          : item.status !== "archived" && (status === "active" ? item.visible : !item.visible)
      );
      await expect
        .poll(() => page.locator('article svg[role="img"]').count())
        .toBe(visibleLabels.length);
      await page.evaluate(() => document.fonts.ready);
      for (const item of visibleLabels) {
        const card = page
          .locator("article")
          .filter({ has: page.locator(`a[href="/labels/${slug}/${item.id}"]`) });
        const svg = card.locator('svg[role="img"]');
        snapshots.set(item.id, await signature(svg));
        const image = await raster(page, svg);
        images.set(item.id, image);
        await writeFile(path.join(evidence, `${slug}-${item.id}-library.png`), image);
      }
    }
    for (const item of labels) {
      await page.goto(`/labels/${slug}/${item.id}`);
      await page.getByRole("button", { name: "Nyomtatási nézet", exact: true }).click();
      await page.evaluate(async () => {
        await document.fonts.ready;
        await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      });
      const svg = page.locator('svg[role="img"]');
      await expect
        .poll(async () => (await signature(svg)).nodes)
        .toEqual(snapshots.get(item.id)!.nodes);
      expect((await signature(svg)).viewBox).toBe(snapshots.get(item.id)!.viewBox);
      const image = await raster(page, svg);
      await writeFile(path.join(evidence, `${slug}-${item.id}-editor.png`), image);
      expect(image.equals(images.get(item.id)!)).toBe(true);
      const qr = (await svg.locator('[data-node-id="qr-product"]').count())
        ? await svg.locator('[data-node-id="qr-product"]').getAttribute("d")
        : null;
      const exported = await request.get(
        `http://localhost:4000/labels/${item.id}/preview.svg?outlined=true`
      );
      if (qr) expect(await exported.text()).toContain(`d="${qr}"`);
    }
    console.log(
      `${slug}: ${snapshots.size} label previews match editor geometry, pixels and exported QR paths`
    );
  });
