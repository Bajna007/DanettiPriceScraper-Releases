import { expect, test } from "@playwright/test";

// Read-only proof also works on an isolated dashboard port beside the operator app.
test.beforeEach(async ({ page }) => {
  await page.route("http://localhost:4000/**", async (route) => {
    expect(route.request().method()).toBe("GET");
    const response = await route.fetch();
    await route.fulfill({
      response,
      headers: { ...response.headers(), "access-control-allow-origin": "*" },
    });
  });
});

for (const brand of ["bean-on", "utopia"]) {
  for (const width of [1440, 390]) {
    test(`${brand}: első előnézet betöltött fontokkal, ${width}px`, async ({ page }) => {
      await page.setViewportSize({ width, height: 900 });
      let releaseAssets!: () => void;
      let releaseFonts!: () => void;
      const assetsHeld = new Promise<void>((resolve) => (releaseAssets = resolve));
      const fontsHeld = new Promise<void>((resolve) => (releaseFonts = resolve));
      const requests = new Map<string, number>();
      await page.route("**/label-assets", async (route) => {
        await assetsHeld;
        await route.fallback();
      });
      await page.route("**/label-assets/*/download", async (route) => {
        const url = route.request().url();
        requests.set(url, (requests.get(url) ?? 0) + 1);
        await fontsHeld;
        await route.fallback();
      });
      try {
        await page.goto(`/labels/${brand}`);
        const cards = page.locator("article");
        const canvases = cards.locator('svg[role="img"]');
        await expect(cards.first()).toBeVisible();
        await expect(canvases).toHaveCount(0);
        const before = await cards.first().boundingBox();
        releaseAssets();
        await expect.poll(() => requests.size).toBeGreaterThan(0);
        await expect(canvases).toHaveCount(0);
        await expect(cards.first().getByRole("link", { name: "Szerkesztés" })).toBeVisible();
        releaseFonts();
        await expect.poll(async () => canvases.count()).toBe(await cards.count());
        const first = canvases.first();
        const rendered = await first.innerHTML();
        await page.evaluate(async () => {
          await document.fonts.ready;
          await new Promise((resolve) =>
            requestAnimationFrame(() => requestAnimationFrame(resolve))
          );
        });
        expect(await first.innerHTML()).toBe(rendered);
        expect(
          await canvases.evaluateAll((svgs) =>
            svgs.every((svg) =>
              [...svg.querySelectorAll("text")].every((text) => {
                const style = getComputedStyle(text);
                return [...document.fonts].some(
                  (font) =>
                    font.status === "loaded" &&
                    style.fontFamily.replaceAll('"', "").replaceAll("'", "") ===
                      font.family.replaceAll('"', "").replaceAll("'", "") &&
                    style.fontWeight === font.weight &&
                    style.fontStyle === font.style
                );
              })
            )
          )
        ).toBe(true);
        const after = await cards.first().boundingBox();
        expect(after?.height).toBeCloseTo(before!.height, 0);
        expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
          true
        );
        expect([...requests.values()].every((count) => count === 1)).toBe(true);
        // Filtering/remounting reuses decoded fonts and keeps archive actions available.
        await page.getByRole("textbox", { name: "Keresés" }).fill("no-matching-font-preview");
        await expect(cards).toHaveCount(0);
        await page.getByRole("textbox", { name: "Keresés" }).fill("");
        await expect(cards.first()).toBeVisible();
        await expect.poll(async () => canvases.count()).toBe(await cards.count());
        expect([...requests.values()].every((count) => count === 1)).toBe(true);
        await page.screenshot({
          path: test.info().outputPath(`preview-${brand}-${width}.png`),
          fullPage: false,
        });
      } finally {
        releaseAssets();
        releaseFonts();
      }
    });
  }
}

for (const brand of ["bean-on", "utopia"]) {
  test(`${brand}: archivált címkék is fonttal jelennek meg`, async ({ page }) => {
    // Present the actual local scenes as archived without writing to the database.
    await page.route("http://localhost:4000/labels?**", async (route) => {
      const response = await route.fetch();
      const data = await response.json();
      await route.fulfill({
        json: {
          ...data,
          items: data.items.map((item: Record<string, unknown>) => ({
            ...item,
            status: "archived",
          })),
        },
        headers: { "access-control-allow-origin": "*" },
      });
    });
    await page.goto(`/labels/${brand}`);
    await page.getByRole("combobox", { name: "Állapot" }).selectOption("archived");
    const cards = page.locator("article");
    await expect(cards.first()).toBeVisible();
    await expect
      .poll(async () => cards.locator('svg[role="img"]').count())
      .toBe(await cards.count());
    await expect(cards.first().getByRole("button", { name: "Visszaállítás" })).toBeVisible();
    await expect(cards.getByRole("alert")).toHaveCount(0);
  });
}

test("A hibás fontbetöltés újrapróbálható, helyettesítő címke nélkül", async ({ page }) => {
  let failedUrl: string | undefined;
  let failed = false;
  await page.route("**/label-assets/*/download", async (route) => {
    if (!failed) {
      failed = true;
      failedUrl = route.request().url();
      await route.abort();
    } else await route.fallback();
  });
  await page.goto("/labels/bean-on");
  const card = page
    .locator("article")
    .filter({ has: page.getByRole("button", { name: "Újrapróbálás" }) })
    .first();
  await expect(card.getByRole("alert")).toBeVisible();
  await expect(card.locator('svg[role="img"]')).toHaveCount(0);
  expect(failedUrl).toBeTruthy();
  // Keep a stable card locator after the error disappears.
  const editUrl = await card.getByRole("link", { name: "Szerkesztés" }).getAttribute("href");
  await card.getByRole("button", { name: "Újrapróbálás" }).click();
  const recovered = page.locator("article").filter({ has: page.locator(`a[href="${editUrl}"]`) });
  await expect(recovered.locator('svg[role="img"]')).toBeVisible();
  await expect(recovered.getByRole("alert")).toHaveCount(0);
});
