import { expect, test, type Page } from "@playwright/test";
import AdmZip from "adm-zip";

const WINDOWS_TEST_FONT = "C:/Windows/Fonts/ARIALN.TTF";

test.describe.serial("Label Studio teljes kezelői folyamat", () => {
  test("Utopia szerkesztés, font, rendelés és export", async ({ page }) => {
    await page.goto("/labels/utopia");
    await expect(page.getByRole("heading", { name: "Utopia Címkestúdió" })).toBeVisible();
    await expect(page.locator("article").first()).toBeVisible();
    expect(await page.locator("article").count()).toBeGreaterThanOrEqual(5);
    await expect(page.locator("article").first().locator('svg[role="img"]')).toHaveAttribute(
      "viewBox",
      "0 0 102 35"
    );

    await page.locator("article").first().getByRole("button", { name: "Shop kép" }).click();
    const utopiaMockup = page.getByRole("dialog", { name: /Shop kép/ });
    await expect(utopiaMockup).toBeVisible();
    await expect(utopiaMockup.getByRole("option")).toHaveCount(2);
    await expect(utopiaMockup.getByText("Előnézet kész")).toBeVisible({ timeout: 20_000 });
    await expect(utopiaMockup.locator('input[type="range"]')).toHaveCount(6);
    await expect(utopiaMockup.getByLabel("Expozíció")).toHaveValue("0");
    await expect(utopiaMockup.getByLabel("Felületi fény")).toHaveValue("0");
    await expect(utopiaMockup.getByLabel("Színhőmérséklet")).toHaveValue("0");
    await expect(utopiaMockup.getByRole("button", { name: "Színhelyes" })).toHaveAttribute(
      "aria-pressed",
      "true"
    );
    await expect(utopiaMockup.getByRole("button", { name: "JPG letöltése" })).toBeVisible();
    await utopiaMockup.getByRole("button", { name: "Fotóhoz igazított" }).click();
    await expect(utopiaMockup.getByLabel("Expozíció")).toHaveValue("10");
    await expect(utopiaMockup.getByLabel("Felületi fény")).toHaveValue("62");
    await expect(utopiaMockup.getByLabel("Színhőmérséklet")).toHaveValue("12");
    await utopiaMockup.getByRole("button", { name: "Színhelyes" }).click();
    const modalClose = utopiaMockup.getByRole("button", { name: "Shop kép bezárása" });
    await expect(modalClose).toBeFocused();
    await page.keyboard.press("Shift+Tab");
    await expect(utopiaMockup.getByRole("button", { name: "Bezárás", exact: true })).toBeFocused();
    await page.keyboard.press("Tab");
    await expect(modalClose).toBeFocused();
    await expect(utopiaMockup.getByTestId("product-mockup-canvas")).toHaveJSProperty("width", 1200);
    await utopiaMockup.getByRole("option", { name: /Rusztikus pörkölő/ }).click();
    await expect(utopiaMockup.getByRole("option", { name: /Rusztikus pörkölő/ })).toHaveAttribute(
      "aria-selected",
      "true"
    );
    await expect(utopiaMockup.getByText("Előnézet kész")).toBeVisible({ timeout: 20_000 });
    await utopiaMockup.getByRole("button", { name: "Bezárás", exact: true }).click();
    await expect(utopiaMockup).toBeHidden();

    const createBlank = page.waitForResponse(
      (response) => response.url().endsWith("/labels") && response.request().method() === "POST"
    );
    await page.getByRole("button", { name: "Új címke", exact: true }).click();
    const blankResponse = await createBlank;
    expect(blankResponse.ok()).toBe(true);
    const blank = (await blankResponse.json()) as {
      item: {
        id: string;
        scene: {
          fields: Record<string, unknown>;
          nodes: Array<{
            id: string;
            type: string;
            fontAssetId?: string;
            fill?: { rgb?: string };
          }>;
        };
      };
    };
    const createdBlankId = blank.item.id;
    expect(blank.item.scene.fields.region).toBe("RÉGIÓ");
    expect(blank.item.scene.fields.notes).toBe("ÍZJEGYEK");
    const blankText = blank.item.scene.nodes.filter((node) => node.type === "text");
    expect(blankText.find((node) => node.id === "country")?.fontAssetId).toBe(
      "00000000-0000-4000-8000-000000000003"
    );
    expect(blankText.find((node) => node.id === "name")?.fontAssetId).toBe(
      "00000000-0000-4000-8000-000000000003"
    );
    expect(blankText.find((node) => node.id === "country")?.fill?.rgb).toBe("#FF007A");
    expect(blankText.find((node) => node.id === "name")?.fill?.rgb).toBe("#FFFFFF");
    expect(blankText.find((node) => node.id === "bestBefore")?.fontAssetId).toBe(
      "00000000-0000-4000-8000-000000000002"
    );

    const mirafloresCard = page.locator("article").filter({ hasText: "Peru Miraflores" });
    await expect(mirafloresCard).toHaveCount(1);
    await expect(mirafloresCard.locator('[data-node-id="country"]')).toContainText("PERU");
    await expect(mirafloresCard.locator('[data-node-id="name"]')).toContainText("MIRAFLORES");
    const editLink = mirafloresCard.getByRole("link", { name: "Szerkesztés" });
    const designId = (await editLink.getAttribute("href"))?.split("/").at(-1);
    if (!designId) throw new Error("Az Utopia design ID nem olvasható ki.");
    const original = (await (
      await page.request.get(`http://localhost:4000/labels/${designId}`)
    ).json()) as { item: { scene: unknown } };

    try {
      await editLink.click();
      await expect(page.getByRole("toolbar", { name: "Címkeszerkesztő eszköztár" })).toBeVisible();
      await page.evaluate(() => document.fonts.ready);
      await expect
        .poll(async () => {
          const footerText = page.locator('[data-node-id="bestBefore"]');
          const dateDivider = page.locator('[data-node-id="date-divider"]');
          return footerText.evaluate(
            (element, dividerX) => {
              const bounds = (element as SVGGraphicsElement).getBBox();
              return bounds.x + bounds.width <= dividerX;
            },
            Number(await dateDivider.getAttribute("x1"))
          );
        })
        .toBe(true);

      const country = page.getByRole("textbox", { name: "Országkötelező" });
      const originalText = "PERU";
      if ((await country.inputValue()) !== originalText) {
        await country.fill(originalText);
        await expect(
          page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
        ).toHaveText("Minden módosítás mentve", {
          timeout: 10_000,
        });
      }
      await country.fill(`${originalText} E2E`);
      await expect(
        page
          .locator("svg text")
          .filter({ hasText: `${originalText} E2E` })
          .first()
      ).toBeVisible();

      await page.getByRole("button", { name: "Szöveg: country", exact: true }).click();
      const hex = page.getByLabel("HEX", { exact: true });
      const x = page.locator("label").filter({ hasText: /^Xmm$/ }).locator("input");
      const originalHex = await hex.inputValue();
      const originalX = await x.inputValue();
      await hex.fill("#00bdb7");
      await page.getByRole("button", { name: "Szöveg: country", exact: true }).click();
      await page.keyboard.press("ArrowRight");
      await expect(x).not.toHaveValue(originalX);

      await page.getByRole("button", { name: "Visszavonás" }).click();
      await page.getByRole("button", { name: "Újra" }).click();
      await expect(x).not.toHaveValue(originalX);

      await x.fill(originalX);
      await hex.fill(originalHex);
      await country.fill(originalText);
      await expect(
        page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
      ).toHaveText("Minden módosítás mentve", {
        timeout: 10_000,
      });

      await page.getByRole("button", { name: "Vonal: brand-divider", exact: true }).click();
      await expect(page.getByRole("heading", { name: "Elválasztók" })).toBeVisible();
      await expect(page.getByText(/mind a 10 strukturális elválasztóját/)).toBeVisible();
      await expect(page.getByRole("button", { name: "Pöttyözött" })).toHaveAttribute(
        "aria-pressed",
        "true"
      );
      await page.getByRole("button", { name: "Folytonos" }).click();
      await expect(
        page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
      ).toHaveText("Minden módosítás mentve", {
        timeout: 10_000,
      });
      const globallyStyled = (await (
        await page.request.get(`http://localhost:4000/labels/${designId}`)
      ).json()) as {
        item: { scene: { nodes: Array<{ id: string; dash?: number[] }> } };
      };
      const separatorIds = new Set(["brand-divider", "footer-line", "weight-line", "date-divider"]);
      expect(
        globallyStyled.item.scene.nodes
          .filter((node) => separatorIds.has(node.id))
          .every((node) => !node.dash?.length)
      ).toBe(true);
      expect(
        globallyStyled.item.scene.nodes.find((node) => node.id === "line-region")?.dash
      ).toBeUndefined();
      await page.getByRole("button", { name: "Utopia alapérték" }).click();
      await expect(
        page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
      ).toHaveText("Minden módosítás mentve", {
        timeout: 10_000,
      });

      const dateBoxToggle = page.getByRole("checkbox", {
        name: "Pörkölési dátum háttere",
      });
      await expect(dateBoxToggle).toBeChecked();
      await page.getByRole("button", { name: "Részletes beállítások" }).click();
      await expect(page.getByRole("heading", { name: "Pörkölési dátum háttere" })).toBeVisible();
      await expect(page.getByRole("spinbutton", { name: "Szélesség mm" })).toBeVisible();
      await expect(page.getByRole("spinbutton", { name: "Magasság mm" })).toBeVisible();
      const southEastHandle = page.locator('[data-resize-handle="se"]');
      await expect(southEastHandle).toBeVisible();
      const handleBox = await southEastHandle.boundingBox();
      expect(handleBox).not.toBeNull();
      await page.mouse.move(
        handleBox!.x + handleBox!.width / 2,
        handleBox!.y + handleBox!.height / 2
      );
      await page.mouse.down();
      await page.mouse.move(
        handleBox!.x + handleBox!.width / 2 + 18,
        handleBox!.y + handleBox!.height / 2 + 10
      );
      await page.mouse.up();
      await expect(
        page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
      ).toHaveText("Minden módosítás mentve", {
        timeout: 10_000,
      });
      await expect
        .poll(
          async () => {
            const resizedDateBox = (await (
              await page.request.get(`http://localhost:4000/labels/${designId}`)
            ).json()) as {
              item: { scene: { nodes: Array<{ id: string; width: number; height: number }> } };
            };
            const resizedDateNode = resizedDateBox.item.scene.nodes.find(
              (node) => node.id === "date-field"
            );
            return {
              widthChanged: (resizedDateNode?.width ?? 0) > 47.128,
              heightChanged: (resizedDateNode?.height ?? 0) > 5.62,
            };
          },
          { timeout: 10_000 }
        )
        .toEqual({ widthChanged: true, heightChanged: true });
      await page.getByRole("textbox", { name: "HEX", exact: true }).fill("#00BDB7");
      await expect(
        page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
      ).toHaveText("Minden módosítás mentve", {
        timeout: 10_000,
      });
      const coloredDateBox = (await (
        await page.request.get(`http://localhost:4000/labels/${designId}`)
      ).json()) as {
        item: {
          scene: {
            nodes: Array<{
              id: string;
              fill?: { rgb: string; cmyk?: { c: number; m: number; y: number; k: number } };
            }>;
          };
        };
      };
      const coloredDateNode = coloredDateBox.item.scene.nodes.find(
        (node) => node.id === "date-field"
      );
      expect(coloredDateNode?.fill?.rgb).toBe("#00BDB7");
      expect(coloredDateNode?.fill?.cmyk?.c).toBeGreaterThan(0.9);
      await page.getByRole("textbox", { name: "HEX", exact: true }).fill("#FFFFFF");
      await expect(
        page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
      ).toHaveText("Minden módosítás mentve", {
        timeout: 10_000,
      });
      await dateBoxToggle.uncheck();
      await expect(
        page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
      ).toHaveText("Minden módosítás mentve", {
        timeout: 10_000,
      });
      const hiddenDateBox = (await (
        await page.request.get(`http://localhost:4000/labels/${designId}`)
      ).json()) as {
        item: {
          scene: {
            fields: Record<string, unknown>;
            nodes: Array<{ id: string; binding?: { field: string; property: string } }>;
          };
        };
      };
      expect(hiddenDateBox.item.scene.fields.showRoastDateBox).toBe(false);
      expect(
        hiddenDateBox.item.scene.nodes.find((node) => node.id === "date-field")?.binding
      ).toEqual({ field: "showRoastDateBox", property: "visible" });
      await dateBoxToggle.check();
      await expect(
        page.getByRole("status").filter({ hasText: "Minden módosítás mentve" })
      ).toHaveText("Minden módosítás mentve", {
        timeout: 10_000,
      });
      const restoredDateBox = (await (
        await page.request.get(`http://localhost:4000/labels/${designId}`)
      ).json()) as {
        item: {
          scene: {
            nodes: Array<{
              id: string;
              x: number;
              y: number;
              width: number;
              height: number;
              fill?: { rgb: string; cmyk?: { c: number; m: number; y: number; k: number } };
            }>;
          };
        };
      };
      expect(
        restoredDateBox.item.scene.nodes.find((node) => node.id === "date-field")
      ).toMatchObject({
        x: 50.907,
        y: 27.912,
        width: 47.128,
        height: 5.62,
        fill: { rgb: "#FFFFFF", cmyk: { c: 0, m: 0, y: 0, k: 0 } },
      });

      await page.goto("/labels/utopia?view=fonts");
      const fontUpload = page.waitForResponse(
        (response) =>
          response.url().endsWith("/label-assets/fonts") && response.request().method() === "POST"
      );
      await page.locator('input[type="file"]').setInputFiles(WINDOWS_TEST_FONT);
      expect((await fontUpload).ok()).toBe(true);
      await expect(page.getByRole("heading", { name: /Arial Narrow/i }).first()).toBeVisible();
      await expect(page.getByText("✓ Magyar ékezetek rendben").first()).toBeVisible();
      const fontZip = new AdmZip();
      fontZip.addLocalFile(WINDOWS_TEST_FONT, "fonts");
      const zipUpload = page.waitForResponse(
        (response) =>
          response.url().endsWith("/label-assets/fonts") && response.request().method() === "POST"
      );
      await page.locator('input[type="file"]').setInputFiles({
        name: "fontok.zip",
        mimeType: "application/zip",
        buffer: fontZip.toBuffer(),
      });
      expect((await zipUpload).ok()).toBe(true);
      await expect(
        page.getByText(/font feldolgozva és a karakterkészlet ellenőrizve/)
      ).toBeVisible();

      await page.goto("/labels/utopia", { waitUntil: "domcontentloaded" });
      const cards = page.locator("article");
      await addCardToOrder(page, cards.nth(0));
      await addCardToOrder(page, cards.nth(1));
      await page.getByRole("link", { name: "Rendelés", exact: true }).click();
      await expect(page.getByRole("navigation", { name: "Utopia címkemodul" })).toBeVisible();
      await expect(page.locator("article")).toHaveCount(2);

      const stepperMetrics = await page
        .locator('[class*="quantityStepper"]')
        .first()
        .evaluate((element) => {
          const outer = element.getBoundingClientRect();
          const controls = [...element.querySelectorAll("button,input")].map((control) => {
            const box = control.getBoundingClientRect();
            return { width: box.width, height: box.height };
          });
          return { outerWidth: outer.width, controls };
        });
      expect(stepperMetrics.controls).toHaveLength(3);
      expect(
        Math.abs(stepperMetrics.controls[0]!.width - stepperMetrics.controls[2]!.width)
      ).toBeLessThan(1);
      expect(stepperMetrics.controls.every((control) => Math.abs(control.height - 42) < 1)).toBe(
        true
      );

      const quantities = page.locator('article input[type="number"]');
      await quantities.nth(0).fill("7");
      await quantities.nth(1).fill("3");
      await reorderFirstTwoItems(page);
      await expect(page.getByText("10", { exact: true }).first()).toBeVisible();

      const continueToExport = page.getByRole("button", {
        name: "Ellenőrzés és letöltés",
        exact: true,
      });
      await expect(continueToExport).toBeEnabled();
      // dnd-kit can leave Playwright waiting for a synthetic pointer action to
      // settle after the completed drag. Activate the already enabled native
      // button directly; the resulting export step is asserted below.
      await continueToExport.evaluate((button) => (button as HTMLButtonElement).click());
      await expect(page.getByRole("button", { name: "Nyomdai fájl elkészítése" })).toBeVisible();
      await expect(page.getByText("Teljes mennyiség").locator("..")).toContainText("10 db");
      await exportAndVerifyPdf(page, "utopia-cimkerendeles-");
    } finally {
      const current = (await (
        await page.request.get(`http://localhost:4000/labels/${designId}`)
      ).json()) as { item: { revision: number } };
      const restore = await page.request.patch(`http://localhost:4000/labels/${designId}`, {
        data: { scene: original.item.scene, expectedRevision: current.item.revision },
      });
      expect(restore.ok()).toBe(true);
      const createdBlank = (await (
        await page.request.get(`http://localhost:4000/labels/${createdBlankId}`)
      ).json()) as { item: { revision: number } };
      const archiveBlank = await page.request.patch(
        `http://localhost:4000/labels/${createdBlankId}`,
        {
          data: {
            visible: false,
            status: "archived",
            expectedRevision: createdBlank.item.revision,
          },
        }
      );
      expect(archiveBlank.ok()).toBe(true);
    }
  });

  test("Bean On rövidített címke-rendelés-export folyamat", async ({ page }) => {
    await page.goto("/labels/bean-on");
    await expect(page.getByRole("heading", { name: "Bean On Címkestúdió" })).toBeVisible();
    await expect(page.locator("article").first()).toBeVisible();
    expect(await page.locator("article").count()).toBeGreaterThanOrEqual(15);
    expect(await page.getByText("Címfont", { exact: true }).count()).toBeGreaterThanOrEqual(15);
    await page.evaluate(() => document.fonts.ready);
    for (const title of ["TT 7030", "TT 8020"]) {
      const titleGroup = page
        .locator("article")
        .filter({ hasText: title })
        .locator('[data-node-id="name"]');
      const glyphs = titleGroup.locator("text");
      await expect(glyphs).toHaveCount(7);
      expect((await glyphs.allTextContents()).join("")).toBe(title);
      const previewGeometry = await glyphs.evaluateAll((elements) => ({
        x: elements.map((element) => Number(element.getAttribute("x"))),
        family: getComputedStyle(elements[0]!).fontFamily,
      }));
      expect(previewGeometry.family).toContain("MS Gothic");
      expect(
        previewGeometry.x.every((x, index, values) => index === 0 || x > values[index - 1]!)
      ).toBe(true);
    }
    await page.getByRole("button", { name: "Új címke", exact: true }).click();
    await expect(page.getByText("Milyen Bean On címke készül?")).toBeVisible();
    await expect(page.getByRole("button", { name: "Single origin" })).toBeVisible();
    await expect(page.getByRole("button", { name: "Keverék" })).toBeVisible();
    await page.getByRole("button", { name: "Mégse" }).click();

    const brazilCard = page.locator("article").filter({ hasText: "Brazil Choco Samba" });
    const brazilName = brazilCard.locator('[data-node-id="name"]');
    await expect(brazilName).toHaveJSProperty("tagName", "g");
    await expect(brazilName.locator("text")).toHaveCount(3);
    await expect(brazilName).toContainText("BRAZIL");
    await expect(brazilCard.locator('svg[role="img"]')).toHaveAttribute(
      "viewBox",
      "-2.5 -2.5 115 40"
    );
    await brazilCard.getByRole("button", { name: "Shop kép" }).click();
    const beanOnMockup = page.getByRole("dialog", { name: /Shop kép · Brazil Choco Samba/ });
    await expect(beanOnMockup.getByRole("option")).toHaveCount(1);
    await expect(beanOnMockup.getByText("Előnézet kész")).toBeVisible({ timeout: 20_000 });
    const shopDownload = page.waitForEvent("download");
    await beanOnMockup.getByRole("button", { name: "JPG letöltése" }).click();
    expect((await shopDownload).suggestedFilename()).toMatch(
      /^bean-on-brazil-choco-samba-.*-shop\.jpg$/
    );
    await beanOnMockup.getByRole("button", { name: "Bezárás", exact: true }).click();
    await brazilCard.getByRole("link", { name: "Szerkesztés" }).click();
    await expect(page.getByRole("toolbar", { name: "Címkeszerkesztő eszköztár" })).toBeVisible();
    const brazilTitleBox = await page.locator('[data-node-id="name"]').boundingBox();
    const brazilFooterBox = await page.locator('[data-node-id="footer-line"]').boundingBox();
    if (!brazilTitleBox || !brazilFooterBox)
      throw new Error("A Brazil referencia-geometria nem mérhető.");
    expect(brazilTitleBox.y + brazilTitleBox.height).toBeLessThan(brazilFooterBox.y + 2);
    await page.getByRole("button", { name: "Címketár", exact: true }).click();
    await expect(page.locator("article").first()).toBeVisible();

    const ethiopiaCard = page.locator("article").filter({ hasText: "Ethiopia Gujji Uraga" });
    await ethiopiaCard.getByRole("link", { name: "Szerkesztés" }).click();
    await expect(page.getByRole("toolbar", { name: "Címkeszerkesztő eszköztár" })).toBeVisible();
    await page.getByRole("button", { name: "Szöveg: name", exact: true }).click();
    await page
      .locator("summary")
      .filter({ hasText: /^Tipográfia$/ })
      .click();
    await expect(page.getByRole("listbox", { name: "Font library" })).toBeVisible();
    expect(await page.getByRole("option").count()).toBeGreaterThan(0);
    await page.locator('[data-node-id="name"]').dblclick();
    const inlineTitle = page.locator('textarea[class*="inlineTextInput"]');
    await expect(inlineTitle).toHaveValue("ETHIOPIA\nGUJJI\nURAGA");
    await expect(page.locator('[data-node-id="name"]')).toHaveAttribute("opacity", "0");
    await inlineTitle.press("Escape");
    await page.getByRole("button", { name: "Címketár", exact: true }).click();
    await expect(page.locator("article").first()).toBeVisible();
    expect(await page.locator("article").count()).toBeGreaterThanOrEqual(15);

    await addCardToOrder(page, page.locator("article").first());
    await page.getByRole("link", { name: "Rendelés", exact: true }).click();
    await expect(page.getByRole("navigation", { name: "Bean On címkemodul" })).toBeVisible();
    await expect(page.locator("article")).toHaveCount(1);
    await page.locator('article input[type="number"]').fill("2");
    await page.locator('article input[type="number"]').press("Tab");
    await page.getByRole("button", { name: "Ellenőrzés és letöltés", exact: true }).click();
    await exportAndVerifyPdf(page, "bean-on-cimkerendeles-");
  });
});

async function reorderFirstTwoItems(page: Page): Promise<void> {
  const handles = page.locator("article [data-drag-handle]");
  const source = await handles.nth(0).boundingBox();
  const target = await handles.nth(1).boundingBox();
  if (!source || !target) throw new Error("A rendelési drag handle nem látható.");
  await page.mouse.move(source.x + source.width / 2, source.y + source.height / 2);
  await page.mouse.down();
  await page.mouse.move(target.x + target.width / 2, target.y + target.height / 2 + 10, {
    steps: 12,
  });
  await page.mouse.up();
  await page.waitForTimeout(600);
}

async function addCardToOrder(page: Page, card: ReturnType<Page["locator"]>): Promise<void> {
  const response = page.waitForResponse(
    (item) => item.url().includes("/label-orders/") && item.request().method() === "POST"
  );
  await card.getByRole("button", { name: /^(Rendeléshez|Mennyiség \+1)$/ }).click();
  expect((await response).ok()).toBe(true);
}

async function exportAndVerifyPdf(page: Page, filenamePrefix: string): Promise<void> {
  const exportButton = page.getByRole("button", { name: "Nyomdai fájl elkészítése" });
  const exportResponse = page.waitForResponse(
    (response) =>
      response.url().includes("/label-orders/") &&
      response.url().endsWith("/export") &&
      response.request().method() === "POST"
  );
  await exportButton.click();
  expect((await exportResponse).ok()).toBe(true);
  await expect(page.getByText("A nyomdai vektoros PDF elkészült.")).toBeVisible();
  const pdfDownload = page.waitForEvent("download");
  await page.getByRole("link", { name: "Vektoros PDF letöltése" }).click();
  const pdf = await pdfDownload;
  expect(pdf.suggestedFilename()).toMatch(new RegExp(`^${filenamePrefix}.*\\.pdf$`));
  expect(await pdf.path()).toBeTruthy();
}
