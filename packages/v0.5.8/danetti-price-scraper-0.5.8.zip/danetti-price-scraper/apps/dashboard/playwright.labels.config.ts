import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  testMatch: [
    "label-studio.spec.ts",
    "label-preview-fonts.spec.ts",
    "app-update.spec.ts",
    "workspace-refresh.spec.ts",
  ],
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 300_000,
  expect: { timeout: 15_000 },
  use: {
    baseURL: process.env.LABEL_STUDIO_URL ?? "http://localhost:3000",
    trace: "retain-on-failure",
  },
  webServer: [
    {
      command: "npm.cmd run dev:api --prefix ../..",
      url: "http://localhost:4000/health",
      // Never silently exercise an operator's running local app/database in E2E.
      reuseExistingServer: process.env.LABEL_STUDIO_REUSE_EXISTING_SERVER === "true",
      timeout: 120_000,
    },
    {
      command: "npm.cmd run dev",
      url: "http://localhost:3000",
      reuseExistingServer: process.env.LABEL_STUDIO_REUSE_EXISTING_SERVER === "true",
      timeout: 120_000,
    },
  ],
});
