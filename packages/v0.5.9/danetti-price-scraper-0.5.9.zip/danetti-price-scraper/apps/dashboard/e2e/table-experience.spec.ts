import { test, expect, type Page, type Locator } from "@playwright/test";
import { mkdir, readFile } from "node:fs/promises";
import { PDFDocument } from "pdf-lib";
import path from "node:path";

const evidence = path.resolve("../../.impeccable/review/tables-20261015");
test.beforeEach(async ({ page }) => {
  await mkdir(evidence, { recursive: true });
  // The isolated preview uses a different port; proxy read requests in the test
  // without broadening the operator API's allowed origins.
  if (process.env.DANETTI_TABLE_BASE_URL) {
    await page.route("http://localhost:4000/**", async (route) => {
      const response = await route.fetch();
      await route.fulfill({
        response,
        headers: {
          ...response.headers(),
          "access-control-allow-origin": process.env.DANETTI_TABLE_BASE_URL!,
        },
      });
    });
  }
  // Verification never changes saved pricing or operator preferences.
  await page.route("**/pricing-settings/**", (route) =>
    route.fulfill({ json: { eurHufRate: 400 } })
  );
  await page.route("**/manual-batch/preferences", (route) =>
    route.fulfill({ json: { autoResume: false } })
  );
});

async function checkResize(page: Page, label: string) {
  const handle = page.getByRole("separator", { name: `${label} oszlopszélesség`, exact: true });
  await handle.scrollIntoViewIfNeeded();
  const before = Number(await handle.getAttribute("aria-valuenow"));
  const position = (await handle.boundingBox())!;
  await page.mouse.move(position.x + position.width / 2, position.y + position.height / 2);
  await page.mouse.down();
  await page.mouse.move(position.x + position.width / 2 + 80, position.y + position.height / 2, {
    steps: 24,
  });
  // React preference remains unchanged during the gesture; only the column is painted.
  await expect(handle).toHaveAttribute("aria-valuenow", String(before));
  await expect(page.locator("table.is-resizing")).toHaveCount(1);
  await page.mouse.up();
  await expect(handle).toHaveAttribute("aria-valuenow", String(before + 80));
  await expect(page.locator("table.is-resizing")).toHaveCount(0);
  await handle.focus();
  await handle.press("ArrowLeft");
  await expect(handle).toHaveAttribute("aria-valuenow", String(before + 70));
  await handle.dblclick();
  await expect
    .poll(async () => Number(await handle.getAttribute("aria-valuenow")))
    .toBeLessThanOrEqual(900);
  await expect.poll(() => page.evaluate(() => document.body.style.userSelect)).toBe("");
}

async function checkAlignment(table: Locator) {
  const mismatches = await table.evaluate((element) => {
    const cells = Array.from(element.querySelectorAll("tbody tr:first-child td"));
    return Array.from(element.querySelectorAll("thead th")).flatMap((header, index) => {
      const numeric =
        header.classList.contains("numeric") || header.classList.contains("cell-number");
      const expected = "left";
      const targets = [header, header.querySelector(".table-sort-button"), cells[index]];
      if (numeric) targets.push(cells[index]?.querySelector("input") ?? null);
      return targets
        .filter((target): target is Element => !!target)
        .filter((target) => getComputedStyle(target).textAlign !== expected)
        .map(
          (target) =>
            `${index}: ${target.tagName} ${getComputedStyle(target).textAlign}, expected ${expected}`
        );
    });
  });
  expect(mismatches).toEqual([]);
}

test("Fejléc és terméktábla: minden oszlop, méretezés, teljes navigáció", async ({ page }) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.setViewportSize({ width: 1366, height: 900 });
  await page.goto("/products");
  const table = page.locator("table.data-table--sheet");
  await expect(table.locator("tbody tr").first()).toBeVisible();
  for (const width of [320, 390, 768, 1024, 1366, 1920]) {
    await page.setViewportSize({ width, height: 900 });
    await page.evaluate(() => scrollTo(0, 0));
    for (const link of await page.locator(".app-nav a").all()) {
      const box = (await link.boundingBox())!;
      expect(box.x).toBeGreaterThanOrEqual(0);
      expect(box.x + box.width).toBeLessThanOrEqual(width + 1);
    }
    await expect(page.getByRole("link", { name: "EPR", exact: true })).toBeVisible();
    await expect(
      page.getByRole("button", { name: "Danetti frissítés ellenőrzése", exact: true })
    ).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(
      true
    );
    await page.screenshot({ path: path.join(evidence, `header-${width}-after.png`) });
  }
  await page.setViewportSize({ width: 1366, height: 900 });
  const labels = await table.locator("thead .table-sort-button").allTextContents();
  await checkAlignment(table);
  for (const label of labels.filter((label) => label !== "Mentés")) {
    const button = table.getByRole("button", { name: label, exact: true });
    await button.click();
    await expect(button.locator("..")).toHaveAttribute("aria-sort", "ascending");
    await expect(table.locator("tbody tr").first()).toBeVisible();
    await button.click();
    await expect(button.locator("..")).toHaveAttribute("aria-sort", "descending");
    await expect(table.locator("tbody tr").first()).toBeVisible();
  }
  await checkResize(page, "Név");
  await table.evaluate((element) => {
    const header = document.querySelector(".app-header")!.getBoundingClientRect().height;
    window.scrollTo(0, element.getBoundingClientRect().top + scrollY - header - 80);
    element.parentElement!.scrollLeft = 0;
  });
  await page.screenshot({ path: path.join(evidence, "products-after.png") });
  expect(errors).toEqual([]);
});

test("Árváltozások: rendezés, 205 sor exportja, oszlopválasztás és nyomtatás", async ({
  page,
  context,
}) => {
  const rows = Array.from({ length: 205 }, (_, index) => ({
    newSnapshotId: `fixture-${index}`,
    sku: `T${index}`,
    productName: index === 0 ? "Ábel" : `Termék ${index}`,
    supplierName: "DVG",
    supplierId: "fixture",
    supplierArticleNumber: `A${index}`,
    oldSupplierNetEur: 1,
    newSupplierNetEur: 205 - index,
    supplierChangeEur: 204 - index,
    supplierChangeHuf: (204 - index) * 400,
    supplierChangePercent: 204 - index,
    currentWooPriceHuf: 1000 + index,
    currentWooPriceSource: "currentPrice",
    currentProfitPercentWithNewCost: index - 10,
    preservedProfitPercent: 20,
    suggestedGrossPriceRoundedHuf: 3000,
    suggestedPriceDeltaHuf: 2000 - index,
    newObservedAt: "2026-10-14T08:00:00Z",
  }));
  const queries: URL[] = [];
  await page.route("**/supplier-price-changes?*", async (route) => {
    const url = new URL(route.request().url());
    queries.push(url);
    const key = url.searchParams.get("sortBy") ?? "newObservedAt";
    const direction = url.searchParams.get("sortDirection") === "asc" ? 1 : -1;
    const sorted = [...rows].sort((a, b) => {
      const av = a[key as keyof typeof a],
        bv = b[key as keyof typeof b];
      return typeof av === "number" && typeof bv === "number"
        ? (av - bv) * direction
        : String(av).localeCompare(String(bv), "hu", { numeric: true }) * direction;
    });
    const offset = Number(url.searchParams.get("offset")),
      limit = Number(url.searchParams.get("limit"));
    await route.fulfill({
      json: {
        items: sorted.slice(offset, offset + limit),
        total: sorted.length,
        limit,
        offset,
        generatedAt: "2026-10-14T08:00:00Z",
        summary: {
          changedCount: 205,
          increaseCount: 204,
          decreaseCount: 0,
          noPreviousPriceCount: 0,
          marginWouldDropCount: 10,
        },
      },
    });
  });
  await context.addInitScript(() => {
    window.print = () => {
      document.body.dataset.printed = "true";
    };
  });
  await page.setViewportSize({ width: 1366, height: 900 });
  await page.goto("/supplier-price-changes");
  const table = page.locator("table.supplier-changes-table");
  await expect(table.locator("tbody tr")).toHaveCount(50);
  await checkAlignment(table);
  const price = table.getByRole("button", { name: "Új beszállítói ár", exact: true });
  await price.click();
  await expect(table.locator("tbody tr").first().locator("td").nth(5)).toContainText("1 EUR");
  await price.click();
  await expect(table.locator("tbody tr").first().locator("td").nth(5)).toContainText("205 EUR");
  await checkResize(page, "Termék");
  await page.getByRole("button", { name: "Export / nyomtatás", exact: true }).click();
  await page.getByRole("button", { name: "Kijelölés törlése" }).click();
  await expect(page.getByRole("button", { name: "CSV letöltése", exact: true })).toBeDisabled();
  await page.getByRole("checkbox", { name: "SKU", exact: true }).check();
  await page.getByRole("checkbox", { name: "Új beszállítói ár", exact: true }).check();
  const downloadPromise = page.waitForEvent("download");
  await page.getByRole("button", { name: "CSV letöltése", exact: true }).click();
  const download = await downloadPromise;
  const downloaded = await readFile((await download.path())!, "utf8");
  expect(downloaded.startsWith('\ufeff"SKU";"Új beszállítói ár (EUR)"')).toBe(true);
  const lines = downloaded.split("\r\n");
  expect(lines).toHaveLength(206);
  expect(lines[1]).toBe('"T0";"205"');
  expect(lines.at(-1)).toBe('"T204";"1"');
  expect(queries.some((url) => url.searchParams.get("offset") === "200")).toBe(true);
  const popupPromise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Nyomtatás / PDF" }).click();
  const popup = await popupPromise;
  await expect(popup.locator("tbody tr")).toHaveCount(205);
  await expect(popup.locator("th")).toHaveCount(3);
  await expect(popup.locator("tbody tr").first().locator("td").nth(2)).toHaveText("205 EUR");
  await expect(popup.locator("tbody tr").last().locator("td").nth(1)).toHaveText("T204");
  await expect(popup.locator("body")).toHaveAttribute("data-printed", "true");
  await popup.close();
  await page.getByRole("button", { name: "Mind kijelölése", exact: true }).click();
  const widePopupPromise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Nyomtatás / PDF" }).click();
  const widePopup = await widePopupPromise;
  await expect(widePopup.locator(".print-band")).toHaveCount(3);
  await expect(widePopup.locator("body")).toContainText("204 %");
  await expect(widePopup.locator("body")).toContainText("+2000 Ft");
  await checkAlignment(widePopup.locator("table").first());
  for (const band of await widePopup.locator(".print-band").all()) {
    await expect(band.locator("th").nth(1)).toHaveText("SKU");
    await expect(band.locator("th").nth(2)).toHaveText("Termék");
  }
  const pdfBytes = await widePopup.pdf({
    path: path.join(evidence, "changes-a4-proof.pdf"),
    preferCSSPageSize: true,
    printBackground: true,
  });
  const pdf = await PDFDocument.load(pdfBytes);
  expect(pdf.getPageCount()).toBeGreaterThan(2);
  expect(pdf.getPage(0).getWidth()).toBeCloseTo(841.92, 0);
  expect(pdf.getPage(0).getHeight()).toBeCloseTo(594.96, 0);
  await widePopup.close();
  await page.getByRole("combobox", { name: "Papírméret", exact: true }).selectOption("A3");
  await page.getByRole("combobox", { name: "PDF elrendezés", exact: true }).selectOption("records");
  const recordsPromise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Nyomtatás / PDF" }).click();
  const records = await recordsPromise;
  await expect(records.locator(".print-record")).toHaveCount(205);
  await expect(records.locator(".print-record").first().locator("dt")).toHaveCount(14);
  await records.close();
  await page.screenshot({ path: path.join(evidence, "changes-export-after.png"), fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(
    true
  );
  await page.screenshot({ path: path.join(evidence, "changes-mobile-after.png"), fullPage: true });
});

test("Valódi helyi árváltozások: gyors API és befejeződő betöltés", async ({ page, request }) => {
  const started = Date.now();
  const response = await request.get(
    "http://localhost:4000/supplier-price-changes?limit=50&eurHufRate=400",
    { timeout: 10000 }
  );
  expect(response.ok()).toBe(true);
  const data = await response.json();
  expect(data.total).toBeGreaterThan(0);
  expect(Date.now() - started).toBeLessThan(8000);
  console.log(`Live price changes: ${data.total} results, ${Date.now() - started} ms`);
  await page.goto("/supplier-price-changes");
  await expect(page.locator("table.supplier-changes-table tbody tr").first()).toBeVisible();
  await expect(page.locator("main")).not.toContainText("Betöltés...");
  await page.screenshot({ path: path.join(evidence, "changes-live-after.png") });
});

test("Termékek PDF: minden megjelenített oszlop, A4/A3 és termékadatlap", async ({
  page,
  context,
}) => {
  await context.addInitScript(() => {
    window.print = () => {
      document.body.dataset.printed = "true";
    };
  });
  const products = Array.from({ length: 3 }, (_, index) => ({
    id: `print-${index}`,
    sku: `T${index}_TEST`,
    name: `Hosszabb terméknév – ellenőrzési minta ${index}`,
    createdAt: "2026-10-14T08:00:00Z",
    lastSeenInImportAt: "2026-10-14T08:00:00Z",
    currentPrice: "5000",
    regularPrice: "6000",
    dvgPurchasePriceEur: "4.72",
  }));
  await page.route("**/catalog/products?*", (route) => {
    const url = new URL(route.request().url());
    const offset = Number(url.searchParams.get("offset")),
      limit = Number(url.searchParams.get("limit"));
    return route.fulfill({
      json: { products: products.slice(offset, offset + limit), total: 3, limit, offset },
    });
  });
  await page.goto("/products");
  await expect(page.locator("table.data-table--sheet tbody tr")).toHaveCount(3);
  await expect(page.locator(".products-page details")).toHaveCount(0);
  await expect(
    page.getByRole("heading", { name: "Árszámítás beállításai", exact: true })
  ).toBeVisible();
  for (const name of ["CSV letöltése", "Nyomtatás / PDF", "Teljes export", "Teljes import"])
    await expect(page.getByRole("button", { name, exact: true })).toBeVisible();
  const popupPromise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Nyomtatás / PDF", exact: true }).click();
  const popup = await popupPromise;
  await expect.poll(() => popup.locator(".print-band").count()).toBeGreaterThan(1);
  for (const band of await popup.locator(".print-band").all()) {
    await expect(band.locator("th").nth(1)).toHaveText("SKU");
    await expect(band.locator("th").nth(2)).toHaveText("Név");
    await expect(band.locator("tbody tr")).toHaveCount(3);
  }
  await checkAlignment(popup.locator("table").first());
  const bytes = await popup.pdf({
    path: path.join(evidence, "products-a4-proof.pdf"),
    preferCSSPageSize: true,
    printBackground: true,
  });
  const pdf = await PDFDocument.load(bytes);
  expect(pdf.getPageCount()).toBeGreaterThan(1);
  expect(pdf.getPage(0).getWidth()).toBeCloseTo(841.92, 0);
  await popup.close();
  await page
    .getByRole("group", { name: "Papírméret", exact: true })
    .getByRole("button", { name: "A3 fekvő", exact: true })
    .click();
  await page
    .getByRole("group", { name: "PDF elrendezés", exact: true })
    .getByRole("button", { name: "Termékenkénti adatlap", exact: true })
    .click();
  const recordPromise = page.waitForEvent("popup");
  await page.getByRole("button", { name: "Nyomtatás / PDF", exact: true }).click();
  const record = await recordPromise;
  await expect(record.locator(".print-record")).toHaveCount(3);
  await expect(record.locator(".print-record").first().locator("dt")).toHaveCount(21);
  const a3Bytes = await record.pdf({
    path: path.join(evidence, "products-a3-records-proof.pdf"),
    preferCSSPageSize: true,
    printBackground: true,
  });
  const a3 = await PDFDocument.load(a3Bytes);
  expect(a3.getPage(0).getWidth()).toBeCloseTo(1191.12, 0);
  await record.close();
});

for (const scope of ["dvg", "lf"])
  test(`${scope.toUpperCase()} táblázat: beszállítói adatok és lapozás előtti rendezés`, async ({
    page,
  }) => {
    const errors: string[] = [];
    page.on("pageerror", (error) => errors.push(error.message));
    const rows = Array.from({ length: 61 }, (_, index) => ({
      catalogProductId: `product-${index}`,
      status: "ok",
      wooSku: `T${index}`,
      wooName: `Termék ${60 - index}`,
      supplierArticleNumber: `A${index}`,
      supplierMappingId: "fixture",
      candidateSource: "saved_mapping",
      supplierNetEur: 61 - index,
      supplierNetHuf: (61 - index) * 400,
      wooGrossHuf: 1000 + index,
      wooNetHuf: 800 + index,
      actualProfitNetHuf: index - 10,
      actualProfitPercentOnCost: index - 20,
      warnings: [],
      matchConfidence: "exact",
      currency: index === 60 ? "CHF" : "EUR",
      lfAutocompleteId: `C:${index}`,
      lfAutocompleteValue: `LF ${index}`,
      lfPartNumber: `LF${index}`,
    }));
    const run = {
      runId: "table-fixture",
      status: "completed",
      startedAt: "2026-10-14T08:00:00Z",
      completedAt: "2026-10-14T08:01:00Z",
      currentItem: null,
      settings: {
        offset: 0,
        limit: 61,
        speedMode: "normal",
        eurHufRate: 400,
        vatPercent: 27,
        markupPercent: 50,
        wooPricesIncludeVat: true,
      },
      totals: { candidates: 61, checked: 61, ok: 61, failed: 0, skipped: 0, safetyStopped: 0 },
      events: [],
      rows,
    };
    await page.route(`**/${scope}-products/manual-batch/**`, (route) => {
      const endpoint = new URL(route.request().url()).pathname.split("/").at(-1);
      return route.fulfill({
        json:
          endpoint === "saved-state"
            ? { run, preferences: { autoResume: false } }
            : endpoint === "progress"
              ? { progress: null }
              : endpoint === "current"
                ? { run }
                : run,
      });
    });
    await page.route("**/suppliers?*", (route) => route.fulfill({ json: { items: [], total: 0 } }));
    await page.addInitScript((supplier) => {
      localStorage.setItem(
        `danetti:${supplier}-results:columns`,
        JSON.stringify({
          supplierNetHuf: true,
          wooGrossHuf: true,
          wooNetHuf: true,
          profitHuf: true,
          profitPercent: true,
        })
      );
    }, scope);
    await page.setViewportSize({ width: 1366, height: 900 });
    await page.goto(`/operator/${scope}`);
    const table = page.locator("table.supplier-observations-table");
    const picker = page.locator(".dvg-results-card .table-column-picker--inline");
    await expect(table.locator("tbody tr")).toHaveCount(50);
    await expect(table.locator("thead th")).toHaveCount(scope === "lf" ? 9 : 6);
    await expect(table).not.toContainText(/HUF|Haszon|profit|Woo bruttó|Woo nettó/i);
    await expect(picker.getByRole("checkbox")).toHaveCount(scope === "lf" ? 9 : 6);
    await expect(picker.getByRole("checkbox", { name: "SKU", exact: true })).toBeVisible();
    await expect(page.locator(".dvg-results-card details")).toHaveCount(0);
    await picker.getByRole("checkbox", { name: "SKU", exact: true }).uncheck();
    await expect(table.getByRole("button", { name: "SKU", exact: true })).toHaveCount(0);
    await picker.getByRole("button", { name: "Mind kijelölése", exact: true }).click();
    const storedColumns = await page.evaluate((supplier) => {
      return Object.keys(JSON.parse(localStorage.getItem(`danetti:${supplier}-results:columns`)!));
    }, scope);
    for (const removed of [
      "supplierNetHuf",
      "wooGrossHuf",
      "wooNetHuf",
      "profitHuf",
      "profitPercent",
    ])
      expect(storedColumns).not.toContain(removed);
    await checkAlignment(table);
    for (const button of await table.locator(".table-sort-button").all()) {
      await button.click();
      await expect(button.locator("..")).toHaveAttribute("aria-sort", "ascending");
      await button.click();
      await expect(button.locator("..")).toHaveAttribute("aria-sort", "descending");
    }
    await table
      .getByRole("button", { name: `${scope.toUpperCase()} nettó ár`, exact: true })
      .click();
    const column = scope === "lf" ? 7 : 4;
    await expect(table.locator("tbody tr").first().locator("td").nth(column)).toHaveText(
      "1.00 CHF"
    );
    await checkResize(page, "Termék");
    const width = await page
      .getByRole("separator", { name: "Termék oszlopszélesség", exact: true })
      .getAttribute("aria-valuenow");
    await page.reload();
    await expect(
      page.getByRole("separator", { name: "Termék oszlopszélesség", exact: true })
    ).toHaveAttribute("aria-valuenow", width!);
    await table.evaluate((element) => {
      const header = document.querySelector(".app-header")!.getBoundingClientRect().height;
      window.scrollTo(0, element.getBoundingClientRect().top + scrollY - header - 80);
      element.parentElement!.scrollLeft = 0;
    });
    await page.screenshot({ path: path.join(evidence, `${scope}-after.png`) });
    await page.setViewportSize({ width: 390, height: 844 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(
      true
    );
    await page.screenshot({
      path: path.join(evidence, `${scope}-mobile-after.png`),
      fullPage: true,
    });
    expect(errors).toEqual([]);
  });

test("Termékek: 205 sor azonos sorrendben CSV/PDF-ben, független oszlopválasztás", async ({
  page,
  context,
}) => {
  const rows = Array.from({ length: 205 }, (_, i) => ({
    id: `export-${i}`,
    sku: `P${i}`,
    name: `Termék ${i}`,
    currentPrice: String(5000 + i),
    dvgPurchasePriceEur: "4.72",
    createdAt: "2026-10-15T08:00:00Z",
  }));
  const queries: URL[] = [];
  await page.route("**/catalog/products?*", (route) => {
    const url = new URL(route.request().url());
    queries.push(url);
    const sorted = [...rows].sort(
      (a, b) =>
        a.name.localeCompare(b.name, "hu", { numeric: true }) *
        (url.searchParams.get("sortDirection") === "desc" ? -1 : 1)
    );
    const offset = Number(url.searchParams.get("offset")),
      limit = Number(url.searchParams.get("limit"));
    return route.fulfill({
      json: { products: sorted.slice(offset, offset + limit), total: rows.length, offset, limit },
    });
  });
  await page.route("**/suppliers?*", (route) =>
    route.fulfill({ json: { items: [], total: 0, limit: 100, offset: 0 } })
  );
  await page.route("**/supplier-mappings?*", (route) =>
    route.fulfill({ json: { items: [], total: 0, limit: 200, offset: 0 } })
  );
  await context.addInitScript(() => {
    window.print = () => {
      document.body.dataset.printed = "true";
    };
  });
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.goto("/products");
  await expect(page.locator("table tbody tr")).toHaveCount(50);
  await expect(page.locator(".products-page details")).toHaveCount(0);
  await expect(page.locator(".catalog-controls select")).toHaveCount(0);
  await page
    .getByRole("group", { name: "Rendezés", exact: true })
    .getByRole("button", { name: "Név", exact: true })
    .click();
  await page
    .getByRole("group", { name: "Irány", exact: true })
    .getByRole("button", { name: "Csökkenő", exact: true })
    .click();
  await expect(page.locator("table tbody tr").first().locator("input").first()).toHaveValue("P204");
  const panel = page.locator(".products-files");
  await panel.getByRole("button", { name: "Csak azonosítók látszanak", exact: true }).click();
  await expect(page.locator("table thead th")).toHaveCount(3);
  await panel.getByRole("button", { name: "Export kijelölés törlése", exact: true }).click();
  await expect(panel.getByRole("button", { name: "CSV letöltése", exact: true })).toBeDisabled();
  for (const label of ["SKU", "Név", "Profit %"])
    await panel.getByRole("checkbox", { name: `${label} · export`, exact: true }).check();
  await expect(
    panel.getByRole("checkbox", { name: "Profit % · táblázat", exact: true })
  ).not.toBeChecked();
  await expect(page.locator("table thead th")).toHaveCount(3);
  const downloadPromise = page.waitForEvent("download");
  await panel.getByRole("button", { name: "CSV letöltése", exact: true }).click();
  const csv = await readFile((await (await downloadPromise).path())!, "utf8");
  const lines = csv.replace(/^\ufeff/, "").split("\r\n");
  expect(lines).toHaveLength(206);
  expect(lines[0]).toBe('"SKU";"Név";"Profit %"');
  const csvIds = lines.slice(1).map((line) => line.split(";")[0].replaceAll('"', ""));
  expect(csvIds[0]).toBe("P204");
  expect(csvIds.at(-1)).toBe("P0");
  const popupPromise = page.waitForEvent("popup");
  await panel.getByRole("button", { name: "Nyomtatás / PDF", exact: true }).click();
  const popup = await popupPromise;
  await expect(popup.locator("tbody tr")).toHaveCount(205);
  expect(await popup.locator("tbody tr td:nth-child(2)").allTextContents()).toEqual(csvIds);
  await expect(popup.locator("tbody tr").first().locator("td").last()).toContainText("%");
  expect(queries.some((q) => q.searchParams.get("offset") === "200")).toBe(true);
  await popup.close();
  for (const width of [320, 390, 768, 1440]) {
    await page.setViewportSize({ width, height: 1000 });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)).toBe(
      true
    );
    await page.screenshot({
      path: path.join(evidence, `products-export-${width}-after.png`),
      fullPage: true,
    });
  }
});
