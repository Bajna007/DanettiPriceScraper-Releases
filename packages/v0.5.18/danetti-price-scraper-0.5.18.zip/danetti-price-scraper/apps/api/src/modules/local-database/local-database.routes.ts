import { createHash } from "node:crypto";
import { createDbClient, type DanettiDbClient, type DanettiSqlClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";

const LOCAL_DATABASE_BACKUP_FORMAT = "danetti-local-database-backup";
const LOCAL_DATABASE_BACKUP_VERSION = 2;
const LOCAL_DATABASE_MAX_BYTES = 250 * 1024 * 1024;
const LOCAL_LAB_HEADER = "x-danetti-local-lab";

const TABLE_RESTORE_ORDER = [
  "suppliers",
  "catalog_import_runs",
  "catalog_products",
  "exchange_rates",
  "pricing_rules",
  "dvg_operator_settings",
  "lf_operator_settings",
  "dvg_operator_runs",
  "lf_operator_runs",
  "manual_operator_runs",
  "supplier_check_settings",
  "supplier_portal_audits",
  "supplier_portal_audit_checks",
  "supplier_portal_audit_evidence_notes",
  "supplier_mappings",
  "crawler_runs",
  "crawler_run_items",
  "evidence_artifacts",
  "catalog_import_rows",
  "supplier_price_snapshots",
  "price_alerts",
  "audit_events",
  "label_assets",
  "label_templates",
  "label_template_versions",
  "label_designs",
  "label_design_versions",
  "label_orders",
  "label_order_items",
  "label_exports",
];

interface LocalDatabaseRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  service?: LocalDatabaseBackupServiceLike;
  now?: () => Date;
}

interface LocalDatabaseBackupServiceLike {
  exportBackup: () => Promise<LocalDatabaseBackup>;
  importBackup: (backup: unknown) => Promise<LocalDatabaseImportResult>;
}

interface TableColumnInfo {
  name: string;
  dataType: string;
  udtName: string;
}

interface TableColumnMap {
  [tableName: string]: TableColumnInfo[];
}

interface LocalDatabaseBackupTable {
  name: string;
  columns: string[];
  rowCount: number;
  rows: Array<Record<string, unknown>>;
}

interface LocalDatabaseBackup {
  format: typeof LOCAL_DATABASE_BACKUP_FORMAT;
  formatVersion: typeof LOCAL_DATABASE_BACKUP_VERSION;
  exportedAt: string;
  schema: "public";
  source: {
    app: "DanettiPriceScraper";
    purpose: "full_local_database_transfer";
  };
  tables: LocalDatabaseBackupTable[];
  totals: {
    tableCount: number;
    rowCount: number;
  };
  integrity?: {
    algorithm: "sha256";
    sha256: string;
  };
}

interface LocalDatabaseImportResult {
  importedAt: string;
  tableCount: number;
  rowCount: number;
  skippedTables: string[];
}

interface LocalDatabaseRouteError extends Error {
  statusCode?: number;
  code?: string;
}

export async function registerLocalDatabaseRoutes(
  server: FastifyInstance,
  options: LocalDatabaseRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getService(): LocalDatabaseBackupServiceLike {
    if (options.service) return options.service;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new LocalDatabaseBackupService(dbClient.sql, options.now);
    } catch (error) {
      throw routeError(
        "database_unavailable",
        error instanceof Error ? error.message : "Database unavailable",
        503
      );
    }
  }

  server.get("/local-database/export", async (request, reply) => {
    try {
      requireLocalLabHeader(request);
      const backup = await getService().exportBackup();
      const filename = formatBackupFilename(backup.exportedAt);
      return reply
        .header("content-type", "application/json; charset=utf-8")
        .header("content-disposition", `attachment; filename=\"${filename}\"`)
        .send(backup);
    } catch (error) {
      return handleLocalDatabaseRouteError(reply, error);
    }
  });

  server.route({
    method: "POST",
    url: "/local-database/import",
    bodyLimit: LOCAL_DATABASE_MAX_BYTES,
    handler: async (request, reply) => {
      try {
        requireLocalLabHeader(request);
        const result = await getService().importBackup(request.body);
        return { result };
      } catch (error) {
        return handleLocalDatabaseRouteError(reply, error);
      }
    },
  });
}

// The portable catalog excludes account, mailbox, document, label and browser data.
export const CATALOG_TRANSFER_TABLES = [
  "suppliers",
  "catalog_import_runs",
  "catalog_products",
  "exchange_rates",
  "pricing_rules",
  "dvg_operator_settings",
  "lf_operator_settings",
  "dvg_operator_runs",
  "lf_operator_runs",
  "manual_operator_runs",
  "supplier_mappings",
  "catalog_import_rows",
  "supplier_price_snapshots",
  "price_alerts",
  "price_change_reviews",
  "dvg_article_change_states",
] as const;

export class LocalDatabaseBackupService implements LocalDatabaseBackupServiceLike {
  constructor(
    private readonly sql: DanettiSqlClient,
    private readonly now: () => Date = () => new Date()
  ) {}

  async exportCatalogTransfer(portable = true): Promise<LocalDatabaseBackup> {
    // One snapshot includes mappings, prices and review records from the same point in time.
    return this.sql.begin("isolation level repeatable read read only", async (tx) => {
      const service = new LocalDatabaseBackupService(tx as unknown as DanettiSqlClient, this.now);
      const columns = await service.readTableColumns(tx as unknown as DanettiSqlClient);
      const tables = [];
      for (const name of CATALOG_TRANSFER_TABLES) {
        if (!columns[name]) throw new Error(`Missing catalog table: ${name}`);
        const names = columns[name]!.map((column) => column.name);
        const rows = (await service.readRows(name, names)).map((row) => {
          const clean = { ...row };
          for (const key of portable
            ? ["evidence_artifact_id", "crawler_run_item_id", "raw_row"]
            : [])
            if (key in clean) clean[key] = null;
          return clean;
        });
        tables.push({ name, columns: names, rows, rowCount: rows.length });
      }
      const backup: LocalDatabaseBackup = {
        format: LOCAL_DATABASE_BACKUP_FORMAT,
        formatVersion: LOCAL_DATABASE_BACKUP_VERSION,
        exportedAt: this.now().toISOString(),
        schema: "public",
        source: { app: "DanettiPriceScraper", purpose: "full_local_database_transfer" },
        tables,
        totals: { tableCount: tables.length, rowCount: tables.reduce((n, t) => n + t.rowCount, 0) },
      };
      backup.integrity = { algorithm: "sha256", sha256: hashBackup(backup) };
      return backup;
    });
  }

  async importCatalogTransfer(input: unknown): Promise<LocalDatabaseImportResult> {
    const backup = parseLocalDatabaseBackup(input);
    const expected = new Set<string>(CATALOG_TRANSFER_TABLES);
    if (
      backup.tables.length !== expected.size ||
      new Set(backup.tables.map((t) => t.name)).size !== expected.size ||
      backup.tables.some((t) => !expected.has(t.name))
    )
      throw new Error("A katalógusátvitel táblalistája hibás vagy hiányos.");
    const columns = await this.readTableColumns(this.sql);
    // Never truncate unrelated modules, and never cascade a schema change silently.
    return this.sql.begin(async (tx) => {
      await tx.unsafe("SELECT pg_advisory_xact_lock(72418018)");
      const ordered = orderTableNames([...expected]);
      for (const name of [...ordered].reverse())
        await tx.unsafe(`DELETE FROM ${quoteTableName(name)}`);
      let rowCount = 0;
      for (const name of ordered) {
        const table = backup.tables.find((t) => t.name === name)!;
        const allowed = new Set((columns[name] ?? []).map((c) => c.name));
        if (table.columns.some((c) => !allowed.has(c)))
          throw new Error(`Unknown transfer columns: ${name}`);
        const selected = table.columns.map(quoteIdentifier).join(", ");
        for (let offset = 0; offset < table.rows.length; offset += 500) {
          const batch = table.rows.slice(offset, offset + 500);
          await tx.unsafe(
            `INSERT INTO ${quoteTableName(name)} (${selected}) SELECT ${selected} FROM jsonb_populate_recordset(NULL::${quoteTableName(name)}, $1::jsonb)`,
            [JSON.stringify(batch)]
          );
          rowCount += batch.length;
        }
      }
      return {
        importedAt: this.now().toISOString(),
        tableCount: ordered.length,
        rowCount,
        skippedTables: Object.keys(columns).filter((name) => !expected.has(name)),
      };
    });
  }

  async exportBackup(): Promise<LocalDatabaseBackup> {
    const columnsByTable = await this.readTableColumns(this.sql);
    const tableNames = orderTableNames(Object.keys(columnsByTable));
    const tables: LocalDatabaseBackupTable[] = [];
    let rowCount = 0;

    for (const tableName of tableNames) {
      const columns = (columnsByTable[tableName] ?? []).map((column) => column.name);
      const rows = await this.readRows(tableName, columns);
      rowCount += rows.length;
      tables.push({ name: tableName, columns, rowCount: rows.length, rows });
    }

    const backup: LocalDatabaseBackup = {
      format: LOCAL_DATABASE_BACKUP_FORMAT,
      formatVersion: LOCAL_DATABASE_BACKUP_VERSION,
      exportedAt: this.now().toISOString(),
      schema: "public",
      source: {
        app: "DanettiPriceScraper",
        purpose: "full_local_database_transfer",
      },
      tables,
      totals: {
        tableCount: tables.length,
        rowCount,
      },
    };
    backup.integrity = {
      algorithm: "sha256",
      sha256: hashBackup(backup),
    };
    return backup;
  }

  async importBackup(input: unknown): Promise<LocalDatabaseImportResult> {
    const backup = parseLocalDatabaseBackup(input);
    const currentColumnsByTable = await this.readTableColumns(this.sql);
    const currentTableNames = orderTableNames(Object.keys(currentColumnsByTable));
    const currentTableSet = new Set(currentTableNames);
    const backupByTable = new Map(backup.tables.map((table) => [table.name, table]));
    const unknownTables = backup.tables.filter((table) => !currentTableSet.has(table.name));

    if (unknownTables.length > 0) {
      throw routeError(
        "local_database_invalid_backup",
        `A backup újabb vagy ismeretlen táblát tartalmaz: ${unknownTables.map((table) => table.name).join(", ")}`,
        400
      );
    }

    let importedRows = 0;

    await this.sql.begin(async (tx) => {
      if (currentTableNames.length > 0) {
        await tx.unsafe(
          `TRUNCATE TABLE ${currentTableNames.map(quoteTableName).join(", ")} RESTART IDENTITY CASCADE`
        );
      }

      for (const tableName of currentTableNames) {
        const table = backupByTable.get(tableName);
        if (!table) continue;

        const currentColumns = currentColumnsByTable[tableName] ?? [];
        const allowedColumns = new Set(currentColumns.map((column) => column.name));
        for (const row of table.rows) {
          const columns = table.columns.filter(
            (column) => allowedColumns.has(column) && Object.hasOwn(row, column)
          );
          if (columns.length === 0) continue;
          await insertRow(tx, tableName, columns, row, currentColumns);
          importedRows += 1;
        }
      }
    });

    return {
      importedAt: this.now().toISOString(),
      tableCount: backup.tables.length,
      rowCount: importedRows,
      skippedTables: currentTableNames.filter((tableName) => !backupByTable.has(tableName)),
    };
  }

  private async readTableColumns(sql: DanettiSqlClient): Promise<TableColumnMap> {
    const rows = await sql.unsafe(`
        SELECT table_name, column_name, data_type, udt_name
      FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name IN (
          SELECT table_name
          FROM information_schema.tables
          WHERE table_schema = 'public'
            AND table_type = 'BASE TABLE'
        )
      ORDER BY table_name, ordinal_position
    `);

    const columnsByTable: TableColumnMap = {};
    for (const row of rows as unknown as Array<{
      table_name: string;
      column_name: string;
      data_type: string;
      udt_name: string;
    }>) {
      columnsByTable[row.table_name] ??= [];
      columnsByTable[row.table_name]?.push({
        name: row.column_name,
        dataType: row.data_type,
        udtName: row.udt_name,
      });
    }
    return columnsByTable;
  }

  private async readRows(
    tableName: string,
    columns: string[]
  ): Promise<Array<Record<string, unknown>>> {
    const orderBy = buildExportOrderBy(columns);
    const rows = (await this.sql.unsafe(
      `SELECT * FROM ${quoteTableName(tableName)}${orderBy}`
    )) as Array<Record<string, unknown>>;
    return rows.map((row) =>
      Object.fromEntries(Object.entries(row).map(([key, value]) => [key, encodeBackupValue(value)]))
    );
  }
}

async function insertRow(
  sql: Pick<DanettiSqlClient, "unsafe">,
  tableName: string,
  columns: string[],
  row: Record<string, unknown>,
  currentColumns: TableColumnInfo[]
): Promise<void> {
  const currentColumnByName = new Map(currentColumns.map((column) => [column.name, column]));
  const columnSql = columns.map(quoteIdentifier).join(", ");
  const placeholders = columns
    .map((column, index) => formatPlaceholder(index + 1, currentColumnByName.get(column)))
    .join(", ");
  const values: unknown[] = columns.map((column) =>
    serializeColumnValue(row[column] ?? null, currentColumnByName.get(column))
  );
  const unsafe = sql.unsafe as unknown as (
    query: string,
    parameters?: unknown[]
  ) => Promise<unknown>;
  await unsafe.call(
    sql,
    `INSERT INTO ${quoteTableName(tableName)} (${columnSql}) VALUES (${placeholders})`,
    values
  );
}

function formatPlaceholder(index: number, column: TableColumnInfo | undefined): string {
  if (!column) return `$${index}`;
  if (column.dataType === "jsonb") return `$${index}::jsonb`;
  if (column.dataType === "json") return `$${index}::json`;
  return `$${index}`;
}

function serializeColumnValue(value: unknown, column: TableColumnInfo | undefined): unknown {
  if (value === null) return null;
  if (column?.dataType === "bytea") return decodeBackupBinary(value);
  if (column?.dataType === "jsonb" || column?.dataType === "json") {
    return JSON.stringify(value);
  }
  return value;
}

function parseLocalDatabaseBackup(input: unknown): LocalDatabaseBackup {
  if (!isPlainObject(input)) {
    throw routeError("local_database_invalid_backup", "A backup fájl nem JSON objektum.", 400);
  }
  if (input.format !== LOCAL_DATABASE_BACKUP_FORMAT) {
    throw routeError(
      "local_database_invalid_backup",
      "Ez nem Danetti helyi adatbázis backup fájl.",
      400
    );
  }
  if (input.formatVersion !== 1 && input.formatVersion !== LOCAL_DATABASE_BACKUP_VERSION) {
    throw routeError(
      "local_database_invalid_backup",
      `Nem támogatott backup verzió: ${String(input.formatVersion)}.`,
      400
    );
  }
  if (!Array.isArray(input.tables)) {
    throw routeError("local_database_invalid_backup", "A backup nem tartalmaz táblalistát.", 400);
  }

  if (input.formatVersion === LOCAL_DATABASE_BACKUP_VERSION) {
    if (
      !isPlainObject(input.integrity) ||
      input.integrity.algorithm !== "sha256" ||
      typeof input.integrity.sha256 !== "string"
    ) {
      throw routeError(
        "local_database_invalid_backup",
        "Az új backup integritási SHA-256 értéke hiányzik.",
        400
      );
    }
    const expected = input.integrity.sha256;
    const actual = hashBackup(input);
    if (expected !== actual) {
      throw routeError(
        "local_database_integrity_failed",
        "A backup SHA-256 ellenőrzése sikertelen. A fájl sérült vagy módosult.",
        400
      );
    }
  }

  const tableNames = new Set<string>();
  const tables = input.tables.map((table) => {
    if (!isPlainObject(table) || typeof table.name !== "string") {
      throw routeError("local_database_invalid_backup", "Érvénytelen tábla a backupban.", 400);
    }
    assertSafeIdentifier(table.name, "table");
    if (tableNames.has(table.name)) {
      throw routeError(
        "local_database_invalid_backup",
        `Duplikált backup tábla: ${table.name}`,
        400
      );
    }
    tableNames.add(table.name);
    if (
      !Array.isArray(table.columns) ||
      !table.columns.every((column) => typeof column === "string")
    ) {
      throw routeError(
        "local_database_invalid_backup",
        `Érvénytelen oszloplista: ${table.name}`,
        400
      );
    }
    for (const column of table.columns) assertSafeIdentifier(column, "column");
    if (!Array.isArray(table.rows) || !table.rows.every(isPlainObject)) {
      throw routeError("local_database_invalid_backup", `Érvénytelen sorlista: ${table.name}`, 400);
    }
    return {
      name: table.name,
      columns: table.columns,
      rowCount: typeof table.rowCount === "number" ? table.rowCount : table.rows.length,
      rows: table.rows as Array<Record<string, unknown>>,
    };
  });

  return {
    format: LOCAL_DATABASE_BACKUP_FORMAT,
    formatVersion: input.formatVersion as typeof LOCAL_DATABASE_BACKUP_VERSION,
    exportedAt: typeof input.exportedAt === "string" ? input.exportedAt : new Date(0).toISOString(),
    schema: "public",
    source: {
      app: "DanettiPriceScraper",
      purpose: "full_local_database_transfer",
    },
    tables,
    totals: {
      tableCount: tables.length,
      rowCount: tables.reduce((total, table) => total + table.rows.length, 0),
    },
    integrity:
      isPlainObject(input.integrity) && typeof input.integrity.sha256 === "string"
        ? { algorithm: "sha256", sha256: input.integrity.sha256 }
        : undefined,
  };
}

function encodeBackupValue(value: unknown): unknown {
  if (Buffer.isBuffer(value) || value instanceof Uint8Array) {
    const bytes = Buffer.from(value);
    return {
      $danettiBinary: "base64",
      sha256: createHash("sha256").update(bytes).digest("hex"),
      data: bytes.toString("base64"),
    };
  }
  return value;
}

function decodeBackupBinary(value: unknown): Buffer {
  if (
    !isPlainObject(value) ||
    value.$danettiBinary !== "base64" ||
    typeof value.data !== "string" ||
    typeof value.sha256 !== "string"
  ) {
    throw routeError(
      "local_database_invalid_backup",
      "Érvénytelen bináris asset a backupban.",
      400
    );
  }
  const bytes = Buffer.from(value.data, "base64");
  const actual = createHash("sha256").update(bytes).digest("hex");
  if (actual !== value.sha256) {
    throw routeError(
      "local_database_integrity_failed",
      "Egy bináris asset SHA-256 ellenőrzése sikertelen.",
      400
    );
  }
  return bytes;
}

function hashBackup(value: unknown): string {
  const clean = isPlainObject(value)
    ? Object.fromEntries(Object.entries(value).filter(([key]) => key !== "integrity"))
    : value;
  return createHash("sha256")
    .update(JSON.stringify(sortBackupValue(clean)))
    .digest("hex");
}

function sortBackupValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortBackupValue);
  if (isPlainObject(value)) {
    return Object.fromEntries(
      Object.entries(value)
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([key, child]) => [key, sortBackupValue(child)])
    );
  }
  return value;
}

function requireLocalLabHeader(request: FastifyRequest): void {
  const headerValue = request.headers[LOCAL_LAB_HEADER];
  const normalized = Array.isArray(headerValue) ? headerValue[0] : headerValue;
  if (String(normalized ?? "").toLowerCase() === "true") return;
  throw routeError(
    "local_database_header_missing",
    "Helyi adatbázis export/import csak a Danetti dashboardból indítható.",
    403
  );
}

function handleLocalDatabaseRouteError(reply: FastifyReply, error: unknown): FastifyReply {
  const known = error as LocalDatabaseRouteError;
  const statusCode = known.statusCode ?? 500;
  const code = known.code ?? (statusCode >= 500 ? "local_database_restore_failed" : "bad_request");
  return reply.code(statusCode).send({
    error: {
      code,
      message: error instanceof Error ? error.message : "Helyi adatbázis művelet sikertelen.",
    },
  });
}

function routeError(code: string, message: string, statusCode: number): LocalDatabaseRouteError {
  const error = new Error(message) as LocalDatabaseRouteError;
  error.code = code;
  error.statusCode = statusCode;
  return error;
}

function orderTableNames(tableNames: string[]): string[] {
  const rank = new Map(TABLE_RESTORE_ORDER.map((table, index) => [table, index]));
  return [...tableNames].sort((left, right) => {
    const leftRank = rank.get(left) ?? Number.MAX_SAFE_INTEGER;
    const rightRank = rank.get(right) ?? Number.MAX_SAFE_INTEGER;
    if (leftRank !== rightRank) return leftRank - rightRank;
    return left.localeCompare(right);
  });
}

function buildExportOrderBy(columns: string[]): string {
  const preferred = ["id", "run_id", "key"].filter((column) => columns.includes(column));
  const orderColumns = preferred.length > 0 ? preferred : columns.slice(0, 1);
  if (orderColumns.length === 0) return "";
  return ` ORDER BY ${orderColumns.map(quoteIdentifier).join(", ")}`;
}

function quoteTableName(tableName: string): string {
  return `"public".${quoteIdentifier(tableName)}`;
}

function quoteIdentifier(identifier: string): string {
  assertSafeIdentifier(identifier, "identifier");
  return `"${identifier.replace(/"/g, '""')}"`;
}

function assertSafeIdentifier(identifier: string, label: string): void {
  if (/^[a-z_][a-z0-9_]*$/.test(identifier)) return;
  throw routeError(
    "local_database_invalid_backup",
    `Érvénytelen ${label} azonosító a backupban: ${identifier}`,
    400
  );
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function formatBackupFilename(exportedAt: string): string {
  const stamp = exportedAt.replace(/[:.]/g, "-").replace(/Z$/, "Z");
  return `danetti-local-db-${stamp}.json`;
}
