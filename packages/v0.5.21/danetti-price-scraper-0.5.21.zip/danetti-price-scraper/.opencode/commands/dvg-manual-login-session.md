---
description: Start safe DVG headed manual-login bridge and parse one detail page in same live context.
agent: danetti-dvg-debugger
---

Goal: run DVG manual-login-only bridge without credentials in chat and without saved portal artifacts.

Load `danetti-supplier-safety` and `danetti-dvg-connector` from `.agents/skills` first.

Agent-executed workflow:

- OpenCode runs `npm.cmd run dvg:manual-login-session`.
- OpenCode starts headed Chromium.
- User enters credentials only in visible Chromium, never in chat.
- OpenCode continues in the same live Playwright context after manual landing is detected.
- Session is memory-only; process exit loses login state.

Required user prompt:

`A látható Chromium ablakban jelentkezz be kézzel DVG-be. Credentialt ne írd chatbe. Ha kész, szólj itt: kész.`

Rules:

- No credential print.
- No request body, headers, cookies, query strings or raw portal content in output.
- Stop on account lock, access denied, too many attempts or security warning.
- Smoke only: no supplier price snapshot implementation.

Safe output fields:

- `loginMode=manual_live_context`
- `status`
- `code`
- `finalPath`
- `loginLandingDetected`
- `detailFetchOk`
- `parsed.dvgArticle`
- `parsed.originalCode`
- `parsed.productName`
- `parsed.currentPrice`
- `parsed.crossedPrice`
- `parsed.currency`
- `parsed.unit`
- `warnings`
- `safetyFlags`
