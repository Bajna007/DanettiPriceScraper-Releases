---
description: Audit workflow bottlenecks and propose or apply tiny Agent OS tooling improvements.
agent: danetti-toolsmith
---

Use `docs/architecture/AI_CONTEXT.md` and `docs/architecture/CURRENT_ARCHITECTURE.md` as hard gates.

Allowed focus:

- Repeated manual command sequences.
- Ambiguous docs.
- Missing safety checklist.
- Missing command or runbook entry.
- Small PowerShell read-only diagnostic helper.

Allowed if project-local, workflow/tooling/docs only, no credentials/artifacts and validatable.

Output:

- Bottleneck.
- Implement/propose decision.
- Files changed or proposal.
- Validation.
