---
description: Run or list Danetti standard validation and forbidden staged-file checks.
agent: danetti-reviewer
---

Default: run Fast gate. Do not list validation commands as the primary next step.

Load `danetti-windows-runtime` from `.agents/skills` for the Windows command and runtime boundary.

Fast command:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/quality-gate.ps1 -Fast
```

Full command when requested:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/quality-gate.ps1 -Full
```

Standard Full validation:

- `npm.cmd run format`
- `npm.cmd run typecheck`
- `npm.cmd run test`
- `npm.cmd run build`
- `npm.cmd run db:check`
- `npm.cmd run local:web:doctor`
- `npm.cmd run credentials:check`

Always check:

- `git status --short`
- `git diff --check`
- Forbidden staged files, including `.env*`, credentials, sessions, cookies, `storageState`, raw HTML, screenshots, MHTML, HAR, trace.zip and `apps/dashboard/next-env.d.ts`.

Output:

- Pass/fail.
- Blocker list.
- Commands run.
- Safe next action.

Rules:

- Run Fast gate by default.
- Run Full gate when explicitly requested or task risk requires it.
- If API/Docker is down, report environment blocker, not code failure.
- Ask the user only for unavailable permission/UI/secret steps or explicit instruction-only requests.
