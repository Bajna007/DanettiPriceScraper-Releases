---
description: Run or guide safe DVG credential/detail test without printing credentials or saving artifacts.
agent: danetti-dvg-debugger
---

Goal: test DVG credential and detail fetch safely through local API.

Load `danetti-supplier-safety` and `danetti-dvg-connector` from `.agents/skills` first.

Agent-executed local workflow:

- Run the PowerShell helper/API test when local runtime is available.
- Do not give the helper command to the user as the primary next step.
- Ask only for missing UI credential entry, unavailable UI interaction, permission prompts, secrets or explicit instruction-only requests.

Argument:

- Optional `testArticle`; default `CS-A2200247`.

Steps:

1. Do not ask user to paste credentials.
2. If no supplier id is known, run `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/dvg-credential-test.ps1 -TestArticle <testArticle>` to list likely DVG credential items.
3. If supplier id is known, run `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/dvg-credential-test.ps1 -SupplierId <supplierId> -TestArticle <testArticle>`.
4. For visual debug, invoke `/dvg-visual-debug` behavior and start runtime with temporary env vars when explicitly requested.
5. Report only diagnostic fields.

Output fields:

- `status`
- `errorCode`
- `stage`
- `finalPath`
- `loginLandingDetected`
- `loginOk`
- `detailFetchOk`
- `parsed.currentPrice`
- `parsed.crossedPrice`
- `parsed.currency`
- `parsed.dvgArticle`
- `parsed.originalCode`
- `warnings`
- `submitStrategy`
- `submitEnabledAfterFill`
- `submitEnabledBeforeSubmit`
- `forensic.clickEventFired`
- `forensic.submitEventFired`
- `forensic.defaultPrevented`
- `forensic.postRequestHappened`
- `forensic.postRequestBlocked`
- `forensic.blockedScriptCount`
- `forensic.consoleErrorCount`
- `forensic.pageErrorCount`

Rules:

- No credentials in prompt, command or output.
