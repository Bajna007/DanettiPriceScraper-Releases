---
description: Read-only Danetti baseline audit and next recommended command.
agent: danetti-reviewer
---

Run read-only baseline only. Do not edit files. Do not hand baseline commands to the user as the primary next step.

Steps:

1. Run `git status --short`, `git branch --show-current`, `git log --oneline -5`.
2. Read root `package.json` scripts.
3. Check presence of `AGENTS.md`, `opencode.json`, `docs/architecture/AI_CONTEXT.md`, `docs/architecture/CURRENT_ARCHITECTURE.md`, `docs/runtime/**`, `docs/security/**`, `.opencode/**`, `scripts/doctor.ps1`, `scripts/quality-gate.ps1`.
4. Summarize current state, missing workflow pieces, commands run and next recommended action.

Rules:

- No credentials.
- No supplier portal access.
- No edits.
- Use `npm.cmd` in any suggested Windows command.
- Ask the user only when a check cannot be run safely by OpenCode.
