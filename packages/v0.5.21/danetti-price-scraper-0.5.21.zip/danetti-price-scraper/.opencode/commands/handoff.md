---
description: Produce a concise session handoff with branch, commit, changed files, validation and next step.
agent: danetti-reviewer
---

Produce a chat handoff only. Do not edit files unless the user explicitly asks.

Collect:

- Branch from `git branch --show-current`.
- Commit from `git rev-parse --short HEAD`.
- Changed files from `git status --short` and `git diff --name-only`.
- Validation commands run in this session.
- Known blockers.
- Recommended next step.

Rules:

- No secrets.
- No credentials.
- No raw supplier artifacts.
- Do not modify runtime code.
- If validation was not run, say so clearly.
