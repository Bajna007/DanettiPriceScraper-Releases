---
description: Audit Danetti Agent OS files, frontmatter, scripts and registry consistency.
agent: danetti-reviewer
---

Audit Agent OS only.

Check:

- `AGENTS.md`
- `opencode.json`
- `docs/architecture/*.md`
- `docs/runtime/*.md`
- `docs/security/*.md`
- `.opencode/commands/*.md` frontmatter
- `.opencode/agents/*.md` frontmatter
- `.agents/skills/*/SKILL.md` frontmatter and `agents/openai.yaml` metadata
- absence of duplicated project skills under `.opencode/skills` and `.codex/skills`
- `scripts/*.ps1`
- current runbook and command consistency

This command is read-only. Report proposed changes; use `/agent-os-fix` only after an explicit fix request.

Must not touch:

- Runtime code.
- DB schema/migrations.
- Connector/parser logic.
- Credentials/artifacts.
- Dependencies.

Report:

- Findings.
- Fixes made.
- Remaining risks.
- Validation run.
