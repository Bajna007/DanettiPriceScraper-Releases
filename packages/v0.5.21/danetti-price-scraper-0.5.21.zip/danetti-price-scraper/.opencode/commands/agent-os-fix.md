---
description: Apply explicitly requested Danetti Agent OS tooling or documentation fixes.
agent: danetti-toolsmith
---

Apply only Agent OS fixes explicitly requested by the user or selected from a prior `/agent-os-audit` report.

Stay within the toolsmith allowed paths. Preserve runtime behavior, inspect the diff, run `npm.cmd run agents:check`, and report every changed file plus validation evidence.

Do not commit or push unless explicitly requested.
