---
description: Run safe DVG manual-session batch pricing workflow from dashboard/API.
agent: danetti-dvg-debugger
---

Goal: use manual DVG login in the visible browser session, then read approved DVG detail pages for local dry-run pricing.

Load `danetti-supplier-safety` and `danetti-dvg-connector` from `.agents/skills` first.

Agent-executed workflow:

- OpenCode starts local app with `npm.cmd run local:web` when runtime is needed.
- Operator opens dashboard page `http://localhost:3000/operator/dvg`.
- Operator enters EUR/HUF, markup, VAT and candidate limits.
- API opens visible browser session and waits for manual DVG login.
- User enters DVG credentials only in the visible browser, never in chat.
- User clicks `Folytatás belépés után` in dashboard after DVG landing is visible.
- API reads DVG detail pages in same memory-only Playwright context with pacing.
- Dashboard polls run state and shows safe rows/events only.

API endpoints:

- `POST /dvg-products/manual-batch/start`
- `POST /dvg-products/manual-batch/:runId/continue-after-login`
- `GET /dvg-products/manual-batch/:runId`
- `POST /dvg-products/manual-batch/:runId/cancel`

Safe output fields:

- run status, totals and current item metadata
- event type/message/article/path only
- Woo SKU/name/local price fields
- DVG article/original code/product name
- parsed DVG price/currency/unit
- HUF pricing/profit calculations
- sanitized warnings only
