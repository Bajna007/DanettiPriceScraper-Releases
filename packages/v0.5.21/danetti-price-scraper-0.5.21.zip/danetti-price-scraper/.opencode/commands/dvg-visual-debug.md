---
description: Start or guide safe local DVG visual debug mode with headed Chromium, slowMo and sanitized console logs.
agent: danetti-dvg-debugger
---

Goal: enable local opt-in DVG visual debug without artifacts.

Load `danetti-supplier-safety`, `danetti-dvg-connector`, and `danetti-windows-runtime` from
`.agents/skills` first.

Agent-executed local workflow:

- When explicitly invoked, set temporary env vars and run `npm.cmd run local:web` when possible.
- Capture and summarize runtime logs, especially `[DVG visual]` lines.
- Do not only print these commands unless the user asks for instructions or OpenCode cannot safely run them.
- Stop and ask only for UI clicks, credential entry, permission prompts or other human-only actions.

PowerShell enable command OpenCode should run when possible:

```powershell
$env:DANETTI_VISUAL_BROWSER="true"
$env:DANETTI_VISUAL_SLOWMO_MS="300"
$env:DANETTI_VISUAL_DEBUG_LOG="true"
npm.cmd run local:web
```

Then use UI only when OpenCode cannot perform the interaction:

1. Beszallitok.
2. DVG De Vecchi.
3. Belepes tesztelese.

PowerShell disable commands OpenCode should run after diagnosis when it owns the started shell/session:

```powershell
Remove-Item Env:DANETTI_VISUAL_BROWSER -ErrorAction SilentlyContinue
Remove-Item Env:DANETTI_VISUAL_SLOWMO_MS -ErrorAction SilentlyContinue
Remove-Item Env:DANETTI_VISUAL_DEBUG_LOG -ErrorAction SilentlyContinue
```

Expected:

- Chromium window visible.
- Steps slowed by `DANETTI_VISUAL_SLOWMO_MS`.
- Console has `[DVG visual]` sanitized step log.
- Response keeps normal diagnostic fields.
