---
description: Run read-only Danetti runtime diagnostics for Docker, DB, API and dashboard readiness.
agent: danetti-runtime-diagnostician
---

Run runtime diagnosis without code changes. Do not give the user a command list as the primary next step.

Load `danetti-windows-runtime` from `.agents/skills` before diagnosis.

Steps:

1. Run `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/doctor.ps1`.
2. Run `npm.cmd run local:web:doctor` if local dependencies are installed.
3. Check Docker/Postgres/Redis/API/dashboard readiness from outputs.
4. Run additional safe read-only checks when needed.
5. Report commands run, blockers and smallest next safe action.

Rules:

- Do not edit files.
- Do not read `.env`.
- Do not print credentials.
- Do not run destructive Docker/git/filesystem commands.
- Use `npm.cmd`, not plain `npm`.
- Ask the user only for permission prompts, unavailable UI interaction, secrets or explicitly requested instructions.
