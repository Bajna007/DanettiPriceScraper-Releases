---
description: Diagnose an existing DVG credential-test JSON using the safe decision tree.
agent: danetti-dvg-debugger
---

Use a pasted or existing DVG credential-test JSON. Diagnose from fields only.

Load `danetti-supplier-safety` and `danetti-dvg-connector` from `.agents/skills` first.

Use current field semantics and decision tree from `danetti-dvg-connector`; keep this command as an execution/output adapter only.

Output:

- Diagnosis.
- Evidence fields used.
- Next safest check.
- Implementation plan only if user explicitly asks for code changes.

Rules:

- Do not request credentials.
- Do not save artifacts.
- Do not modify connector/parser/runtime code unless explicitly requested after diagnosis.
