---
description: Bootstrap the Danetti local web launcher flow safely on Windows.
agent: build
---

Bootstrap the Danetti local web runtime and desktop launcher flow in the current workspace.

Load `danetti-windows-runtime` from `.agents/skills` and follow it throughout this workflow.

Steps:

1. Confirm the workspace with `git status --short` and do not overwrite unrelated uncommitted work.
2. Read `AGENTS.md`, `docs/architecture/AI_CONTEXT.md`, `docs/architecture/CURRENT_ARCHITECTURE.md`, `README.md` and root `package.json`.
3. Check launcher scripts under `scripts/launcher/` and the local runtime scripts under `scripts/`.
4. Use `npm.cmd` for Windows commands.
5. Install dependencies only when needed with `npm.cmd install`.
6. Create or refresh shortcuts with `npm.cmd run launcher:install`.
7. Validate with `npm.cmd run local:web:doctor` and report blockers plus the smallest safe next action.

Rules:

- Do not read, create or print `.env*`, credential, session, cookie, browser profile, HAR, screenshot, trace, MHTML or DB dump files.
- Do not run Docker prune, Docker reset, volume deletion or database dump/delete commands.
- Keep WooCommerce read-only.
- Do not commit or push unless explicitly requested.
- Prefer `Danetti Javitas` / `npm.cmd run launcher:repair` for repeatable Docker/WSL recovery instead of machine restart advice.
