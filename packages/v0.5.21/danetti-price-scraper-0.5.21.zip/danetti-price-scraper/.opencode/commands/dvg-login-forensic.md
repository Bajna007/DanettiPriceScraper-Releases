---
description: Run or guide safe DVG login forensic diagnostics for click, submit, POST, script guard and preventDefault signals.
agent: danetti-dvg-debugger
---

Goal: diagnose DVG login submit path without credentials in chat and without saved portal artifacts.

Load `danetti-supplier-safety` and `danetti-dvg-connector` from `.agents/skills` first.

Agent-executed workflow:

- Prefer local API/helper execution when runtime is available.
- Use visual debug only when explicitly requested or when headed observation is needed.
- Ask user only for credential entry, UI clicks unavailable to OpenCode, permission prompts or secrets.

Steps:

1. Run baseline `git status --short` and confirm no unintended files are present.
2. If local runtime is available, run `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/dvg-credential-test.ps1 -TestArticle CS-A2200247` or same helper with known `-SupplierId`.
3. For preventDefault root-cause mode, add `-ForensicV3`; this runs one `press_sequentially_tab_blur` attempt and enables pass-through preventDefault instrumentation.
4. If headed observation is needed, invoke `/dvg-visual-debug` behavior, then collect sanitized `[DVG visual]` lines.
5. Report only response fields and sanitized visual log fields.

Forensic fields:

- `fillStrategy`
- `submitStrategy`
- `submitEnabledAfterFill`
- `submitEnabledBeforeSubmit`
- `forensic.clickEventFired`
- `forensic.submitEventFired`
- `forensic.defaultPrevented`
- `forensic.preventDefaultCalled`
- `forensic.preventDefaultEventType`
- `forensic.preventDefaultTargetTag`
- `forensic.preventDefaultTargetId`
- `forensic.preventDefaultStackSummary`
- `forensic.submitHandlerCount`
- `forensic.clickHandlerCount`
- `forensic.postRequestHappened`
- `forensic.postRequestBlocked`
- `forensic.loginPostPath`
- `forensic.loginPostStatus`
- `forensic.blockedRequestCount`
- `forensic.blockedScriptCount`
- `forensic.externalScriptHosts.length`
- `forensic.consoleErrorCount`
- `forensic.pageErrorCount`
- `forensic.formOnSubmitPresent`
- `forensic.buttonOnClickPresent`
- `forensic.hiddenFieldCount`
- `forensic.requiredFieldCount`
- `forensic.emptyRequiredFieldNamesSanitized`
- `forensic.captchaLikeElementPresent`
- `forensic.recaptchaLikeElementPresent`
- `forensic.cookieConsentVisible`
- `activeElementSummary`
- `finalPath`
- `loginLandingDetected`
- `errorCode`

Rules:

- No username/password in prompt, command or output.
- No headers, request body, cookies, query strings or raw page content in output.
