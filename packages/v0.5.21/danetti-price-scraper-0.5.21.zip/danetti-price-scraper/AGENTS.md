# DanettiPriceScraper Agent Rules

## Execution contract

- Finish the authorized result, reuse existing approval and honor narrower user scope. Resolve routine details; identify the exact rule when a real blocker needs user input.
- Read relevant context only. Keep a compact checkpoint for long work; historical documents are evidence rather than current instructions.
- Keep model/provider settings user-selected. Optional shared `instructions/models/gpt-6-astra.md` tunes Astra; this repository remains usable with other models.
- Use focused repository checks and stop retesting when sufficient evidence passes. Keep Actions disabled; distinguish local proof, enforced merge rules and actual delivery.

Default: terse technical communication. If user writes Hungarian, respond in Hungarian.

Read first for current project context:

- `docs/architecture/AI_CONTEXT.md`
- `docs/architecture/CURRENT_ARCHITECTURE.md`

Shared Codex/OpenCode skill contract:

- Keep portable project skills only under `.agents/skills/<name>/SKILL.md`; both clients discover
  this tree natively.
- Do not duplicate project skills under `.opencode/skills` or `.codex/skills`.
- Do not vendor shared user-level skills in this repository. `caveman` and
  `emil-design-eng` belong under `$HOME/.agents/skills`.
- `impeccable` is provider-specific. Invoke it by name and let Codex or
  OpenCode resolve its own global installation; never copy it into this repo.
- For every rendered frontend change, load `emil-design-eng` before planning
  or editing, then use `impeccable` for the final audit and responsive proof.
- Load `danetti-windows-runtime` for Windows launcher, Docker, API/dashboard, migration, health, or
  new-machine runtime work.
- Load `danetti-supplier-safety` for every supplier, credential, portal, mapping, snapshot, pacing,
  or WooCommerce-boundary task.
- Load `danetti-dvg-connector` alongside supplier safety for DVG login, detail parsing, mapping, or
  session diagnosis.
- Load `danetti-csv-import` for WooCommerce CSV and local catalog import work.
- Keep `.opencode/agents` and `.opencode/commands` as OpenCode-only adapters; their durable domain
  rules belong in the shared skills above.

Hard rules:

- Use `npm.cmd` on Windows PowerShell.
- Before commits: `git status --short`, inspect diff, run validation, stage explicit intended files only.
- Treat edits as local by default. Commit or push only on an explicit user request or while following the documented release workflow.

Validation by changed scope:

- Instruction-only changes: `npm.cmd run agents:check`, `npm.cmd run repo:check`, and `git diff --check`.
- Application changes: run the relevant checks below; database/runtime diagnostics apply only when those contracts change.

- `npm.cmd run format`
- `npm.cmd run typecheck`
- `npm.cmd run test`
- `npm.cmd run build`
- `npm.cmd run db:check`
- `npm.cmd run local:web:doctor`

Active packages:

- `apps/api`
- `apps/dashboard`
- `apps/worker` dry-run/placeholder only
- `packages/connectors`
- `packages/db`
- `packages/label-engine`
- `packages/shared`
