---
name: danetti-supplier-safety
description: Enforce Danetti supplier and WooCommerce safety. Use for B2B portals, connectors, Playwright, credentials, pacing, queues, retries, mapping suggestions, price snapshots, supplier evidence, or staging and committing supplier-related work.
---

# Danetti Supplier Safety

## Keep external systems read-only

- Never write WooCommerce prices, stock, products, orders, customers, carts, settings, or metadata.
- Never place supplier orders, carts, quotes, payments, account changes, or other commercial writes.
- Stop and request architecture review when a task crosses either boundary.

## Protect credentials and evidence

- Keep credentials in provider-owned login UI or the approved local credential store; never ask
  for passwords in chat or commit `.env`, cookies, sessions, storage state, HAR, MHTML, raw HTML,
  traces, or private screenshots.
- Prefer sanitized response fields over raw portal content for diagnosis.
- Stop on account lock, access denial, security warnings, or unexpected write-capable navigation.

## Pace and resume conservatively

- Default to at most six products per minute unless a stricter connector policy applies.
- Add delay and jitter; do not parallelize portal requests without explicit connector evidence.
- Preserve `queued`, `running`, `success`, `failed`, `skipped`, `interrupted`, and
  `safety_stopped` states so interrupted work resumes intentionally.
- Select connector strategy explicitly: `search_result`, `search_then_detail`, `direct_url`,
  `export_file`, or `network_response`.

## Enforce mapping and snapshot gates

- Treat saved supplier mappings as authoritative.
- Treat WooCommerce SKU prefixes as suggestions only.
- Require manual review for original-code-only or cross-reference matches.
- Block snapshots when trusted mapping, price, or currency is missing.

## Check the change boundary

- Stage explicit files only; never use `git add .`.
- Exclude `.env*`, credentials, sessions, supplier artifacts, and
  `apps/dashboard/next-env.d.ts` from commits.
- Run the relevant Danetti validation before recommending a commit.
