---
name: danetti-csv-import
description: >
  Danetti WooCommerce CSV import standard. Load for WooCommerce CSV, catalog
  import, SKU parsing, import validation, mapping suggestions, and local catalog
  reference tasks.
---

# Danetti CSV Import Skill

Use for WooCommerce CSV/import/catalog tasks only.

## Required Fields

Expected WooCommerce CSV fields:

- `ID`
- `Type`
- `SKU`
- `Name`
- `Published`
- `Regular price`
- `Sale price`
- `Categories`
- `In stock?` or `Stock status`
- `Parent`
- `Attribute N name` and `Attribute N value(s)`, where available

Strongly recommended:

- `Permalink`
- `Short description`
- `Tags`
- `Images`
- `Stock`
- `Weight`
- Relevant meta fields

## SKU Rules

- SKU is primary identity.
- Example SKU: `421944065151_SAE125`.
- A single `_` starts the internal suffix; `__` separates supplier article candidates.
- `supplierArticleCandidate` remains the first candidate for compatibility. Use `readWooSkuArticleCandidates` from `@danetti/shared` to read all candidates.
- In `1755603__8W17201_W051`, articles are `1755603` and `8W17201`; the final internal suffix is `W051`. In `8S29/1__SP053`, both parts are articles and the internal suffix is null.
- LF/DVG candidate selection is provider-specific and independent of candidate order. Saved mappings take precedence; ambiguous candidates require review. Exact supplier evidence is required before trusted mapping or price storage.

## Import Rules

- Missing SKU is skipped or rejected.
- Duplicate SKU is reported.
- Add-only import never updates existing products.
- Products missing from later CSVs are not deleted.
- Unknown columns are preserved in `rawRow`.
- No WooCommerce API writes.
- No WooCommerce API credentials for MVP import.

## Safety

- WooCommerce is read-only source data.
- CSV import stores local reference catalog only.
- Stop and request architecture review if task asks for WooCommerce price, stock, metadata, order, cart, customer, or settings writes.
