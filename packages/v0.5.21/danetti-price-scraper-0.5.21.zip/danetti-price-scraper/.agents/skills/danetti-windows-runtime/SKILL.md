---
name: danetti-windows-runtime
description: Diagnose, start, validate, or repair the DanettiPriceScraper Windows localhost runtime. Use for Node/npm.cmd, Docker Desktop, Postgres, Redis, Fastify API, Next.js dashboard, migrations, launcher shortcuts, health checks, and new-machine setup.
---

# Danetti Windows Runtime

## Establish the boundary

- Read `AGENTS.md`, `docs/architecture/AI_CONTEXT.md`, and
  `docs/architecture/CURRENT_ARCHITECTURE.md` before changing runtime behavior.
- Confirm the repository and inspect `git status --short`; preserve unrelated work.
- Keep the product web-only: the supported runtime is the localhost dashboard plus API, not
  Electron, AppShell, or an installer.

## Use the canonical commands

- Use `npm.cmd`, never plain `npm`, from Windows PowerShell.
- Install locked dependencies with `npm.cmd install` only when they are missing or explicitly
  need reconciliation.
- Diagnose with `npm.cmd run bootstrap:doctor`, `scripts/doctor.ps1`, and
  `npm.cmd run local:web:doctor` before attempting repair.
- Start normal operator use with `npm.cmd run local:web`; reserve `local:web:serve` for
  development because watch restarts interrupt supplier sessions.
- Validate changes with the gates in `AGENTS.md`; use `scripts/quality-gate.ps1 -Fast` for the
  focused gate and `-Full` for release-level evidence.

## Diagnose in order

1. Verify Node.js 20 or newer and `npm.cmd` availability.
2. Verify Docker CLI, daemon, Compose, Postgres, and Redis without pruning or deleting volumes.
3. Verify migrations and `npm.cmd run db:check`.
4. Verify API health, dashboard readiness, and the operator route.
5. Repair only the narrow failing layer; do not restart unrelated Docker workloads.

## Protect local state

- Do not read or create `.env` during diagnostics and never print credentials.
- Do not delete Docker volumes, databases, caches, or runtime state without explicit authority.
- Keep runtime errors shown to the operator actionable and Hungarian.
- Do not deploy production from this workflow.
