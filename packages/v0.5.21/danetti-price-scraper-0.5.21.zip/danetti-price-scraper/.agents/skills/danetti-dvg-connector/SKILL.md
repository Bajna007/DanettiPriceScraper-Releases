---
name: danetti-dvg-connector
description: Diagnose or change the Danetti DVG/De Vecchi connector safely. Use for DVG manual login, visible browser sessions, credential tests, product detail URLs, price parsing, article mapping, snapshots, retries, and connector-specific error codes.
---

# Danetti DVG Connector

Load `danetti-supplier-safety` alongside this skill for shared supplier, credential, pacing, and
snapshot rules.

## Preserve the session boundary

- Keep credentials in the visible local browser or approved local credential store; never request
  them in chat, log them, or save browser artifacts.
- Use one memory-only browser context from manual login through detail parsing. A process restart
  loses the session and must not trigger an automatic login loop.
- Stop on access denial, account lock, security warning, unexpected write flow, or repeated login
  failure.

## Use the DVG contract

- Login URL: `https://devecchigiuseppesrl.com/e-commerce/account/login.asp?`.
- Successful landing path: `/e-commerce/cerca.asp`.
- Detail path:
  `/e-commerce/welcome/ordini/dettagli.asp?codice-articolo={ARTICLE}`.
- Login form: `form#formLogin`; user field: `input#txtUser`; password field:
  `input#txtPw`; submit: `button[type=submit]`.
- Parse `currentPrice`, `crossedPrice`, `currency`, `unit`, `dvgArticle`, `originalCode`, and the
  sanitized product name.

## Diagnose from safe fields

- `/e-commerce/cerca.asp` with `loginLandingDetected=true`: login succeeded.
- `/e-commerce/account/login.asp`: credential, session, or login-flow problem.
- `dvg_price_not_found`: detail content or parser problem.
- `dvg_detail_redirected_to_login`: session/detail access problem.
- `dvg_test_article_missing`: test article or mapping problem.

## Enforce mapping and snapshot gates

- Treat a saved supplier mapping as primary.
- Accept an exact displayed DVG article only when it matches the expected article.
- Treat original-code-only matches as review candidates, never automatic mappings.
- Store no price snapshot unless mapping, price, and currency gates all pass.
- Keep connector code under `packages/connectors/src/connectors/dvg-devecchi` and shared browser
  safety under `packages/connectors/src/safety`.
