# Beszállítói árváltozások

Route: `/supplier-price-changes`. Header destination: **Árváltozások**.

## Surface purpose and incumbent world

Give the operator a durable DVG/LF price-change work list, precise latest-pair
comparison and inspectable transition history. Extend **Quiet Operator Cockpit**,
Operate mode, in [DESIGN.md](../../DESIGN.md), with compact text, pale working
surfaces, evergreen actions and textual statuses. This code-led extension uses
existing catalog controls and shared table toolbar; it introduces no global rules.

## Composition and behavior

View and inclusive date filters precede the pending-work/closure explanation.
**Árjavaslat vezérlőpult** groups supplier, direction and minimum-change controls
with permanently visible **Árszámítás beállításai**. Pricing settings stay
expanded. Preserve-profit and fixed-profit modes remain explicit; EUR/HUF, VAT,
rounding increment, direction and enabled state form five equal columns above
720px and stack on narrow screens. Controls stay readable at 812px and on phones.

**Teendők** is the initial default; the selected view is saved locally. Pending
current events persist until manual or proven CSV closure, including after an
unchanged measurement. **Legutóbbi két sikeres mérés** compares consecutive
successful observations and omits unchanged pairs. **Teljes előzmény** retains
all actual transitions, including A → B → A, closed and superseded changes.
Repeated unchanged observations do not invent transitions. Show first change
time and last successful check separately. Date filtering uses the first
change's Europe/Budapest day and includes both boundaries.

The status cell places **Lezárás** or **Újranyitás** below its text with spacing
and a divider. Closed current events remain available in full history. The same
**Oszlopok és nyomtatás** toolbar as Products and Article Changes selects
visible/exported columns. Export the full sorted filtered list before pagination
through CSV or A4/A3 landscape print/PDF with column bands or records. Preserve
EUR/Ft/% meanings, negative signs and unknown values.

Shared sheet layout expands a few columns proportionally to fill the container;
many columns retain meaningful widths and scrolling within the table. Products,
Article Changes and DVG/LF operator tables share this behavior.

## Evidence and lifecycle boundary

Freeze the own-price baseline. Prefer captured evidence from the previous
measurement; if historical evidence is unavailable, freeze the first-view price
and label **Áralap: első megtekintés** (`first_seen`). Later catalog edits must
not move the baseline or silently rewrite the recommendation.

Manual closure and CSV closure preserve history. Any imported own-price change
counts, including zero or a 0.01 HUF difference; it need not match the suggestion.
CSV closure requires a newer completed successful import, unique stable
WooCommerce identity, matching current SKU and price, and immutable numeric
imported-price proof. Older imports without proof cannot close retroactively.
Completed partial catalog imports close only the proven corrected identities;
other tasks remain open. Preview, failed, ambiguous and unproven imports do not close tasks.
Reopening requires a newer import; atomic updates prevent stale CSV proof from
replacing a newer review decision.

A direct catalog-price edit can show **Saját ár módosult** but does not itself
close an event. Closure requires CSV proof or the button. Supplier access and
review remain read-only; review decisions do not edit mappings, supplier price
snapshots, catalog prices or WooCommerce.

Shared supplier status contracts, labels and active/terminal helpers live in
`supplier-workflow.ts`; DVG/LF compatibility aliases remain. Operator tables omit
technical warning columns and LF autocomplete/main-source columns, while actual
safety checks and warning logic remain active.

## Implementation references

- [Page](../../apps/dashboard/app/supplier-price-changes/page.tsx) and
  [styles](../../apps/dashboard/app/globals.css).
- [Service](../../apps/api/src/modules/supplier-price-changes/supplier-price-changes.service.ts),
  [repository](../../apps/api/src/modules/supplier-price-changes/supplier-price-changes.repository.ts)
  and [routes](../../apps/api/src/modules/supplier-price-changes/supplier-price-changes.routes.ts).
- [Toolbar](../../apps/dashboard/src/components/CatalogTableToolbar.tsx),
  [sheet layout](../../apps/dashboard/src/components/SheetHeader.tsx),
  [export](../../apps/dashboard/src/products/price-changes-export.ts) and
  [workflow](../../packages/shared/src/supplier-workflow.ts).
- [Imported-price proof](../../packages/db/drizzle/0025_imported_price_proof.sql) and
  [procedure](../../docs/runtime/DVG_OPERATOR_RUNBOOK.md#shared-price-change-workflow).
