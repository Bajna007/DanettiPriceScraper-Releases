# Cikkszámváltozások

Route: `/article-changes`. Header destination: **Cikkszámváltozások**.

## Surface purpose

Let a local operator move from a changed DVG or LF article to an evidenced successor,
its current purchase cost and the resulting profit against the local catalog.
Keep unresolved relationships, unavailable products and missing pages legible
without implying that a successor or price has been accepted.

## Incumbent world

Extend the **Quiet Operator Cockpit**, Operate mode, in [DESIGN.md](../../DESIGN.md):
cool pale surfaces, evergreen actions, compact Segoe UI and restrained status
color with explicit text. This is an existing operator-surface extension; it
introduces no global palette, typography, component or identity rules. This is
a code-led extension of the incumbent shared table toolbar.

## Composition and behavior

The page leads with its title and links to **DVG operátor** and **LF operátor**. One working
panel explains successor verification, groups speed and start/stop/refresh
actions, explains profit%, and exposes live run state with checked/total progress
and the current supplier/article. One sequential queue checks DVG, then LF.
The default speed is **Nagyon gyors**. Active review
disables further starts; **Ellenőrzés leállítása** remains available.

The following results panel contains **Teendők** and **Lezártak**, a DVG/LF/both
provider filter, four separate status scopes, search, a priced-only checkbox and
a wide sheet table. Each row joins status and recovery action to
SKU/name, old and successor links, net purchase cost in EUR/HUF, local gross
selling price, net profit/profit% and the check time with its exchange rate.
Amounts carry units; unavailable values use a dash. Negative profit uses the
danger color and retains its minus sign. Status text explains missing,
unavailable, unpriced, failed and unresolved rows.

All 13 columns are selectable, sortable and resizable: supplier, status, SKU,
product, old/new article, EUR/Ft net purchase cost, gross selling price, profit%,
net profit, exchange rate and check time. The same **Oszlopok és nyomtatás**
toolbar as Products and Price Changes selects visible/exported columns. CSV
exports the full sorted filtered list with UTF-8 BOM, semicolons and decimal
commas. Print/PDF supports A4/A3 landscape, column bands with repeated
identifiers, or per-product records, retaining EUR/Ft/% meaning and unknowns.
Shared sheet layout expands a few visible columns proportionally to fill the
container and preserves horizontal scrolling for many columns.

Shared sorting and column resizing preserve the existing table interaction.
Filtering and sorting precede 50-row pagination. The bulk action targets the
entire filtered list, limited to 500 rows per start, rather than the visible page.

The working area is bounded at 1640px. At 640px and below, the introduction and
status scopes stack, action buttons fill a row and reach 44px height, and the
header wraps. The table retains column meaning in its horizontal scroll area;
article identifiers can wrap and links retain descriptive labels.

## Evidence and data boundary

Each supplier's latest operator run supplies changed, unavailable and missing
rows; saved review results persist separately. Follow at most three hops: DVG
requires an explicit same-origin New shop successor link; LF requires an
explicit primary-detail replacement or verified changed-code redirect from the
saved detail page. Alternatives and cross-references are not successors.
Price/profit require the exact expected article and its own positive net EUR
unit price at the smallest quantity; DVG uses the blue actual price. A restored
original is distinguished from an accepted successor. Cycles,
ambiguous relationships, wrong articles and unconfirmed or missing prices remain
unaccepted. A missing page does not establish discontinuation.

Use the centrally saved exchange rate at check start and the local catalog's
selling price for net profit and profit% on net cost. Reuse authentication in
the dedicated New Shop or LF profile; LF review never clears authentication
and normal LF operator login behavior is unchanged. Reviews share each
supplier's browser lease with normal runs. Persist review state without catalog
price, mapping or snapshot writes. Supplier access remains read-only. This
surface makes no Legacy-versus-New-shop comparison claim.

**Lezárás** and **Újranyitás** sit below status with spacing and a divider.
Closed rows remain available as history. Automatic CSV closure requires a
completed successful import, unique stable WooCommerce identity, matching
current/imported SKU, the verified new article token present and the old token
absent. Completed partial catalog imports close only the proven corrected
identities and preserve other reviews. Preview, failed, ambiguous or unproven
imports do not close reviews. Reopening blocks the same older import until a newer import
provides proof. Reconstructed CSV closure history keeps unknown price/profit
null. Interrupted review preserves results for targeted retry.

## Implementation references

- [Page](../../apps/dashboard/app/article-changes/page.tsx) and
  [responsive styles](../../apps/dashboard/app/article-changes/page.module.css).
- [Review service](../../apps/api/src/modules/dvg-article-changes/dvg-article-changes.service.ts)
  and [repository](../../apps/api/src/modules/dvg-article-changes/dvg-article-changes.repository.ts).
- [Shared statuses and fields](../../packages/shared/src/dvg-article-changes.ts).
- [Shared workflow contracts](../../packages/shared/src/supplier-workflow.ts),
  [coordinator](../../apps/api/src/modules/dvg-article-changes/article-changes.coordinator.ts),
  [LF adapter](../../apps/api/src/modules/dvg-article-changes/lf-article-changes.adapter.ts)
  and [CSV reconciliation](../../apps/api/src/modules/dvg-article-changes/article-changes.catalog-reconciliation.ts).
- [Operator procedure](../../docs/runtime/DVG_OPERATOR_RUNBOOK.md#article-changes-and-successor-review).

This brief records the implemented surface contract. Live cohort totals and
completion results belong to dated run evidence, not this reusable brief.
