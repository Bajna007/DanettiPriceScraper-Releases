## Summary

-

## Validation

- [ ] `npm.cmd run format`
- [ ] `npm.cmd run typecheck`
- [ ] `npm.cmd run test`
- [ ] `npm.cmd run build`
- [ ] `npm.cmd run db:check`
- [ ] `git diff --check`
- [ ] `npm.cmd run local:web:doctor` if local runtime check is relevant

## Manual Acceptance Checklist

- [ ] `npm.cmd run local:web` starts web-only runtime.
- [ ] `http://localhost:3000/operator/dvg` opens.
- [ ] DVG browser opens from operator page.
- [ ] Manual DVG login completed only in visible browser.
- [ ] Session check passed.
- [ ] One mapping dry-run passed.
- [ ] One gated snapshot saved.
- [ ] Selected micro-batch handles 1-5 mappings and has no select-all.
- [ ] Manual run history updates.
- [ ] JSON/CSV export checked.
- [ ] Retry-one checked for exactly one failed/blocked item.
- [ ] Reset profile checked.
- [ ] No sensitive data visible in UI/debug/export.

## Notes / Blockers

-
