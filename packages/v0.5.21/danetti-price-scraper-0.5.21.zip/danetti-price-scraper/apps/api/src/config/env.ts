import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { config } from "dotenv";

const localDefaults: Record<string, string> = {
  API_PORT: "4000",
  DATABASE_URL: "postgresql://danetti:danetti_dev_password@localhost:5432/danetti_price_monitor",
  REDIS_URL: "redis://localhost:6379",
  RUN_WORKER: "false",
  SUPPLIER_CHECK_RATE_LIMIT_PER_MINUTE: "6",
};

export function loadLocalEnv(): void {
  const envPath = findUp(".env", process.env.INIT_CWD ?? process.cwd());
  if (envPath) {
    config({ path: envPath });
  }

  if (process.env.NODE_ENV === "production") {
    return;
  }

  for (const [key, value] of Object.entries(localDefaults)) {
    process.env[key] ??= value;
  }
}

function findUp(filename: string, startDirectory: string): string | null {
  let current = resolve(startDirectory);

  while (true) {
    const candidate = resolve(current, filename);
    if (existsSync(candidate)) {
      return candidate;
    }

    const parent = dirname(current);
    if (parent === current) {
      return null;
    }

    current = parent;
  }
}
