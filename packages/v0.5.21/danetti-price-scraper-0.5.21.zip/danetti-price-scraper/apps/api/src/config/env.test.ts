import assert from "node:assert/strict";
import { loadLocalEnv } from "./env.js";

const originalEnv = { ...process.env };

delete process.env.DATABASE_URL;
delete process.env.REDIS_URL;
delete process.env.RUN_WORKER;
process.env.NODE_ENV = "development";

loadLocalEnv();

assert.equal(
  process.env.DATABASE_URL,
  "postgresql://danetti:danetti_dev_password@localhost:5432/danetti_price_monitor"
);
assert.equal(process.env.REDIS_URL, "redis://localhost:6379");
assert.equal(process.env.RUN_WORKER, "false");

for (const key of Object.keys(process.env)) {
  if (!(key in originalEnv)) {
    delete process.env[key];
  }
}

Object.assign(process.env, originalEnv);

console.log("API local env defaults tests passed");
