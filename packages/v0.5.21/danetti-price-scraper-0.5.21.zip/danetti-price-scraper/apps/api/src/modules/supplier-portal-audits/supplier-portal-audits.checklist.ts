import type { AuditCheckStatus } from "./supplier-portal-audits.types.js";

export interface DefaultPortalAuditCheck {
  checkKey: string;
  label: string;
  requiredForApproval: boolean;
}

export const DEFAULT_PORTAL_AUDIT_CHECKS: DefaultPortalAuditCheck[] = [
  { checkKey: "login_flow_documented", label: "Login flow documented", requiredForApproval: true },
  {
    checkKey: "two_factor_or_captcha_documented",
    label: "2FA/CAPTCHA behavior documented",
    requiredForApproval: true,
  },
  {
    checkKey: "account_lock_risk_documented",
    label: "Account lock risk documented",
    requiredForApproval: true,
  },
  {
    checkKey: "search_flow_documented",
    label: "Search flow documented",
    requiredForApproval: true,
  },
  {
    checkKey: "sku_exact_match_confirmed",
    label: "SKU exact match confirmed",
    requiredForApproval: true,
  },
  {
    checkKey: "result_page_type_confirmed",
    label: "Result page type confirmed",
    requiredForApproval: true,
  },
  {
    checkKey: "price_location_documented",
    label: "Price location documented",
    requiredForApproval: true,
  },
  {
    checkKey: "stock_location_documented",
    label: "Stock location documented",
    requiredForApproval: true,
  },
  {
    checkKey: "cart_indicator_checked",
    label: "Cart indicator checked",
    requiredForApproval: true,
  },
  {
    checkKey: "dangerous_url_patterns_documented",
    label: "Dangerous URL patterns documented",
    requiredForApproval: true,
  },
  {
    checkKey: "allowed_url_patterns_documented",
    label: "Allowed URL patterns documented",
    requiredForApproval: true,
  },
  {
    checkKey: "allowed_domains_documented",
    label: "Allowed domains documented",
    requiredForApproval: true,
  },
  {
    checkKey: "allowed_methods_documented",
    label: "Allowed methods documented",
    requiredForApproval: true,
  },
  { checkKey: "post_methods_reviewed", label: "POST methods reviewed", requiredForApproval: true },
  { checkKey: "rate_limit_defined", label: "Rate limit defined", requiredForApproval: true },
  {
    checkKey: "terms_or_business_approval_reviewed",
    label: "Terms/business approval reviewed",
    requiredForApproval: true,
  },
  { checkKey: "no_credentials_stored", label: "No credentials stored", requiredForApproval: true },
  {
    checkKey: "no_sensitive_evidence_stored",
    label: "No sensitive evidence stored",
    requiredForApproval: true,
  },
  {
    checkKey: "connector_strategy_recommended",
    label: "Connector strategy recommended",
    requiredForApproval: true,
  },
];

export const APPROVAL_PASSING_CHECK_STATUSES = new Set<AuditCheckStatus>([
  "pass",
  "not_applicable",
]);
