import { DVG_DETAIL_BASE_URL, type DvgMappingReviewOutcome } from "@danetti/connectors";
import type { NewSupplierPriceSnapshot, SupplierMapping, SupplierPriceSnapshot } from "@danetti/db";
import type {
  SupplierSnapshotListFilters,
  SupplierSnapshotsRepositoryLike,
} from "./supplier-snapshots.repository.js";

export interface SupplierSnapshotSummary {
  id: string;
  supplierId: string;
  supplierMappingId: string | null;
  catalogProductId: string | null;
  supplierArticleNumber: string;
  supplierProductName: string | null;
  priceNetEur: number | null;
  priceGrossEur: number | null;
  currency: string;
  stockStatus: string;
  availabilityText: string | null;
  matchConfidence: string;
  resultUrl: string | null;
  observedAt: string;
  createdAt: string;
}

export interface PersistSupplierPriceSnapshotInput {
  saveSnapshot: boolean;
  supplierId: string;
  supplierMappingId: string | null;
  catalogProductId: string | null;
  supplierArticleNumber: string;
  supplierProductName: string | null;
  priceNetEur: number | null;
  priceGrossEur?: number | null;
  currency: string | null;
  stockStatus: string;
  availabilityText: string | null;
  mappingReviewOutcome: DvgMappingReviewOutcome;
  snapshotGateAllowed: boolean;
  blockingSafetyFlags: string[];
  resultUrl: string | null;
  observedAt: Date;
}

export interface PersistSupplierPriceSnapshotResult {
  snapshotId: string;
  observedAt: string;
  snapshot: SupplierSnapshotSummary;
}

export class SupplierSnapshotValidationError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus = 400
  ) {
    super(message);
    this.name = "SupplierSnapshotValidationError";
  }
}

export class SupplierSnapshotDatabaseError extends Error {
  constructor(message = "Database unavailable") {
    super(message);
    this.name = "SupplierSnapshotDatabaseError";
  }
}

export async function persistSupplierPriceSnapshot(input: {
  repository: SupplierSnapshotsRepositoryLike;
  data: PersistSupplierPriceSnapshotInput;
}): Promise<PersistSupplierPriceSnapshotResult> {
  const data = input.data;
  if (!data.saveSnapshot) {
    throw new SupplierSnapshotValidationError(
      "snapshot_save_not_requested",
      "Snapshot save was not requested"
    );
  }
  if (!data.supplierMappingId) {
    throw new SupplierSnapshotValidationError(
      "supplier_mapping_required",
      "Supplier mapping is required for snapshot persistence"
    );
  }

  validateUuid(data.supplierId, "supplierId");
  validateUuid(data.supplierMappingId, "supplierMappingId");
  if (data.catalogProductId) validateUuid(data.catalogProductId, "catalogProductId");

  const mapping = await input.repository.getMappingById(data.supplierMappingId);
  const validMapping = assertMappingCanPersist({ mapping, data });
  assertSnapshotGateCanPersist(data);
  const priceNetEur = formatMoney(data.priceNetEur);
  const currency = data.currency ?? "EUR";

  const insert: NewSupplierPriceSnapshot = {
    supplierId: data.supplierId,
    supplierMappingId: data.supplierMappingId,
    catalogProductId: validMapping.catalogProductId,
    crawlerRunItemId: null,
    supplierArticleNumber: data.supplierArticleNumber,
    supplierProductName: data.supplierProductName,
    priceNetEur,
    priceGrossEur: data.priceGrossEur === null ? null : formatOptionalMoney(data.priceGrossEur),
    currency,
    stockStatus: normalizeStockStatus(data.stockStatus),
    availabilityText: data.availabilityText,
    matchConfidence: "exact",
    resultUrl: data.resultUrl,
    observedAt: data.observedAt,
    evidenceArtifactId: null,
  };

  const snapshot = await input.repository.insertSnapshot(insert);
  const summary = summarizeSnapshot(snapshot);
  return { snapshotId: summary.id, observedAt: summary.observedAt, snapshot: summary };
}

export function validateSupplierSnapshotListQuery(query: unknown): SupplierSnapshotListFilters {
  const input = isRecord(query) ? query : {};
  return {
    supplierId: optionalUuid(input.supplierId, "supplierId"),
    supplierMappingId: optionalUuid(input.supplierMappingId, "supplierMappingId"),
    catalogProductId: optionalUuid(input.catalogProductId, "catalogProductId"),
    supplierArticleNumber: optionalString(input.supplierArticleNumber, "supplierArticleNumber"),
    limit: boundedInteger(input.limit, 50, 1, 200, "limit"),
    offset: boundedInteger(input.offset, 0, 0, Number.MAX_SAFE_INTEGER, "offset"),
  };
}

export function validateSnapshotIdParam(value: unknown): string {
  if (typeof value !== "string") {
    throw new SupplierSnapshotValidationError("invalid_uuid", "id must be a UUID");
  }
  validateUuid(value, "id");
  return value;
}

export function summarizeSnapshot(snapshot: SupplierPriceSnapshot): SupplierSnapshotSummary {
  return {
    id: snapshot.id,
    supplierId: snapshot.supplierId,
    supplierMappingId: snapshot.supplierMappingId,
    catalogProductId: snapshot.catalogProductId,
    supplierArticleNumber: snapshot.supplierArticleNumber,
    supplierProductName: snapshot.supplierProductName,
    priceNetEur: numberOrNull(snapshot.priceNetEur),
    priceGrossEur: numberOrNull(snapshot.priceGrossEur),
    currency: snapshot.currency,
    stockStatus: snapshot.stockStatus,
    availabilityText: snapshot.availabilityText,
    matchConfidence: snapshot.matchConfidence,
    resultUrl: snapshot.resultUrl,
    observedAt: snapshot.observedAt.toISOString(),
    createdAt: snapshot.createdAt.toISOString(),
  };
}

function assertMappingCanPersist(input: {
  mapping: SupplierMapping | null;
  data: PersistSupplierPriceSnapshotInput;
}): SupplierMapping {
  const { mapping, data } = input;
  if (!mapping) {
    throw new SupplierSnapshotValidationError(
      "mapping_not_found",
      "Supplier mapping not found",
      404
    );
  }
  if (!mapping.enabled) {
    throw new SupplierSnapshotValidationError("mapping_disabled", "Supplier mapping is disabled");
  }
  if (mapping.supplierId !== data.supplierId) {
    throw new SupplierSnapshotValidationError(
      "mapping_supplier_mismatch",
      "Supplier mapping does not belong to requested supplier",
      403
    );
  }
  if (data.catalogProductId && mapping.catalogProductId !== data.catalogProductId) {
    throw new SupplierSnapshotValidationError(
      "mapping_catalog_product_mismatch",
      "Supplier mapping does not belong to requested catalog product"
    );
  }
  if (mapping.supplierArticleNumber !== data.supplierArticleNumber) {
    throw new SupplierSnapshotValidationError(
      "mapping_article_mismatch",
      "Supplier mapping article does not match parsed request"
    );
  }
  return mapping;
}

function assertSnapshotGateCanPersist(data: PersistSupplierPriceSnapshotInput): void {
  if (!data.snapshotGateAllowed) {
    throw new SupplierSnapshotValidationError(
      "snapshot_gate_blocked",
      "Snapshot gate blocked save"
    );
  }
  if (
    data.mappingReviewOutcome !== "trusted_exact_mapping" &&
    data.mappingReviewOutcome !== "trusted_saved_mapping"
  ) {
    throw new SupplierSnapshotValidationError(
      "mapping_review_required",
      "Trusted mapping review is required"
    );
  }
  if (!Number.isFinite(data.priceNetEur)) {
    throw new SupplierSnapshotValidationError("invalid_price", "Current supplier price is invalid");
  }
  if (data.currency !== "EUR") {
    throw new SupplierSnapshotValidationError("currency_not_eur", "Only EUR snapshots are allowed");
  }
  if (data.blockingSafetyFlags.length > 0) {
    throw new SupplierSnapshotValidationError(
      "blocking_safety_flag",
      "Blocking safety flags prevent snapshot persistence"
    );
  }
  if (!data.resultUrl || !isAllowedDvgDetailUrl(data.resultUrl)) {
    throw new SupplierSnapshotValidationError("invalid_result_url", "Result URL is not allowed");
  }
}

function isAllowedDvgDetailUrl(value: string): boolean {
  try {
    const url = new URL(value);
    const expected = new URL(DVG_DETAIL_BASE_URL);
    return (
      url.protocol === expected.protocol &&
      url.hostname === expected.hostname &&
      url.port === expected.port &&
      url.username === "" &&
      url.password === "" &&
      url.pathname === expected.pathname &&
      url.hash === "" &&
      url.searchParams.has("codice-articolo") &&
      Array.from(url.searchParams.keys()).length === 1
    );
  } catch {
    return false;
  }
}

function formatMoney(value: number | null): string {
  if (value === null || !Number.isFinite(value)) {
    throw new SupplierSnapshotValidationError("invalid_price", "Current supplier price is invalid");
  }
  return value.toFixed(2);
}

function formatOptionalMoney(value: number | null | undefined): string | null {
  if (value === undefined || value === null) return null;
  if (!Number.isFinite(value)) {
    throw new SupplierSnapshotValidationError("invalid_price", "Gross supplier price is invalid");
  }
  return value.toFixed(2);
}

function normalizeStockStatus(
  value: string
): "in_stock" | "limited" | "out_of_stock" | "backorder" | "unknown" {
  if (
    value === "in_stock" ||
    value === "limited" ||
    value === "out_of_stock" ||
    value === "backorder" ||
    value === "unknown"
  ) {
    return value;
  }
  return "unknown";
}

function numberOrNull(value: string | number | null): number | null {
  if (value === null) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function optionalUuid(value: unknown, field: string): string | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  if (typeof value !== "string") {
    throw new SupplierSnapshotValidationError("invalid_query", `${field} must be a UUID`);
  }
  validateUuid(value, field);
  return value;
}

function optionalString(value: unknown, field: string): string | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  if (typeof value !== "string") {
    throw new SupplierSnapshotValidationError("invalid_query", `${field} must be a string`);
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : undefined;
}

function boundedInteger(
  value: unknown,
  defaultValue: number,
  min: number,
  max: number,
  field: string
): number {
  if (value === undefined || value === null || value === "") return defaultValue;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new SupplierSnapshotValidationError(
      "invalid_query",
      `${field} must be an integer between ${min} and ${max}`
    );
  }
  return parsed;
}

export function validateUuid(value: string, field: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new SupplierSnapshotValidationError("invalid_uuid", `${field} must be a UUID`);
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
