const DEFAULT_MAX_BYTES = 10 * 1024 * 1024;

export const CSV_IMPORT_MAX_BYTES = readPositiveIntegerEnv(
  "CSV_IMPORT_MAX_BYTES",
  DEFAULT_MAX_BYTES
);
export const CSV_IMPORT_SAMPLE_ROWS = 50;
export const DEFAULT_LIST_LIMIT = 50;
export const MAX_LIST_LIMIT = 200;
export const DEFAULT_IMPORT_ROW_LIMIT = 100;
export const MAX_IMPORT_ROW_LIMIT = 500;

function readPositiveIntegerEnv(name: string, fallback: number): number {
  const value = process.env[name];

  if (value === undefined || value.trim().length === 0) {
    return fallback;
  }

  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}
