export type RuntimeOverallStatus = "ok" | "degraded" | "error";
export type RuntimeDependencyStatus = "ok" | "missing_config" | "unavailable";

export interface RuntimeServiceHealth {
  status: "ok";
}

export interface RuntimeDependencyHealth {
  status: RuntimeDependencyStatus;
  message: string;
}

export interface RuntimeWorkerHealth {
  status: "unknown" | "not_checked";
  message: string;
}

export interface RuntimeLauncherHealth {
  runId: string | null;
}

export interface RuntimeHealthResponse {
  status: RuntimeOverallStatus;
  api: RuntimeServiceHealth;
  database: RuntimeDependencyHealth;
  redis: RuntimeDependencyHealth;
  worker: RuntimeWorkerHealth;
  launcher: RuntimeLauncherHealth;
}
