const owners = new Map<string, string>();

export function acquireDvgSession(runId: string): boolean {
  return acquireSupplierSession("dvg", runId);
}

export function releaseDvgSession(runId: string): void {
  releaseSupplierSession("dvg", runId);
}

export function acquireSupplierSession(supplier: string, runId: string): boolean {
  if (owners.has(supplier)) return false;
  owners.set(supplier, runId);
  return true;
}
export function releaseSupplierSession(supplier: string, runId: string): void {
  if (owners.get(supplier) === runId) owners.delete(supplier);
}
