import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type {
  NewSupplier,
  NewSupplierCheckSettings,
  Supplier,
  SupplierCheckSettings,
} from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import { SuppliersRepository } from "./suppliers.repository.js";
import { SupplierDatabaseError, SupplierValidationError } from "./suppliers.types.js";
import {
  assertValidSupplierCheckSettingsMerge,
  validateCreateSupplierInput,
  validateUpdateSupplierCheckSettingsInput,
  validateUpdateSupplierInput,
} from "./suppliers.service.js";

interface SupplierRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  repository?: SupplierRepositoryLike;
}

interface SupplierRepositoryLike {
  list(input: { limit: number; offset: number }): Promise<Supplier[]>;
  getById(id: string): Promise<Supplier | null>;
  create(input: NewSupplier): Promise<Supplier>;
  update(id: string, input: Partial<NewSupplier>): Promise<Supplier | null>;
  getOrCreateCheckSettingsBySupplierId(supplierId: string): Promise<SupplierCheckSettings>;
  updateCheckSettings(
    supplierId: string,
    input: Partial<NewSupplierCheckSettings>
  ): Promise<SupplierCheckSettings | null>;
}

interface ListQuery {
  limit?: string;
  offset?: string;
}

interface IdParams {
  id: string;
}

export async function registerSupplierRoutes(
  server: FastifyInstance,
  options: SupplierRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getRepository(): SupplierRepositoryLike {
    if (options.repository) return options.repository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new SuppliersRepository(dbClient.db);
    } catch (error) {
      throw new SupplierDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/suppliers", async (request, reply) => {
    try {
      const query = request.query as ListQuery;
      const limit = parseBoundedInteger(query.limit, 50, 200, "limit");
      const offset = parseBoundedInteger(query.offset, 0, Number.MAX_SAFE_INTEGER, "offset");
      const items = await getRepository().list({ limit, offset });
      return { items, limit, offset };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/suppliers", async (request, reply) => {
    try {
      const input = validateCreateSupplierInput(request.body);
      const supplier = await createSupplierOrThrow(getRepository(), input);
      return reply.code(201).send(supplier);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/suppliers/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const supplier = await getRepository().getById(params.id);
      if (supplier === null)
        return reply
          .code(404)
          .send({ error: { code: "not_found", message: "Supplier not found" } });
      return supplier;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.patch("/suppliers/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const input = validateUpdateSupplierInput(request.body);
      const supplier = await getRepository().update(params.id, input);
      if (supplier === null)
        return reply
          .code(404)
          .send({ error: { code: "not_found", message: "Supplier not found" } });
      return supplier;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/suppliers/:id/check-settings", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const repository = getRepository();
      const supplier = await repository.getById(params.id);
      if (supplier === null) {
        return reply
          .code(404)
          .send({ error: { code: "not_found", message: "Supplier not found" } });
      }

      return await repository.getOrCreateCheckSettingsBySupplierId(params.id);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.patch("/suppliers/:id/check-settings", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const repository = getRepository();
      const supplier = await repository.getById(params.id);
      if (supplier === null) {
        return reply
          .code(404)
          .send({ error: { code: "not_found", message: "Supplier not found" } });
      }

      const current = await repository.getOrCreateCheckSettingsBySupplierId(params.id);
      const input = validateUpdateSupplierCheckSettingsInput(request.body);
      assertValidSupplierCheckSettingsMerge(current, input);
      const settings = await repository.updateCheckSettings(params.id, input);
      if (settings === null) {
        return reply
          .code(404)
          .send({ error: { code: "not_found", message: "Supplier check settings not found" } });
      }

      return settings;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

async function createSupplierOrThrow(
  repository: SupplierRepositoryLike,
  input: NewSupplier
): Promise<Supplier> {
  try {
    return await repository.create(input);
  } catch (error) {
    if (isDuplicateSupplierCodeError(error)) {
      throw new SupplierValidationError(
        "duplicate_supplier_code",
        `Supplier code already exists: ${input.code}`,
        409
      );
    }
    throw error;
  }
}

function isDuplicateSupplierCodeError(error: unknown): boolean {
  if (isDuplicateSupplierCodeErrorRecord(error)) return true;
  if (error !== null && typeof error === "object" && "cause" in error) {
    return isDuplicateSupplierCodeErrorRecord((error as { cause?: unknown }).cause);
  }
  return false;
}

function isDuplicateSupplierCodeErrorRecord(error: unknown): boolean {
  if (error === null || typeof error !== "object") return false;
  const record = error as Record<string, unknown>;
  const code = typeof record.code === "string" ? record.code : "";
  const constraint = typeof record.constraint === "string" ? record.constraint : "";
  const message = error instanceof Error ? error.message : "";
  return (
    code === "23505" ||
    constraint === "suppliers_code_unique" ||
    /duplicate key value|unique constraint|suppliers_code_unique/i.test(message)
  );
}

function parseBoundedInteger(
  value: string | undefined,
  defaultValue: number,
  maxValue: number,
  field: string
): number {
  if (value === undefined) return defaultValue;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0 || parsed > maxValue) {
    throw new SupplierValidationError(
      "invalid_query",
      `${field} must be an integer between 0 and ${maxValue}`
    );
  }
  return parsed;
}

function validateUuid(value: string, field: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new SupplierValidationError("invalid_uuid", `${field} must be a UUID`);
  }
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof SupplierValidationError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  if (error instanceof SupplierDatabaseError) {
    return reply
      .code(503)
      .send({ error: { code: "database_unavailable", message: error.message } });
  }
  return reply
    .code(500)
    .send({ error: { code: "internal_error", message: "Unexpected supplier API error" } });
}
