import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import { SupplierMappingsRepository } from "../supplier-mappings/supplier-mappings.repository.js";
import { createSupplierCheckQueueClient } from "../../queue/supplier-check.queue.js";
import { CheckQueueError, CheckValidationError } from "./checks.types.js";
import {
  buildDryRunMappingJob,
  buildDryRunSupplierJob,
  validateDryRunRequestBody,
  validateUuid,
} from "./checks.service.js";

interface CheckRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
}

interface IdParams {
  id: string;
}

export async function registerCheckRoutes(
  server: FastifyInstance,
  options: CheckRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;
  let queueClient: ReturnType<typeof createSupplierCheckQueueClient> | null = null;

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) await dbClient.close();
    if (queueClient !== null) await queueClient.close();
  });

  function getMappingRepository(): SupplierMappingsRepository {
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new SupplierMappingsRepository(dbClient.db);
    } catch (error) {
      throw new CheckQueueError(error instanceof Error ? error.message : "Database unavailable");
    }
  }

  function getQueueClient() {
    queueClient ??= createSupplierCheckQueueClient();
    return queueClient;
  }

  server.post("/checks/dry-run/mapping/:id", async (request, reply) => {
    try {
      validateDryRunRequestBody(request.body);
      const params = request.params as IdParams;
      validateUuid(params.id, "mappingId");
      const mapping = await getMappingRepository().getById(params.id);
      if (mapping === null) {
        return reply.code(404).send({ error: { code: "not_found", message: "Mapping not found" } });
      }
      const job = await getQueueClient().queue.add(
        "dry_run_mapping_check",
        buildDryRunMappingJob(mapping),
        {
          removeOnComplete: 100,
          removeOnFail: 100,
        }
      );
      return reply.code(202).send({ jobId: job.id, status: "queued" });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/checks/dry-run/supplier/:id", async (request, reply) => {
    try {
      validateDryRunRequestBody(request.body);
      const params = request.params as IdParams;
      const job = await getQueueClient().queue.add(
        "dry_run_supplier_check",
        buildDryRunSupplierJob(params.id),
        {
          removeOnComplete: 100,
          removeOnFail: 100,
        }
      );
      return reply.code(202).send({ jobId: job.id, status: "queued" });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/checks/jobs/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      const job = await getQueueClient().queue.getJob(params.id);
      if (job === undefined)
        return reply.code(404).send({ error: { code: "not_found", message: "Job not found" } });
      return {
        id: job.id,
        name: job.name,
        state: await job.getState(),
        data: job.data,
        returnvalue: job.returnvalue,
        failedReason: job.failedReason,
      };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof CheckValidationError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  return reply.code(503).send({
    error: {
      code: "queue_unavailable",
      message: error instanceof Error ? error.message : "Supplier check queue unavailable",
    },
  });
}
