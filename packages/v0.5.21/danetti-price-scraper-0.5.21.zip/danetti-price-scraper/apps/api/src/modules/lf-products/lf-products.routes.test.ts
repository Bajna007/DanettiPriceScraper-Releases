import assert from "node:assert/strict";
import type {
  LfManualBatchCandidate,
  LfManualBatchRow,
  LfManualBatchSettings,
  LfManualBatchState,
} from "@danetti/connectors";
import Fastify from "fastify";
import type { LfExactAutoPairCandidate, LfOperatorPreferences } from "./lf-products.repository.js";
import { registerLfProductsRoutes } from "./lf-products.routes.js";

const exactAutoPairCandidate: LfExactAutoPairCandidate = {
  catalogProductId: "11111111-1111-4111-8111-111111111111",
  wooSku: "5067364_UN303",
  wooName: "TEST LF PRODUCT",
  currentPrice: null,
  regularPrice: null,
  salePrice: null,
  supplierId: "22222222-2222-4222-8222-222222222222",
  supplierMappingId: null,
  supplierArticleNumber: "5067364",
  candidateSource: "suggested_supplier_article",
  matchConfidence: "suggested_supplier_article",
  existingLfMappingId: null,
  existingLfSupplierArticleNumber: null,
  existingLfDirectUrl: null,
};
const manualCandidate: LfManualBatchCandidate = {
  catalogProductId: "44444444-4444-4444-8444-444444444444",
  wooSku: "LF-PRICE-TEST",
  wooName: "TEST LF PRICE PRODUCT",
  currentPrice: "10000",
  regularPrice: "12000",
  salePrice: null,
  supplierId: exactAutoPairCandidate.supplierId,
  supplierMappingId: "55555555-5555-4555-8555-555555555555",
  supplierArticleNumber: "5072594",
  candidateSource: "saved_mapping",
  matchConfidence: "saved_mapping",
};
const exactAutoPairWrites: Array<{ dryRun: boolean; directUrl: string }> = [];
const capturedSettings: LfManualBatchSettings[] = [];
const capturedProgressRows: Array<{ row: LfManualBatchRow; runId: string; globalIndex: number }> =
  [];
const persistedOperatorRunStates: LfManualBatchState[] = [];
let savedPreferences: LfOperatorPreferences | null = null;
let savedOperatorRunState: LfManualBatchState | null = null;
let runnerMode: "success" | "throw_after_row" | "price_success" = "success";
const server = Fastify({ logger: false });
await registerLfProductsRoutes(server, {
  env: { NODE_ENV: "test" },
  repository: {
    listCandidates: async (settings) => {
      capturedSettings.push(settings);
      return settings.onlyMappedLf === false ? [exactAutoPairCandidate] : [manualCandidate];
    },
    saveCatalogProductLfRunRow: async (row, input) => {
      capturedProgressRows.push({ row, runId: input.runId, globalIndex: input.globalIndex });
      return {
        progressSaved: true,
        pricingSaved:
          input.settings.dryRun === false &&
          input.settings.allowSnapshotWrite === true &&
          row.status === "ok" &&
          row.supplierMappingId !== null,
      };
    },
    getLatestLfRunProgress: async () => {
      const latest = capturedProgressRows.at(-1);
      if (!latest) return null;
      return {
        runId: latest.runId,
        checked: capturedProgressRows.length,
        ok: capturedProgressRows.filter((entry) => entry.row.status === "ok").length,
        failed: capturedProgressRows.filter((entry) => entry.row.status !== "ok").length,
        skipped: 0,
        safetyStopped: 0,
        nextOffset: latest.globalIndex,
        updatedAt: "2026-06-02T10:00:00.000Z",
      };
    },
    saveLfOperatorRunState: async (state) => {
      savedOperatorRunState = state;
      persistedOperatorRunStates.push(state);
    },
    getLatestLfOperatorRunState: async () => savedOperatorRunState,
    saveLfOperatorPreferences: async (preferences) => {
      savedPreferences = preferences;
    },
    getLfOperatorPreferences: async () => savedPreferences,
    listExactAutoPairCandidates: async (input) => ({
      supplierId: exactAutoPairCandidate.supplierId,
      totalCandidates: 1,
      skippedDvgMappedCount: 2,
      skippedNotLfCandidateCount: 3,
      candidates: [exactAutoPairCandidate].slice(input.offset, input.offset + input.limit),
    }),
    upsertExactAutoPairMapping: async (input) => {
      exactAutoPairWrites.push({ dryRun: input.dryRun, directUrl: input.directUrl });
      return {
        status: input.dryRun ? "would_create" : "created",
        mappingId: input.dryRun ? null : "33333333-3333-4333-8333-333333333333",
        existingSupplierArticleNumber: null,
      };
    },
  },
  runnerFactory: (callbacks) => ({
    openBrowser: async () => {
      callbacks.onStatus?.("opening_browser");
    },
    waitForManualLogin: async () => {
      callbacks.onStatus?.("login_detected");
      return true;
    },
    runCandidates: async (candidates) => {
      callbacks.onStatus?.("running");
      for (const candidate of candidates) {
        callbacks.onRow?.(
          runnerMode === "price_success"
            ? buildLfPriceBatchRow(candidate, candidate === manualCandidate ? "ok" : "failed")
            : buildLfExactAutoPairBatchRow(candidate)
        );
      }
      if (runnerMode === "throw_after_row") throw new Error("lf runner failed after row");
      callbacks.onStatus?.("completed");
    },
    cancel: async () => undefined,
    close: async () => undefined,
  }),
  exactSearch: async (input) => ({
    searchedArticle: input.supplierArticleNumber.trim().toUpperCase(),
    outcome: "trusted_lf_item",
    accepted: true,
    supplierArticleNumber: input.supplierArticleNumber.trim(),
    lfAutocompleteId: `C:${input.supplierArticleNumber.trim()}`,
    lfAutocompleteValue: `${input.supplierArticleNumber.trim()} TEST ITEM`,
    lfManufacturerCode: null,
    lfManufacturerName: null,
    lfFinalUrl: `https://b2bnet.lfspareparts724.com/en/product/test/${input.supplierArticleNumber.trim()}/RisultatoRicercaRapida`,
    lfProductName: "TEST ITEM",
    lfProductId: input.supplierArticleNumber.trim(),
    lfPartNumber: input.supplierArticleNumber.trim(),
    warnings: [],
  }),
});

try {
  const exact = await server.inject({
    method: "POST",
    url: "/lf-products/exact-search",
    headers: { "x-danetti-local-lab": "true" },
    payload: { supplierArticleNumber: "5067364" },
  });
  assert.equal(exact.statusCode, 200);
  assert.equal(exact.json().accepted, true);
  assert.equal(exact.json().lfAutocompleteId, "C:5067364");

  const missingHeader = await server.inject({
    method: "POST",
    url: "/lf-products/exact-search",
    payload: { supplierArticleNumber: "5067364" },
  });
  assert.equal(missingHeader.statusCode, 403);
  assert.equal(missingHeader.json().error.code, "lf_manual_batch_header_missing");

  const invalid = await server.inject({
    method: "POST",
    url: "/lf-products/exact-search",
    headers: { "x-danetti-local-lab": "true" },
    payload: { supplierArticleNumber: "" },
  });
  assert.equal(invalid.statusCode, 400);
  assert.equal(invalid.json().error.code, "lf_exact_search_invalid_input");

  const savedPreferencesResponse = await server.inject({
    method: "PUT",
    url: "/lf-products/manual-batch/preferences",
    headers: { "x-danetti-local-lab": "true" },
    payload: { autoResume: false, vatPercent: 25, targetProfitMultiplier: 1.4 },
  });
  assert.equal(savedPreferencesResponse.statusCode, 200);
  const persistedPreferences = savedPreferences as LfOperatorPreferences | null;
  assert.notEqual(persistedPreferences, null);
  assert.equal(persistedPreferences?.autoResume, false);
  assert.equal(persistedPreferences?.targetProfitMultiplier, 1.4);

  const readPreferencesResponse = await server.inject({
    method: "GET",
    url: "/lf-products/manual-batch/preferences",
    headers: { "x-danetti-local-lab": "true" },
  });
  assert.equal(readPreferencesResponse.statusCode, 200);
  assert.equal(readPreferencesResponse.json().preferences.autoResume, false);
  assert.equal(readPreferencesResponse.json().preferences.vatPercent, 25);

  const dryRun = await server.inject({
    method: "POST",
    url: "/lf-products/exact-auto-pair",
    headers: { "x-danetti-local-lab": "true" },
    payload: { limit: 1, eurHufRate: 400 },
  });
  assert.equal(dryRun.statusCode, 200);
  assert.equal(dryRun.json().dryRun, true);
  assert.equal(dryRun.json().wouldCreateCount, 1);
  assert.equal(dryRun.json().createdCount, 0);
  assert.equal(dryRun.json().skippedDvgMappedCount, 2);
  assert.equal(dryRun.json().rows[0].lfFinalUrl.includes("/en/product/"), true);

  const apply = await server.inject({
    method: "POST",
    url: "/lf-products/exact-auto-pair",
    headers: { "x-danetti-local-lab": "true" },
    payload: { limit: 10_000, dryRun: false, eurHufRate: 400 },
  });
  assert.equal(apply.statusCode, 200);
  assert.equal(apply.json().dryRun, false);
  assert.equal(apply.json().createdCount, 1);
  assert.equal(exactAutoPairWrites.at(-1)?.dryRun, false);
  assert.equal(exactAutoPairWrites.at(-1)?.directUrl.includes("/en/product/"), true);

  const currentAfterApply = await server.inject({
    method: "GET",
    url: "/lf-products/manual-batch/current",
    headers: { "x-danetti-local-lab": "true" },
  });
  assert.equal(currentAfterApply.statusCode, 200);
  assert.equal(currentAfterApply.json().run.status, "completed");
  assert.equal(currentAfterApply.json().run.settings.onlyMappedLf, false);
  assert.equal(currentAfterApply.json().run.rows.length, 1);
  assert.equal(currentAfterApply.json().run.export.available, true);
  assert.equal(currentAfterApply.json().run.export.containsSecrets, false);
  assert.equal(capturedProgressRows.length, 0);
  assert.equal(
    currentAfterApply
      .json()
      .run.events.some((event: { message: string }) => /LF mapping mentve/.test(event.message)),
    true
  );

  runnerMode = "throw_after_row";
  const writesBeforeInterrupted = exactAutoPairWrites.length;
  const interruptedPairing = await server.inject({
    method: "POST",
    url: "/lf-products/exact-auto-pair",
    headers: { "x-danetti-local-lab": "true" },
    payload: { limit: 10_000, dryRun: false, eurHufRate: 400 },
  });
  assert.equal(interruptedPairing.statusCode, 500);
  assert.equal(exactAutoPairWrites.length, writesBeforeInterrupted + 1);
  assert.equal(exactAutoPairWrites.at(-1)?.dryRun, false);
  runnerMode = "success";

  const manualPairWritesBefore = exactAutoPairWrites.length;
  const manualPairProgressBefore = capturedProgressRows.length;
  const manualPairStart = await server.inject({
    method: "POST",
    url: "/lf-products/manual-batch/start",
    headers: { "x-danetti-local-lab": "true" },
    payload: {
      limit: 1,
      eurHufRate: 400,
      onlyMappedLf: false,
      allowSuggestedLfArticle: true,
      allowSkuPrefixCandidate: true,
    },
  });
  assert.equal(manualPairStart.statusCode, 201);
  assert.equal(manualPairStart.json().settings.onlyMappedLf, false);
  assert.equal(manualPairStart.json().settings.rerunPreviousNonOkOnly, false);
  assert.equal(manualPairStart.json().settings.dryRun, true);
  assert.equal(manualPairStart.json().settings.allowSnapshotWrite, false);
  assert.equal(manualPairStart.json().resume.action, "wait_for_current_run");
  assert.equal(manualPairStart.json().export.available, false);
  const manualPairRunId = manualPairStart.json().runId as string;
  const manualPairContinue = await server.inject({
    method: "POST",
    url: `/lf-products/manual-batch/${manualPairRunId}/continue-after-login`,
    headers: { "x-danetti-local-lab": "true" },
  });
  assert.equal(manualPairContinue.statusCode, 202);
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(exactAutoPairWrites.length, manualPairWritesBefore + 1);
  assert.equal(exactAutoPairWrites.at(-1)?.dryRun, true);
  assert.equal(capturedProgressRows.length, manualPairProgressBefore);
  const manualPairStatus = await server.inject({
    method: "GET",
    url: `/lf-products/manual-batch/${manualPairRunId}`,
    headers: { "x-danetti-local-lab": "true" },
  });
  assert.equal(manualPairStatus.statusCode, 200);
  assert.equal(manualPairStatus.json().status, "completed");
  assert.equal(manualPairStatus.json().export.available, true);
  assert.equal(
    manualPairStatus.json().export.suggestedFilename,
    `lf-${manualPairRunId}-sanitized-results.json`
  );
  assert.equal(
    manualPairStatus
      .json()
      .events.some((event: { message: string }) =>
        /Ellenőrizve, menthető LF találat/.test(event.message)
      ),
    true
  );
  assert.equal(
    manualPairStatus
      .json()
      .events.some((event: { message: string }) => /LF mapping mentve/.test(event.message)),
    false
  );

  runnerMode = "price_success";
  const priceStart = await server.inject({
    method: "POST",
    url: "/lf-products/manual-batch/start",
    headers: { "x-danetti-local-lab": "true" },
    payload: { limit: 1, eurHufRate: 400, onlyMappedLf: true, rerunPreviousNonOkOnly: true },
  });
  assert.equal(priceStart.statusCode, 201);
  assert.equal(priceStart.json().settings.dryRun, true);
  assert.equal(priceStart.json().settings.allowSnapshotWrite, false);
  assert.equal(priceStart.json().settings.rerunPreviousNonOkOnly, true);
  assert.equal(capturedSettings.at(-1)?.rerunPreviousNonOkOnly, true);
  const priceRunId = priceStart.json().runId as string;
  const priceContinue = await server.inject({
    method: "POST",
    url: `/lf-products/manual-batch/${priceRunId}/continue-after-login`,
    headers: { "x-danetti-local-lab": "true" },
  });
  assert.equal(priceContinue.statusCode, 202);
  await new Promise((resolve) => setTimeout(resolve, 0));
  const priceStatus = await server.inject({
    method: "GET",
    url: `/lf-products/manual-batch/${priceRunId}`,
    headers: { "x-danetti-local-lab": "true" },
  });
  assert.equal(priceStatus.statusCode, 200);
  assert.equal(priceStatus.json().status, "completed");
  assert.equal(priceStatus.json().rows[0].supplierNetEur, 5);
  assert.equal(priceStatus.json().resume.action, "start_new");
  assert.equal(priceStatus.json().export.available, true);
  assert.equal(priceStatus.json().export.containsSecrets, false);
  assert.equal(capturedProgressRows.at(-1)?.runId, priceRunId);
  assert.equal(capturedProgressRows.at(-1)?.globalIndex, 1);
  assert.equal(
    capturedProgressRows.at(-1)?.row.supplierMappingId,
    manualCandidate.supplierMappingId
  );
  assert.equal(
    priceStatus
      .json()
      .events.some(
        (event: { message?: string }) => event.message === "Catalog LF pricing saved: LF-PRICE-TEST"
      ),
    false
  );
  const priceProgress = await server.inject({
    method: "GET",
    url: "/lf-products/manual-batch/progress",
    headers: { "x-danetti-local-lab": "true" },
  });
  assert.equal(priceProgress.statusCode, 200);
  assert.equal(priceProgress.json().progress.runId, priceRunId);
  assert.equal(priceProgress.json().progress.nextOffset, 1);
  assert.equal(priceProgress.json().progress.resume.action, "retry_from_next_offset");
  assert.equal(priceProgress.json().progress.export.rowCount, capturedProgressRows.length);
  assert.equal(persistedOperatorRunStates.at(-1)?.runId, priceRunId);

  const writePriceStart = await server.inject({
    method: "POST",
    url: "/lf-products/manual-batch/start",
    headers: { "x-danetti-local-lab": "true" },
    payload: {
      limit: 1,
      eurHufRate: 400,
      onlyMappedLf: true,
      dryRun: false,
      allowSnapshotWrite: true,
    },
  });
  assert.equal(writePriceStart.statusCode, 201);
  assert.equal(writePriceStart.json().settings.dryRun, false);
  assert.equal(writePriceStart.json().settings.allowSnapshotWrite, true);
  const writePriceRunId = writePriceStart.json().runId as string;
  await server.inject({
    method: "POST",
    url: `/lf-products/manual-batch/${writePriceRunId}/continue-after-login`,
    headers: { "x-danetti-local-lab": "true" },
  });
  await new Promise((resolve) => setTimeout(resolve, 0));
  const writePriceStatus = await server.inject({
    method: "GET",
    url: `/lf-products/manual-batch/${writePriceRunId}`,
    headers: { "x-danetti-local-lab": "true" },
  });
  assert.equal(writePriceStatus.statusCode, 200);
  assert.equal(writePriceStatus.json().status, "completed");
  assert.equal(
    writePriceStatus
      .json()
      .events.some(
        (event: { message?: string }) => event.message === "Catalog LF pricing saved: LF-PRICE-TEST"
      ),
    true
  );

  const invalidRerunSources = await server.inject({
    method: "POST",
    url: "/lf-products/manual-batch/start",
    headers: { "x-danetti-local-lab": "true" },
    payload: {
      limit: 1,
      eurHufRate: 400,
      onlyMappedLf: false,
      rerunPreviousNonOkOnly: true,
      allowSuggestedLfArticle: true,
    },
  });
  assert.equal(invalidRerunSources.statusCode, 400);
  assert.equal(invalidRerunSources.json().error.code, "lf_manual_batch_invalid_settings");
  runnerMode = "success";
} finally {
  await server.close();
}

console.log("LF products route tests passed");

function buildLfExactAutoPairBatchRow(candidate: LfManualBatchCandidate): LfManualBatchRow {
  return {
    status: "ok",
    catalogProductId: candidate.catalogProductId,
    wooSku: candidate.wooSku,
    wooName: candidate.wooName,
    supplierId: candidate.supplierId,
    supplierMappingId: candidate.supplierMappingId,
    supplierArticleNumber: candidate.supplierArticleNumber,
    candidateSource: candidate.candidateSource,
    lfAutocompleteId: `C:${candidate.supplierArticleNumber}`,
    lfAutocompleteValue: `${candidate.supplierArticleNumber} TEST ITEM`,
    lfManufacturerCode: null,
    lfManufacturerName: null,
    lfFinalUrl: `https://b2bnet.lfspareparts724.com/en/product/test/${candidate.supplierArticleNumber}/RisultatoRicercaRapida`,
    lfProductName: "TEST ITEM",
    lfProductId: candidate.supplierArticleNumber,
    lfPartNumber: candidate.supplierArticleNumber,
    supplierNetEur: null,
    supplierGrossEur: null,
    currency: null,
    unit: null,
    eurHufRate: 400,
    markupPercent: 30,
    vatPercent: 27,
    matchConfidence: "trusted_lf_item",
    warnings: [],
    wooPriceHuf: null,
    wooPriceSource: null,
    wooGrossHuf: null,
    wooNetHuf: null,
    supplierNetHuf: null,
    targetNetHuf: null,
    targetGrossHuf: null,
    targetGrossHufRounded: null,
    actualProfitNetHuf: null,
    actualProfitPercentOnCost: null,
    actualGrossDeltaToTargetHuf: null,
  };
}

function buildLfPriceBatchRow(
  candidate: LfManualBatchCandidate,
  status: LfManualBatchRow["status"],
  settings: Pick<LfManualBatchSettings, "eurHufRate" | "markupPercent" | "vatPercent"> = {
    eurHufRate: 400,
    markupPercent: 0,
    vatPercent: 27,
  }
): LfManualBatchRow {
  return {
    status,
    catalogProductId: candidate.catalogProductId,
    wooSku: candidate.wooSku,
    wooName: candidate.wooName,
    supplierId: candidate.supplierId,
    supplierMappingId: candidate.supplierMappingId,
    supplierArticleNumber: candidate.supplierArticleNumber,
    candidateSource: candidate.candidateSource,
    lfAutocompleteId: `C:${candidate.supplierArticleNumber}`,
    lfAutocompleteValue: `${candidate.supplierArticleNumber} TEST ITEM`,
    lfManufacturerCode: null,
    lfManufacturerName: null,
    lfFinalUrl: `https://b2bnet.lfspareparts724.com/en/product/test/${candidate.supplierArticleNumber}/RisultatoRicercaRapida`,
    lfProductName: "TEST PRICE ITEM",
    lfProductId: candidate.supplierArticleNumber,
    lfPartNumber: candidate.supplierArticleNumber,
    supplierNetEur: status === "ok" ? 5 : null,
    supplierGrossEur: null,
    currency: status === "ok" ? "EUR" : null,
    unit: status === "ok" ? "pc" : null,
    eurHufRate: settings.eurHufRate,
    markupPercent: settings.markupPercent,
    vatPercent: settings.vatPercent,
    matchConfidence: status === "ok" ? "trusted_lf_item" : candidate.matchConfidence,
    warnings: [],
    wooPriceHuf: status === "ok" ? 10000 : null,
    wooPriceSource: status === "ok" ? "currentPrice" : null,
    wooGrossHuf: status === "ok" ? 10000 : null,
    wooNetHuf: status === "ok" ? 7874.0157480314965 : null,
    supplierNetHuf: status === "ok" ? 2000 : null,
    targetNetHuf: status === "ok" ? 2000 : null,
    targetGrossHuf: status === "ok" ? 2540 : null,
    targetGrossHufRounded: status === "ok" ? 2540 : null,
    actualProfitNetHuf: status === "ok" ? 5874.0157480314965 : null,
    actualProfitPercentOnCost: status === "ok" ? 293.7007874015748 : null,
    actualGrossDeltaToTargetHuf: status === "ok" ? 7460 : null,
  };
}
