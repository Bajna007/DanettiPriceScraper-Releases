import type {
  NewSupplierPortalAudit,
  NewSupplierPortalAuditCheck,
  NewSupplierPortalAuditEvidenceNote,
  SupplierPortalAudit,
  SupplierPortalAuditCheck,
  SupplierPortalAuditEvidenceNote,
  SupplierCheckSettings,
} from "@danetti/db";

export type PortalAuditStatus = "draft" | "in_review" | "approved" | "rejected" | "needs_update";
export type ResultPageType =
  | "search_result"
  | "search_then_detail"
  | "direct_url"
  | "export_file"
  | "network_response"
  | "unknown";
export type AuditCheckStatus = "unknown" | "pass" | "fail" | "not_applicable" | "needs_review";
export type EvidenceNoteType =
  | "manual_note"
  | "selector_note"
  | "network_note"
  | "screenshot_reference"
  | "html_reference"
  | "risk_note";

export type PortalAuditRecord = SupplierPortalAudit;
export type NewPortalAuditRecord = NewSupplierPortalAudit;
export type PortalAuditCheckRecord = SupplierPortalAuditCheck;
export type NewPortalAuditCheckRecord = NewSupplierPortalAuditCheck;
export type PortalAuditEvidenceNoteRecord = SupplierPortalAuditEvidenceNote;
export type NewPortalAuditEvidenceNoteRecord = NewSupplierPortalAuditEvidenceNote;

export interface PortalAuditListFilters {
  supplierId?: string;
  status?: PortalAuditStatus;
  limit: number;
  offset: number;
}

export interface PortalAuditListItem extends SupplierPortalAudit {
  supplierCode: string;
  supplierName: string;
}

export interface PortalAuditDetail extends PortalAuditListItem {
  checks: SupplierPortalAuditCheck[];
  evidenceNotes: SupplierPortalAuditEvidenceNote[];
}

export interface PortalAuditConnectorReadiness {
  auditId: string;
  status: PortalAuditStatus;
  ready: boolean;
  missingRequiredFields: string[];
  failingChecks: string[];
  warnings: string[];
  recommendedStrategy: ResultPageType | null;
  safetySummary: {
    allowedDomains: string[];
    allowedUrlPatterns: string[];
    dangerousUrlPatterns: string[];
    allowedMethods: string[];
    allowedPostPatterns: string[];
    suggestedRateLimitPerMinute: number;
    resultPageType: ResultPageType;
    has2fa: boolean | null;
    hasCaptcha: boolean | null;
    hasAccountLockRisk: boolean | null;
    skuExactMatchRequired: boolean;
    safetyNotesPresent: boolean;
  };
  requiredBeforeConnector: string[];
  noGoReasons: string[];
  nextAction: string;
}

export interface PortalAuditConnectorPlan {
  connectorIdSuggestion: string;
  displayNameSuggestion: string;
  allowedDomains: string[];
  allowedUrlPatterns: string[];
  deniedUrlPatterns: string[];
  allowedMethods: string[];
  allowedPostPatterns: string[];
  lookupStrategy: ResultPageType | null;
  expectedPageKind: ResultPageType;
  priceExtractionNotes: string;
  stockExtractionNotes: string;
  matchValidationRules: string[];
  rateLimitSettings: {
    auditSuggestedRateLimitPerMinute: number;
    productsPerMinute: number | null;
    delayBetweenProductsSeconds: number | null;
    jitterMinSeconds: number | null;
    jitterMaxSeconds: number | null;
    maxRetriesPerItem: number | null;
    navigationTimeoutSeconds: number | null;
    itemTimeoutSeconds: number | null;
  };
  safetyStopRules: string[];
  evidencePlan: string[];
  manualSessionPolicy: string[];
  openQuestions: string[];
  implementationSteps: string[];
  acceptanceCriteria: string[];
  testPlan: string[];
}

export interface PortalAuditConnectorPlanResponse {
  auditId: string;
  supplier: {
    id: string;
    code: string;
    name: string;
  };
  readiness: PortalAuditConnectorReadiness;
  connectorPlan: PortalAuditConnectorPlan;
}

export interface PortalAuditSafeExport {
  auditId: string;
  supplier: {
    id: string;
    code: string;
    name: string;
  };
  audit: Omit<PortalAuditDetail, "evidenceNotes" | "checks">;
  checks: Array<Pick<SupplierPortalAuditCheck, "checkKey" | "label" | "status" | "notes">>;
  evidenceNotes: Array<
    Pick<
      SupplierPortalAuditEvidenceNote,
      "id" | "title" | "evidenceType" | "containsSensitiveData" | "createdBy" | "createdAt"
    >
  >;
  readiness: PortalAuditConnectorReadiness;
  connectorPlanSummary: Pick<
    PortalAuditConnectorPlan,
    | "connectorIdSuggestion"
    | "displayNameSuggestion"
    | "lookupStrategy"
    | "expectedPageKind"
    | "rateLimitSettings"
    | "safetyStopRules"
    | "openQuestions"
  >;
}

export type PortalAuditCheckSettingsRecord = SupplierCheckSettings;

export class PortalAuditValidationError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus = 400
  ) {
    super(message);
    this.name = "PortalAuditValidationError";
  }
}

export class PortalAuditDatabaseError extends Error {
  constructor(message = "Database unavailable") {
    super(message);
    this.name = "PortalAuditDatabaseError";
  }
}
