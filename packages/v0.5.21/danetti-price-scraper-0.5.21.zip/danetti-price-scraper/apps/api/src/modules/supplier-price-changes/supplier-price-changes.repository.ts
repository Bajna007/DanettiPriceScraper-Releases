import { DVG_CONNECTOR_ID, LF_CONNECTOR_ID } from "@danetti/connectors";
import {
  catalogProducts,
  catalogImportRows,
  catalogImportRuns,
  exchangeRates,
  priceChangeReviews,
  type DanettiDatabase,
} from "@danetti/db";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import type { SupplierPriceChangeRow } from "./supplier-price-changes.service.js";

export interface ImportedPriceCorrection {
  eventId: string;
  priceHuf: number;
  finishedAt: Date;
  importRunId: string;
}

export type SupplierPriceChangeSupplierScope = "all" | "dvg" | "lf";
export interface PriceChangeReview {
  eventId: string;
  baselineWooGrossHuf: string | number | null;
  baselineSource: string;
  decision: string;
  decidedAt: Date | null;
}
export interface SupplierPriceChangeSnapshotRow {
  snapshotId: string;
  supplierId: string;
  supplierName: string | null;
  supplierMappingId: string | null;
  catalogProductId: string;
  sku: string;
  productName: string;
  supplierArticleNumber: string;
  priceNetEur: string | number | null;
  observedAt: Date;
  createdAt: Date;
  currentPrice: string | number | null;
  salePrice: string | number | null;
  regularPrice: string | number | null;
  observedWooGrossHuf?: string | number | null;
}
export interface SupplierPriceChangesRepositoryLike {
  getLatestEurHufRate(): Promise<number | null>;
  listRecentCatalogSnapshots(
    limit: number,
    supplierScope: SupplierPriceChangeSupplierScope
  ): Promise<SupplierPriceChangeSnapshotRow[]>;
  ensureReviews?(reviews: PriceChangeReview[]): Promise<PriceChangeReview[]>;
  decideReview?(
    eventId: string,
    decision: "open" | "resolved" | "csv",
    now: Date
  ): Promise<boolean>;
  findImportedPriceCorrections?(
    items: SupplierPriceChangeRow[]
  ): Promise<ImportedPriceCorrection[]>;
}

export class SupplierPriceChangesRepository implements SupplierPriceChangesRepositoryLike {
  constructor(private readonly db: DanettiDatabase) {}
  async getLatestEurHufRate(): Promise<number | null> {
    const [rate] = await this.db
      .select({ value: exchangeRates.eurHufRate })
      .from(exchangeRates)
      .orderBy(desc(exchangeRates.effectiveAt), desc(exchangeRates.createdAt))
      .limit(1);
    return rate ? Number(rate.value) : null;
  }
  async ensureReviews(reviews: PriceChangeReview[]): Promise<PriceChangeReview[]> {
    if (!reviews.length) return [];
    for (let i = 0; i < reviews.length; i += 500) {
      const batch = reviews.slice(i, i + 500);
      // Insert-only baseline; neither imports nor repeated checks move it.
      await this.db
        .insert(priceChangeReviews)
        .values(
          batch.map((r) => ({
            ...r,
            baselineWooGrossHuf:
              r.baselineWooGrossHuf === null ? null : String(r.baselineWooGrossHuf),
          }))
        )
        .onConflictDoNothing();
    }
    const result: PriceChangeReview[] = [];
    for (let i = 0; i < reviews.length; i += 500)
      result.push(
        ...(await this.db
          .select()
          .from(priceChangeReviews)
          .where(
            inArray(
              priceChangeReviews.eventId,
              reviews.slice(i, i + 500).map((r) => r.eventId)
            )
          ))
      );
    return result;
  }
  async decideReview(
    eventId: string,
    decision: "open" | "resolved" | "csv",
    now: Date
  ): Promise<boolean> {
    const rows = await this.db
      .update(priceChangeReviews)
      .set({ decision, decidedAt: now })
      .where(
        and(
          eq(priceChangeReviews.eventId, eventId),
          decision === "csv"
            ? sql`${priceChangeReviews.decision} not in ('resolved','csv') and (${priceChangeReviews.decision} <> 'open' or ${priceChangeReviews.decidedAt} < ${now.toISOString()}::timestamptz)`
            : undefined
        )
      )
      .returning({ id: priceChangeReviews.eventId });
    return rows.length === 1;
  }
  async findImportedPriceCorrections(
    items: SupplierPriceChangeRow[]
  ): Promise<ImportedPriceCorrection[]> {
    if (!items.length) return [];
    const identities = await this.db
      .select({
        id: catalogProducts.id,
        wooId: catalogProducts.sourceProductId,
        variationId: catalogProducts.sourceVariationId,
      })
      .from(catalogProducts)
      .where(inArray(catalogProducts.id, [...new Set(items.map((item) => item.catalogProductId))]));
    const byProduct = new Map(identities.map((row) => [row.id, row.variationId ?? row.wooId]));
    const wooIds = [...new Set([...byProduct.values()].filter((id): id is string => !!id))];
    if (!wooIds.length) return [];
    const rows = await this.db
      .select({
        wooId: catalogImportRows.sourceProductId,
        sku: catalogImportRows.sku,
        price: catalogImportRows.importedWooGrossHuf,
        runId: catalogImportRuns.id,
        finishedAt: catalogImportRuns.finishedAt,
        currentSku: catalogProducts.sku,
        currentWooId: catalogProducts.sourceProductId,
        currentVariationId: catalogProducts.sourceVariationId,
        currentPrice: catalogProducts.currentPrice,
        salePrice: catalogProducts.salePrice,
        regularPrice: catalogProducts.regularPrice,
      })
      .from(catalogImportRows)
      .innerJoin(catalogImportRuns, eq(catalogImportRows.catalogImportRunId, catalogImportRuns.id))
      .leftJoin(catalogProducts, eq(catalogImportRows.catalogProductId, catalogProducts.id))
      .where(
        and(
          eq(catalogImportRuns.status, "completed"),
          inArray(catalogImportRows.sourceProductId, wooIds),
          inArray(catalogImportRows.status, ["inserted", "updated", "skipped_existing"])
        )
      );
    const latest = new Map<string, typeof rows>();
    for (const row of rows) {
      if (!row.wooId || !row.finishedAt) continue;
      const previous = latest.get(row.wooId);
      if (!previous || row.finishedAt > previous[0]!.finishedAt!) latest.set(row.wooId, [row]);
      else if (row.finishedAt.getTime() === previous[0]!.finishedAt!.getTime()) previous.push(row);
    }
    return items.flatMap((item) => {
      const id = byProduct.get(item.catalogProductId),
        proofs = id ? latest.get(id) : null;
      if (!proofs || proofs.length !== 1) return [];
      const proof = proofs[0]!,
        current = proof.currentPrice ?? proof.salePrice ?? proof.regularPrice;
      if (
        proof.price === null ||
        current === null ||
        !proof.finishedAt ||
        proof.currentSku !== proof.sku ||
        (proof.currentVariationId ?? proof.currentWooId) !== proof.wooId ||
        Number(current) !== Number(proof.price)
      )
        return [];
      return [
        {
          eventId: item.eventId,
          priceHuf: Number(proof.price),
          finishedAt: proof.finishedAt,
          importRunId: proof.runId,
        },
      ];
    });
  }
  async listRecentCatalogSnapshots(
    _limit: number,
    scope: SupplierPriceChangeSupplierScope
  ): Promise<SupplierPriceChangeSnapshotRow[]> {
    const supplierCode =
      scope === "dvg" ? DVG_CONNECTOR_ID : scope === "lf" ? LF_CONNECTOR_ID : null;
    // Merge evidence before compacting consecutive equal-price periods. Keep each
    // period's endpoints and the latest two checks. A -> B -> A remains two events.
    const rows = await this.db.execute(sql`
      WITH runs AS (
        SELECT run_id, started_at, coalesce(completed_at, updated_at) AS ended_at, rows, ${DVG_CONNECTOR_ID}::text AS code FROM dvg_operator_runs
        UNION ALL
        SELECT run_id, started_at, coalesce(completed_at, updated_at), rows, ${LF_CONNECTOR_ID}::text FROM lf_operator_runs
      ), trusted AS MATERIALIZED (
        SELECT r.run_id, r.started_at, r.ended_at, r.code, item.ordinality,
          CASE WHEN item.value->>'supplierMappingId' ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' THEN (item.value->>'supplierMappingId')::uuid END AS mapping_id,
          CASE WHEN item.value->>'catalogProductId' ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' THEN (item.value->>'catalogProductId')::uuid END AS product_id,
          CASE WHEN item.value->>'supplierId' ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' THEN (item.value->>'supplierId')::uuid END AS supplier_id,
          upper(trim(item.value->>'supplierArticleNumber')) AS article,
          item.value->>'matchConfidence' AS confidence,
          upper(trim(item.value->>'dvgArticle')) AS dvg_article,
          upper(trim(item.value->>'lfAutocompleteId')) AS lf_article,
          CASE WHEN item.value->>'supplierNetEur' ~ '^[0-9]+([.][0-9]+)?$' THEN round((item.value->>'supplierNetEur')::numeric, 2) END AS price,
          CASE WHEN item.value->>'wooGrossHuf' ~ '^[0-9]+([.][0-9]+)?$' THEN (item.value->>'wooGrossHuf')::numeric END AS woo
        FROM runs r CROSS JOIN LATERAL jsonb_array_elements(r.rows) WITH ORDINALITY item(value, ordinality)
        WHERE (${supplierCode}::text IS NULL OR r.code = ${supplierCode})
          AND item.value->>'status' = 'ok' AND item.value->>'currency' = 'EUR'
          AND item.value->>'candidateSource' = 'saved_mapping'
      ), operator_observations AS MATERIALIZED (
        SELECT 'operator:' || r.code || ':' || r.run_id || ':' || r.ordinality AS id,
          m.supplier_id, s.name AS supplier_name, m.id AS supplier_mapping_id,
          p.id AS catalog_product_id, p.sku, p.name AS product_name, m.supplier_article_number,
          r.price, r.started_at AS observed_at, r.started_at AS created_at,
          p.current_price, p.sale_price, p.regular_price, r.woo, r.ended_at
        FROM trusted r JOIN supplier_mappings m ON m.id = r.mapping_id
          AND m.catalog_product_id = r.product_id AND m.supplier_id = r.supplier_id
          AND upper(trim(m.supplier_article_number)) = r.article
        JOIN suppliers s ON s.id = m.supplier_id AND s.code = r.code
        JOIN catalog_products p ON p.id = m.catalog_product_id
        WHERE r.price > 0 AND ((r.code = ${DVG_CONNECTOR_ID} AND r.confidence = 'exact_dvg_article' AND r.dvg_article = r.article)
          OR (r.code = ${LF_CONNECTOR_ID} AND r.confidence = 'trusted_lf_item' AND r.lf_article = 'C:' || r.article))
      ), observations AS (
        SELECT id, supplier_id, supplier_name, supplier_mapping_id, catalog_product_id,
          sku, product_name, supplier_article_number, price, observed_at, created_at,
          current_price, sale_price, regular_price, woo FROM operator_observations
        UNION ALL
        SELECT snap.id::text, snap.supplier_id, s.name, snap.supplier_mapping_id,
          p.id, p.sku, p.name, snap.supplier_article_number, snap.price_net_eur,
          snap.observed_at, snap.created_at, p.current_price, p.sale_price, p.regular_price, NULL::numeric
        FROM supplier_price_snapshots snap JOIN catalog_products p ON p.id = snap.catalog_product_id
        LEFT JOIN suppliers s ON s.id = snap.supplier_id
        WHERE snap.currency = 'EUR' AND snap.price_net_eur > 0
          AND (${supplierCode}::text IS NULL OR s.code = ${supplierCode})
          AND NOT EXISTS (SELECT 1 FROM operator_observations op
            WHERE op.catalog_product_id = snap.catalog_product_id AND op.supplier_id = snap.supplier_id
              AND op.supplier_mapping_id IS NOT DISTINCT FROM snap.supplier_mapping_id
              AND op.supplier_article_number = snap.supplier_article_number AND op.price = snap.price_net_eur
              AND snap.observed_at BETWEEN op.observed_at AND op.ended_at)
      ), ordered AS (
        SELECT *, lag(price) OVER w AS previous_price,
          row_number() OVER (PARTITION BY catalog_product_id, supplier_id, supplier_mapping_id, supplier_article_number
            ORDER BY observed_at DESC, created_at DESC, id DESC) AS latest_rank
        FROM observations WINDOW w AS (PARTITION BY catalog_product_id, supplier_id, supplier_mapping_id, supplier_article_number
          ORDER BY observed_at, created_at, id)
      ), periods AS (
        SELECT *, sum(CASE WHEN previous_price IS DISTINCT FROM price THEN 1 ELSE 0 END) OVER (
          PARTITION BY catalog_product_id, supplier_id, supplier_mapping_id, supplier_article_number
          ORDER BY observed_at, created_at, id) AS period FROM ordered
      ), endpoints AS (
        SELECT *, row_number() OVER (PARTITION BY catalog_product_id, supplier_id, supplier_mapping_id, supplier_article_number, period
          ORDER BY observed_at, created_at, id) AS first_in_period,
          row_number() OVER (PARTITION BY catalog_product_id, supplier_id, supplier_mapping_id, supplier_article_number, period
          ORDER BY observed_at DESC, created_at DESC, id DESC) AS last_in_period FROM periods
      ) SELECT id AS "snapshotId", supplier_id AS "supplierId", supplier_name AS "supplierName",
        supplier_mapping_id AS "supplierMappingId", catalog_product_id AS "catalogProductId", sku,
        product_name AS "productName", supplier_article_number AS "supplierArticleNumber", price AS "priceNetEur",
        observed_at AS "observedAt", created_at AS "createdAt", current_price AS "currentPrice",
        sale_price AS "salePrice", regular_price AS "regularPrice", woo AS "observedWooGrossHuf"
      FROM endpoints WHERE first_in_period = 1 OR last_in_period = 1 OR latest_rank <= 2
    `);
    return rows.map((row) => ({
      ...(row as unknown as SupplierPriceChangeSnapshotRow),
      observedAt: new Date(row.observedAt as Date),
      createdAt: new Date(row.createdAt as Date),
    }));
  }
}
