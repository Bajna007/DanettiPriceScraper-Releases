import { parseWooSku, readWooSkuArticleCandidates, type NewSupplierMapping } from "@danetti/db";
import {
  buildDvgDetailUrl,
  decideDvgMappingReview,
  decideDvgPriceSnapshotGate,
  isDvgPrefixedArticleCandidate,
} from "@danetti/connectors";
import type { LookupStrategy } from "../suppliers/suppliers.types.js";
import {
  SupplierMappingValidationError,
  type CreateSupplierMappingInput,
  type DvgAutoPairCandidate,
  type DvgMappingReviewPreviewInput,
  type DvgMappingReviewPreviewResponse,
  type UpdateSupplierMappingInput,
} from "./supplier-mappings.types.js";

const LOOKUP_STRATEGIES: LookupStrategy[] = [
  "search_result",
  "search_then_detail",
  "direct_url",
  "export_file",
  "network_response",
];

const SENSITIVE_KEY_PATTERN = /(credential|password|secret|token|cookie|session|storageState)/i;

export function validateCreateSupplierMappingInput(input: unknown): NewSupplierMapping {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  const lookupStrategy = readLookupStrategy(record, "lookupStrategy", true) ?? "search_result";
  const directUrl = readOptionalString(record, "directUrl");

  validateDirectUrlForStrategy(lookupStrategy, directUrl);

  return {
    catalogProductId: readUuid(record, "catalogProductId"),
    supplierId: readUuid(record, "supplierId"),
    supplierArticleNumber: readRequiredString(record, "supplierArticleNumber"),
    lookupStrategy,
    supplierProductNameOverride: readOptionalString(record, "supplierProductNameOverride"),
    directUrl,
    priority: readOptionalInteger(record, "priority") ?? 100,
    enabled: readOptionalBoolean(record, "enabled") ?? true,
    isPrimary: readOptionalBoolean(record, "isPrimary") ?? false,
    matchValidationMode: "exact_article_number",
    notes: readOptionalString(record, "notes"),
  };
}

export function validateUpdateSupplierMappingInput(
  input: unknown,
  currentLookupStrategy: LookupStrategy,
  currentDirectUrl: string | null
): Partial<NewSupplierMapping> {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  const update: Partial<NewSupplierMapping> = { updatedAt: new Date() };
  const lookupStrategy =
    readLookupStrategy(record, "lookupStrategy", false) ?? currentLookupStrategy;
  const directUrl =
    "directUrl" in record ? readOptionalString(record, "directUrl") : currentDirectUrl;

  if ("supplierArticleNumber" in record) {
    update.supplierArticleNumber = readRequiredString(record, "supplierArticleNumber");
  }
  if ("supplierProductNameOverride" in record) {
    update.supplierProductNameOverride = readOptionalString(record, "supplierProductNameOverride");
  }
  if ("lookupStrategy" in record) update.lookupStrategy = lookupStrategy;
  validateDirectUrlForStrategy(lookupStrategy, directUrl);
  if ("directUrl" in record) update.directUrl = directUrl;
  if ("priority" in record) update.priority = readOptionalInteger(record, "priority") ?? 100;
  if ("enabled" in record) update.enabled = readRequiredBoolean(record, "enabled");
  if ("isPrimary" in record) update.isPrimary = readRequiredBoolean(record, "isPrimary");
  if ("notes" in record) update.notes = readOptionalString(record, "notes");

  return update;
}

function validateDirectUrlForStrategy(
  lookupStrategy: LookupStrategy,
  directUrl: string | null
): void {
  if (
    directUrl !== null &&
    lookupStrategy !== "direct_url" &&
    lookupStrategy !== "search_then_detail"
  ) {
    throw new SupplierMappingValidationError(
      "direct_url_not_allowed",
      "directUrl is only allowed for direct_url or search_then_detail lookup strategy"
    );
  }
}

function assertNoSensitiveFields(input: unknown): void {
  if (input === null || typeof input !== "object") return;

  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (SENSITIVE_KEY_PATTERN.test(key)) {
      throw new SupplierMappingValidationError(
        "sensitive_field",
        `Sensitive field is not allowed: ${key}`
      );
    }
    assertNoSensitiveFields(value);
  }
}

function asRecord(input: unknown): Record<string, unknown> {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    throw new SupplierMappingValidationError("invalid_body", "Request body must be an object");
  }
  return input as Record<string, unknown>;
}

function readRequiredString(record: Record<string, unknown>, key: string): string {
  const value = readOptionalString(record, key);
  if (value === null) {
    throw new SupplierMappingValidationError("missing_field", `${key} is required`);
  }
  return value;
}

function readOptionalString(record: Record<string, unknown>, key: string): string | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "string") {
    throw new SupplierMappingValidationError("invalid_field", `${key} must be a string`);
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

function readUuid(record: Record<string, unknown>, key: string): string {
  const value = readRequiredString(record, key);
  validateUuid(value, key);
  return value;
}

export function validateUuid(value: string, field: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new SupplierMappingValidationError("invalid_uuid", `${field} must be a UUID`);
  }
}

function readLookupStrategy(
  record: Record<string, unknown>,
  key: string,
  required: boolean
): LookupStrategy | null {
  const value = readOptionalString(record, key);
  if (value === null) {
    if (required) throw new SupplierMappingValidationError("missing_field", `${key} is required`);
    return null;
  }
  if (!LOOKUP_STRATEGIES.includes(value as LookupStrategy)) {
    throw new SupplierMappingValidationError(
      "invalid_lookup_strategy",
      `Invalid lookup strategy: ${value}`
    );
  }
  return value as LookupStrategy;
}

function readOptionalInteger(record: Record<string, unknown>, key: string): number | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "number" || !Number.isInteger(value)) {
    throw new SupplierMappingValidationError("invalid_field", `${key} must be an integer`);
  }
  return value;
}

function readRequiredBoolean(record: Record<string, unknown>, key: string): boolean {
  const value = record[key];
  if (typeof value !== "boolean") {
    throw new SupplierMappingValidationError("invalid_field", `${key} must be a boolean`);
  }
  return value;
}

function readOptionalBoolean(record: Record<string, unknown>, key: string): boolean | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "boolean") {
    throw new SupplierMappingValidationError("invalid_field", `${key} must be a boolean`);
  }
  return value;
}

export function buildMappingSuggestions(input: {
  product: {
    id: string;
    sku: string;
    suggestedSupplierArticle: string | null;
    internalSkuSuffix: string | null;
  };
  suppliers: Array<{ id: string; code: string; name: string }>;
}) {
  const product = input.product;

  if (!product.suggestedSupplierArticle && !product.sku.includes("__")) {
    return {
      catalogProductId: product.id,
      sku: product.sku,
      suggestedSupplierArticle: product.suggestedSupplierArticle,
      internalSkuSuffix: product.internalSkuSuffix,
      suggestedMappings: [],
      reason: "missing_suggested_supplier_article",
    };
  }

  return {
    catalogProductId: product.id,
    sku: product.sku,
    suggestedSupplierArticle: product.suggestedSupplierArticle,
    internalSkuSuffix: product.internalSkuSuffix,
    suggestedMappings: input.suppliers.flatMap((supplier) => {
      let articles = product.suggestedSupplierArticle ? [product.suggestedSupplierArticle] : [];
      if (product.sku.includes("__")) {
        const all = readWooSkuArticleCandidates(product.sku);
        articles =
          supplier.code === "dvg-devecchi"
            ? all.filter(isDvgPrefixedArticleCandidate)
            : supplier.code === "lf-spare-parts-724"
              ? all.filter((article) => /^\d{4,10}$/.test(article))
              : all;
      }
      return articles.map((article) => ({
        supplierId: supplier.id,
        supplierCode: supplier.code,
        supplierName: supplier.name,
        suggestedSupplierArticleNumber: article,
        defaultLookupStrategy: "search_result" as const,
      }));
    }),
  };
}

export function validateDvgMappingReviewPreviewInput(input: unknown): DvgMappingReviewPreviewInput {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  const catalogProductId = readOptionalString(record, "catalogProductId");
  if (catalogProductId !== null) validateUuid(catalogProductId, "catalogProductId");

  const blockingSafetyFlags = readOptionalStringArray(record, "blockingSafetyFlags") ?? [];
  return {
    catalogProductId: catalogProductId ?? undefined,
    expectedArticle: readOptionalString(record, "expectedArticle"),
    parsedDvgArticle: readOptionalString(record, "parsedDvgArticle"),
    parsedOriginalCode: readOptionalString(record, "parsedOriginalCode"),
    mappingSource: readOptionalString(record, "mappingSource"),
    existingMapping: readOptionalExistingMapping(record["existingMapping"]),
    invalidOrAccessDenied: readOptionalBoolean(record, "invalidOrAccessDenied") ?? false,
    currentPriceNetEur: readOptionalNumber(record, "currentPriceNetEur"),
    currency: readOptionalString(record, "currency"),
    blockingSafetyFlags,
  };
}

export function buildDvgMappingReviewPreview(input: {
  preview: DvgMappingReviewPreviewInput;
  catalogFallback?: { expectedArticle?: string | null; mappingSource?: string | null } | null;
}): DvgMappingReviewPreviewResponse {
  const expectedArticle =
    input.preview.expectedArticle ?? input.catalogFallback?.expectedArticle ?? null;
  const mappingSource = input.preview.mappingSource ?? input.catalogFallback?.mappingSource ?? null;
  const review = decideDvgMappingReview({
    expectedArticle,
    parsedDvgArticle: input.preview.parsedDvgArticle,
    parsedOriginalCode: input.preview.parsedOriginalCode,
    mappingSource,
    existingMapping: input.preview.existingMapping,
    invalidOrAccessDenied: input.preview.invalidOrAccessDenied,
  });
  const snapshotGate = decideDvgPriceSnapshotGate({
    loginSucceeded: true,
    currentPriceNetEur: input.preview.currentPriceNetEur,
    currency: input.preview.currency,
    reviewOutcome: review.outcome,
    blockingSafetyFlags: input.preview.blockingSafetyFlags,
  });

  return {
    outcome: review.outcome,
    priceSnapshotAllowed: snapshotGate.allowed,
    suggestedSupplierArticle: review.suggestedSupplierArticle,
    discoveredSupplierArticle: review.discoveredSupplierArticle,
    reason: snapshotGate.allowed ? review.reason : snapshotGate.reason,
    warnings: [...review.warnings, ...snapshotGate.warnings],
    snapshotGate,
  };
}

export function deriveDvgExpectedArticleFromCatalogProduct(product: {
  sku: string;
  suggestedSupplierArticle: string | null;
}): { expectedArticle: string | null; mappingSource: string | null } {
  const dvgCandidate = readDvgAutoPairCandidate(product);
  if (dvgCandidate)
    return {
      expectedArticle: dvgCandidate.supplierArticleNumber,
      mappingSource: dvgCandidate.source,
    };
  if (!product.sku.includes("__") && product.suggestedSupplierArticle?.trim()) {
    return {
      expectedArticle: product.suggestedSupplierArticle.trim(),
      mappingSource: "catalog_suggested_supplier_article",
    };
  }

  const skuPrefix = product.sku.includes("__")
    ? null
    : parseWooSku(product.sku).supplierArticleCandidate;
  return skuPrefix
    ? { expectedArticle: skuPrefix, mappingSource: "sku_prefix" }
    : { expectedArticle: null, mappingSource: "none" };
}

export function readDvgAutoPairCandidate(input: {
  sku: string;
  suggestedSupplierArticle: string | null;
}): DvgAutoPairCandidate | null {
  const suggested = normalizeDvgAutoPairArticle(input.suggestedSupplierArticle);
  if (suggested !== null) {
    return { supplierArticleNumber: suggested, source: "suggested_supplier_article" };
  }

  const articles = readWooSkuArticleCandidates(input.sku)
    .map(normalizeDvgAutoPairArticle)
    .filter((article): article is string => article !== null);
  if (articles.length === 1)
    return {
      supplierArticleNumber: articles[0]!,
      source: input.sku.includes("__") ? "sku_article" : "sku_prefix",
    };
  return null;
}

export function buildDvgAutoPairDirectUrl(supplierArticleNumber: string): string {
  return buildDvgDetailUrl(supplierArticleNumber).toString();
}

function normalizeDvgAutoPairArticle(value: string | null | undefined): string | null {
  const trimmed = value?.trim();
  if (!trimmed) return null;
  if (!isDvgPrefixedArticleCandidate(trimmed)) return null;
  return trimmed.toUpperCase();
}

function readOptionalStringArray(record: Record<string, unknown>, key: string): string[] | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (!Array.isArray(value)) {
    throw new SupplierMappingValidationError("invalid_field", `${key} must be an array`);
  }
  return value.map((item) => {
    if (typeof item !== "string") {
      throw new SupplierMappingValidationError("invalid_field", `${key} must contain strings`);
    }
    return item.trim();
  });
}

function readOptionalNumber(record: Record<string, unknown>, key: string): number | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "number") {
    throw new SupplierMappingValidationError("invalid_field", `${key} must be a number`);
  }
  return value;
}

function readOptionalExistingMapping(
  input: unknown
): { supplierArticleNumber?: string | null } | null {
  if (input === undefined || input === null) return null;
  if (typeof input !== "object" || Array.isArray(input)) {
    throw new SupplierMappingValidationError("invalid_field", "existingMapping must be an object");
  }
  const record = input as Record<string, unknown>;
  return { supplierArticleNumber: readOptionalString(record, "supplierArticleNumber") };
}
