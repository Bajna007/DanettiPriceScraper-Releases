import assert from "node:assert/strict";
import type { SupplierArticleChangesState, SupplierArticleChangeItem } from "@danetti/shared";
import { ArticleChangesCoordinator, articleReviewId } from "./article-changes.coordinator.js";
import { registerSupplierArticleChangesRoutes } from "./article-changes.routes.js";
import Fastify from "fastify";
const id = "11111111-1111-4111-8111-111111111111";
const calls: string[] = [];
const services = Object.fromEntries(
  (["dvg", "lf"] as const).map((supplier) => {
    const item = {
      supplier,
      catalogProductId: id,
      originalArticle: supplier === "dvg" ? "OLD" : "1000001",
      sourceStatus: "article_changed",
    } as SupplierArticleChangeItem;
    const state: SupplierArticleChangesState = {
      items: [item],
      sourceRunId: supplier,
      job: null,
      updatedAt: new Date().toISOString(),
    };
    let task: Promise<void> | null = null;
    return [
      supplier,
      {
        list: async () => structuredClone(state),
        review: async (productId: string, article: string, decision: string) => {
          assert.equal(productId, id);
          assert.equal(article, item.originalArticle);
          calls.push(`review:${supplier}:${decision}`);
          return structuredClone(state);
        },
        start: async (ids: string[]) => {
          calls.push(supplier);
          assert.deepEqual(ids, [id]);
          state.job = {
            supplier,
            runId: supplier + calls.length,
            status: "running",
            checked: 0,
            total: 1,
            currentArticle: item.originalArticle,
            startedAt: new Date().toISOString(),
            finishedAt: null,
            message: null,
          };
          task = new Promise<void>((resolve) =>
            setImmediate(() => {
              state.job!.checked = 1;
              state.job!.status = "completed";
              resolve();
            })
          );
          return structuredClone(state);
        },
        settled: async () => {
          await task;
        },
        cancel: async () => {
          await task;
          state.job!.status = "cancelled";
          return structuredClone(state);
        },
        close: async () => {},
      },
    ];
  })
) as unknown as ConstructorParameters<typeof ArticleChangesCoordinator>[0];
let saved: SupplierArticleChangesState | null = null;
const storage = {
  load: async () => saved,
  save: async (state: SupplierArticleChangesState) => {
    saved = structuredClone(state);
  },
};
const coordinator = new ArticleChangesCoordinator(services, storage);
const initial = await coordinator.list();
assert.equal(initial.items.length, 2);
assert.equal(new Set(initial.items.map(articleReviewId)).size, 2);
await coordinator.start(initial.items.map(articleReviewId));
await assert.rejects(coordinator.start(initial.items.map(articleReviewId)), /Már fut/);
await assert.rejects(coordinator.review(`dvg:${id}`, "OLD", "resolved"), /Várd meg/);
await coordinator.settled();
const done = await coordinator.list();
assert.deepEqual(calls, ["dvg", "lf"]);
assert.equal(done.job?.checked, 2);
assert.equal(done.job?.total, 2);
assert.equal(done.job?.status, "completed");
const app = Fastify();
await registerSupplierArticleChangesRoutes(app, { coordinator });
const headers = { "x-danetti-local-lab": "true" };
assert.equal((await app.inject({ url: "/article-changes" })).statusCode, 403);
for (const payload of [
  { reviewIds: [id] },
  { reviewIds: [`dvg:${id}`, `dvg:${id}`] },
  { url: "https://evil.invalid" },
  { reviewIds: [`other:${id}`] },
])
  assert.equal(
    (await app.inject({ method: "POST", url: "/article-changes/run", headers, payload }))
      .statusCode,
    400
  );
assert.equal((await app.inject({ url: "/dvg-article-changes", headers })).json().items.length, 1);
assert.equal((await app.inject({ url: "/article-changes", headers })).json().items.length, 2);
for (const payload of [
  { reviewId: id, originalArticle: "OLD", decision: "resolved" },
  { reviewId: `lf:${id}`, originalArticle: "", decision: "resolved" },
  { reviewId: `lf:${id}`, originalArticle: "1000001", decision: "bad" },
])
  assert.equal(
    (await app.inject({ method: "POST", url: "/article-changes/review", headers, payload }))
      .statusCode,
    400
  );
assert.equal(
  (
    await app.inject({
      method: "POST",
      url: "/article-changes/review",
      payload: { reviewId: `lf:${id}`, originalArticle: "1000001", decision: "resolved" },
    })
  ).statusCode,
  403
);
assert.equal(
  (
    await app.inject({
      method: "POST",
      url: "/article-changes/review",
      headers,
      payload: { reviewId: `lf:${id}`, originalArticle: "1000001", decision: "resolved" },
    })
  ).statusCode,
  200
);
assert.equal(calls.at(-1), "review:lf:resolved");
await app.close();
calls.length = 0;
const cancellable = new ArticleChangesCoordinator(services, {
  load: async () => null,
  save: async () => {},
});
await cancellable.start(initial.items.map(articleReviewId));
await cancellable.cancel();
assert.deepEqual(calls, ["dvg"], "cancelling the current supplier must not start queued LF work");
assert.equal((await cancellable.list()).job?.status, "cancelled");
await cancellable.close();
const interrupted = new ArticleChangesCoordinator(services, {
  ...storage,
  load: async () => ({ ...done, job: { ...done.job!, status: "running" } }),
});
assert.equal((await interrupted.list()).job?.status, "interrupted");
await interrupted.close();
console.log(
  "Shared DVG/LF queue, composite identities, sequential supplier groups, cancellation, concurrency, route guards and restart persistence passed"
);
