import assert from "node:assert/strict";
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import { sql } from "drizzle-orm";
import { schema } from "@danetti/db";
import { CatalogImportRepository, type CatalogProductSortBy } from "./catalog-import.repository.js";

const url = process.env.CATALOG_SHEET_TEST_DATABASE_URL;
if (!url) throw new Error("CATALOG_SHEET_TEST_DATABASE_URL must point to the local test database");
const client = postgres(url, { max: 1 });
try {
  await drizzle(client, { schema }).transaction(async (testDb) => {
    const tx = Object.assign(
      (strings: TemplateStringsArray, ...parameters: unknown[]) =>
        testDb.execute(sql(strings, ...parameters)),
      { unsafe: (query: string) => testDb.execute(sql.raw(query)) }
    );
    await tx`SET LOCAL search_path TO pg_temp`;
    // Transaction-owned shadow tables never read or alter the operator's catalog.
    for (const table of ["catalog_products", "suppliers", "supplier_mappings"])
      await tx.unsafe(
        `create temp table ${table} (like public.${table} including defaults) on commit drop`
      );
    const names = ["Cecil", "Ábel", "Béla", "Dénes"];
    const values = [100, 2, 10, null];
    const supplier = (
      await tx`insert into suppliers (code, name, base_url) values ('DVG', 'DVG', 'https://example.invalid') returning id`
    )[0]!;
    const lf = (
      await tx`insert into suppliers (code, name, base_url) values ('lf-spare-parts-724', 'LF', 'https://example.invalid') returning id`
    )[0]!;
    for (let i = 0; i < values.length; i++) {
      const [product] =
        await tx`insert into catalog_products (sku, name, current_price, dvg_purchase_price_eur, lf_purchase_price_eur)
        values (${`T${i}`}, ${names[i]!}, ${values[i]}, ${i === 1 ? 999 : values[i]}, ${i === 1 ? 2 : null}) returning id`;
      await tx`insert into supplier_mappings (catalog_product_id, supplier_id, supplier_article_number, is_primary) values (${product!.id}, ${i === 1 ? lf.id : supplier.id}, ${`A${i}`}, true)`;
    }
    const repository = new CatalogImportRepository(testDb);
    for (const sortBy of [
      "sku",
      "name",
      "supplier",
      "supplierArticle",
      "url",
      "dvgSupplierArticle",
      "dvgPurchaseEur",
      "dvgPurchaseHuf",
      "dvgWooGross",
      "dvgWooNet",
      "dvgProfitHuf",
      "dvgProfitPercent",
      "targetWooGross",
      "dvgUpdated",
      "dvgStatus",
      "suggestedArticle",
      "suffix",
      "currentPrice",
      "regularPrice",
      "salePrice",
      "lastSeen",
    ] satisfies CatalogProductSortBy[]) {
      for (const sortDirection of ["asc", "desc"] as const) {
        const result = await repository.listProducts({
          limit: 2,
          offset: 0,
          sortBy,
          sortDirection,
          eurHufRate: 400,
          vatPercent: 27,
          targetProfitMultiplier: 1.5,
          roundingEnabled: true,
          roundingIncrementHuf: 100,
        });
        assert.equal(result.total, 4);
        assert.equal(result.products.length, 2);
      }
    }
    for (const [sortBy, expected] of [
      ["name", ["Ábel", "Béla", "Cecil", "Dénes"]],
      ["currentPrice", ["Ábel", "Béla", "Cecil", "Dénes"]],
      ["dvgPurchaseEur", ["Ábel", "Béla", "Cecil", "Dénes"]],
    ] as const) {
      const all = [];
      for (let offset = 0; offset < 4; offset += 2)
        all.push(
          ...(
            await repository.listProducts({ limit: 2, offset, sortBy, sortDirection: "asc" })
          ).products.map((product) => product.name)
        );
      assert.deepEqual(all, expected);
    }
    const descending = await repository.listProducts({
      limit: 4,
      offset: 0,
      sortBy: "currentPrice",
      sortDirection: "desc",
    });
    assert.deepEqual(
      descending.products.map((product) => product.name),
      ["Cecil", "Béla", "Ábel", "Dénes"]
    );
    await tx`update catalog_products set dvg_last_run_status = case sku when 'T0' then 'skipped' when 'T2' then 'failed' else null end, lf_last_run_status = case sku when 'T1' then 'ok' else null end`;
    const statuses = await repository.listProducts({
      limit: 4,
      offset: 0,
      sortBy: "dvgStatus",
      sortDirection: "asc",
    });
    assert.deepEqual(
      statuses.products.map((product) => product.name),
      ["Béla", "Cecil", "Dénes", "Ábel"]
    );
    await tx`update catalog_products set lf_last_run_message = 'Ár hiányzik' where sku = 'T1'`;
    const messages = await repository.listProducts({
      limit: 4,
      offset: 0,
      sortBy: "dvgStatus",
      sortDirection: "asc",
    });
    assert.deepEqual(
      messages.products.map((product) => product.name),
      ["Béla", "Cecil", "Ábel", "Dénes"]
    );
  });
  console.log(
    "Catalog sheet global sorting passed: every data column, numeric/text, mapping-aware prices, pagination and nulls"
  );
} finally {
  await client.end();
}
