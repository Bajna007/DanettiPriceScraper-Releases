import assert from "node:assert/strict";
import { parseWooSku } from "@danetti/db";
import type { CatalogImportRepository } from "./catalog-import.repository.js";
import {
  buildValidationReport,
  CatalogImportService,
  classifyCatalogImportRows,
  parseWooCsv,
  summarizeClassifiedRows,
} from "./catalog-import.service.js";
import { CatalogImportValidationError } from "./catalog-import.types.js";

const productRow = {
  ID: "101",
  Type: "simple",
  SKU: "421944065151_SAE125",
  Name: "Dining Chair",
  Published: "1",
  "Visibility in catalog": "visible",
  "Regular price": "199.99",
  "Sale price": "149.99",
  "Global Unique ID": "5991234567890",
  Categories: "Chairs, Dining",
  Tags: "oak, upholstered",
  "In stock?": "1",
  Stock: "12",
  "Attribute 1 name": "Color",
  "Attribute 1 value(s)": "Oak",
};

const parsedProductRows = [{ rowNumber: 2, rawRow: productRow }];

const previewRows = classifyCatalogImportRows({
  mode: "preview_only",
  parsedRows: parsedProductRows,
  existingProducts: [],
});
const previewSummary = summarizeClassifiedRows(previewRows, "preview_only");
assert.equal(previewRows[0]?.status, "inserted");
assert.equal(previewRows[0]?.wouldInsert, true);
assert.equal(previewSummary.insertedCount, 1);
assert.equal(previewSummary.updatedCount, 0);

const addOnlyRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: parsedProductRows,
  existingProducts: [],
});
const addOnlySummary = summarizeClassifiedRows(addOnlyRows, "add_only");
assert.equal(addOnlyRows[0]?.status, "inserted");
assert.equal(addOnlyRows[0]?.wouldInsert, true);
assert.equal(addOnlyRows[0]?.productInput?.sku, "421944065151_SAE125");
assert.equal(addOnlyRows[0]?.productInput?.barcodeOrGlobalId, "5991234567890");
assert.equal(addOnlyRows[0]?.productInput?.suggestedSupplierArticle, "421944065151");
assert.equal(addOnlyRows[0]?.productInput?.internalSkuSuffix, "SAE125");

const labeledSkuRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: [
    {
      rowNumber: 2,
      rawRow: { ...productRow, SKU: "Cikkszám: 1394009_UN715" },
    },
  ],
  existingProducts: [],
});
assert.equal(labeledSkuRows[0]?.sku, "1394009_UN715");
assert.equal(labeledSkuRows[0]?.productInput?.sku, "1394009_UN715");
assert.equal(labeledSkuRows[0]?.productInput?.suggestedSupplierArticle, "1394009");
assert.equal(labeledSkuRows[0]?.productInput?.internalSkuSuffix, "UN715");
assert.deepEqual(addOnlyRows[0]?.normalized.categories, ["Chairs", "Dining"]);
assert.deepEqual(addOnlyRows[0]?.normalized.tags, ["oak", "upholstered"]);
assert.deepEqual(addOnlyRows[0]?.normalized.attributes, { Color: "Oak" });
assert.equal(addOnlySummary.insertedCount, 1);

const existingRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: parsedProductRows,
  existingProducts: [{ id: "existing-product-id", sku: "421944065151_SAE125" }],
});
assert.equal(existingRows[0]?.status, "skipped_existing");
assert.equal(existingRows[0]?.wouldInsert, false);

const fullSyncExistingRows = classifyCatalogImportRows({
  mode: "update_existing",
  parsedRows: parsedProductRows,
  existingProducts: [{ id: "existing-product-id", sku: "421944065151_SAE125" }],
});
const fullSyncExistingSummary = summarizeClassifiedRows(fullSyncExistingRows, "update_existing");
assert.equal(fullSyncExistingRows[0]?.status, "updated");
assert.equal(fullSyncExistingRows[0]?.wouldInsert, false);
assert.equal(fullSyncExistingRows[0]?.productInput?.regularPrice, "199.99");
assert.equal(fullSyncExistingSummary.insertedCount, 0);
assert.equal(fullSyncExistingSummary.updatedCount, 1);

const duplicateRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: [
    { rowNumber: 2, rawRow: productRow },
    { rowNumber: 3, rawRow: { ...productRow, Name: "Duplicate Chair" } },
  ],
  existingProducts: [],
});
assert.equal(duplicateRows[0]?.status, "skipped_duplicate");
assert.equal(duplicateRows[0]?.errorCode, null);
assert.equal(duplicateRows[0]?.warningCode, "duplicate_sku");
assert.equal(duplicateRows[1]?.status, "inserted");
assert.equal(duplicateRows[1]?.warningCode, "duplicate_sku");

const missingSkuRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: [{ rowNumber: 2, rawRow: { ID: "102", Name: "Missing SKU" } }],
  existingProducts: [],
});
assert.equal(missingSkuRows[0]?.status, "skipped_missing_sku");
assert.equal(missingSkuRows[0]?.errorCode, null);
assert.equal(missingSkuRows[0]?.warningCode, "missing_sku");

const invalidPriceRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: [{ rowNumber: 2, rawRow: { ...productRow, "Regular price": "not-a-price" } }],
  existingProducts: [],
});
assert.equal(invalidPriceRows[0]?.status, "inserted");
assert.equal(invalidPriceRows[0]?.errorCode, null);
assert.equal(invalidPriceRows[0]?.warningCode, "invalid_regular_price");
assert.equal(invalidPriceRows[0]?.productInput?.regularPrice, null);

const emptyNameRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: [{ rowNumber: 2, rawRow: { ...productRow, Name: "" } }],
  existingProducts: [],
});
assert.equal(emptyNameRows[0]?.status, "inserted");
assert.equal(emptyNameRows[0]?.errorCode, null);
assert.equal(emptyNameRows[0]?.warningCode, "missing_name");
assert.equal(emptyNameRows[0]?.productInput?.name, "Név nélküli termék (421944065151_SAE125)");

const unsupportedTypeRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: [{ rowNumber: 2, rawRow: { ...productRow, Type: "bundle_plus" } }],
  existingProducts: [],
});
assert.equal(unsupportedTypeRows[0]?.status, "inserted");
assert.equal(unsupportedTypeRows[0]?.errorCode, null);
assert.equal(unsupportedTypeRows[0]?.warningCode, "unsupported_type");

const missingParentRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: [
    {
      rowNumber: 2,
      rawRow: { ...productRow, Type: "variation", Parent: "", "Parent SKU": "" },
    },
  ],
  existingProducts: [],
});
assert.equal(missingParentRows[0]?.status, "inserted");
assert.equal(missingParentRows[0]?.errorCode, null);
assert.equal(missingParentRows[0]?.warningCode, "missing_variation_parent");

const skuWarningRows = classifyCatalogImportRows({
  mode: "add_only",
  parsedRows: [{ rowNumber: 2, rawRow: { ...productRow, SKU: "NO_UNDERSCORE_EXTRA" } }],
  existingProducts: [],
});
const skuWarningParsedCsv = parseWooCsv(
  Buffer.from("SKU,Name\nNO_UNDERSCORE_EXTRA,Dining Chair\n", "utf8")
);
const validationReport = buildValidationReport(skuWarningRows, skuWarningParsedCsv.columnMapping);
assert.equal(skuWarningRows[0]?.warningCode, "sku_format_warning");
assert.equal(
  validationReport.warnings.some((warning) => warning.code === "sku_format_warning"),
  true
);
assert.equal(validationReport.warnings[0]?.name, "Dining Chair");

const fallbackNameCsv = parseWooCsv(
  Buffer.from("SKU,Termék neve\nNO_UNDERSCORE_EXTRA,Fallback Name Chair\n", "utf8")
);
const fallbackNameRows = classifyCatalogImportRows({
  mode: "preview_only",
  parsedRows: fallbackNameCsv.rows,
  columnMapping: fallbackNameCsv.columnMapping,
  existingProducts: [],
});
const fallbackNameReport = buildValidationReport(fallbackNameRows, fallbackNameCsv.columnMapping);
assert.equal(fallbackNameRows[0]?.status, "inserted");
assert.equal(fallbackNameRows[0]?.productInput?.name, "Fallback Name Chair");
assert.equal(
  fallbackNameReport.warnings.some(
    (warning) => warning.code === "sku_format_warning" && warning.name === "Fallback Name Chair"
  ),
  true
);
assert.equal(
  fallbackNameReport.warnings.some((warning) => warning.code === "missing_name"),
  false
);

assert.deepEqual(parseWooSku("421944065151_SAE125"), {
  fullSku: "421944065151_SAE125",
  supplierArticleCandidate: "421944065151",
  internalSuffix: "SAE125",
});

const parsedCsv = parseWooCsv(
  Buffer.from("\ufeffID,SKU,Name\n101, 421944065151_SAE125 , Dining Chair\n", "utf8")
);
assert.equal(parsedCsv.rows.length, 1);
assert.equal(parsedCsv.rows[0]?.rawRow.SKU, "421944065151_SAE125");
assert.equal(parsedCsv.rows[0]?.rowNumber, 2);
assert.equal(parsedCsv.columnMapping.effectiveMapping.sku, "SKU");

const missingSkuCsv = parseWooCsv(Buffer.from("ID,Name\n101,Dining Chair\n", "utf8"));
const missingSkuReport = buildValidationReport(
  classifyCatalogImportRows({
    mode: "preview_only",
    parsedRows: missingSkuCsv.rows,
    columnMapping: missingSkuCsv.columnMapping,
    existingProducts: [],
  }),
  missingSkuCsv.columnMapping
);
assert.deepEqual(missingSkuReport.missingRequiredColumns, []);

const huCsv = parseWooCsv(
  Buffer.from("Azonosító,Cikkszám,Név,Normál ár,Vonalkód\n101,HU_1,Szék,12,599\n", "utf8")
);
assert.equal(huCsv.columnMapping.effectiveMapping.sku, "Cikkszám");
assert.equal(huCsv.columnMapping.effectiveMapping.barcodeOrGlobalId, "Vonalkód");

assert.throws(() => parseWooCsv(Buffer.from("", "utf8")), CatalogImportValidationError);

const fullSyncRepository = createImportRepositoryStub({
  existingProducts: [{ id: "existing-product-id", sku: "421944065151_SAE125" }],
});
const fullSyncService = new CatalogImportService(fullSyncRepository.repository);
const fullSyncResult = await fullSyncService.importCsv({
  mode: "update_existing",
  uploadedCsv: buildUploadedCsv(),
  parsedCsv: parseWooCsv(
    Buffer.from(
      "ID,Type,SKU,Name,Regular price\n101,simple,421944065151_SAE125,Dining Chair,249.99\n102,simple,999999_NEW,New Product,99.00\n",
      "utf8"
    )
  ),
});
assert.equal(fullSyncResult.insertedCount, 1);
assert.equal(fullSyncResult.updatedCount, 1);
assert.equal(fullSyncResult.deletedCount, 0);
assert.deepEqual(
  fullSyncRepository.upserts.map((input) => input.sku),
  ["421944065151_SAE125", "999999_NEW"]
);
assert.equal(fullSyncRepository.upserts[0]?.regularPrice, "249.99");
assert.deepEqual(
  fullSyncRepository.importRows.map((row) => row.status),
  ["updated", "inserted"]
);
assert.equal(fullSyncRepository.lastSummary?.status, "completed");

const invalidPriceFullSyncRepository = createImportRepositoryStub({
  existingProducts: [{ id: "existing-product-id", sku: "421944065151_SAE125" }],
});
const invalidPriceFullSyncService = new CatalogImportService(
  invalidPriceFullSyncRepository.repository
);
const invalidPriceFullSyncResult = await invalidPriceFullSyncService.importCsv({
  mode: "update_existing",
  uploadedCsv: buildUploadedCsv(),
  parsedCsv: parseWooCsv(
    Buffer.from(
      "ID,Type,SKU,Name,Regular price\n101,simple,421944065151_SAE125,Dining Chair,249.99\n102,simple,999999_NEW,Broken Product,not-a-price\n",
      "utf8"
    )
  ),
});
assert.equal(invalidPriceFullSyncResult.insertedCount, 1);
assert.equal(invalidPriceFullSyncResult.updatedCount, 1);
assert.equal(invalidPriceFullSyncResult.deletedCount, 0);
assert.deepEqual(
  invalidPriceFullSyncRepository.upserts.map((input) => input.sku),
  ["421944065151_SAE125", "999999_NEW"]
);
assert.equal(invalidPriceFullSyncRepository.upserts[1]?.regularPrice, null);
assert.equal(
  invalidPriceFullSyncResult.validation.warnings.some(
    (warning) => warning.code === "invalid_regular_price" && warning.name === "Broken Product"
  ),
  true
);
assert.deepEqual(
  invalidPriceFullSyncRepository.importRows.map((row) => row.status),
  ["updated", "inserted"]
);
assert.equal(invalidPriceFullSyncRepository.lastSummary?.status, "completed");

const missingNameFullSyncRepository = createImportRepositoryStub({
  existingProducts: [{ id: "existing-product-id", sku: "421944065151_SAE125" }],
});
const missingNameFullSyncService = new CatalogImportService(
  missingNameFullSyncRepository.repository
);
const missingNameFullSyncResult = await missingNameFullSyncService.importCsv({
  mode: "update_existing",
  uploadedCsv: buildUploadedCsv(),
  parsedCsv: parseWooCsv(
    Buffer.from(
      "ID,Type,SKU,Name,Regular price\n101,simple,421944065151_SAE125,Dining Chair,249.99\n102,simple,999999_NEW,,99.00\n",
      "utf8"
    )
  ),
});
assert.equal(missingNameFullSyncResult.insertedCount, 1);
assert.equal(missingNameFullSyncResult.updatedCount, 1);
assert.equal(missingNameFullSyncResult.failedCount, 0);
assert.equal(missingNameFullSyncRepository.upserts.length, 2);
assert.deepEqual(
  missingNameFullSyncRepository.importRows.map((row) => row.status),
  ["updated", "inserted"]
);
assert.equal(missingNameFullSyncRepository.upserts[1]?.name, "Név nélküli termék (999999_NEW)");
assert.equal(
  missingNameFullSyncResult.validation.warnings.some((warning) => warning.code === "missing_name"),
  true
);
assert.equal(missingNameFullSyncRepository.lastSummary?.status, "completed");

console.log("Catalog import classification tests passed");

function buildUploadedCsv() {
  return {
    filename: "products.csv",
    mimetype: "text/csv",
    buffer: Buffer.from("SKU,Name\n", "utf8"),
    fileSha256: "sha256",
    fileSizeBytes: 9,
  };
}

function createImportRepositoryStub(input: {
  existingProducts: Array<{ id: string; sku: string }>;
}) {
  const upserts: Array<{ sku?: string; name?: string; regularPrice?: string | null }> = [];
  const importRows: Array<{ status: string }> = [];
  let lastSummary: { status: string } | null = null;
  const repository = {
    async transaction<T>(handler: (repository: CatalogImportRepository) => Promise<T>) {
      return handler(repository as unknown as CatalogImportRepository);
    },
    async createImportRun() {
      return { id: "import-run-id" };
    },
    async listExistingProductsBySku() {
      return input.existingProducts;
    },
    async insertCatalogProductAddOnly() {
      throw new Error("add-only path must not be used in full sync test");
    },
    async upsertCatalogProductFromCsv(product: {
      sku?: string;
      name?: string;
      regularPrice?: string | null;
    }) {
      upserts.push(product);
      return {
        id: product.sku === "421944065151_SAE125" ? "existing-product-id" : "new-product-id",
        sku: product.sku ?? "missing-sku",
      };
    },
    async createImportRows(rows: Array<{ status: string }>) {
      importRows.push(...rows);
    },
    async updateImportRunSummary(_id: string, summary: { status: string }) {
      lastSummary = summary;
    },
  };

  return {
    repository: repository as unknown as CatalogImportRepository,
    upserts,
    importRows,
    get lastSummary() {
      return lastSummary;
    },
  };
}
