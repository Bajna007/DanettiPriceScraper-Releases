import assert from "node:assert/strict";

import {
  buildDvgRunMessage,
  buildDvgSupplierPriceSnapshot,
  canPersistDvgTrustedPricingRow,
  canWriteDvgTrustedPricing,
  readDvgOperatorRunNextOffset,
  readDvgPatternArticle,
  type PersistableDvgPricingRow,
} from "./dvg-products.repository.js";
import type { DvgManualBatchState } from "@danetti/connectors";

assert.equal(
  readDvgPatternArticle({ sku: "8B05809_DANETTI", suggestedSupplierArticle: null }),
  "8B05809"
);
assert.equal(
  readDvgPatternArticle({ sku: "8F705/A_F413", suggestedSupplierArticle: null }),
  "8F705/A"
);
assert.equal(
  readDvgPatternArticle({ sku: "SKU_INTERNAL", suggestedSupplierArticle: "8BC05809" }),
  "8BC05809"
);
assert.equal(
  readDvgPatternArticle({ sku: "CS-A2200247_SAE125", suggestedSupplierArticle: null }),
  null
);
assert.equal(
  readDvgPatternArticle({ sku: "421944065151_SAE125", suggestedSupplierArticle: null }),
  null
);

const observedAt = new Date("2026-06-14T08:00:00.000Z");
const persistableRow = {
  status: "ok",
  catalogProductId: "product-1",
  wooSku: "CS-A2200247_SAE125",
  wooName: "Teszt termek",
  supplierId: "supplier-1",
  supplierMappingId: "mapping-1",
  supplierArticleNumber: "CS-A2200247",
  candidateSource: "saved_mapping",
  dvgDetailUrl:
    "https://devecchigiuseppesrl.com/e-commerce/welcome/ordini/dettagli.asp?codice-articolo=CS-A2200247",
  dvgProductName: "DVG termek",
  dvgArticle: "CS-A2200247",
  dvgOriginalCode: "A2200247",
  supplierNetEur: 4.95,
  supplierCrossedEur: null,
  currency: "EUR",
  unit: "pc",
  eurHufRate: 400,
  markupPercent: 30,
  vatPercent: 27,
  matchConfidence: "exact_dvg_article",
  warnings: [],
  wooPriceHuf: 10000,
  wooPriceSource: "currentPrice",
  wooGrossHuf: 10000,
  wooNetHuf: 7874.02,
  supplierNetHuf: 1980,
  targetNetHuf: 2574,
  targetGrossHuf: 3268.98,
  targetGrossHufRounded: null,
  actualProfitNetHuf: 5894.02,
  actualProfitPercentOnCost: 297.68,
  actualGrossDeltaToTargetHuf: 6731.02,
} satisfies PersistableDvgPricingRow;

const snapshot = buildDvgSupplierPriceSnapshot(persistableRow, observedAt);
assert.equal(snapshot.supplierId, "supplier-1");
assert.equal(snapshot.catalogProductId, "product-1");
assert.equal(snapshot.supplierArticleNumber, "CS-A2200247");
assert.equal(snapshot.priceNetEur, "4.95");
assert.equal(snapshot.currency, "EUR");
assert.equal(snapshot.matchConfidence, "exact");
assert.equal(snapshot.observedAt, observedAt);

assert.equal(buildDvgRunMessage(persistableRow), "DVG ár beolvasva.");
assert.equal(
  buildDvgRunMessage({
    ...persistableRow,
    status: "article_changed",
    supplierArticleNumber: "A2200247",
    dvgArticle: "CS-A2200247",
    warnings: ["dvg_supplier_article_changed"],
  }),
  "DVG cikkszám megváltozott: új cikkszám CS-A2200247; mapping ellenőrzés kell."
);
assert.equal(
  buildDvgRunMessage({
    ...persistableRow,
    status: "article_changed",
    supplierArticleNumber: "9V8343",
    dvgArticle: null,
    dvgOriginalCode: "9V8343",
    warnings: ["dvg_supplier_article_changed"],
  }),
  "DVG cikkszám megváltozott; mapping ellenőrzés kell."
);
assert.equal(
  buildDvgRunMessage({
    ...persistableRow,
    status: "price_missing",
    supplierNetEur: null,
    warnings: ["dvg_supplier_not_in_production", "current_price_missing"],
  }),
  "DVG szerint a termék már nem gyártott."
);
assert.equal(
  buildDvgRunMessage({
    ...persistableRow,
    status: "article_not_found",
    supplierNetEur: null,
    warnings: ["dvg_detail_request_info_redirect", "dvg_article_not_found_or_changed"],
  }),
  "DVG nem találta a cikkszámot, vagy request-info/üres oldalra irányított."
);

assert.equal(canWriteDvgTrustedPricing({ dryRun: true, allowSnapshotWrite: false }), false);
assert.equal(canWriteDvgTrustedPricing({ dryRun: false, allowSnapshotWrite: false }), false);
assert.equal(canWriteDvgTrustedPricing({ dryRun: true, allowSnapshotWrite: true }), false);
assert.equal(canWriteDvgTrustedPricing({ dryRun: false, allowSnapshotWrite: true }), true);
assert.equal(
  canPersistDvgTrustedPricingRow(persistableRow, {
    dryRun: false,
    allowSnapshotWrite: true,
  }),
  true
);
assert.equal(
  canPersistDvgTrustedPricingRow(
    {
      ...persistableRow,
      wooSku: "8A4/V_DVG",
      supplierArticleNumber: "8a4/v",
      dvgArticle: "8A4/V",
      dvgOriginalCode: "8A4/V",
    },
    { dryRun: false, allowSnapshotWrite: true }
  ),
  true
);
assert.equal(
  canPersistDvgTrustedPricingRow(
    { ...persistableRow, supplierMappingId: null },
    { dryRun: false, allowSnapshotWrite: true }
  ),
  false
);
assert.equal(
  canPersistDvgTrustedPricingRow(
    { ...persistableRow, candidateSource: "dvg_article_pattern" },
    { dryRun: false, allowSnapshotWrite: true }
  ),
  false
);
assert.equal(
  canPersistDvgTrustedPricingRow(
    { ...persistableRow, currency: "USD" },
    { dryRun: false, allowSnapshotWrite: true }
  ),
  false
);
assert.equal(
  canPersistDvgTrustedPricingRow(
    { ...persistableRow, dvgArticle: "OTHER" },
    { dryRun: false, allowSnapshotWrite: true }
  ),
  false
);
assert.equal(
  canPersistDvgTrustedPricingRow(persistableRow, { dryRun: true, allowSnapshotWrite: false }),
  false
);

const interruptedRunState = {
  runId: "run-1",
  status: "session_lost",
  startedAt: "2026-06-14T08:00:00.000Z",
  completedAt: null,
  settings: {
    speedMode: "normal",
    markupPercent: 0,
    vatPercent: 27,
    eurHufRate: 400,
    wooPricesIncludeVat: true,
    limit: 10,
    offset: 5,
    onlyMappedDvg: true,
    rerunPreviousNonOkOnly: false,
    allowSuggestedDvgArticle: false,
    allowSkuPrefixCandidate: false,
    dryRun: true,
    allowSnapshotWrite: false,
    itemTimeoutMs: 25_000,
    detailFetchTimeoutMs: 10_000,
    fallbackNavigationTimeoutMs: 15_000,
    recoverAfterConsecutiveTimeouts: 3,
  },
  currentItem: null,
  totals: {
    candidates: 10,
    checked: 2,
    ok: 1,
    failed: 1,
    skipped: 0,
    safetyStopped: 0,
  },
  events: [],
  rows: [
    persistableRow,
    { ...persistableRow, status: "redirected_to_login", supplierArticleNumber: "CS-LOGIN" },
  ],
} satisfies DvgManualBatchState;

assert.equal(readDvgOperatorRunNextOffset(interruptedRunState), 6);

assert.deepEqual(
  readDvgPatternArticle({ sku: "1755603__8W17201_W051", suggestedSupplierArticle: "1755603" }),
  "8W17201"
);
assert.equal(
  readDvgPatternArticle({ sku: "8W17201__8S29/1", suggestedSupplierArticle: null }),
  null
);
console.log("DVG products repository tests passed");
