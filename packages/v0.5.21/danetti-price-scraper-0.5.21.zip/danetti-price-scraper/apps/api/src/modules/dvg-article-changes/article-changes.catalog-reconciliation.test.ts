import assert from "node:assert/strict";
import type { SupplierArticleChangeItem } from "@danetti/shared";
import {
  findArticleCatalogCorrections,
  type CatalogImportProof,
} from "./article-changes.catalog-reconciliation.js";
const item = {
  supplier: "dvg",
  catalogProductId: "a",
  originalArticle: "9M620/K",
  newArticle: "9M620K",
  status: "priced",
  newArticleVerified: true,
} as SupplierArticleChangeItem;
const other = { ...item, catalogProductId: "b", originalArticle: "8S240/C", newArticle: "8S41CAP" };
const identities = new Map([
  ["a", "woo-1"],
  ["b", "woo-2"],
]);
const proof = {
  currentSku: "9M620K_X",
  currentWooId: "woo-1",
  catalogProductId: "new-row",
  wooId: "woo-1",
  sku: "9M620K_X",
  importRunId: "csv-completed",
  finishedAt: "2026-10-19T15:00:00Z",
} satisfies CatalogImportProof;
assert.deepEqual(findArticleCatalogCorrections([item, other], identities, [proof]), [
  { catalogProductId: "a", newSku: "9M620K_X", importRunId: "csv-completed" },
]);
for (const proofs of [
  [],
  [{ ...proof, wooId: "unrelated" }],
  [{ ...proof, sku: "9M620/K_X" }],
  [{ ...proof, sku: "9M620/K__9M620K_X" }],
  [proof, { ...proof, catalogProductId: "ambiguous", sku: "9M620/K_X" }],
  [proof, { ...proof, sku: "9M620/K_X", finishedAt: "2026-10-20T15:00:00Z" }],
])
  assert.deepEqual(findArticleCatalogCorrections([item], identities, proofs), []);
assert.deepEqual(findArticleCatalogCorrections([item], new Map(), [proof]), []);
assert.deepEqual(
  findArticleCatalogCorrections(
    [{ ...item, reviewOpenedAt: "2026-10-19T15:00:00.000Z" }],
    identities,
    [proof]
  ),
  [],
  "same CSV cannot close a reopened row"
);
assert.equal(
  findArticleCatalogCorrections([{ ...item, reviewOpenedAt: "2026-10-19T14:59:00Z" }], identities, [
    proof,
  ]).length,
  1
);
assert.deepEqual(
  findArticleCatalogCorrections(
    [{ ...item, newArticleVerified: false, status: "needs_review" }],
    identities,
    [proof]
  ),
  []
);
assert.equal(
  findArticleCatalogCorrections([item], identities, [
    { ...proof, sku: "1755603__9m620k_X", currentSku: "1755603__9m620k_X" },
  ]).length,
  1
);
console.log(
  "CSV corrections require unique stable Woo identity, verified successor and latest completed-import SKU; partial/ambiguous/missing/reverted rows retained"
);
