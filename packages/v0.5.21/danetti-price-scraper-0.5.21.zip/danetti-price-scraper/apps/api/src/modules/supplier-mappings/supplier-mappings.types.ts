import type { NewSupplierMapping, SupplierMapping } from "@danetti/db";
import type { LookupStrategy } from "../suppliers/suppliers.types.js";

export interface CreateSupplierMappingInput {
  catalogProductId: string;
  supplierId: string;
  supplierArticleNumber: string;
  lookupStrategy: LookupStrategy;
  supplierProductNameOverride?: string | null;
  directUrl?: string | null;
  priority?: number;
  enabled?: boolean;
  isPrimary?: boolean;
  notes?: string | null;
}

export interface UpdateSupplierMappingInput {
  supplierArticleNumber?: string;
  supplierProductNameOverride?: string | null;
  lookupStrategy?: LookupStrategy;
  directUrl?: string | null;
  priority?: number;
  enabled?: boolean;
  isPrimary?: boolean;
  notes?: string | null;
}

export interface SupplierMappingListFilters {
  catalogProductId?: string;
  supplierId?: string;
  enabled?: boolean;
  limit: number;
  offset: number;
}

export interface DvgMappingReviewPreviewInput {
  catalogProductId?: string;
  expectedArticle?: string | null;
  parsedDvgArticle?: string | null;
  parsedOriginalCode?: string | null;
  mappingSource?: string | null;
  existingMapping?: { supplierArticleNumber?: string | null } | null;
  invalidOrAccessDenied?: boolean;
  currentPriceNetEur?: number | null;
  currency?: string | null;
  blockingSafetyFlags?: string[];
}

export interface DvgMappingReviewPreviewResponse {
  outcome: string;
  priceSnapshotAllowed: boolean;
  suggestedSupplierArticle: string | null;
  discoveredSupplierArticle: string | null;
  reason: string;
  warnings: string[];
  snapshotGate: {
    allowed: boolean;
    reason: string;
    warnings: string[];
  };
}

export type DvgAutoPairCandidateSource =
  | "suggested_supplier_article"
  | "sku_prefix"
  | "sku_article";

export type DvgAutoPairStatus =
  | "created"
  | "updated"
  | "verified"
  | "conflict"
  | "skipped_not_dvg_candidate";

export interface DvgAutoPairCandidate {
  supplierArticleNumber: string;
  source: DvgAutoPairCandidateSource;
}

export interface DvgAutoPairRow {
  catalogProductId: string;
  sku: string;
  name: string;
  supplierArticleNumber: string | null;
  directUrl: string | null;
  status: DvgAutoPairStatus;
  source: DvgAutoPairCandidateSource | null;
  existingSupplierArticleNumber: string | null;
  message: string;
}

export interface DvgAutoPairResult {
  supplierId: string;
  totalProducts: number;
  dvgCandidateCount: number;
  createdCount: number;
  updatedCount: number;
  verifiedCount: number;
  conflictCount: number;
  skippedNotDvgCandidateCount: number;
  rows: DvgAutoPairRow[];
}

export type SupplierMappingRecord = SupplierMapping;
export type SupplierMappingCreateRecord = NewSupplierMapping;

export class SupplierMappingValidationError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus = 400
  ) {
    super(message);
    this.name = "SupplierMappingValidationError";
  }
}

export class SupplierMappingDatabaseError extends Error {
  constructor(message = "Database unavailable") {
    super(message);
    this.name = "SupplierMappingDatabaseError";
  }
}
