import {
  calculatePriceSuggestion,
  supplierPriceChangeStatusLabels,
  supplierReviewResolutionLabels,
  type SupplierPriceChangeView,
  type SupplierPriceChangeStatus,
} from "@danetti/shared";
import type {
  PriceChangeReview,
  SupplierPriceChangeSnapshotRow,
  SupplierPriceChangeSupplierScope,
} from "./supplier-price-changes.repository.js";
import { compareTableValues, priceChangeSortFields, type PriceChangeSortBy } from "@danetti/shared";
import { createHash } from "node:crypto";

export type PriceChangeView = SupplierPriceChangeView;
export type PriceChangeStatus = SupplierPriceChangeStatus;

export type SupplierPriceChangeDirection = "all" | "increase" | "decrease";
export type SupplierPriceChangeRoundingMode = "up" | "nearest";

export interface SupplierPriceChangeQuery {
  view?: PriceChangeView;
  fromDate?: string;
  toDate?: string;
  sortBy?: PriceChangeSortBy;
  sortDirection?: "asc" | "desc";
  limit: number;
  offset: number;
  eurHufRate?: number;
  vatPercent: number;
  pricingMode?: "preserve" | "fixed";
  fixedProfitPercent?: number;
  roundingEnabled: boolean;
  roundingIncrementHuf: number;
  roundingMode: SupplierPriceChangeRoundingMode;
  direction: SupplierPriceChangeDirection;
  supplierScope: SupplierPriceChangeSupplierScope;
  minChangePercent: number;
  minChangeHuf: number;
  maxSnapshotScan: number;
}

export interface SupplierPriceChangeListInput extends SupplierPriceChangeQuery {
  eurHufRate: number;
}

export interface SupplierPriceChangeRow {
  eventId: string;
  reviewStatus: PriceChangeStatus;
  reviewStatusLabel: string;
  changeObservedAt: string;
  lastCheckedAt: string;
  resolvedAt: string | null;
  baselineWooGrossHuf: number | null;
  baselineSource: string;
  latestComparison: boolean;
  catalogProductId: string;
  sku: string;
  productName: string;
  supplierId: string;
  supplierName: string | null;
  supplierMappingId: string | null;
  supplierArticleNumber: string;
  oldSnapshotId: string;
  newSnapshotId: string;
  oldObservedAt: string;
  newObservedAt: string;
  oldSupplierNetEur: number;
  newSupplierNetEur: number;
  oldSupplierNetHuf: number;
  newSupplierNetHuf: number;
  supplierChangeEur: number;
  supplierChangeHuf: number;
  supplierChangePercent: number;
  currentWooPriceHuf: number | null;
  currentWooPriceSource: "currentPrice" | "salePrice" | "regularPrice" | null;
  currentWooNetHuf: number | null;
  preservedProfitPercent: number | null;
  appliedProfitPercent: number | null;
  currentProfitPercentWithNewCost: number | null;
  currentProfitPercentDelta: number | null;
  suggestedGrossPriceHuf: number | null;
  suggestedGrossPriceRoundedHuf: number | null;
  suggestedPriceDeltaHuf: number | null;
  warnings: string[];
}

export interface SupplierPriceChangeSummary {
  changedCount: number;
  increaseCount: number;
  decreaseCount: number;
  noPreviousPriceCount: number;
  missingWooPriceCount: number;
  marginWouldDropCount: number;
  maxSnapshotScan: number;
}

export interface SupplierPriceChangeResponse {
  items: SupplierPriceChangeRow[];
  total: number;
  limit: number;
  offset: number;
  generatedAt: string;
  settings: {
    view: PriceChangeView;
    fromDate: string | null;
    toDate: string | null;
    eurHufRate: number;
    vatPercent: number;
    pricingMode: "preserve" | "fixed";
    fixedProfitPercent: number | null;
    roundingEnabled: boolean;
    roundingIncrementHuf: number;
    roundingMode: SupplierPriceChangeRoundingMode;
    direction: SupplierPriceChangeDirection;
    supplierScope: SupplierPriceChangeSupplierScope;
    minChangePercent: number;
    minChangeHuf: number;
  };
  summary: SupplierPriceChangeSummary;
}

export class SupplierPriceChangeValidationError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus = 400
  ) {
    super(message);
    this.name = "SupplierPriceChangeValidationError";
  }
}

export class SupplierPriceChangeDatabaseError extends Error {
  constructor(message = "Database unavailable") {
    super(message);
    this.name = "SupplierPriceChangeDatabaseError";
  }
}

export function validateSupplierPriceChangeQuery(query: unknown): SupplierPriceChangeQuery {
  const input = isRecord(query) ? query : {};
  if (input.view !== undefined && !["pending", "latest", "all"].includes(String(input.view)))
    throw new SupplierPriceChangeValidationError("invalid_view", "Érvénytelen nézet.");
  const fromDate = readDate(input.fromDate),
    toDate = readDate(input.toDate);
  if (fromDate && toDate && fromDate > toDate)
    throw new SupplierPriceChangeValidationError(
      "invalid_date_range",
      "A kezdő dátum nem lehet későbbi a zárónál."
    );
  if (
    input.sortBy !== undefined &&
    !priceChangeSortFields.includes(input.sortBy as PriceChangeSortBy)
  ) {
    throw new SupplierPriceChangeValidationError("invalid_sortBy", "Invalid sort column");
  }
  if (
    input.sortDirection !== undefined &&
    input.sortDirection !== "asc" &&
    input.sortDirection !== "desc"
  ) {
    throw new SupplierPriceChangeValidationError("invalid_sortDirection", "Invalid sort direction");
  }
  if (
    input.pricingMode !== undefined &&
    input.pricingMode !== "preserve" &&
    input.pricingMode !== "fixed"
  )
    throw new SupplierPriceChangeValidationError(
      "invalid_pricingMode",
      "Érvénytelen árképzési mód."
    );
  const fixedProfitPercent = optionalNumber(
    input.fixedProfitPercent,
    0,
    1000,
    "fixedProfitPercent"
  );
  if (input.pricingMode === "fixed" && fixedProfitPercent === undefined)
    throw new SupplierPriceChangeValidationError(
      "fixed_profit_required",
      "Adj meg fix profit százalékot 0 és 1000 között."
    );
  return {
    view: (input.view as PriceChangeView | undefined) ?? "pending",
    fromDate,
    toDate,
    sortBy: (input.sortBy as PriceChangeSortBy | undefined) ?? "newObservedAt",
    sortDirection: input.sortDirection === "asc" ? "asc" : "desc",
    limit: boundedInteger(input.limit, 50, 1, 200, "limit"),
    offset: boundedInteger(input.offset, 0, 0, Number.MAX_SAFE_INTEGER, "offset"),
    eurHufRate: optionalNumber(input.eurHufRate, 100, 1000, "eurHufRate"),
    vatPercent: optionalNumber(input.vatPercent, 0, 100, "vatPercent") ?? 27,
    pricingMode: input.pricingMode === "fixed" ? "fixed" : "preserve",
    fixedProfitPercent,
    roundingEnabled: optionalBoolean(input.roundingEnabled) ?? true,
    roundingIncrementHuf:
      boundedInteger(input.roundingIncrementHuf, 100, 1, 100000, "roundingIncrementHuf") || 100,
    roundingMode: input.roundingMode === "nearest" ? "nearest" : "up",
    direction: readDirection(input.direction),
    supplierScope: readSupplierScope(input.supplierScope),
    minChangePercent: optionalNumber(input.minChangePercent, 0, 1000, "minChangePercent") ?? 0,
    minChangeHuf: optionalNumber(input.minChangeHuf, 0, 100000000, "minChangeHuf") ?? 0,
    maxSnapshotScan: boundedInteger(input.maxSnapshotScan, 50000, 100, 200000, "maxSnapshotScan"),
  };
}

export function buildSupplierPriceChangeResponse(input: {
  rows: SupplierPriceChangeSnapshotRow[];
  reviews?: PriceChangeReview[];
  query: SupplierPriceChangeListInput;
  now?: Date;
}): SupplierPriceChangeResponse {
  const { query } = input;
  const grouped = new Map<string, SupplierPriceChangeSnapshotRow[]>();
  for (const row of [...input.rows].sort(compareSnapshotsNewestFirst)) {
    const key = getSnapshotChangeGroupKey(row);
    const group = grouped.get(key) ?? [];
    if (numberOrNull(row.priceNetEur)! > 0 && !group.some((r) => r.snapshotId === row.snapshotId))
      group.push(row);
    grouped.set(key, group);
  }

  const summaryBase: SupplierPriceChangeSummary = {
    changedCount: 0,
    increaseCount: 0,
    decreaseCount: 0,
    noPreviousPriceCount: 0,
    missingWooPriceCount: 0,
    marginWouldDropCount: 0,
    maxSnapshotScan: query.maxSnapshotScan,
  };
  const changes: SupplierPriceChangeRow[] = [];

  const reviews = new Map(input.reviews?.map((r) => [r.eventId, r]));
  for (const group of grouped.values()) {
    if (group.length < 2) {
      summaryBase.noPreviousPriceCount += 1;
      continue;
    }
    const periods: SupplierPriceChangeSnapshotRow[][] = [];
    for (const observation of [...group].reverse()) {
      const period = periods.at(-1);
      if (period && Number(period[0]!.priceNetEur) === Number(observation.priceNetEur))
        period.push(observation);
      else periods.push([observation]);
    }
    for (let i = 1; i < periods.length; i++) {
      const first = periods[i]![0]!,
        current = periods[i]!.at(-1)!,
        previous = periods[i - 1]!.at(-1)!;
      const eventId = createHash("sha256")
        .update(getSnapshotChangeGroupKey(first) + "\u001f" + first.snapshotId)
        .digest("hex");
      const review = reviews.get(eventId);
      const observedBaseline =
        numberOrNull(previous.observedWooGrossHuf) ?? numberOrNull(first.observedWooGrossHuf);
      const baseline = review
        ? numberOrNull(review.baselineWooGrossHuf)
        : (observedBaseline ?? selectWooPrice(current).value);
      const change = buildChangeRow({ current, previous, query, baseline });
      if (!change) continue;
      const latest = i === periods.length - 1;
      const priceUpdated =
        baseline !== null &&
        change.currentWooPriceHuf !== null &&
        Math.round(change.currentWooPriceHuf * 100) !== Math.round(baseline * 100);
      const status: PriceChangeStatus = !latest
        ? "superseded"
        : review?.decision === "resolved" || review?.decision === "csv"
          ? "resolved"
          : review?.decision === "open"
            ? "pending"
            : priceUpdated
              ? "price_updated"
              : "pending";
      changes.push({
        ...change,
        eventId,
        reviewStatus: status,
        reviewStatusLabel:
          status === "resolved"
            ? supplierReviewResolutionLabels[review?.decision === "csv" ? "csv" : "manual"]
            : priceChangeStatusLabel(status),
        changeObservedAt: first.observedAt.toISOString(),
        lastCheckedAt: group[0]!.observedAt.toISOString(),
        baselineWooGrossHuf: baseline,
        baselineSource:
          review?.baselineSource ?? (observedBaseline === null ? "first_seen" : "observation"),
        resolvedAt: review?.decidedAt?.toISOString() ?? null,
        latestComparison: latest && Number(group[0]!.priceNetEur) !== Number(group[1]!.priceNetEur),
      });
    }
  }

  const filtered = changes.filter((change) => matchesFilters(change, query));
  const summary = summarizeChanges(filtered, summaryBase);
  const sortBy = query.sortBy ?? "newObservedAt";
  filtered.sort(
    (a, b) =>
      compareTableValues(
        sortBy === "newObservedAt" ? Date.parse(a.newObservedAt) : a[sortBy],
        sortBy === "newObservedAt" ? Date.parse(b.newObservedAt) : b[sortBy],
        query.sortDirection ?? "desc"
      ) || a.newSnapshotId.localeCompare(b.newSnapshotId)
  );

  return {
    items: filtered.slice(query.offset, query.offset + query.limit),
    total: filtered.length,
    limit: query.limit,
    offset: query.offset,
    generatedAt: (input.now ?? new Date()).toISOString(),
    settings: {
      view: query.view ?? "pending",
      fromDate: query.fromDate ?? null,
      toDate: query.toDate ?? null,
      eurHufRate: query.eurHufRate,
      vatPercent: query.vatPercent,
      pricingMode: query.pricingMode ?? "preserve",
      fixedProfitPercent: query.pricingMode === "fixed" ? query.fixedProfitPercent! : null,
      roundingEnabled: query.roundingEnabled,
      roundingIncrementHuf: query.roundingIncrementHuf,
      roundingMode: query.roundingMode,
      direction: query.direction,
      supplierScope: query.supplierScope,
      minChangePercent: query.minChangePercent,
      minChangeHuf: query.minChangeHuf,
    },
    summary,
  };
}

function getSnapshotChangeGroupKey(row: SupplierPriceChangeSnapshotRow): string {
  return [
    row.catalogProductId,
    row.supplierId,
    row.supplierMappingId ?? "no_mapping",
    row.supplierArticleNumber,
  ].join("\u001f");
}

function summarizeChanges(
  changes: SupplierPriceChangeRow[],
  base: SupplierPriceChangeSummary
): SupplierPriceChangeSummary {
  const summary = { ...base, changedCount: changes.length };
  for (const change of changes) {
    if (change.supplierChangeEur > 0) summary.increaseCount += 1;
    if (change.supplierChangeEur < 0) summary.decreaseCount += 1;
    if (change.currentWooPriceHuf === null) summary.missingWooPriceCount += 1;
    if (
      change.currentProfitPercentWithNewCost !== null &&
      change.preservedProfitPercent !== null &&
      change.currentProfitPercentWithNewCost < change.preservedProfitPercent
    ) {
      summary.marginWouldDropCount += 1;
    }
  }
  return summary;
}

function buildChangeRow(input: {
  current: SupplierPriceChangeSnapshotRow;
  previous: SupplierPriceChangeSnapshotRow;
  query: SupplierPriceChangeListInput;
  baseline: number | null;
}): Omit<
  SupplierPriceChangeRow,
  | "eventId"
  | "reviewStatus"
  | "reviewStatusLabel"
  | "changeObservedAt"
  | "lastCheckedAt"
  | "resolvedAt"
  | "baselineWooGrossHuf"
  | "baselineSource"
  | "latestComparison"
> | null {
  const { current, previous, query } = input;
  const newSupplierNetEur = numberOrNull(current.priceNetEur);
  const oldSupplierNetEur = numberOrNull(previous.priceNetEur);
  if (newSupplierNetEur === null || oldSupplierNetEur === null || oldSupplierNetEur <= 0) {
    return null;
  }
  const supplierChangeEur = newSupplierNetEur - oldSupplierNetEur;
  if (supplierChangeEur === 0) return null;

  const vatMultiplier = 1 + query.vatPercent / 100;
  const oldSupplierNetHuf = oldSupplierNetEur * query.eurHufRate;
  const newSupplierNetHuf = newSupplierNetEur * query.eurHufRate;
  const supplierChangeHuf = newSupplierNetHuf - oldSupplierNetHuf;
  const supplierChangePercent = (supplierChangeEur / oldSupplierNetEur) * 100;
  const woo = selectWooPrice(current);
  const currentWooNetHuf = woo.value === null ? null : woo.value / vatMultiplier;
  const preservedProfitPercent =
    input.baseline === null
      ? null
      : ((input.baseline / vatMultiplier - oldSupplierNetHuf) / oldSupplierNetHuf) * 100;
  const currentProfitPercentWithNewCost =
    currentWooNetHuf === null || newSupplierNetHuf <= 0
      ? null
      : ((currentWooNetHuf - newSupplierNetHuf) / newSupplierNetHuf) * 100;
  const {
    appliedProfitPercent,
    suggestedGrossPriceHuf,
    suggestedGrossPriceRoundedHuf,
    suggestedPriceDeltaHuf,
  } = calculatePriceSuggestion({
    ...query,
    pricingMode: query.pricingMode ?? "preserve",
    supplierNetEur: newSupplierNetEur,
    currentWooGrossHuf: woo.value,
    preservedProfitPercent,
  });
  const warnings: string[] = [];
  if (numberOrNull(current.observedWooGrossHuf) === null)
    warnings.push("woo_baseline_first_seen_if_no_historical_price");
  if (woo.value === null) warnings.push("woo_price_missing");
  if (preservedProfitPercent !== null && preservedProfitPercent < 0)
    warnings.push("negative_previous_margin");

  return {
    catalogProductId: current.catalogProductId,
    sku: current.sku,
    productName: current.productName,
    supplierId: current.supplierId,
    supplierName: current.supplierName,
    supplierMappingId: current.supplierMappingId,
    supplierArticleNumber: current.supplierArticleNumber,
    oldSnapshotId: previous.snapshotId,
    newSnapshotId: current.snapshotId,
    oldObservedAt: previous.observedAt.toISOString(),
    newObservedAt: current.observedAt.toISOString(),
    oldSupplierNetEur,
    newSupplierNetEur,
    oldSupplierNetHuf,
    newSupplierNetHuf,
    supplierChangeEur,
    supplierChangeHuf,
    supplierChangePercent,
    currentWooPriceHuf: woo.value,
    currentWooPriceSource: woo.source,
    currentWooNetHuf,
    preservedProfitPercent,
    appliedProfitPercent,
    currentProfitPercentWithNewCost,
    currentProfitPercentDelta:
      preservedProfitPercent === null || currentProfitPercentWithNewCost === null
        ? null
        : currentProfitPercentWithNewCost - preservedProfitPercent,
    suggestedGrossPriceHuf,
    suggestedGrossPriceRoundedHuf,
    suggestedPriceDeltaHuf,
    warnings,
  };
}

function matchesFilters(
  change: SupplierPriceChangeRow,
  query: SupplierPriceChangeListInput
): boolean {
  if (
    (query.view ?? "pending") === "pending" &&
    !["pending", "price_updated"].includes(change.reviewStatus)
  )
    return false;
  if (query.view === "latest" && !change.latestComparison) return false;
  const date = new Date(change.changeObservedAt).toLocaleDateString("sv-SE", {
    timeZone: "Europe/Budapest",
  });
  if (query.fromDate && date < query.fromDate) return false;
  if (query.toDate && date > query.toDate) return false;
  if (query.direction === "increase" && change.supplierChangeEur <= 0) return false;
  if (query.direction === "decrease" && change.supplierChangeEur >= 0) return false;
  if (Math.abs(change.supplierChangePercent) < query.minChangePercent) return false;
  if (Math.abs(change.supplierChangeHuf) < query.minChangeHuf) return false;
  return true;
}

export function priceChangeStatusLabel(status: PriceChangeStatus): string {
  return supplierPriceChangeStatusLabels[status];
}
function readDate(value: unknown): string | undefined {
  if (value === undefined || value === "") return undefined;
  if (
    typeof value !== "string" ||
    !/^\d{4}-\d{2}-\d{2}$/.test(value) ||
    !Number.isFinite(Date.parse(value)) ||
    new Date(value).toISOString().slice(0, 10) !== value
  )
    throw new SupplierPriceChangeValidationError("invalid_date", "Érvénytelen dátum.");
  return value;
}

function selectWooPrice(row: SupplierPriceChangeSnapshotRow): {
  value: number | null;
  source: "currentPrice" | "salePrice" | "regularPrice" | null;
} {
  const currentPrice = numberOrNull(row.currentPrice);
  if (currentPrice !== null) return { value: currentPrice, source: "currentPrice" };
  const salePrice = numberOrNull(row.salePrice);
  if (salePrice !== null) return { value: salePrice, source: "salePrice" };
  const regularPrice = numberOrNull(row.regularPrice);
  if (regularPrice !== null) return { value: regularPrice, source: "regularPrice" };
  return { value: null, source: null };
}

function readDirection(value: unknown): SupplierPriceChangeDirection {
  if (value === "increase" || value === "decrease" || value === "all") return value;
  return "all";
}

function readSupplierScope(value: unknown): SupplierPriceChangeSupplierScope {
  if (value === "dvg" || value === "lf") return value;
  return "all";
}

function compareSnapshotsNewestFirst(
  left: SupplierPriceChangeSnapshotRow,
  right: SupplierPriceChangeSnapshotRow
): number {
  const observedDelta = right.observedAt.getTime() - left.observedAt.getTime();
  if (observedDelta !== 0) return observedDelta;
  const createdDelta = right.createdAt.getTime() - left.createdAt.getTime();
  if (createdDelta !== 0) return createdDelta;
  return right.snapshotId.localeCompare(left.snapshotId);
}

function optionalBoolean(value: unknown): boolean | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  if (value === true || value === "true") return true;
  if (value === false || value === "false") return false;
  throw new SupplierPriceChangeValidationError(
    "invalid_query",
    "roundingEnabled must be true or false"
  );
}

function boundedInteger(
  value: unknown,
  fallback: number,
  min: number,
  max: number,
  field: string
): number {
  if (value === undefined || value === null || value === "") return fallback;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new SupplierPriceChangeValidationError(
      "invalid_query",
      `${field} must be an integer between ${min} and ${max}`
    );
  }
  return parsed;
}

function optionalNumber(
  value: unknown,
  min: number,
  max: number,
  field: string
): number | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new SupplierPriceChangeValidationError(
      "invalid_query",
      `${field} must be a number between ${min} and ${max}`
    );
  }
  return parsed;
}

function numberOrNull(value: string | number | null | undefined): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
