import type { FastifyInstance } from "fastify";
import { getRuntimeHealth } from "./runtime-health.service.js";

export async function registerRuntimeHealthRoutes(server: FastifyInstance): Promise<void> {
  server.get("/health/runtime", async () => getRuntimeHealth());
}
