import { isSupplierRunTerminal } from "@danetti/shared";
import {
  LF_MANUAL_BATCH_SPEED_PROFILES,
  LfManualSessionBatchRunner,
  createLfRunSummary,
  createLfRunTelemetry,
  normalizeLfArticle,
  searchLfExactOwnArticleWithManualSession,
  type LfExactSearchInput,
  type LfExactSearchResult,
  type LfManualBatchCallbacks,
  type LfManualBatchCandidate,
  type LfManualBatchEvent,
  type LfManualBatchRow,
  type LfManualBatchRunStatus,
  type LfManualBatchSettings,
  type LfManualBatchSpeedMode,
  type LfManualBatchState,
} from "@danetti/connectors";
import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import {
  PricingSettingsRepository,
  type PricingSettingsRepositoryLike,
} from "../pricing-settings/pricing-settings.repository.js";
import {
  LfProductsRepository,
  type LfCatalogRunProgress,
  type LfExactAutoPairCandidate,
  type LfExactAutoPairCandidateList,
  type LfExactAutoPairMappingResult,
  type LfExactAutoPairMappingStatus,
  type LfOperatorPreferences,
  type LfProductsCandidateRepository,
} from "./lf-products.repository.js";

interface LfProductsRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  env?: Record<string, string | undefined>;
  repository?: LfProductsCandidateRepository;
  pricingSettingsRepository?: PricingSettingsRepositoryLike;
  runnerFactory?: LfManualBatchRunnerFactory;
  exactSearch?: LfExactSearch;
  now?: () => Date;
}

interface LfManualBatchRunnerLike {
  openBrowser(): Promise<void>;
  waitForManualLogin(timeoutMs?: number): Promise<boolean>;
  runCandidates(
    candidates: readonly LfManualBatchCandidate[],
    settings: LfManualBatchSettings
  ): Promise<void>;
  cancel(): Promise<void>;
  close(): Promise<void>;
}

type LfManualBatchRunnerFactory = (callbacks: LfManualBatchCallbacks) => LfManualBatchRunnerLike;
type LfExactSearch = (input: LfExactSearchInput) => Promise<LfExactSearchResult>;
type LfExactAutoPairRepository = LfProductsCandidateRepository & {
  listExactAutoPairCandidates(
    input: Pick<
      LfManualBatchSettings,
      "limit" | "offset" | "allowSuggestedLfArticle" | "allowSkuPrefixCandidate"
    >
  ): Promise<LfExactAutoPairCandidateList>;
  upsertExactAutoPairMapping(input: {
    candidate: LfExactAutoPairCandidate;
    supplierArticleNumber: string;
    directUrl: string;
    supplierProductNameOverride: string | null;
    dryRun: boolean;
    observedAt: Date;
  }): Promise<LfExactAutoPairMappingResult>;
};

interface RunParams {
  runId: string;
}

interface ValidatedStartInput {
  settings: LfManualBatchSettings;
  manualLoginTimeoutMs: number;
}

interface LfManualBatchRunRecord {
  state: LfManualBatchState;
  runner: LfManualBatchRunnerLike;
  repository: LfProductsCandidateRepository;
  candidates: LfManualBatchCandidate[];
  manualLoginTimeoutMs: number;
  promise: Promise<void> | null;
  rowPersistencePromises: Promise<void>[];
  statePersistencePromises: Promise<void>[];
}

interface LfManualBatchProgress {
  runId: string;
  checked: number;
  ok: number;
  failed: number;
  skipped: number;
  safetyStopped: number;
  nextOffset: number;
  updatedAt: string;
}

type ManualBatchResumeAction =
  | "start_new"
  | "continue_after_login"
  | "retry_from_next_offset"
  | "login_again"
  | "wait_for_current_run";

interface ManualBatchResumeAdvice {
  canResume: boolean;
  action: ManualBatchResumeAction;
  runId: string | null;
  nextOffset: number | null;
  reason: string;
}

interface ManualBatchExportMetadata {
  available: boolean;
  format: "sanitized_rows_json";
  suggestedFilename: string | null;
  rowCount: number;
  totals: {
    checked: number;
    ok: number;
    failed: number;
    skipped: number;
    safetyStopped: number;
  };
  nextOffset: number | null;
  containsSecrets: false;
}

type LfManualBatchStateResponse = LfManualBatchState & {
  resume: ManualBatchResumeAdvice;
  export: ManualBatchExportMetadata;
};

type LfManualBatchProgressSnapshot = LfCatalogRunProgress | LfManualBatchProgress;

type LfManualBatchProgressResponse = LfManualBatchProgressSnapshot & {
  resume: ManualBatchResumeAdvice;
  export: ManualBatchExportMetadata;
};

interface ValidatedExactAutoPairInput {
  settings: LfManualBatchSettings;
  manualLoginTimeoutMs: number;
}

type LfExactAutoPairRowStatus =
  | LfExactAutoPairMappingStatus
  | "no_match"
  | "cross_reference_only"
  | "needs_mapping_review"
  | "ambiguous_match"
  | "article_changed"
  | "item_not_available"
  | "detail_url_missing"
  | "redirected_to_login"
  | "item_timeout"
  | "failed";

interface LfExactAutoPairRow {
  catalogProductId: string;
  wooSku: string;
  wooName: string;
  supplierArticleNumber: string;
  candidateSource: LfExactAutoPairCandidate["candidateSource"];
  status: LfExactAutoPairRowStatus;
  dryRun: boolean;
  mappingId: string | null;
  existingSupplierArticleNumber: string | null;
  lfAutocompleteId: string | null;
  lfAutocompleteValue: string | null;
  lfFinalUrl: string | null;
  lfProductName: string | null;
  lfProductId: string | null;
  lfPartNumber: string | null;
  matchConfidence: string;
  warnings: string[];
  message: string;
}

interface LfExactAutoPairResponse {
  runId: string;
  status: LfManualBatchRunStatus;
  dryRun: boolean;
  supplierId: string;
  totalCandidates: number;
  checkedCount: number;
  acceptedCount: number;
  rejectedCount: number;
  createdCount: number;
  updatedCount: number;
  verifiedCount: number;
  wouldCreateCount: number;
  wouldUpdateCount: number;
  conflictCount: number;
  skippedDvgMappedCount: number;
  skippedNotLfCandidateCount: number;
  nextOffset: number;
  rows: LfExactAutoPairRow[];
}

const DEFAULT_MANUAL_LOGIN_TIMEOUT_MS = 300_000;
const MAX_LF_BATCH_ITEMS = 10_000;
const MAX_LF_EXACT_AUTO_PAIR_ITEMS = MAX_LF_BATCH_ITEMS;
const MAX_LF_BATCH_OFFSET = 50_000;
const MAX_EVENTS = 300;
const LF_LOCAL_LAB_HEADER = "x-danetti-local-lab";
const TERMINAL_STATUSES = new Set<LfManualBatchRunStatus>([
  "login_timeout",
  "detached_session_failed",
  "completed",
  "cancelled",
  "session_lost",
  "interrupted",
  "failed",
]);

export async function registerLfProductsRoutes(
  server: FastifyInstance,
  options: LfProductsRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;
  let activeRun: LfManualBatchRunRecord | null = null;
  let preferences = defaultLfOperatorPreferences();
  const env = options.env ?? process.env;
  const now = options.now ?? (() => new Date());
  const runnerFactory =
    options.runnerFactory ?? ((callbacks) => new LfManualSessionBatchRunner(callbacks));
  const exactSearch = options.exactSearch ?? searchLfExactOwnArticleWithManualSession;

  server.addHook("onClose", async () => {
    await activeRun?.runner.close().catch(() => undefined);
    if (activeRun) releaseSupplierSession("lf", activeRun.state.runId);
    if (options.dbClient === undefined && dbClient !== null) await dbClient.close();
  });

  function getRepository(): LfProductsCandidateRepository {
    if (options.repository) return options.repository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new LfProductsRepository(dbClient.db);
    } catch (error) {
      throw new LfProductsRouteError(
        "database_unavailable",
        error instanceof Error ? error.message : "Database unavailable",
        503
      );
    }
  }

  function getPricingSettingsRepository(): PricingSettingsRepositoryLike {
    if (options.pricingSettingsRepository) return options.pricingSettingsRepository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new PricingSettingsRepository(dbClient.db);
    } catch (error) {
      throw new LfProductsRouteError(
        "database_unavailable",
        error instanceof Error ? error.message : "Database unavailable",
        503
      );
    }
  }

  server.post("/lf-products/manual-batch/start", async (request, reply) => {
    let acquiredRunId: string | null = null;
    try {
      assertRouteAllowed(request, env);
      const input = await validateStartInput(request.body, async () => {
        const latest = await getPricingSettingsRepository().getLatestExchangeRate();
        return latest ? Number(latest.eurHufRate) : null;
      });
      if (activeRun && !isTerminalStatus(activeRun.state.status)) {
        throw new LfProductsRouteError(
          "lf_manual_batch_active",
          "LF manual batch already active",
          409
        );
      }

      const repository = getRepository();
      const candidates = await repository.listCandidates(input.settings);
      if (candidates.length === 0) {
        throw new LfProductsRouteError(
          "lf_candidates_missing",
          "No LF candidate product found",
          400
        );
      }

      const runId = `lf-manual-${now().getTime()}`;
      if (!acquireSupplierSession("lf", runId))
        throw new LfProductsRouteError(
          "lf_manual_batch_active",
          "Another LF check is using the browser",
          409
        );
      acquiredRunId = runId;
      const state = createInitialState(runId, input.settings, candidates.length, now());
      const persistence = createLfPersistenceQueue(
        repository,
        state,
        now,
        async (row, rowNumber) => {
          await persistManualBatchMappingRow(repository, candidates, state, row, rowNumber, now);
        }
      );
      const callbacks = createStateCallbacks(
        state,
        now,
        persistence.queueRowPersistence,
        persistence.queueStatePersistence
      );
      const runner = runnerFactory(callbacks);
      activeRun = {
        state,
        runner,
        repository,
        candidates,
        manualLoginTimeoutMs: input.manualLoginTimeoutMs,
        promise: null,
        rowPersistencePromises: persistence.rowPersistencePromises,
        statePersistencePromises: persistence.statePersistencePromises,
      };
      callbacks.onEvent?.({ type: "runStarted", message: "LF manual batch run created" });
      await runner.openBrowser();
      return reply.code(201).send(toLfManualBatchStateResponse(state));
    } catch (error) {
      if (acquiredRunId) releaseSupplierSession("lf", acquiredRunId);
      if (activeRun && activeRun.state.status === "opening_browser") {
        setStatus(activeRun.state, "failed", now);
        addEvent(activeRun.state, now, { type: "runStopped", message: "LF browser open failed" });
        activeRun.statePersistencePromises.push(
          persistLfOperatorRunState(activeRun.repository, activeRun.state, now)
        );
        await activeRun.runner.close().catch(() => undefined);
      }
      return handleRouteError(reply, error);
    }
  });

  server.get("/lf-products/manual-batch/current", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      return { run: activeRun ? toLfManualBatchStateResponse(activeRun.state) : null };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/lf-products/manual-batch/progress", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const repository = getRepository();
      const progress =
        (await repository.getLatestLfRunProgress?.()) ?? buildProgress(activeRun?.state, now);
      return {
        progress: progress ? toLfManualBatchProgressResponse(progress) : null,
      };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/lf-products/manual-batch/saved-state", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const repository = getRepository();
      if (activeRun) return { run: toLfManualBatchStateResponse(activeRun.state), preferences };
      const run = await repository.getLatestLfOperatorRunState?.();
      preferences = (await repository.getLfOperatorPreferences?.()) ?? preferences;
      const normalizedRun = run ? normalizeSavedLfOperatorRunState(run, now) : null;
      if (run && normalizedRun && run.status !== normalizedRun.status) {
        await repository.saveLfOperatorRunState?.(normalizedRun, now()).catch(() => undefined);
      }
      return {
        run: normalizedRun ? toLfManualBatchStateResponse(normalizedRun) : null,
        preferences,
      };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/lf-products/manual-batch/preferences", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      preferences = (await getRepository().getLfOperatorPreferences?.()) ?? preferences;
      return { preferences };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.put("/lf-products/manual-batch/preferences", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      preferences = validateOperatorPreferences(request.body);
      await getRepository().saveLfOperatorPreferences?.(preferences, now());
      return { preferences };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/lf-products/exact-search", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const input = validateExactSearchInput(request.body);
      const lockId = `lf-exact-search-${now().getTime()}`;
      if (!acquireSupplierSession("lf", lockId))
        throw new LfProductsRouteError(
          "lf_manual_batch_active",
          "Another LF check is using the browser",
          409
        );
      try {
        return await exactSearch(input);
      } finally {
        releaseSupplierSession("lf", lockId);
      }
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/lf-products/exact-auto-pair", async (request, reply) => {
    let acquiredRunId: string | null = null;
    let runner: LfManualBatchRunnerLike | null = null;
    let exactAutoPairState: LfManualBatchState | null = null;
    let exactRepository: LfExactAutoPairRepository | null = null;
    let rowPersistencePromises: Promise<void>[] = [];
    let statePersistencePromises: Promise<void>[] = [];
    const exactAutoPairRows: LfExactAutoPairRow[] = [];
    try {
      assertRouteAllowed(request, env);
      if (activeRun && !isTerminalStatus(activeRun.state.status)) {
        throw new LfProductsRouteError(
          "lf_manual_batch_active",
          "LF manual batch already active",
          409
        );
      }
      const input = await validateExactAutoPairInput(request.body, async () => {
        const latest = await getPricingSettingsRepository().getLatestExchangeRate();
        return latest ? Number(latest.eurHufRate) : null;
      });
      const repository = getExactAutoPairRepository(getRepository());
      exactRepository = repository;
      const candidateList = await repository.listExactAutoPairCandidates(input.settings);
      const runId = `lf-exact-auto-pair-${now().getTime()}`;
      if (!acquireSupplierSession("lf", runId))
        throw new LfProductsRouteError(
          "lf_manual_batch_active",
          "Another LF check is using the browser",
          409
        );
      acquiredRunId = runId;
      const state = createInitialState(
        runId,
        input.settings,
        candidateList.candidates.length,
        now()
      );
      exactAutoPairState = state;
      if (candidateList.candidates.length === 0) {
        setStatus(state, "completed", now);
        addEvent(state, now, { type: "runCompleted", message: "No LF exact candidates found" });
        await persistLfOperatorRunState(repository, state, now);
        return buildExactAutoPairResponse(candidateList, state, [], input.settings.offset);
      }

      const persistence = createLfPersistenceQueue(
        repository,
        state,
        now,
        async (row, rowNumber) => {
          const candidate = candidateList.candidates[rowNumber - 1];
          if (!candidate) return;
          exactAutoPairRows[rowNumber - 1] = await persistExactAutoPairRow(
            repository,
            candidate,
            row,
            input.settings.dryRun,
            now()
          );
        }
      );
      rowPersistencePromises = persistence.rowPersistencePromises;
      statePersistencePromises = persistence.statePersistencePromises;
      runner = runnerFactory(
        createStateCallbacks(
          state,
          now,
          persistence.queueRowPersistence,
          persistence.queueStatePersistence
        )
      );
      activeRun = {
        state,
        runner,
        repository,
        candidates: candidateList.candidates,
        manualLoginTimeoutMs: input.manualLoginTimeoutMs,
        promise: null,
        rowPersistencePromises,
        statePersistencePromises,
      };
      addEvent(state, now, { type: "runStarted", message: "LF exact auto-pair run created" });
      await runner.openBrowser();
      const loginOk = await runner.waitForManualLogin(input.manualLoginTimeoutMs);
      if (!loginOk) {
        setStatus(state, "login_timeout", now);
        addEvent(state, now, { type: "runStopped", message: "Manual LF login timeout" });
        return buildExactAutoPairResponse(candidateList, state, [], input.settings.offset);
      }

      await runner.runCandidates(candidateList.candidates, input.settings);
      if (!isTerminalStatus(state.status)) setStatus(state, "completed", now);
      await Promise.all(rowPersistencePromises);
      const rows = compactExactAutoPairRows(exactAutoPairRows);
      addExactAutoPairResultEvents(state, rows, now);
      statePersistencePromises.push(persistLfOperatorRunState(repository, state, now));
      await Promise.all(statePersistencePromises);
      return buildExactAutoPairResponse(candidateList, state, rows, input.settings.offset);
    } catch (error) {
      if (exactAutoPairState && !isTerminalStatus(exactAutoPairState.status)) {
        setStatus(exactAutoPairState, "failed", now);
        addEvent(exactAutoPairState, now, {
          type: "runStopped",
          message: "LF exact auto-pair failed",
        });
      }
      return handleRouteError(reply, error);
    } finally {
      await runner?.close().catch(() => undefined);
      if (acquiredRunId) releaseSupplierSession("lf", acquiredRunId);
      await Promise.all(rowPersistencePromises).catch(() => undefined);
      if (exactAutoPairState && exactRepository) {
        statePersistencePromises.push(
          persistLfOperatorRunState(exactRepository, exactAutoPairState, now)
        );
        await Promise.all(statePersistencePromises).catch(() => undefined);
      }
    }
  });

  server.post("/lf-products/manual-batch/:runId/continue-after-login", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const record = getRunRecord(activeRun, request.params);
      if (isTerminalStatus(record.state.status)) return toLfManualBatchStateResponse(record.state);
      record.promise ??= runManualBatch(record, now);
      return reply.code(202).send(toLfManualBatchStateResponse(record.state));
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/lf-products/manual-batch/:runId", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      return toLfManualBatchStateResponse(getRunRecord(activeRun, request.params).state);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/lf-products/manual-batch/:runId/cancel", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const record = getRunRecord(activeRun, request.params);
      await record.runner.cancel();
      releaseSupplierSession("lf", record.state.runId);
      setStatus(record.state, "cancelled", now);
      addEvent(record.state, now, { type: "runStopped", message: "LF run cancelled" });
      record.statePersistencePromises.push(
        persistLfOperatorRunState(record.repository, record.state, now)
      );
      return toLfManualBatchStateResponse(record.state);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

async function runManualBatch(record: LfManualBatchRunRecord, now: () => Date): Promise<void> {
  try {
    const loginOk = await record.runner.waitForManualLogin(record.manualLoginTimeoutMs);
    if (!loginOk) {
      if (!isTerminalStatus(record.state.status)) {
        setStatus(record.state, "login_timeout", now);
        addEvent(record.state, now, { type: "runStopped", message: "Manual LF login timeout" });
      }
      return;
    }
    await record.runner.runCandidates(record.candidates, record.state.settings);
  } catch (error) {
    if (!isTerminalStatus(record.state.status)) {
      setStatus(record.state, "failed", now);
      addEvent(record.state, now, {
        type: "runStopped",
        message: `LF run failed: ${sanitizeCode(error instanceof Error ? error.name : "lf_run_failed")}`,
      });
    }
  } finally {
    refreshRunDerivedData(record.state);
    await record.runner.close().catch(() => undefined);
    releaseSupplierSession("lf", record.state.runId);
    await Promise.all(record.rowPersistencePromises);
    record.statePersistencePromises.push(
      persistLfOperatorRunState(record.repository, record.state, now)
    );
    await Promise.all(record.statePersistencePromises);
  }
}

function getExactAutoPairRepository(
  repository: LfProductsCandidateRepository
): LfExactAutoPairRepository {
  if (
    typeof repository.listExactAutoPairCandidates !== "function" ||
    typeof repository.upsertExactAutoPairMapping !== "function"
  ) {
    throw new LfProductsRouteError(
      "lf_exact_auto_pair_repository_missing",
      "LF exact auto-pair repository is unavailable",
      503
    );
  }
  return repository as LfExactAutoPairRepository;
}

function createLfPersistenceQueue(
  repository: LfProductsCandidateRepository,
  state: LfManualBatchState,
  now: () => Date,
  onRowPersisted?: (row: LfManualBatchRow, rowNumber: number) => Promise<void> | void
): {
  rowPersistencePromises: Promise<void>[];
  statePersistencePromises: Promise<void>[];
  queueRowPersistence: (row: LfManualBatchRow, rowNumber: number) => void;
  queueStatePersistence: () => void;
} {
  const rowPersistencePromises: Promise<void>[] = [];
  const statePersistencePromises: Promise<void>[] = [];
  let rowPersistenceChain = Promise.resolve();
  let statePersistenceChain = Promise.resolve();

  const queueRowPersistence = (row: LfManualBatchRow, rowNumber: number) => {
    const promise = rowPersistenceChain.then(async () => {
      await persistCatalogLfRunRow(repository, state, row, state.settings.offset + rowNumber, now);
      await onRowPersisted?.(row, rowNumber);
    });
    rowPersistenceChain = promise.catch(() => undefined);
    rowPersistencePromises.push(promise);
  };

  const queueStatePersistence = () => {
    const promise = statePersistenceChain.then(() =>
      persistLfOperatorRunState(repository, state, now)
    );
    statePersistenceChain = promise.catch(() => undefined);
    statePersistencePromises.push(promise);
  };

  return {
    rowPersistencePromises,
    statePersistencePromises,
    queueRowPersistence,
    queueStatePersistence,
  };
}

async function persistCatalogLfRunRow(
  repository: LfProductsCandidateRepository,
  state: LfManualBatchState,
  row: LfManualBatchRow,
  globalIndex: number,
  now: () => Date
): Promise<void> {
  if (isLfMappingOnlyRun(state.settings)) return;
  if (!repository.saveCatalogProductLfRunRow) return;
  try {
    const result = await repository.saveCatalogProductLfRunRow(row, {
      runId: state.runId,
      globalIndex,
      observedAt: now(),
      settings: state.settings,
    });
    if (result.pricingSaved) {
      addEvent(state, now, {
        type: "calculationDone",
        message: `Catalog LF pricing saved: ${row.wooSku}`,
      });
    }
  } catch (error) {
    addEvent(state, now, {
      type: "runStopped",
      message: `Catalog LF progress save failed: ${sanitizeCode(
        error instanceof Error ? error.name : "lf_catalog_progress_save_failed"
      )}`,
    });
  }
}

async function persistLfOperatorRunState(
  repository: LfProductsCandidateRepository,
  state: LfManualBatchState,
  now: () => Date
): Promise<void> {
  await repository.saveLfOperatorRunState?.(cloneState(state), now()).catch(() => undefined);
}

async function persistExactAutoPairRow(
  repository: LfExactAutoPairRepository,
  candidate: LfExactAutoPairCandidate,
  batchRow: LfManualBatchRow,
  dryRun: boolean,
  observedAt: Date
): Promise<LfExactAutoPairRow> {
  if (!isTrustedLfExactAutoPairRow(batchRow)) {
    return buildRejectedExactAutoPairRow(
      candidate,
      batchRow,
      rejectedExactAutoPairStatus(batchRow),
      dryRun
    );
  }
  if (!batchRow.lfFinalUrl) {
    return buildRejectedExactAutoPairRow(candidate, batchRow, "detail_url_missing", dryRun);
  }

  try {
    const mappingResult = await repository.upsertExactAutoPairMapping({
      candidate,
      supplierArticleNumber: normalizeLfArticle(batchRow.supplierArticleNumber),
      directUrl: batchRow.lfFinalUrl,
      supplierProductNameOverride: batchRow.lfProductName,
      dryRun,
      observedAt,
    });
    return buildAcceptedExactAutoPairRow(candidate, batchRow, mappingResult, dryRun);
  } catch {
    return buildRejectedExactAutoPairRow(
      candidate,
      { ...batchRow, warnings: [...batchRow.warnings, "lf_mapping_save_failed"] },
      "failed",
      dryRun
    );
  }
}

async function persistManualBatchMappingRow(
  repository: LfProductsCandidateRepository,
  candidates: readonly LfManualBatchCandidate[],
  state: LfManualBatchState,
  row: LfManualBatchRow,
  rowNumber: number,
  now: () => Date
): Promise<void> {
  if (!isLfMappingOnlyRun(state.settings)) return;
  const candidate = candidates[rowNumber - 1];
  if (!isLfExactAutoPairCandidate(candidate)) return;
  const exactRepository = getExactAutoPairRepository(repository);
  const exactRow = await persistExactAutoPairRow(
    exactRepository,
    candidate,
    row,
    state.settings.dryRun,
    now()
  );
  addEvent(state, now, {
    type: isSavedExactAutoPairStatus(exactRow.status) ? "calculationDone" : "itemSkipped",
    article: exactRow.supplierArticleNumber,
    message: exactAutoPairEventMessage(exactRow),
  });
}

function isLfExactAutoPairCandidate(
  candidate: LfManualBatchCandidate | undefined
): candidate is LfExactAutoPairCandidate {
  return Boolean(
    candidate && "existingLfMappingId" in candidate && "existingLfDirectUrl" in candidate
  );
}

function compactExactAutoPairRows(rows: readonly (LfExactAutoPairRow | undefined)[]) {
  return rows.filter((row): row is LfExactAutoPairRow => row !== undefined);
}

function isLfMappingOnlyRun(settings: LfManualBatchSettings): boolean {
  return settings.onlyMappedLf === false && settings.allowSnapshotWrite === false;
}

function buildExactAutoPairResponse(
  candidateList: LfExactAutoPairCandidateList,
  state: LfManualBatchState,
  rows: readonly LfExactAutoPairRow[],
  offset: number
): LfExactAutoPairResponse {
  const acceptedStatuses = new Set<LfExactAutoPairRowStatus>([
    "would_create",
    "would_update",
    "created",
    "updated",
    "verified",
    "conflict",
  ]);
  const acceptedCount = rows.filter((row) => acceptedStatuses.has(row.status)).length;
  return {
    runId: state.runId,
    status: state.status,
    dryRun: state.settings.dryRun,
    supplierId: candidateList.supplierId,
    totalCandidates: candidateList.totalCandidates,
    checkedCount: rows.length,
    acceptedCount,
    rejectedCount: rows.length - acceptedCount,
    createdCount: rows.filter((row) => row.status === "created").length,
    updatedCount: rows.filter((row) => row.status === "updated").length,
    verifiedCount: rows.filter((row) => row.status === "verified").length,
    wouldCreateCount: rows.filter((row) => row.status === "would_create").length,
    wouldUpdateCount: rows.filter((row) => row.status === "would_update").length,
    conflictCount: rows.filter((row) => row.status === "conflict").length,
    skippedDvgMappedCount: candidateList.skippedDvgMappedCount,
    skippedNotLfCandidateCount: candidateList.skippedNotLfCandidateCount,
    nextOffset: offset + countProgressAdvancingRows(state.rows),
    rows: rows.map((row) => ({ ...row, warnings: [...row.warnings] })),
  };
}

function addExactAutoPairResultEvents(
  state: LfManualBatchState,
  rows: readonly LfExactAutoPairRow[],
  now: () => Date
): void {
  for (const row of rows) {
    addEvent(state, now, {
      type: isSavedExactAutoPairStatus(row.status) ? "calculationDone" : "itemSkipped",
      article: row.supplierArticleNumber,
      message: exactAutoPairEventMessage(row),
    });
  }
  refreshRunDerivedData(state);
}

function isSavedExactAutoPairStatus(status: LfExactAutoPairRowStatus): boolean {
  return ["created", "updated", "verified", "would_create", "would_update"].includes(status);
}

function exactAutoPairEventMessage(row: LfExactAutoPairRow): string {
  switch (row.status) {
    case "would_create":
      return `Ellenőrizve, menthető LF találat: ${row.wooSku}`;
    case "would_update":
      return `Ellenőrizve, frissíthető LF találat: ${row.wooSku}`;
    case "created":
      return `LF mapping mentve: ${row.wooSku}`;
    case "updated":
      return `LF mapping frissítve: ${row.wooSku}`;
    case "verified":
      return `LF mapping már rendben volt: ${row.wooSku}`;
    case "conflict":
      return `LF mapping konfliktus, kézi ellenőrzés kell: ${row.wooSku}`;
    case "cross_reference_only":
      return `Nem mentve: az LF csak más beszállítói hivatkozást adott: ${row.wooSku}`;
    case "no_match":
      return `Nem mentve: nincs saját LF termék: ${row.wooSku}`;
    case "needs_mapping_review":
      return `Nem mentve: bizonytalan LF találat: ${row.wooSku}`;
    case "ambiguous_match":
      return `Nem mentve: nem egyértelmű LF találat: ${row.wooSku}`;
    case "article_changed":
      return `Nem mentve: LF cikkszám változott: ${row.wooSku}`;
    case "item_not_available":
      return `Nem mentve: LF cikk nem rendelhető vagy kifutott: ${row.wooSku}`;
    case "detail_url_missing":
      return `Nem mentve: hiányzik a menthető LF termékoldal URL: ${row.wooSku}`;
    case "redirected_to_login":
      return `Nem mentve: az LF újra belépést kért: ${row.wooSku}`;
    case "item_timeout":
      return `Nem mentve: időtúllépés: ${row.wooSku}`;
    case "failed":
      return `Nem mentve: LF párosítási hiba: ${row.wooSku}`;
  }
}

function isTrustedLfExactAutoPairRow(row: LfManualBatchRow): boolean {
  if (row.status !== "ok") return false;
  if (row.matchConfidence !== "trusted_lf_item") return false;
  if (!row.lfAutocompleteId?.startsWith("C:")) return false;
  const autocompleteArticle = row.lfAutocompleteId.slice(2);
  return normalizeLfArticle(autocompleteArticle) === normalizeLfArticle(row.supplierArticleNumber);
}

function buildAcceptedExactAutoPairRow(
  candidate: LfExactAutoPairCandidate,
  row: LfManualBatchRow,
  mappingResult: LfExactAutoPairMappingResult,
  dryRun: boolean
): LfExactAutoPairRow {
  return {
    ...baseExactAutoPairRow(candidate, row, dryRun),
    status: mappingResult.status,
    mappingId: mappingResult.mappingId,
    existingSupplierArticleNumber: mappingResult.existingSupplierArticleNumber,
    message: exactAutoPairMessage(mappingResult.status),
  };
}

function buildRejectedExactAutoPairRow(
  candidate: LfExactAutoPairCandidate,
  row: LfManualBatchRow,
  status: LfExactAutoPairRowStatus,
  dryRun: boolean
): LfExactAutoPairRow {
  return {
    ...baseExactAutoPairRow(candidate, row, dryRun),
    status,
    mappingId: null,
    existingSupplierArticleNumber: candidate.existingLfSupplierArticleNumber,
    message: exactAutoPairMessage(status),
  };
}

function baseExactAutoPairRow(
  candidate: LfExactAutoPairCandidate,
  row: LfManualBatchRow,
  dryRun: boolean
): Omit<LfExactAutoPairRow, "status" | "mappingId" | "existingSupplierArticleNumber" | "message"> {
  return {
    catalogProductId: candidate.catalogProductId,
    wooSku: candidate.wooSku,
    wooName: candidate.wooName,
    supplierArticleNumber: normalizeLfArticle(row.supplierArticleNumber),
    candidateSource: candidate.candidateSource,
    dryRun,
    lfAutocompleteId: row.lfAutocompleteId,
    lfAutocompleteValue: row.lfAutocompleteValue,
    lfFinalUrl: row.lfFinalUrl,
    lfProductName: row.lfProductName,
    lfProductId: row.lfProductId,
    lfPartNumber: row.lfPartNumber,
    matchConfidence: row.matchConfidence,
    warnings: [...row.warnings],
  };
}

function rejectedExactAutoPairStatus(row: LfManualBatchRow): LfExactAutoPairRowStatus {
  if (row.status === "redirected_to_login") return "redirected_to_login";
  if (row.status === "item_timeout") return "item_timeout";
  if (row.status === "article_changed") return "article_changed";
  if (row.status === "item_not_available") return "item_not_available";
  if (row.status === "ambiguous_match") return "ambiguous_match";
  if (row.status === "cross_reference_only") return "cross_reference_only";
  if (row.status === "article_not_found") return "no_match";
  if (row.status === "needs_mapping_review") return "needs_mapping_review";
  return "failed";
}

function exactAutoPairMessage(status: LfExactAutoPairRowStatus): string {
  switch (status) {
    case "would_create":
      return "Dry-run: LF mapping would be created with observed detail URL.";
    case "would_update":
      return "Dry-run: existing LF mapping would be updated with observed detail URL.";
    case "created":
      return "LF mapping created with observed detail URL.";
    case "updated":
      return "Existing LF mapping updated with observed detail URL.";
    case "verified":
      return "Existing LF mapping is already exact and URL-backed.";
    case "conflict":
      return "Existing active LF primary mapping uses a different article; manual review required.";
    case "no_match":
      return "LF exact search found no own item.";
    case "cross_reference_only":
      return "LF returned only a supplier cross-reference, not an own LF item.";
    case "needs_mapping_review":
      return "LF exact search needs manual review.";
    case "ambiguous_match":
      return "LF exact search returned an ambiguous item result.";
    case "article_changed":
      return "LF detail indicates the article number changed.";
    case "item_not_available":
      return "LF detail indicates the item is unavailable or discontinued.";
    case "detail_url_missing":
      return "LF own item was trusted, but no detail URL was observed.";
    case "redirected_to_login":
      return "LF session was redirected to login.";
    case "item_timeout":
      return "LF item lookup timed out.";
    case "failed":
      return "LF exact auto-pair row failed.";
  }
}

function buildProgress(
  state: LfManualBatchState | null | undefined,
  now: () => Date
): LfManualBatchProgress | null {
  if (!state || state.rows.length === 0) return null;
  return {
    runId: state.runId,
    checked: state.totals.checked,
    ok: state.totals.ok,
    failed: state.totals.failed,
    skipped: state.totals.skipped,
    safetyStopped: state.totals.safetyStopped,
    nextOffset: state.settings.offset + countProgressAdvancingRows(state.rows),
    updatedAt: state.events.at(-1)?.createdAt ?? state.completedAt ?? now().toISOString(),
  };
}

function countProgressAdvancingRows(rows: readonly LfManualBatchState["rows"][number][]): number {
  return rows.filter((row) => row.status !== "redirected_to_login").length;
}

function createInitialState(
  runId: string,
  settings: LfManualBatchSettings,
  candidateCount: number,
  now: Date
): LfManualBatchState {
  return {
    runId,
    status: "not_started",
    startedAt: now.toISOString(),
    completedAt: null,
    settings,
    currentItem: null,
    totals: {
      candidates: candidateCount,
      checked: 0,
      ok: 0,
      failed: 0,
      skipped: 0,
      safetyStopped: 0,
    },
    telemetry: undefined,
    summary: undefined,
    events: [],
    rows: [],
  };
}

function createStateCallbacks(
  state: LfManualBatchState,
  now: () => Date,
  onRowSaved?: (row: LfManualBatchRow, rowNumber: number) => void,
  onStateChanged?: () => void
): LfManualBatchCallbacks {
  return {
    onStatus(status) {
      setStatus(state, status, now);
      onStateChanged?.();
    },
    onEvent(event) {
      addEvent(state, now, event);
    },
    onCurrentItem(currentItem) {
      state.currentItem = currentItem;
      refreshRunDerivedData(state);
    },
    onRow(row) {
      state.rows.push(row);
      refreshTotals(state);
      onRowSaved?.(row, state.rows.length);
      onStateChanged?.();
    },
  };
}

function setStatus(
  state: LfManualBatchState,
  status: LfManualBatchRunStatus,
  now: () => Date
): void {
  state.status = status;
  if (isTerminalStatus(status) && state.completedAt === null)
    state.completedAt = now().toISOString();
  refreshRunDerivedData(state);
}

function addEvent(
  state: LfManualBatchState,
  now: () => Date,
  event: Omit<LfManualBatchEvent, "id" | "createdAt">
): void {
  state.events.push({ id: state.events.length + 1, createdAt: now().toISOString(), ...event });
  if (state.events.length > MAX_EVENTS) state.events.splice(0, state.events.length - MAX_EVENTS);
  refreshRunDerivedData(state);
}

function refreshTotals(state: LfManualBatchState): void {
  state.totals.checked = state.rows.length;
  state.totals.ok = state.rows.filter((row) => row.status === "ok").length;
  state.totals.skipped = state.rows.filter((row) => row.status.startsWith("skipped_")).length;
  state.totals.safetyStopped = 0;
  state.totals.failed = state.rows.filter(
    (row) => row.status !== "ok" && !row.status.startsWith("skipped_")
  ).length;
  refreshRunDerivedData(state);
}

function refreshRunDerivedData(state: LfManualBatchState): void {
  state.telemetry = createLfRunTelemetry(state);
  state.summary = createLfRunSummary(state.rows, state.totals.candidates);
}

function getRunRecord(
  activeRun: LfManualBatchRunRecord | null,
  params: unknown
): LfManualBatchRunRecord {
  const runId = (params as RunParams).runId;
  if (!activeRun || activeRun.state.runId !== runId) {
    throw new LfProductsRouteError("lf_manual_batch_not_found", "LF manual batch not found", 404);
  }
  return activeRun;
}

async function validateStartInput(
  body: unknown,
  loadDefaultEurHufRate: () => Promise<number | null>
): Promise<ValidatedStartInput> {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  const eurHufRate = await readEurHufRate(input.eurHufRate, loadDefaultEurHufRate);
  const speedMode = readLfManualBatchSpeedMode(input.speedMode);
  const speedDefaults = LF_MANUAL_BATCH_SPEED_PROFILES[speedMode];
  const onlyMappedLf = optionalBoolean(input.onlyMappedLf, true, "onlyMappedLf");
  const allowSuggestedLfArticle = optionalBoolean(
    input.allowSuggestedLfArticle,
    false,
    "allowSuggestedLfArticle"
  );
  const allowSkuPrefixCandidate = optionalBoolean(
    input.allowSkuPrefixCandidate,
    false,
    "allowSkuPrefixCandidate"
  );
  const rerunPreviousNonOkOnly = optionalBoolean(
    input.rerunPreviousNonOkOnly,
    false,
    "rerunPreviousNonOkOnly"
  );
  if (!onlyMappedLf && !allowSuggestedLfArticle && !allowSkuPrefixCandidate) {
    throw new LfProductsRouteError(
      "lf_manual_batch_invalid_settings",
      "At least one LF candidate source must be enabled for LF pairing runs",
      400
    );
  }
  if (
    rerunPreviousNonOkOnly &&
    (!onlyMappedLf || allowSuggestedLfArticle || allowSkuPrefixCandidate)
  ) {
    throw new LfProductsRouteError(
      "lf_manual_batch_invalid_settings",
      "LF previous non-OK rerun requires saved mapped LF price candidates only",
      400
    );
  }
  const settings: LfManualBatchSettings = {
    speedMode,
    markupPercent: boundedNumber(input.markupPercent, 30, 0, 500, "markupPercent"),
    vatPercent: boundedNumber(input.vatPercent, 27, 0, 50, "vatPercent"),
    eurHufRate,
    wooPricesIncludeVat: optionalBoolean(input.wooPricesIncludeVat, true, "wooPricesIncludeVat"),
    limit: boundedInteger(input.limit, 20, 1, MAX_LF_BATCH_ITEMS, "limit"),
    offset: boundedInteger(input.offset, 0, 0, MAX_LF_BATCH_OFFSET, "offset"),
    onlyMappedLf,
    rerunPreviousNonOkOnly,
    allowSuggestedLfArticle,
    allowSkuPrefixCandidate,
    dryRun: optionalBoolean(input.dryRun, true, "dryRun"),
    allowSnapshotWrite: optionalBoolean(input.allowSnapshotWrite, false, "allowSnapshotWrite"),
    itemTimeoutMs: boundedInteger(
      input.itemTimeoutMs,
      speedDefaults.itemTimeoutMs,
      5_000,
      120_000,
      "itemTimeoutMs"
    ),
  };
  return {
    settings,
    manualLoginTimeoutMs: boundedInteger(
      input.manualLoginTimeoutMs,
      DEFAULT_MANUAL_LOGIN_TIMEOUT_MS,
      30_000,
      900_000,
      "manualLoginTimeoutMs"
    ),
  };
}

async function validateExactAutoPairInput(
  body: unknown,
  loadDefaultEurHufRate: () => Promise<number | null>
): Promise<ValidatedExactAutoPairInput> {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  const speedMode = readLfManualBatchSpeedMode(input.speedMode);
  const speedDefaults = LF_MANUAL_BATCH_SPEED_PROFILES[speedMode];
  const allowSuggestedLfArticle = optionalBoolean(
    input.allowSuggestedLfArticle,
    true,
    "allowSuggestedLfArticle"
  );
  const allowSkuPrefixCandidate = optionalBoolean(
    input.allowSkuPrefixCandidate,
    true,
    "allowSkuPrefixCandidate"
  );
  if (!allowSuggestedLfArticle && !allowSkuPrefixCandidate) {
    throw new LfProductsRouteError(
      "lf_manual_batch_invalid_settings",
      "At least one LF candidate source must be enabled",
      400
    );
  }
  const settings: LfManualBatchSettings = {
    speedMode,
    markupPercent: boundedNumber(input.markupPercent, 30, 0, 500, "markupPercent"),
    vatPercent: boundedNumber(input.vatPercent, 27, 0, 50, "vatPercent"),
    eurHufRate: await readOptionalAutoPairEurHufRate(input.eurHufRate, loadDefaultEurHufRate),
    wooPricesIncludeVat: optionalBoolean(input.wooPricesIncludeVat, true, "wooPricesIncludeVat"),
    limit: boundedInteger(input.limit, 10, 1, MAX_LF_EXACT_AUTO_PAIR_ITEMS, "limit"),
    offset: boundedInteger(input.offset, 0, 0, MAX_LF_BATCH_OFFSET, "offset"),
    onlyMappedLf: false,
    rerunPreviousNonOkOnly: false,
    allowSuggestedLfArticle,
    allowSkuPrefixCandidate,
    dryRun: optionalBoolean(input.dryRun, true, "dryRun"),
    allowSnapshotWrite: false,
    itemTimeoutMs: boundedInteger(
      input.itemTimeoutMs,
      speedDefaults.itemTimeoutMs,
      5_000,
      120_000,
      "itemTimeoutMs"
    ),
  };
  return {
    settings,
    manualLoginTimeoutMs: boundedInteger(
      input.manualLoginTimeoutMs,
      DEFAULT_MANUAL_LOGIN_TIMEOUT_MS,
      30_000,
      900_000,
      "manualLoginTimeoutMs"
    ),
  };
}

function validateExactSearchInput(body: unknown): LfExactSearchInput {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  return {
    supplierArticleNumber: readRequiredExactSearchArticle(input.supplierArticleNumber),
    manualLoginTimeoutMs: boundedInteger(
      input.manualLoginTimeoutMs,
      DEFAULT_MANUAL_LOGIN_TIMEOUT_MS,
      30_000,
      900_000,
      "manualLoginTimeoutMs"
    ),
    itemTimeoutMs: boundedInteger(input.itemTimeoutMs, 30_000, 5_000, 120_000, "itemTimeoutMs"),
  };
}

function readRequiredExactSearchArticle(value: unknown): string {
  if (typeof value !== "string") {
    throw new LfProductsRouteError(
      "lf_exact_search_invalid_input",
      "supplierArticleNumber is required",
      400
    );
  }
  const trimmed = value.trim();
  if (trimmed.length === 0 || trimmed.length > 80 || /[\r\n]/.test(trimmed)) {
    throw new LfProductsRouteError(
      "lf_exact_search_invalid_input",
      "supplierArticleNumber must be 1-80 characters",
      400
    );
  }
  return trimmed;
}

function validateOperatorPreferences(body: unknown): LfOperatorPreferences {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  return {
    autoResume: optionalBoolean(input.autoResume, true, "autoResume"),
    vatPercent: boundedNumber(input.vatPercent, 27, 0, 50, "vatPercent"),
    targetProfitMultiplier: optionalNullableNumber(
      input.targetProfitMultiplier,
      1,
      20,
      "targetProfitMultiplier"
    ),
    minimumProfitPercent: optionalNullableNumber(
      input.minimumProfitPercent,
      -1000,
      10000,
      "minimumProfitPercent"
    ),
  };
}

function defaultLfOperatorPreferences(): LfOperatorPreferences {
  return {
    autoResume: true,
    vatPercent: 27,
    targetProfitMultiplier: null,
    minimumProfitPercent: null,
  };
}

function normalizeSavedLfOperatorRunState(
  run: LfManualBatchState,
  now: () => Date
): LfManualBatchState {
  const normalized = cloneState(run);
  if (isTerminalStatus(normalized.status)) return normalized;

  setStatus(normalized, "interrupted", now);
  addEvent(normalized, now, {
    type: "runStopped",
    message: "LF run interrupted after API/runtime restart",
  });
  return normalized;
}

function toLfManualBatchStateResponse(state: LfManualBatchState): LfManualBatchStateResponse {
  const snapshot = cloneState(state);
  return {
    ...snapshot,
    resume: buildLfResumeAdvice(snapshot),
    export: buildLfExportMetadata(snapshot),
  };
}

function toLfManualBatchProgressResponse(
  progress: LfManualBatchProgressSnapshot
): LfManualBatchProgressResponse {
  return {
    ...progress,
    resume: buildLfProgressResumeAdvice(progress),
    export: buildLfProgressExportMetadata(progress),
  };
}

function buildLfResumeAdvice(state: LfManualBatchState): ManualBatchResumeAdvice {
  const nextOffset = getLfStateNextOffset(state);
  if (state.status === "waiting_for_manual_login" || state.status === "login_detected") {
    return {
      canResume: true,
      action: "continue_after_login",
      runId: state.runId,
      nextOffset,
      reason: "Az LF böngészőfutás bejelentkezés után folytatható.",
    };
  }
  if (state.status === "running" || state.status === "opening_browser") {
    return {
      canResume: false,
      action: "wait_for_current_run",
      runId: state.runId,
      nextOffset,
      reason: "LF futás aktív, várd meg az aktuális lépést vagy állítsd le kézzel.",
    };
  }
  if (["session_lost", "login_timeout", "detached_session_failed"].includes(state.status)) {
    return {
      canResume: true,
      action: "login_again",
      runId: state.runId,
      nextOffset,
      reason: "Az LF session új belépést igényel; indíts új futást a következő offsettel.",
    };
  }
  if (["interrupted", "failed"].includes(state.status)) {
    return {
      canResume: true,
      action: "retry_from_next_offset",
      runId: state.runId,
      nextOffset,
      reason: "A mentett LF futás újraindítható a következő nem feldolgozott offset környékéről.",
    };
  }
  return {
    canResume: false,
    action: "start_new",
    runId: state.runId,
    nextOffset,
    reason: "Nincs folytatandó aktív LF futás; indítható új batch.",
  };
}

function buildLfProgressResumeAdvice(
  progress: LfManualBatchProgressSnapshot
): ManualBatchResumeAdvice {
  return {
    canResume: progress.checked > 0,
    action: progress.checked > 0 ? "retry_from_next_offset" : "start_new",
    runId: progress.runId,
    nextOffset: progress.nextOffset,
    reason:
      progress.checked > 0
        ? "Mentett LF progress alapján a következő offset használható új batch indításához."
        : "Nincs mentett LF progress.",
  };
}

function buildLfExportMetadata(state: LfManualBatchState): ManualBatchExportMetadata {
  return {
    available: state.rows.length > 0,
    format: "sanitized_rows_json",
    suggestedFilename:
      state.rows.length > 0 ? `lf-${sanitizeCode(state.runId)}-sanitized-results.json` : null,
    rowCount: state.rows.length,
    totals: {
      checked: state.totals.checked,
      ok: state.totals.ok,
      failed: state.totals.failed,
      skipped: state.totals.skipped,
      safetyStopped: state.totals.safetyStopped,
    },
    nextOffset: getLfStateNextOffset(state),
    containsSecrets: false,
  };
}

function buildLfProgressExportMetadata(
  progress: LfManualBatchProgressSnapshot
): ManualBatchExportMetadata {
  return {
    available: progress.checked > 0,
    format: "sanitized_rows_json",
    suggestedFilename:
      progress.checked > 0 ? `lf-${sanitizeCode(progress.runId)}-progress-summary.json` : null,
    rowCount: progress.checked,
    totals: {
      checked: progress.checked,
      ok: progress.ok,
      failed: progress.failed,
      skipped: progress.skipped,
      safetyStopped: progress.safetyStopped,
    },
    nextOffset: progress.nextOffset,
    containsSecrets: false,
  };
}

function getLfStateNextOffset(state: LfManualBatchState): number {
  return state.settings.offset + countProgressAdvancingRows(state.rows);
}

function readLfManualBatchSpeedMode(value: unknown): LfManualBatchSpeedMode {
  if (value === undefined || value === null || value === "") return "normal";
  if (value === "normal" || value === "fast" || value === "very_fast") return value;
  throw new LfProductsRouteError(
    "lf_manual_batch_invalid_settings",
    "speedMode must be normal, fast or very_fast",
    400
  );
}

async function readEurHufRate(
  value: unknown,
  loadDefaultEurHufRate: () => Promise<number | null>
): Promise<number> {
  if (value === undefined || value === null || value === "") {
    const latest = await loadDefaultEurHufRate();
    if (latest === null) {
      throw new LfProductsRouteError(
        "pricing_exchange_rate_required",
        "EUR/HUF exchange rate must be provided or saved before starting LF batch",
        400
      );
    }
    return boundedRequiredNumber(latest, 100, 1000, "eurHufRate");
  }
  return boundedRequiredNumber(value, 100, 1000, "eurHufRate");
}

async function readOptionalAutoPairEurHufRate(
  value: unknown,
  loadDefaultEurHufRate: () => Promise<number | null>
): Promise<number> {
  if (value !== undefined && value !== null && value !== "") {
    return boundedRequiredNumber(value, 100, 1000, "eurHufRate");
  }
  const latest = await loadDefaultEurHufRate().catch(() => null);
  return latest === null ? 400 : boundedRequiredNumber(latest, 100, 1000, "eurHufRate");
}

function assertRouteAllowed(
  request: FastifyRequest,
  env: Record<string, string | undefined>
): void {
  if (!isLoopbackIp(request.ip)) {
    throw new LfProductsRouteError(
      "lf_manual_batch_local_only",
      "LF manual batch is local-only",
      403
    );
  }
  if (request.headers[LF_LOCAL_LAB_HEADER] !== "true") {
    throw new LfProductsRouteError(
      "lf_manual_batch_header_missing",
      "LF manual batch requires local lab header",
      403
    );
  }
  const origin = stringHeader(request.headers.origin);
  if (origin && !isAllowedLocalWebOrigin(origin)) {
    throw new LfProductsRouteError(
      "lf_manual_batch_origin_forbidden",
      "LF manual batch requires localhost dashboard origin",
      403
    );
  }
  const referer = stringHeader(request.headers.referer);
  if (!origin && referer && !isAllowedLocalWebOrigin(referer)) {
    throw new LfProductsRouteError(
      "lf_manual_batch_origin_forbidden",
      "LF manual batch requires localhost dashboard origin",
      403
    );
  }
  const explicitlyEnabled = env.ENABLE_SUPPLIER_SESSION_LAB?.trim().toLowerCase() === "true";
  if (env.NODE_ENV === "production" && !explicitlyEnabled) {
    throw new LfProductsRouteError(
      "lf_manual_batch_disabled",
      "LF manual batch is disabled in production unless explicitly enabled",
      403
    );
  }
}

function cloneState(state: LfManualBatchState): LfManualBatchState {
  const telemetry = state.telemetry ?? createLfRunTelemetry(state);
  const summary = state.summary ?? createLfRunSummary(state.rows, state.totals.candidates);
  return {
    ...state,
    settings: { ...state.settings },
    currentItem: state.currentItem ? { ...state.currentItem } : null,
    totals: { ...state.totals },
    telemetry: { ...telemetry },
    summary: { ...summary },
    events: state.events.map((event) => ({ ...event })),
    rows: state.rows.map((row) => ({ ...row, warnings: [...row.warnings] })),
  };
}

function assertNoSensitiveKeys(value: unknown): void {
  if (!isRecord(value)) return;
  for (const key of Object.keys(value)) {
    if (/password|credential|cookie|session|storageState|token|secret/i.test(key)) {
      throw new LfProductsRouteError("sensitive_field", "Sensitive field is not accepted", 400);
    }
  }
}

function boundedInteger(
  value: unknown,
  defaultValue: number,
  min: number,
  max: number,
  field: string
): number {
  if (value === undefined || value === null || value === "") return defaultValue;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new LfProductsRouteError(
      "lf_manual_batch_invalid_settings",
      `${field} must be an integer between ${min} and ${max}`,
      400
    );
  }
  return parsed;
}

function boundedNumber(
  value: unknown,
  defaultValue: number,
  min: number,
  max: number,
  field: string
): number {
  if (value === undefined || value === null || value === "") return defaultValue;
  return boundedRequiredNumber(value, min, max, field);
}

function boundedRequiredNumber(value: unknown, min: number, max: number, field: string): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new LfProductsRouteError(
      "lf_manual_batch_invalid_settings",
      `${field} must be a number between ${min} and ${max}`,
      400
    );
  }
  return parsed;
}

function optionalNullableNumber(
  value: unknown,
  min: number,
  max: number,
  field: string
): number | null {
  if (value === undefined || value === null || value === "") return null;
  return boundedRequiredNumber(value, min, max, field);
}

function optionalBoolean(value: unknown, defaultValue: boolean, field: string): boolean {
  if (value === undefined || value === null || value === "") return defaultValue;
  if (typeof value === "boolean") return value;
  throw new LfProductsRouteError(
    "lf_manual_batch_invalid_settings",
    `${field} must be boolean`,
    400
  );
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isAllowedLocalWebOrigin(value: string): boolean {
  try {
    const url = new URL(value);
    return (
      url.protocol === "http:" &&
      url.port === "3000" &&
      (url.hostname === "localhost" ||
        url.hostname === "127.0.0.1" ||
        url.hostname === "::1" ||
        url.hostname === "[::1]")
    );
  } catch {
    return false;
  }
}

function stringHeader(value: string | string[] | undefined): string | null {
  if (Array.isArray(value)) return value[0] ?? null;
  return value ?? null;
}

function isLoopbackIp(value: string): boolean {
  return value === "127.0.0.1" || value === "::1" || value === "::ffff:127.0.0.1";
}

const isTerminalStatus = isSupplierRunTerminal;

function sanitizeCode(value: string): string {
  return value.replace(/[^A-Za-z0-9._:-]/g, "_").slice(0, 120) || "lf_manual_batch_failed";
}

class LfProductsRouteError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus: number
  ) {
    super(message);
    this.name = "LfProductsRouteError";
  }
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof LfProductsRouteError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  return reply
    .code(500)
    .send({ error: { code: "internal_error", message: "Unexpected LF products API error" } });
}
import {
  acquireSupplierSession,
  releaseSupplierSession,
} from "../dvg-products/dvg-session-lock.js";
