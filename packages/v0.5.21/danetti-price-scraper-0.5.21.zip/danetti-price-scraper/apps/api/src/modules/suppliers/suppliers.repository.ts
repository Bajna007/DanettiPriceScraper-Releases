import {
  supplierCheckSettings,
  suppliers,
  type DanettiDatabase,
  type NewSupplier,
  type NewSupplierCheckSettings,
  type Supplier,
  type SupplierCheckSettings,
} from "@danetti/db";
import { desc, eq } from "drizzle-orm";
import { getOrCreateDvgSupplier } from "./dvg-supplier.js";
import { getOrCreateLfSupplier } from "./lf-supplier.js";

export class SuppliersRepository {
  constructor(private readonly db: DanettiDatabase) {}

  async list(input: { limit: number; offset: number }): Promise<Supplier[]> {
    await Promise.all([getOrCreateDvgSupplier(this.db), getOrCreateLfSupplier(this.db)]);

    return this.db
      .select()
      .from(suppliers)
      .orderBy(desc(suppliers.createdAt))
      .limit(input.limit)
      .offset(input.offset);
  }

  async getById(id: string): Promise<Supplier | null> {
    const [supplier] = await this.db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1);
    return supplier ?? null;
  }

  async create(input: NewSupplier): Promise<Supplier> {
    const [supplier] = await this.db.insert(suppliers).values(input).returning();
    if (supplier === undefined) throw new Error("Failed to create supplier");
    return supplier;
  }

  async update(id: string, input: Partial<NewSupplier>): Promise<Supplier | null> {
    const [supplier] = await this.db
      .update(suppliers)
      .set(input)
      .where(eq(suppliers.id, id))
      .returning();
    return supplier ?? null;
  }

  async getCheckSettingsBySupplierId(supplierId: string): Promise<SupplierCheckSettings | null> {
    const [settings] = await this.db
      .select()
      .from(supplierCheckSettings)
      .where(eq(supplierCheckSettings.supplierId, supplierId))
      .limit(1);
    return settings ?? null;
  }

  async getOrCreateCheckSettingsBySupplierId(supplierId: string): Promise<SupplierCheckSettings> {
    const existing = await this.getCheckSettingsBySupplierId(supplierId);
    if (existing !== null) return existing;

    const [created] = await this.db
      .insert(supplierCheckSettings)
      .values({ supplierId })
      .onConflictDoNothing({ target: supplierCheckSettings.supplierId })
      .returning();

    if (created !== undefined) return created;

    const concurrent = await this.getCheckSettingsBySupplierId(supplierId);
    if (concurrent === null) throw new Error("Failed to create supplier check settings");
    return concurrent;
  }

  async getOrCreateDvgSupplier(): Promise<Supplier> {
    return getOrCreateDvgSupplier(this.db);
  }

  async getOrCreateLfSupplier(): Promise<Supplier> {
    return getOrCreateLfSupplier(this.db);
  }

  async updateCheckSettings(
    supplierId: string,
    input: Partial<NewSupplierCheckSettings>
  ): Promise<SupplierCheckSettings | null> {
    const [settings] = await this.db
      .update(supplierCheckSettings)
      .set(input)
      .where(eq(supplierCheckSettings.supplierId, supplierId))
      .returning();
    return settings ?? null;
  }
}
