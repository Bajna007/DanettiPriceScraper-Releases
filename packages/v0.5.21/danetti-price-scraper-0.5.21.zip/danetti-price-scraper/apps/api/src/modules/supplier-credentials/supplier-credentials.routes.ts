import {
  DVG_CONNECTOR_ID,
  runDvgLoginAndParseDetail,
  type DvgCredentialDetailTestResult,
  type DvgCredentials,
} from "@danetti/connectors";
import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import { SupplierMappingsRepository } from "../supplier-mappings/supplier-mappings.repository.js";
import { SuppliersRepository } from "../suppliers/suppliers.repository.js";
import { SupplierDatabaseError, SupplierValidationError } from "../suppliers/suppliers.types.js";
import {
  createDefaultSupplierCredentialStore,
  type SupplierCredentialStore,
} from "./supplier-credentials.store.js";
import {
  applyCredentialTestResult,
  assertCredentialConnectorSupported,
  createSupplierCredentialSecret,
  credentialsToDvgProvider,
  getSupplierCredentialStatus,
  inferCredentialConnectorId,
  resolveSupplierCredentialForDvg,
  sanitizeCredentialTestCode,
  validateSupplierCredentialSaveInput,
  validateSupplierCredentialTestInput,
  type CredentialSupplier,
} from "./supplier-credentials.service.js";
import {
  SupplierCredentialError,
  type SupplierCredentialDetailTestResponse,
} from "./supplier-credentials.types.js";

interface SupplierCredentialRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  credentialStore?: SupplierCredentialStore;
  supplierSource?: SupplierCredentialSupplierSource;
  mappingSource?: SupplierCredentialMappingSource;
  credentialTester?: SupplierCredentialTester;
  env?: Record<string, string | undefined>;
}

interface SupplierCredentialSupplierSource {
  list(input: { limit: number; offset: number }): Promise<CredentialSupplier[]>;
  getById(id: string): Promise<CredentialSupplier | null>;
}

interface SupplierCredentialTester {
  testDvgCredential(input: {
    credentials: DvgCredentials;
    article: string;
    forensicMode?: "prevent_default_v3";
  }): Promise<DvgCredentialDetailTestResult>;
}

interface SupplierCredentialMappingSource {
  getFirstSupplierArticle(supplierId: string): Promise<string | null>;
}

type SafeDvgCredentialDetailTestResult = Omit<DvgCredentialDetailTestResult, "code"> & {
  code: string;
};

interface IdParams {
  supplierId: string;
}

export async function registerSupplierCredentialRoutes(
  server: FastifyInstance,
  options: SupplierCredentialRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;
  const credentialStore = options.credentialStore ?? createDefaultSupplierCredentialStore();
  const credentialTester = options.credentialTester ?? defaultSupplierCredentialTester;
  const env = options.env ?? process.env;

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getSupplierSource(): SupplierCredentialSupplierSource {
    if (options.supplierSource) return options.supplierSource;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      const repository = new SuppliersRepository(dbClient.db);
      return {
        list: (input) => repository.list(input),
        getById: (id) => repository.getById(id),
      };
    } catch (error) {
      throw new SupplierDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  function getMappingSource(): SupplierCredentialMappingSource {
    if (options.mappingSource) return options.mappingSource;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      const repository = new SupplierMappingsRepository(dbClient.db);
      return {
        async getFirstSupplierArticle(supplierId) {
          const [mapping] = await repository.list({
            supplierId,
            enabled: true,
            limit: 1,
            offset: 0,
          });
          return mapping?.supplierArticleNumber ?? null;
        },
      };
    } catch (error) {
      throw new SupplierDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/supplier-credentials", async (_request, reply) => {
    try {
      const suppliers = await getSupplierSource().list({ limit: 200, offset: 0 });
      const credentialSuppliers = suppliers.filter((supplier) =>
        inferCredentialConnectorId(supplier)
      );
      const items = await Promise.all(
        credentialSuppliers.map((supplier) =>
          getSupplierCredentialStatus({ supplier, store: credentialStore, env })
        )
      );
      return { items, limit: 200, offset: 0 };
    } catch (error) {
      return handleCredentialRouteError(reply, error);
    }
  });

  server.get("/supplier-credentials/:supplierId", async (request, reply) => {
    try {
      const supplier = await getSupplierFromParams(request.params, getSupplierSource());
      return await getSupplierCredentialStatus({ supplier, store: credentialStore, env });
    } catch (error) {
      return handleCredentialRouteError(reply, error);
    }
  });

  server.put("/supplier-credentials/:supplierId", async (request, reply) => {
    try {
      const supplier = await getSupplierFromParams(request.params, getSupplierSource());
      const input = validateSupplierCredentialSaveInput(request.body);
      const connectorId = assertCredentialConnectorSupported(supplier, input.connectorId);
      const secret = createSupplierCredentialSecret({
        supplierId: supplier.id,
        connectorId,
        username: input.username,
        password: input.password,
      });
      await credentialStore.put(secret);
      return await getSupplierCredentialStatus({ supplier, store: credentialStore, env });
    } catch (error) {
      return handleCredentialRouteError(reply, error);
    }
  });

  server.delete("/supplier-credentials/:supplierId", async (request, reply) => {
    try {
      const supplier = await getSupplierFromParams(request.params, getSupplierSource());
      const connectorId = assertCredentialConnectorSupported(supplier, undefined);
      await credentialStore.delete(supplier.id, connectorId);
      return await getSupplierCredentialStatus({ supplier, store: credentialStore, env });
    } catch (error) {
      return handleCredentialRouteError(reply, error);
    }
  });

  server.post("/supplier-credentials/:supplierId/test", async (request, reply) => {
    try {
      const supplier = await getSupplierFromParams(request.params, getSupplierSource());
      const testInput = validateSupplierCredentialTestInput(request.body);
      const connectorId = assertCredentialConnectorSupported(supplier, DVG_CONNECTOR_ID);
      const article =
        testInput.testArticle ??
        (await resolveDvgTestArticle({
          supplierId: supplier.id,
          mappingSource: getMappingSource(),
          env,
        }));
      const resolved = await resolveSupplierCredentialForDvg({
        supplier,
        store: credentialStore,
        env,
      });
      const testResult = await safeTestDvgCredential(credentialTester, {
        credentials: resolved.credentials,
        article,
        forensicMode: testInput.forensicMode,
      });
      if (resolved.storedSecret) {
        await credentialStore.put(
          applyCredentialTestResult(resolved.storedSecret, {
            status: testResult.status === "success" ? "success" : "failed",
            code: testResult.code,
          })
        );
      }
      return buildCredentialTestResponse(supplier.id, connectorId, true, testResult);
    } catch (error) {
      return handleCredentialRouteError(reply, error);
    }
  });
}

const defaultSupplierCredentialTester: SupplierCredentialTester = {
  async testDvgCredential(input) {
    return runDvgLoginAndParseDetail({
      credentialProvider: credentialsToDvgProvider(input.credentials),
      article: input.article,
      forensicMode: input.forensicMode,
    });
  },
};

async function safeTestDvgCredential(
  tester: SupplierCredentialTester,
  input: { credentials: DvgCredentials; article: string; forensicMode?: "prevent_default_v3" }
): Promise<SafeDvgCredentialDetailTestResult> {
  try {
    const result = await tester.testDvgCredential(input);
    return { ...result, code: sanitizeCredentialTestCode(result.code) };
  } catch {
    return {
      status: "failed",
      code: "credential_test_failed",
      loginOk: false,
      detailFetchOk: false,
      parsed: null,
      warnings: ["credential_test_failed"],
      stage: "login_page_open",
      safeMessage: "Credential test failed before DVG login completed.",
      selectorHint: null,
      loginPageMessage: null,
      finalPath: null,
      loginLandingDetected: false,
      usernameFilled: null,
      passwordFilled: null,
      formActionHost: null,
      formMethod: null,
      submitEnabled: null,
      submitEnabledAfterFill: null,
      submitEnabledBeforeSubmit: null,
      submitStrategy: null,
      submitCandidateSummary: [],
      attemptedStrategies: [],
      winningStrategy: null,
      fillStrategy: null,
      forensic: null,
    };
  }
}

async function resolveDvgTestArticle(input: {
  supplierId: string;
  mappingSource: SupplierCredentialMappingSource;
  env: Record<string, string | undefined>;
}): Promise<string> {
  const mappedArticle = await input.mappingSource.getFirstSupplierArticle(input.supplierId);
  if (mappedArticle) return validateResolvedDvgTestArticle(mappedArticle);

  if (input.env.ALLOW_DVG_LIVE_SMOKE === "true" && input.env.DVG_TEST_ARTICLE?.trim()) {
    return validateResolvedDvgTestArticle(input.env.DVG_TEST_ARTICLE);
  }

  throw new SupplierCredentialError(
    "dvg_test_article_missing",
    "DVG test article is required for credential test"
  );
}

function validateResolvedDvgTestArticle(article: string): string {
  const validated = validateSupplierCredentialTestInput({ testArticle: article }).testArticle;
  if (!validated) {
    throw new SupplierCredentialError(
      "dvg_test_article_missing",
      "DVG test article is required for credential test"
    );
  }
  return validated;
}

function buildCredentialTestResponse(
  supplierId: string,
  connectorId: string,
  credentialConfigured: boolean,
  result: SafeDvgCredentialDetailTestResult
): SupplierCredentialDetailTestResponse {
  return {
    status: result.status,
    supplierId,
    connectorId,
    credentialConfigured,
    loginOk: result.loginOk,
    detailFetchOk: result.detailFetchOk,
    parsed: result.parsed,
    warnings: result.warnings,
    errorCode: result.status === "success" ? null : result.code,
    stage: result.stage,
    safeMessage: result.safeMessage,
    selectorHint: result.selectorHint,
    loginPageMessage: result.loginPageMessage,
    finalPath: result.finalPath,
    loginLandingDetected: result.loginLandingDetected,
    fillStrategy: result.fillStrategy,
    usernameFilled: result.usernameFilled,
    passwordFilled: result.passwordFilled,
    formActionHost: result.formActionHost,
    formMethod: result.formMethod,
    submitEnabled: result.submitEnabled,
    submitEnabledAfterFill: result.submitEnabledAfterFill,
    submitEnabledBeforeSubmit: result.submitEnabledBeforeSubmit,
    submitStrategy: result.submitStrategy,
    submitCandidateSummary: result.submitCandidateSummary,
    attemptedStrategies: result.attemptedStrategies,
    winningStrategy: result.winningStrategy,
    activeElementSummary: result.activeElementSummary,
    forensic: result.forensic,
  };
}

async function getSupplierFromParams(
  params: unknown,
  supplierSource: SupplierCredentialSupplierSource
): Promise<CredentialSupplier> {
  const supplierId = (params as IdParams).supplierId;
  validateUuid(supplierId, "supplierId");
  const supplier = await supplierSource.getById(supplierId);
  if (supplier === null) {
    throw new SupplierCredentialError("not_found", "Supplier not found", 404);
  }
  return supplier;
}

function validateUuid(value: string, field: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new SupplierCredentialError("invalid_uuid", `${field} must be a UUID`);
  }
}

function handleCredentialRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof SupplierCredentialError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  if (error instanceof SupplierValidationError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  if (error instanceof SupplierDatabaseError) {
    return reply
      .code(503)
      .send({ error: { code: "database_unavailable", message: error.message } });
  }
  return reply
    .code(500)
    .send({ error: { code: "internal_error", message: "Unexpected credential API error" } });
}
