import {
  createDbClient,
  dvgArticleChangeStates,
  catalogProducts,
  catalogImportRuns,
  catalogImportRows,
  type DanettiDatabase,
} from "@danetti/db";
import { eq, and, inArray, or } from "drizzle-orm";
import type {
  DvgManualBatchCandidate,
  DvgManualBatchSettings,
  DvgManualBatchState,
  DvgManualBatchRow,
} from "@danetti/connectors";
import type { SupplierArticleChangesState, SupplierArticleChangeItem } from "@danetti/shared";
import {
  findArticleCatalogCorrections,
  type ArticleCatalogCorrection,
} from "./article-changes.catalog-reconciliation.js";
import { DvgProductsRepository } from "../dvg-products/dvg-products.repository.js";
import { PricingSettingsRepository } from "../pricing-settings/pricing-settings.repository.js";

export type ArticleReviewRow = Omit<DvgManualBatchRow, "priceBasis"> & {
  priceBasis?: "blue_unit_price_lowest_quantity" | "lf_net_unit_price_lowest_quantity";
};
export type ArticleChangesSource = Pick<
  DvgManualBatchState,
  "runId" | "completedAt" | "settings"
> & { rows: ArticleReviewRow[] };
export interface ArticleChangesRepository {
  load(): Promise<SupplierArticleChangesState | null>;
  save(state: SupplierArticleChangesState): Promise<void>;
  source(): Promise<ArticleChangesSource | null>;
  candidates(settings: DvgManualBatchSettings): Promise<DvgManualBatchCandidate[]>;
  exchangeRate(): Promise<number | null>;
  catalogCorrections?(items: SupplierArticleChangeItem[]): Promise<ArticleCatalogCorrection[]>;
  catalogIdentities?(ids: string[]): Promise<Map<string, string>>;
}

export class DvgArticleChangesRepository implements ArticleChangesRepository {
  constructor(
    protected readonly db: DanettiDatabase,
    private readonly key = "new_shop"
  ) {}
  async load() {
    const [row] = await this.db
      .select()
      .from(dvgArticleChangeStates)
      .where(eq(dvgArticleChangeStates.key, this.key));
    return row ? (row.state as unknown as SupplierArticleChangesState) : null;
  }
  async save(state: SupplierArticleChangesState) {
    await this.db
      .insert(dvgArticleChangeStates)
      .values({
        key: this.key,
        state: state as unknown as Record<string, unknown>,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: dvgArticleChangeStates.key,
        set: { state: state as unknown as Record<string, unknown>, updatedAt: new Date() },
      });
  }
  source(): Promise<ArticleChangesSource | null> {
    return new DvgProductsRepository(this.db).getLatestDvgOperatorRunState("new_shop");
  }
  candidates(settings: DvgManualBatchSettings) {
    return new DvgProductsRepository(this.db).listCandidates({
      ...settings,
      offset: 0,
      limit: 10000,
      onlyMappedDvg: true,
      rerunPreviousNonOkOnly: false,
      allowSuggestedDvgArticle: false,
      allowSkuPrefixCandidate: false,
    });
  }
  async exchangeRate() {
    const rate = await new PricingSettingsRepository(this.db).getLatestExchangeRate();
    return rate ? Number(rate.eurHufRate) : null;
  }
  async catalogCorrections(
    items: SupplierArticleChangeItem[]
  ): Promise<ArticleCatalogCorrection[]> {
    if (!items.length) return [];
    const identities = await this.catalogIdentities(items.map((item) => item.catalogProductId));
    for (const item of items)
      if (item.wooProductId) identities.set(item.catalogProductId, item.wooProductId);
    const wooIds = [...new Set(identities.values())];
    if (!wooIds.length) return [];
    const imported = await this.db
      .select({
        catalogProductId: catalogImportRows.catalogProductId,
        sourceId: catalogImportRows.sourceProductId,
        sku: catalogImportRows.sku,
        currentSku: catalogProducts.sku,
        currentSourceId: catalogProducts.sourceProductId,
        currentVariationId: catalogProducts.sourceVariationId,
        importRunId: catalogImportRuns.id,
        finishedAt: catalogImportRuns.finishedAt,
      })
      .from(catalogImportRows)
      .innerJoin(catalogImportRuns, eq(catalogImportRows.catalogImportRunId, catalogImportRuns.id))
      .leftJoin(catalogProducts, eq(catalogImportRows.catalogProductId, catalogProducts.id))
      .where(
        and(
          eq(catalogImportRuns.status, "completed"),
          inArray(catalogImportRows.status, ["inserted", "updated", "skipped_existing"]),
          inArray(catalogImportRows.sourceProductId, wooIds)
        )
      );
    return findArticleCatalogCorrections(
      items,
      identities,
      imported.flatMap((row) => {
        const id = row.sourceId;
        return id && row.finishedAt && row.sku
          ? [
              {
                catalogProductId: row.catalogProductId ?? "",
                wooId: id,
                sku: row.sku,
                importRunId: row.importRunId,
                finishedAt: row.finishedAt.toISOString(),
                currentSku: row.currentSku,
                currentWooId: row.currentVariationId ?? row.currentSourceId,
              },
            ]
          : [];
      })
    );
  }
  async catalogIdentities(ids: string[]): Promise<Map<string, string>> {
    if (!ids.length) return new Map();
    const rows = await this.db
      .select({
        id: catalogProducts.id,
        wooId: catalogProducts.sourceProductId,
        variationId: catalogProducts.sourceVariationId,
      })
      .from(catalogProducts)
      .where(inArray(catalogProducts.id, ids));
    return new Map(
      rows.flatMap((row) => {
        const id = row.variationId ?? row.wooId;
        return id ? [[row.id, id] as const] : [];
      })
    );
  }
}

export { createDbClient };
