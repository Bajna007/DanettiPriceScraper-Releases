import {
  isLikelyLfOwnArticleCandidate,
  normalizeLfArticle,
  type LfManualBatchCandidate,
  type LfManualBatchRow,
  type LfManualBatchSettings,
  type LfManualBatchState,
} from "@danetti/connectors";
import {
  catalogProducts,
  lfOperatorRuns,
  lfOperatorSettings,
  supplierMappings,
  supplierPriceSnapshots,
  suppliers,
  parseWooSku,
  readWooSkuArticleCandidates,
  type CatalogProduct,
  type DanettiDatabase,
  type NewCatalogProduct,
  type NewSupplierMapping,
  type NewSupplierPriceSnapshot,
  type SupplierMapping,
} from "@danetti/db";
import { and, desc, eq, isNotNull, ne, or } from "drizzle-orm";
import { getOrCreateDvgSupplier } from "../suppliers/dvg-supplier.js";
import { getOrCreateLfSupplier } from "../suppliers/lf-supplier.js";

export interface LfProductsCandidateRepository {
  listCandidates(settings: LfManualBatchSettings): Promise<LfManualBatchCandidate[]>;
  saveCatalogProductLfRunRow?(
    row: LfManualBatchRow,
    input: LfCatalogRunRowPersistenceInput
  ): Promise<LfCatalogRunRowPersistenceResult>;
  getLatestLfRunProgress?(): Promise<LfCatalogRunProgress | null>;
  saveLfOperatorRunState?(state: LfManualBatchState, observedAt: Date): Promise<void>;
  getLatestLfOperatorRunState?(): Promise<LfManualBatchState | null>;
  saveLfOperatorPreferences?(preferences: LfOperatorPreferences, observedAt: Date): Promise<void>;
  getLfOperatorPreferences?(): Promise<LfOperatorPreferences | null>;
  listExactAutoPairCandidates?(
    input: LfExactAutoPairCandidateListInput
  ): Promise<LfExactAutoPairCandidateList>;
  upsertExactAutoPairMapping?(
    input: LfExactAutoPairMappingInput
  ): Promise<LfExactAutoPairMappingResult>;
}

export type LfExactAutoPairCandidateSource =
  | "suggested_supplier_article"
  | "sku_prefix_candidate"
  | "sku_segment_candidate";

export interface LfExactAutoPairCandidate extends LfManualBatchCandidate {
  candidateSource: LfExactAutoPairCandidateSource;
  existingLfMappingId: string | null;
  existingLfSupplierArticleNumber: string | null;
  existingLfDirectUrl: string | null;
}

export interface LfExactAutoPairCandidateListInput {
  limit: number;
  offset: number;
  allowSuggestedLfArticle: boolean;
  allowSkuPrefixCandidate: boolean;
}

export interface LfExactAutoPairCandidateList {
  supplierId: string;
  totalCandidates: number;
  skippedDvgMappedCount: number;
  skippedNotLfCandidateCount: number;
  candidates: LfExactAutoPairCandidate[];
}

export type LfExactAutoPairMappingStatus =
  | "would_create"
  | "would_update"
  | "created"
  | "updated"
  | "verified"
  | "conflict";

export interface LfExactAutoPairMappingInput {
  candidate: LfExactAutoPairCandidate;
  supplierArticleNumber: string;
  directUrl: string;
  supplierProductNameOverride: string | null;
  dryRun: boolean;
  observedAt: Date;
}

export interface LfExactAutoPairMappingResult {
  status: LfExactAutoPairMappingStatus;
  mappingId: string | null;
  existingSupplierArticleNumber: string | null;
}

export type LfPricingWriteControls = Pick<LfManualBatchSettings, "dryRun" | "allowSnapshotWrite">;

export interface LfCatalogRunRowPersistenceInput {
  runId: string;
  globalIndex: number;
  observedAt: Date;
  settings: LfPricingWriteControls;
}

export interface LfCatalogRunRowPersistenceResult {
  progressSaved: boolean;
  pricingSaved: boolean;
}

export interface LfCatalogRunProgress {
  runId: string;
  checked: number;
  ok: number;
  failed: number;
  skipped: number;
  safetyStopped: number;
  nextOffset: number;
  updatedAt: string;
}

export type PersistableLfPricingRow = LfManualBatchRow & {
  supplierNetEur: number;
  supplierNetHuf: number;
  wooGrossHuf: number;
  wooNetHuf: number;
  actualProfitNetHuf: number;
  actualProfitPercentOnCost: number;
};

export interface LfOperatorPreferences {
  autoResume: boolean;
  vatPercent: number;
  targetProfitMultiplier: number | null;
  minimumProfitPercent: number | null;
}

export class LfProductsRepository implements LfProductsCandidateRepository {
  constructor(private readonly db: DanettiDatabase) {}

  async listCandidates(settings: LfManualBatchSettings): Promise<LfManualBatchCandidate[]> {
    if (isLfMappingOnlyCandidateRun(settings)) {
      const candidateList = await this.listExactAutoPairCandidates({
        limit: settings.limit,
        offset: settings.offset,
        allowSuggestedLfArticle: settings.allowSuggestedLfArticle,
        allowSkuPrefixCandidate: settings.allowSkuPrefixCandidate,
      });
      return candidateList.candidates;
    }

    const supplier = await getOrCreateLfSupplier(this.db);
    const candidates: LfManualBatchCandidate[] = [];
    const seen = new Set<string>();
    const targetCount = settings.offset + settings.limit;

    const addCandidate = (candidate: LfManualBatchCandidate, strictLfOwnArticle: boolean) => {
      if (strictLfOwnArticle && !isLikelyLfOwnArticleCandidate(candidate.supplierArticleNumber)) {
        return;
      }
      const key = `${candidate.catalogProductId}:${candidate.supplierArticleNumber}`;
      if (seen.has(key)) return;
      seen.add(key);
      candidates.push(candidate);
    };

    const mappedRowsWhere = settings.rerunPreviousNonOkOnly
      ? and(
          eq(suppliers.id, supplier.id),
          eq(suppliers.enabled, true),
          eq(supplierMappings.enabled, true),
          isNotNull(catalogProducts.lfLastRunStatus),
          ne(catalogProducts.lfLastRunStatus, "ok")
        )
      : and(
          eq(suppliers.id, supplier.id),
          eq(suppliers.enabled, true),
          eq(supplierMappings.enabled, true)
        );

    const mappedRows = await this.db
      .select({
        catalogProductId: catalogProducts.id,
        wooSku: catalogProducts.sku,
        wooName: catalogProducts.name,
        currentPrice: catalogProducts.currentPrice,
        regularPrice: catalogProducts.regularPrice,
        salePrice: catalogProducts.salePrice,
        supplierId: suppliers.id,
        supplierMappingId: supplierMappings.id,
        supplierArticleNumber: supplierMappings.supplierArticleNumber,
      })
      .from(supplierMappings)
      .innerJoin(catalogProducts, eq(supplierMappings.catalogProductId, catalogProducts.id))
      .innerJoin(suppliers, eq(supplierMappings.supplierId, suppliers.id))
      .where(mappedRowsWhere)
      .orderBy(desc(supplierMappings.isPrimary), desc(supplierMappings.updatedAt))
      .limit(targetCount);

    const mappedProductIds = new Set(mappedRows.map((row) => row.catalogProductId));
    for (const row of mappedRows) {
      addCandidate(
        { ...row, candidateSource: "saved_mapping", matchConfidence: "saved_mapping" },
        false
      );
    }

    if (
      settings.rerunPreviousNonOkOnly ||
      settings.onlyMappedLf ||
      candidates.length >= targetCount
    ) {
      return candidates.slice(settings.offset, targetCount);
    }

    if (settings.allowSuggestedLfArticle) {
      const suggestedRows = await this.db
        .select()
        .from(catalogProducts)
        .where(isNotNull(catalogProducts.suggestedSupplierArticle))
        .orderBy(desc(catalogProducts.createdAt))
        .limit(Math.max(targetCount * 5, 25));

      for (const product of suggestedRows) {
        if (candidates.length >= targetCount) break;
        if (mappedProductIds.has(product.id)) continue;
        for (const candidate of readLfExactAutoPairCandidates(product, {
          limit: 1,
          offset: 0,
          allowSuggestedLfArticle: true,
          allowSkuPrefixCandidate: false,
        })) {
          addCandidate(
            productToCandidate(
              product,
              supplier.id,
              candidate.supplierArticleNumber,
              candidate.source
            ),
            true
          );
        }
      }
    }

    if (settings.allowSkuPrefixCandidate && candidates.length < targetCount) {
      const productRows = await this.db
        .select()
        .from(catalogProducts)
        .orderBy(desc(catalogProducts.createdAt))
        .limit(Math.max(targetCount * 20, 100));

      for (const product of productRows) {
        if (candidates.length >= targetCount) break;
        if (mappedProductIds.has(product.id)) continue;
        for (const candidate of readLfExactAutoPairCandidates(product, {
          limit: 10,
          offset: 0,
          allowSuggestedLfArticle: false,
          allowSkuPrefixCandidate: true,
        })) {
          addCandidate(
            productToCandidate(
              product,
              supplier.id,
              candidate.supplierArticleNumber,
              candidate.source
            ),
            true
          );
        }
      }
    }

    return candidates.slice(settings.offset, targetCount);
  }

  async saveCatalogProductLfRunRow(
    row: LfManualBatchRow,
    input: LfCatalogRunRowPersistenceInput
  ): Promise<LfCatalogRunRowPersistenceResult> {
    const values: Partial<NewCatalogProduct> = {
      lfLastRunId: input.runId,
      lfLastRunIndex: input.globalIndex,
      lfLastRunStatus: row.status,
      lfLastRunMessage: buildLfRunMessage(row),
      lfLastRunUpdatedAt: input.observedAt,
      updatedAt: input.observedAt,
    };
    const pricingSaved = canPersistLfTrustedPricingRow(row, input.settings);
    if (pricingSaved) {
      Object.assign(values, {
        lfPurchasePriceEur: decimalString(row.supplierNetEur, 4),
        lfPurchasePriceHuf: decimalString(row.supplierNetHuf, 2),
        lfWooGrossHuf: decimalString(row.wooGrossHuf, 2),
        lfWooNetHuf: decimalString(row.wooNetHuf, 2),
        lfProfitNetHuf: decimalString(row.actualProfitNetHuf, 2),
        lfProfitPercent: decimalString(row.actualProfitPercentOnCost, 2),
        lfSupplierArticleNumber: normalizeLfArticle(row.supplierArticleNumber),
        lfPricingUpdatedAt: input.observedAt,
      });
    }

    await this.db
      .update(catalogProducts)
      .set(values)
      .where(eq(catalogProducts.id, row.catalogProductId));

    if (pricingSaved) {
      await this.insertLfSupplierPriceSnapshot(row, input.observedAt);
    }

    return { progressSaved: true, pricingSaved };
  }

  async getLatestLfRunProgress(): Promise<LfCatalogRunProgress | null> {
    const [latest] = await this.db
      .select({ runId: catalogProducts.lfLastRunId })
      .from(catalogProducts)
      .where(isNotNull(catalogProducts.lfLastRunUpdatedAt))
      .orderBy(desc(catalogProducts.lfLastRunUpdatedAt))
      .limit(1);
    if (!latest?.runId) return null;

    const rows = await this.db
      .select({
        index: catalogProducts.lfLastRunIndex,
        status: catalogProducts.lfLastRunStatus,
        updatedAt: catalogProducts.lfLastRunUpdatedAt,
      })
      .from(catalogProducts)
      .where(eq(catalogProducts.lfLastRunId, latest.runId));

    let checked = 0;
    let ok = 0;
    let skipped = 0;
    let safetyStopped = 0;
    let failed = 0;
    let nextOffset = 0;
    let updatedAt: Date | null = null;
    for (const row of rows) {
      if (typeof row.index !== "number" || !row.status) continue;
      if (isLfRunProgressAdvancingStatus(row.status)) {
        checked += 1;
        nextOffset = Math.max(nextOffset, row.index);
      }
      if (row.status === "ok") ok += 1;
      else if (row.status.startsWith("skipped_")) skipped += 1;
      else failed += 1;
      if (row.status === "safety_stopped") safetyStopped += 1;
      if (row.updatedAt && (updatedAt === null || row.updatedAt > updatedAt)) {
        updatedAt = row.updatedAt;
      }
    }

    return {
      runId: latest.runId,
      checked,
      ok,
      failed,
      skipped,
      safetyStopped,
      nextOffset,
      updatedAt: (updatedAt ?? new Date(0)).toISOString(),
    };
  }

  async saveLfOperatorRunState(state: LfManualBatchState, observedAt: Date): Promise<void> {
    const nextOffset = readLfOperatorRunNextOffset(state);
    await this.db
      .insert(lfOperatorRuns)
      .values({
        runId: state.runId,
        status: state.status,
        startedAt: new Date(state.startedAt),
        completedAt: state.completedAt ? new Date(state.completedAt) : null,
        settings: state.settings as unknown as Record<string, unknown>,
        currentItem: state.currentItem as unknown as Record<string, unknown> | null,
        totals: state.totals as unknown as Record<string, unknown>,
        events: state.events as unknown as Record<string, unknown>[],
        rows: state.rows as unknown as Record<string, unknown>[],
        nextOffset,
        autoResume: true,
        updatedAt: observedAt,
      })
      .onConflictDoUpdate({
        target: lfOperatorRuns.runId,
        set: {
          status: state.status,
          completedAt: state.completedAt ? new Date(state.completedAt) : null,
          settings: state.settings as unknown as Record<string, unknown>,
          currentItem: state.currentItem as unknown as Record<string, unknown> | null,
          totals: state.totals as unknown as Record<string, unknown>,
          events: state.events as unknown as Record<string, unknown>[],
          rows: state.rows as unknown as Record<string, unknown>[],
          nextOffset,
          updatedAt: observedAt,
        },
      });
  }

  async getLatestLfOperatorRunState(): Promise<LfManualBatchState | null> {
    const [run] = await this.db
      .select()
      .from(lfOperatorRuns)
      .orderBy(desc(lfOperatorRuns.updatedAt))
      .limit(1);
    if (!run) return null;
    return {
      runId: run.runId,
      status: run.status as LfManualBatchState["status"],
      startedAt: run.startedAt.toISOString(),
      completedAt: run.completedAt?.toISOString() ?? null,
      settings: run.settings as unknown as LfManualBatchState["settings"],
      currentItem: run.currentItem as unknown as LfManualBatchState["currentItem"],
      totals: run.totals as unknown as LfManualBatchState["totals"],
      events: run.events as unknown as LfManualBatchState["events"],
      rows: run.rows as unknown as LfManualBatchState["rows"],
    };
  }

  async saveLfOperatorPreferences(
    preferences: LfOperatorPreferences,
    observedAt: Date
  ): Promise<void> {
    await this.db
      .insert(lfOperatorSettings)
      .values({
        key: "operator-preferences",
        value: preferences as unknown as Record<string, unknown>,
        updatedAt: observedAt,
      })
      .onConflictDoUpdate({
        target: lfOperatorSettings.key,
        set: {
          value: preferences as unknown as Record<string, unknown>,
          updatedAt: observedAt,
        },
      });
  }

  async getLfOperatorPreferences(): Promise<LfOperatorPreferences | null> {
    const [setting] = await this.db
      .select({ value: lfOperatorSettings.value })
      .from(lfOperatorSettings)
      .where(eq(lfOperatorSettings.key, "operator-preferences"))
      .limit(1);
    return setting?.value ? normalizeLfOperatorPreferences(setting.value) : null;
  }

  private async insertLfSupplierPriceSnapshot(
    row: PersistableLfPricingRow & { supplierMappingId: string },
    observedAt: Date
  ): Promise<void> {
    await this.db
      .insert(supplierPriceSnapshots)
      .values(buildLfSupplierPriceSnapshot(row, observedAt));
  }

  async listExactAutoPairCandidates(
    input: LfExactAutoPairCandidateListInput
  ): Promise<LfExactAutoPairCandidateList> {
    const [lfSupplier, dvgSupplier] = await Promise.all([
      getOrCreateLfSupplier(this.db),
      getOrCreateDvgSupplier(this.db),
    ]);
    const [products, mappings] = await Promise.all([
      this.db.select().from(catalogProducts).orderBy(desc(catalogProducts.createdAt)),
      this.db
        .select()
        .from(supplierMappings)
        .where(
          or(
            eq(supplierMappings.supplierId, lfSupplier.id),
            eq(supplierMappings.supplierId, dvgSupplier.id)
          )
        ),
    ]);
    const activeDvgProductIds = new Set(
      mappings
        .filter((mapping) => mapping.supplierId === dvgSupplier.id && mapping.enabled)
        .map((mapping) => mapping.catalogProductId)
    );
    const lfMappingsByProductId = groupMappingsByCatalogProductId(
      mappings.filter((mapping) => mapping.supplierId === lfSupplier.id)
    );
    const candidates: LfExactAutoPairCandidate[] = [];
    let skippedDvgMappedCount = 0;
    let skippedNotLfCandidateCount = 0;

    for (const product of products) {
      if (activeDvgProductIds.has(product.id)) {
        skippedDvgMappedCount += 1;
        continue;
      }

      const productCandidates = readLfExactAutoPairCandidates(product, input);
      if (productCandidates.length === 0) {
        skippedNotLfCandidateCount += 1;
        continue;
      }

      const existingLfMapping = preferredMapping(lfMappingsByProductId.get(product.id) ?? []);
      for (const candidate of productCandidates) {
        candidates.push(
          productToCandidate(
            product,
            lfSupplier.id,
            candidate.supplierArticleNumber,
            candidate.source,
            existingLfMapping
          )
        );
      }
    }

    return {
      supplierId: lfSupplier.id,
      totalCandidates: candidates.length,
      skippedDvgMappedCount,
      skippedNotLfCandidateCount,
      candidates: candidates.slice(input.offset, input.offset + input.limit),
    };
  }

  async upsertExactAutoPairMapping(
    input: LfExactAutoPairMappingInput
  ): Promise<LfExactAutoPairMappingResult> {
    const lfSupplier = await getOrCreateLfSupplier(this.db);
    const mappings = await this.db
      .select()
      .from(supplierMappings)
      .where(
        and(
          eq(supplierMappings.catalogProductId, input.candidate.catalogProductId),
          eq(supplierMappings.supplierId, lfSupplier.id)
        )
      )
      .orderBy(desc(supplierMappings.enabled), desc(supplierMappings.isPrimary));
    const sameArticleMapping = mappings.find((mapping) =>
      sameLfArticle(mapping.supplierArticleNumber, input.supplierArticleNumber)
    );
    const activePrimary = mappings.find((mapping) => mapping.enabled && mapping.isPrimary) ?? null;

    if (
      activePrimary &&
      activePrimary.id !== sameArticleMapping?.id &&
      !sameLfArticle(activePrimary.supplierArticleNumber, input.supplierArticleNumber)
    ) {
      return {
        status: "conflict",
        mappingId: activePrimary.id,
        existingSupplierArticleNumber: activePrimary.supplierArticleNumber,
      };
    }

    if (sameArticleMapping) {
      const update = buildLfExactAutoPairMappingUpdate(sameArticleMapping, input);
      if (Object.keys(update).length === 0) {
        return {
          status: "verified",
          mappingId: sameArticleMapping.id,
          existingSupplierArticleNumber: sameArticleMapping.supplierArticleNumber,
        };
      }
      if (input.dryRun) {
        return {
          status: "would_update",
          mappingId: sameArticleMapping.id,
          existingSupplierArticleNumber: sameArticleMapping.supplierArticleNumber,
        };
      }
      const [updated] = await this.db
        .update(supplierMappings)
        .set(update)
        .where(eq(supplierMappings.id, sameArticleMapping.id))
        .returning();
      return {
        status: "updated",
        mappingId: updated?.id ?? sameArticleMapping.id,
        existingSupplierArticleNumber: sameArticleMapping.supplierArticleNumber,
      };
    }

    if (input.dryRun) {
      return { status: "would_create", mappingId: null, existingSupplierArticleNumber: null };
    }

    const [created] = await this.db
      .insert(supplierMappings)
      .values({
        catalogProductId: input.candidate.catalogProductId,
        supplierId: lfSupplier.id,
        supplierArticleNumber: input.supplierArticleNumber,
        supplierProductNameOverride: input.supplierProductNameOverride,
        lookupStrategy: "search_then_detail",
        directUrl: input.directUrl,
        priority: 10,
        enabled: true,
        isPrimary: true,
        matchValidationMode: "exact_article_number",
        notes: buildLfExactAutoPairNotes(input.supplierArticleNumber),
        createdBy: "lf_exact_auto_pair",
        updatedBy: "lf_exact_auto_pair",
      })
      .returning();
    if (created === undefined) throw new Error("Failed to create LF exact mapping");
    return { status: "created", mappingId: created.id, existingSupplierArticleNumber: null };
  }
}

function isLfMappingOnlyCandidateRun(settings: LfManualBatchSettings): boolean {
  return settings.onlyMappedLf === false && settings.allowSnapshotWrite === false;
}

function normalizeLfOperatorPreferences(value: Record<string, unknown>): LfOperatorPreferences {
  return {
    autoResume: value.autoResume !== false,
    vatPercent: readNumberPreference(value.vatPercent, 27),
    targetProfitMultiplier: readNullableNumberPreference(value.targetProfitMultiplier),
    minimumProfitPercent: readNullableNumberPreference(value.minimumProfitPercent),
  };
}

function readNumberPreference(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function readNullableNumberPreference(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function productToCandidate(
  product: CatalogProduct,
  supplierId: string,
  supplierArticleNumber: string,
  candidateSource: LfExactAutoPairCandidateSource,
  existingLfMapping?: SupplierMapping | null
): LfExactAutoPairCandidate {
  return {
    catalogProductId: product.id,
    wooSku: product.sku,
    wooName: product.name,
    currentPrice: product.currentPrice,
    regularPrice: product.regularPrice,
    salePrice: product.salePrice,
    supplierId,
    supplierMappingId: existingLfMapping?.id ?? null,
    supplierArticleNumber,
    candidateSource,
    matchConfidence: candidateSource,
    existingLfMappingId: existingLfMapping?.id ?? null,
    existingLfSupplierArticleNumber: existingLfMapping?.supplierArticleNumber ?? null,
    existingLfDirectUrl: existingLfMapping?.directUrl ?? null,
  };
}

export function readLfExactAutoPairCandidates(
  product: Pick<CatalogProduct, "sku" | "suggestedSupplierArticle">,
  input: LfExactAutoPairCandidateListInput
): Array<{ supplierArticleNumber: string; source: LfExactAutoPairCandidateSource }> {
  const candidates: Array<{
    supplierArticleNumber: string;
    source: LfExactAutoPairCandidateSource;
  }> = [];
  const seen = new Set<string>();
  const addCandidate = (
    value: string | null | undefined,
    source: LfExactAutoPairCandidateSource
  ) => {
    const article = normalizeLfArticle(value);
    if (!isLikelyLfOwnArticleCandidate(article) || seen.has(article)) return;
    seen.add(article);
    candidates.push({ supplierArticleNumber: article, source });
  };

  if (input.allowSuggestedLfArticle) {
    addCandidate(product.suggestedSupplierArticle, "suggested_supplier_article");
    addCandidate(
      readLabeledCikkszamArticle(product.suggestedSupplierArticle),
      "suggested_supplier_article"
    );
  }

  if (input.allowSkuPrefixCandidate) {
    const parsed = parseWooSku(product.sku);
    const skuSegments = product.sku.includes("__")
      ? readWooSkuArticleCandidates(product.sku)
      : parsed.fullSku.split("_");
    const skuPrefix = skuSegments[0];
    addCandidate(skuPrefix, "sku_prefix_candidate");
    addCandidate(readLabeledCikkszamArticle(skuPrefix), "sku_prefix_candidate");

    for (const skuSegment of skuSegments.slice(1)) {
      addCandidate(skuSegment, "sku_segment_candidate");
    }
  }

  return candidates;
}

function readLabeledCikkszamArticle(value: string | null | undefined): string | null {
  const asciiLabel = normalizeLfArticle(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  return /^CIKKSZAM:\s*(\d{4,10})$/.exec(asciiLabel)?.[1] ?? null;
}

function groupMappingsByCatalogProductId(
  mappings: SupplierMapping[]
): Map<string, SupplierMapping[]> {
  const grouped = new Map<string, SupplierMapping[]>();
  for (const mapping of mappings) {
    const current = grouped.get(mapping.catalogProductId) ?? [];
    current.push(mapping);
    grouped.set(mapping.catalogProductId, current);
  }
  return grouped;
}

function preferredMapping(mappings: SupplierMapping[]): SupplierMapping | null {
  return (
    mappings.find((mapping) => mapping.enabled && mapping.isPrimary) ??
    mappings.find((mapping) => mapping.enabled) ??
    mappings[0] ??
    null
  );
}

function sameLfArticle(left: string, right: string): boolean {
  return normalizeLfArticle(left) === normalizeLfArticle(right);
}

export function buildLfSupplierPriceSnapshot(
  row: PersistableLfPricingRow & { supplierMappingId: string },
  observedAt: Date
): NewSupplierPriceSnapshot {
  return {
    supplierId: row.supplierId,
    supplierMappingId: row.supplierMappingId,
    catalogProductId: row.catalogProductId,
    crawlerRunItemId: null,
    supplierArticleNumber: normalizeLfArticle(row.supplierArticleNumber),
    supplierProductName: row.lfProductName,
    priceNetEur: decimalString(row.supplierNetEur, 2),
    priceGrossEur: row.supplierGrossEur === null ? null : decimalString(row.supplierGrossEur, 2),
    currency: row.currency ?? "EUR",
    stockStatus: "unknown",
    availabilityText: null,
    matchConfidence: "exact",
    resultUrl: row.lfFinalUrl,
    observedAt,
    evidenceArtifactId: null,
  };
}

export function readLfOperatorRunNextOffset(state: LfManualBatchState): number {
  const processedRows = state.rows.filter((row) =>
    isLfRunProgressAdvancingStatus(row.status)
  ).length;
  return state.settings.offset + processedRows;
}

function isPersistableLfPricingRow(row: LfManualBatchRow): row is PersistableLfPricingRow {
  return (
    row.status === "ok" &&
    row.currency === "EUR" &&
    Number.isFinite(row.supplierNetEur) &&
    Number.isFinite(row.supplierNetHuf) &&
    Number.isFinite(row.wooGrossHuf) &&
    Number.isFinite(row.wooNetHuf) &&
    Number.isFinite(row.actualProfitNetHuf) &&
    Number.isFinite(row.actualProfitPercentOnCost)
  );
}

export function canWriteLfTrustedPricing(settings: LfPricingWriteControls): boolean {
  return settings.dryRun === false && settings.allowSnapshotWrite === true;
}

export function canPersistLfTrustedPricingRow(
  row: LfManualBatchRow,
  settings: LfPricingWriteControls
): row is PersistableLfPricingRow & { supplierMappingId: string } {
  const autocompleteId = row.lfAutocompleteId;
  return (
    canWriteLfTrustedPricing(settings) &&
    isPersistableLfPricingRow(row) &&
    row.supplierMappingId !== null &&
    row.candidateSource === "saved_mapping" &&
    row.matchConfidence === "trusted_lf_item" &&
    autocompleteId !== null &&
    autocompleteId.startsWith("C:") &&
    sameLfArticle(autocompleteId.slice(2), row.supplierArticleNumber)
  );
}

function decimalString(value: number, scale: number): string {
  return value.toFixed(scale).replace(/0+$/, "").replace(/\.$/, "");
}

export function buildLfRunMessage(row: LfManualBatchRow): string {
  const message = readLfRunMessage(row);
  return message.slice(0, 500);
}

function readLfRunMessage(row: LfManualBatchRow): string {
  if (row.status === "article_changed") {
    return row.lfPartNumber && row.lfPartNumber !== row.supplierArticleNumber
      ? `LF cikkszám megváltozott: új cikkszám ${row.lfPartNumber}; mapping ellenőrzés kell.`
      : "LF cikkszám megváltozott; mapping ellenőrzés kell.";
  }
  if (hasLfWarning(row, "lf_supplier_article_changed", "lf_article_replaced_or_changed")) {
    return row.lfPartNumber && row.lfPartNumber !== row.supplierArticleNumber
      ? `LF cikkszám megváltozott: új cikkszám ${row.lfPartNumber}; mapping ellenőrzés kell.`
      : "LF cikkszám megváltozott; mapping ellenőrzés kell.";
  }
  if (hasLfWarning(row, "lf_item_no_longer_in_production")) {
    return "LF szerint a termék már nem gyártott.";
  }
  if (hasLfWarning(row, "lf_item_cancelled")) return "LF szerint a cikk törölt/cancelled.";
  if (row.status === "item_not_available" || hasLfWarning(row, "lf_item_not_available")) {
    return "LF szerint a cikk jelenleg nem rendelhető / item not available.";
  }
  if (
    hasLfWarning(
      row,
      "lf_no_match",
      "lf_article_not_found",
      "lf_empty_detail_or_search_redirect",
      "lf_product_id_missing",
      "lf_part_number_missing"
    )
  ) {
    return "LF nem találta a cikkszámot, vagy üres/keresési oldalra irányított.";
  }
  if (hasLfWarning(row, "lf_login_required"))
    return "LF session/login elveszett; új bejelentkezés kell.";
  if (row.status === "cross_reference_only") {
    const manufacturer = row.lfManufacturerName?.trim();
    const reference = row.lfAutocompleteId?.trim();
    const evidence = [manufacturer, reference].filter(Boolean).join(" · ");
    const source =
      manufacturer && /de\s*vecchi|devecchi/i.test(manufacturer)
        ? "DVG-jelölt"
        : manufacturer
          ? "külső forrás-jelölt"
          : "más beszállítói forrás-jelölt";
    return `LF kereszthivatkozás${evidence ? `: ${evidence}` : ""}. Fő forrás: ${source}; LF mapping nem készült.`;
  }
  if (row.status === "price_missing" || hasLfWarning(row, "lf_net_unit_price_missing")) {
    return "LF termékoldal van, de nettó ár nincs; lehet kifutott vagy nem rendelhető.";
  }
  if (row.status === "ambiguous_match")
    return "LF találat nem egyértelmű; mapping ellenőrzés kell.";
  if (row.status === "needs_mapping_review") return "LF mapping ellenőrzés kell.";
  if (row.status === "item_timeout") return "LF tétel időtúllépés miatt kimaradt.";
  if (row.status === "redirected_to_login")
    return "LF session/login elveszett; új bejelentkezés kell.";
  if (row.status.startsWith("skipped_")) return "LF tétel kihagyva: nincs megbízható cikkszám.";
  if (row.status === "ok") {
    return row.supplierNetEur === null ? "LF detail oldal ellenőrizve." : "LF ár beolvasva.";
  }
  return row.warnings.length > 0 ? row.warnings.join("; ") : row.matchConfidence;
}

function hasLfWarning(row: LfManualBatchRow, ...warnings: string[]): boolean {
  return warnings.some((warning) => row.warnings.includes(warning));
}

function isLfRunProgressAdvancingStatus(status: string): boolean {
  return status !== "redirected_to_login";
}

function buildLfExactAutoPairMappingUpdate(
  mapping: SupplierMapping,
  input: LfExactAutoPairMappingInput
): Partial<NewSupplierMapping> {
  const update: Partial<NewSupplierMapping> = {};
  if (!sameLfArticle(mapping.supplierArticleNumber, input.supplierArticleNumber)) {
    update.supplierArticleNumber = input.supplierArticleNumber;
  }
  if (mapping.supplierProductNameOverride !== input.supplierProductNameOverride) {
    update.supplierProductNameOverride = input.supplierProductNameOverride;
  }
  if (mapping.lookupStrategy !== "search_then_detail") update.lookupStrategy = "search_then_detail";
  if (mapping.directUrl !== input.directUrl) update.directUrl = input.directUrl;
  if (!mapping.enabled) update.enabled = true;
  if (!mapping.isPrimary) update.isPrimary = true;
  if (mapping.notes !== buildLfExactAutoPairNotes(input.supplierArticleNumber)) {
    update.notes = buildLfExactAutoPairNotes(input.supplierArticleNumber);
  }
  if (Object.keys(update).length > 0) {
    update.updatedAt = input.observedAt;
    update.updatedBy = "lf_exact_auto_pair";
  }
  return update;
}

function buildLfExactAutoPairNotes(supplierArticleNumber: string): string {
  return `LF exact auto-pair: trusted own item C:${normalizeLfArticle(supplierArticleNumber)}; detail URL observed.`;
}
