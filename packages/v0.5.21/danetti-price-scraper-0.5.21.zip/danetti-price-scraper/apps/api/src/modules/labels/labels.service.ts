import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { basename, extname, relative, resolve } from "node:path";
import {
  createBlankBeanOnTemplateScene,
  createBlankUtopiaTemplateScene,
  createBeanOnSeeds,
  createPrintSheetExport,
  createTemplateScene,
  createUtopiaSeeds,
  DEFAULT_LABEL_FONT_ID,
  hasBlockingIssues,
  loadFontAssetFile,
  missingGlyphs,
  parseFont,
  parseFontFile,
  preflightScene,
  renderSvg,
  validateScene,
  stableJson,
  type ExportOrderItem,
  type ExportProfile,
  type FontAsset,
  type LabelBrand,
  type LabelScene,
} from "@danetti/label-engine";
import type { DanettiSqlClient } from "@danetti/db";
import { migrateStoredLabelScenes } from "./scene-migrations.js";

export class LabelStudioError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode = 400
  ) {
    super(message);
    this.name = "LabelStudioError";
  }
}

type Row = Record<string, unknown>;
type LooseQuery = (query: string, parameters?: unknown[]) => Promise<unknown>;
const LATIN_UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const LATIN_LOWERCASE = "abcdefghijklmnopqrstuvwxyz";
const REFERENCE_SUBSET_FONT_IDS = new Set([
  "00000000-0000-4000-8000-000000000002",
  "00000000-0000-4000-8000-000000000003",
  "00000000-0000-4000-8000-000000000004",
]);

type BundledLabelAsset = {
  id: string;
  brand: LabelBrand | null;
  kind: "font" | "svg" | "binary";
  filename: string;
  mimeType: string;
  sha256: string;
  family: string | null;
  style: string | null;
  weight: number | null;
  active: boolean;
  metadata: Row;
  file: string;
};
type BundledLabelTemplate = {
  brand: LabelBrand;
  code: string;
  name: string;
  active: boolean;
  scene: LabelScene;
};
type BundledLabelDesign = {
  brand: LabelBrand;
  name: string;
  internalCode: string;
  templateCode: string;
  visible: boolean;
  sortOrder: number;
  status: "draft" | "approved" | "archived";
  revision: number;
  scene: LabelScene;
};
type BundledLabelCatalog = {
  schemaVersion: "1.0.0";
  catalogId: string;
  assets: BundledLabelAsset[];
  templates: BundledLabelTemplate[];
  designs: BundledLabelDesign[];
};
type LoadedBundledLabelCatalog = {
  catalog: BundledLabelCatalog;
  digest: string;
};
export class LabelStudioService {
  private seeded = false;
  private seeding: Promise<void> | null = null;
  private readonly raw: LooseQuery;
  constructor(
    private readonly sql: DanettiSqlClient,
    private readonly now: () => Date = () => new Date()
  ) {
    const unsafe = sql.unsafe.bind(sql) as unknown as LooseQuery;
    this.raw = (query, parameters) => unsafe(query, normalizeParameters(parameters));
  }

  async ensureSeeded(): Promise<void> {
    if (this.seeded) return;
    this.seeding ??= this.seed().finally(() => {
      this.seeding = null;
    });
    await this.seeding;
  }

  private async seed(): Promise<void> {
    const bundledCatalog = loadBundledLabelCatalog();
    await this.sql.begin(async (tx) => {
      const unsafe = tx.unsafe.bind(tx) as unknown as LooseQuery;
      const raw: LooseQuery = (query, parameters) => unsafe(query, normalizeParameters(parameters));
      await raw(`SELECT pg_advisory_xact_lock(hashtext('danetti-label-studio-seed'))`);
      const bundledAssetIds = await this.installBundledAssets(raw, bundledCatalog.catalog);
      await this.ensureDefaultFont(raw);
      // Apply the portable update catalog first, then let the code-owned reference
      // seeds advance any older bundled scene to the current validated revision.
      await this.syncBundledCatalog(raw, bundledCatalog, bundledAssetIds);
      for (const brand of ["utopia", "bean_on", "custom"] as const) {
        const code =
          brand === "custom"
            ? "custom-blank"
            : brand === "utopia"
              ? "utopia-102x35"
              : "bean-on-110x35";
        const name =
          brand === "custom"
            ? "Egyedi, szabad méretű címke"
            : brand === "utopia"
              ? "Utopia 102 × 35 mm"
              : "Bean On 110 × 35 mm";
        await raw(
          `INSERT INTO label_templates (brand, code, name) VALUES ($1::label_brand, $2, $3) ON CONFLICT (brand, code) DO NOTHING`,
          [brand, code, name]
        );
        const template = first(
          await raw(`SELECT * FROM label_templates WHERE brand = $1::label_brand AND code = $2`, [
            brand,
            code,
          ])
        );
        if (!template)
          throw new LabelStudioError(
            "template_seed_failed",
            `A(z) ${name} sablon nem hozható létre.`,
            500
          );
        const targetTemplateScene = createTemplateScene(brand);
        let templateVersionId = stringValue(template.current_version_id);
        if (!templateVersionId) {
          const version = first(
            await raw(
              `INSERT INTO label_template_versions (template_id, version, scene, field_schema, note) VALUES ($1, 1, $2::jsonb, $3::jsonb, $4) RETURNING id`,
              [
                template.id,
                JSON.stringify(targetTemplateScene),
                JSON.stringify(targetTemplateScene.fieldSchema),
                "Golden master forrásból rekonstruált sablon",
              ]
            )
          );
          templateVersionId = stringValue(version?.id);
          await raw(
            `UPDATE label_templates SET current_version_id = $2, updated_at = now() WHERE id = $1`,
            [template.id, templateVersionId]
          );
        } else {
          const currentTemplateVersion = first(
            await raw(`SELECT scene FROM label_template_versions WHERE id = $1`, [
              templateVersionId,
            ])
          );
          if (
            shouldRefreshSystemReferenceScene(currentTemplateVersion?.scene, targetTemplateScene)
          ) {
            const nextVersion = Number(
              first(
                await raw(
                  `SELECT COALESCE(MAX(version), 0) + 1 AS version FROM label_template_versions WHERE template_id = $1`,
                  [template.id]
                )
              )?.version ?? 1
            );
            const version = first(
              await raw(
                `INSERT INTO label_template_versions (template_id, version, scene, field_schema, note) VALUES ($1, $2, $3::jsonb, $4::jsonb, $5) RETURNING id`,
                [
                  template.id,
                  nextVersion,
                  JSON.stringify(targetTemplateScene),
                  JSON.stringify(targetTemplateScene.fieldSchema),
                  "Referencia-PDF validált sablonszinkron",
                ]
              )
            );
            templateVersionId = stringValue(version?.id);
            await raw(
              `UPDATE label_templates SET current_version_id = $2, updated_at = now() WHERE id = $1`,
              [template.id, templateVersionId]
            );
          }
        }
        const seeds =
          brand === "custom" ? [] : brand === "utopia" ? createUtopiaSeeds() : createBeanOnSeeds();
        for (let index = 0; index < seeds.length; index += 1) {
          const seed = seeds[index]!;
          await raw(
            `INSERT INTO label_designs (brand, name, internal_code, template_id, visible, sort_order, status) VALUES ($1::label_brand, $2, $3, $4, true, $5, 'approved') ON CONFLICT (brand, internal_code) DO NOTHING`,
            [brand, seed.name, seed.internalCode, template.id, index]
          );
          const design = first(
            await raw(
              `SELECT * FROM label_designs WHERE brand = $1::label_brand AND internal_code = $2`,
              [brand, seed.internalCode]
            )
          );
          if (design && !design.current_version_id) {
            const version = first(
              await raw(
                `INSERT INTO label_design_versions (design_id, template_version_id, version, scene, note) VALUES ($1, $2, 1, $3::jsonb, $4) RETURNING id`,
                [design.id, templateVersionId, JSON.stringify(seed.scene), "Forrás-PDF seed"]
              )
            );
            await raw(`UPDATE label_designs SET current_version_id = $2 WHERE id = $1`, [
              design.id,
              version?.id,
            ]);
          } else if (design?.current_version_id) {
            const currentVersion = first(
              await raw(`SELECT scene FROM label_design_versions WHERE id = $1`, [
                design.current_version_id,
              ])
            );
            if (shouldRefreshSystemReferenceScene(currentVersion?.scene, seed.scene)) {
              const nextVersion = Number(
                first(
                  await raw(
                    `SELECT COALESCE(MAX(version), 0) + 1 AS version FROM label_design_versions WHERE design_id = $1`,
                    [design.id]
                  )
                )?.version ?? 1
              );
              const version = first(
                await raw(
                  `INSERT INTO label_design_versions (design_id, template_version_id, version, scene, note) VALUES ($1, $2, $3, $4::jsonb, $5) RETURNING id`,
                  [
                    design.id,
                    templateVersionId,
                    nextVersion,
                    JSON.stringify(seed.scene),
                    "Referencia-PDF validált v2 szinkron",
                  ]
                )
              );
              await raw(
                `UPDATE label_designs SET current_version_id = $2, revision = revision + 1, updated_at = now() WHERE id = $1`,
                [design.id, version?.id]
              );
            }
          }
        }
        const blankTemplates =
          brand === "custom"
            ? []
            : brand === "utopia"
              ? [
                  {
                    code: "utopia-empty",
                    name: "Üres Utopia 102×35 mm",
                    note: "Új címke helyőrző sablon",
                    scene: createBlankUtopiaTemplateScene(),
                  },
                ]
              : [
                  {
                    code: "bean-on-single-origin",
                    name: "Üres Bean On — single origin",
                    note: "Új Bean On single origin helyőrző sablon",
                    scene: createBlankBeanOnTemplateScene("single_origin"),
                  },
                  {
                    code: "bean-on-blend",
                    name: "Üres Bean On — keverék",
                    note: "Új Bean On keverék helyőrző sablon",
                    scene: createBlankBeanOnTemplateScene("blend"),
                  },
                ];
        for (const blankTemplate of blankTemplates) {
          await raw(
            `INSERT INTO label_templates (brand, code, name) VALUES ($1::label_brand, $2, $3) ON CONFLICT (brand, code) DO NOTHING`,
            [brand, blankTemplate.code, blankTemplate.name]
          );
          const blank = first(
            await raw(`SELECT * FROM label_templates WHERE brand = $1::label_brand AND code = $2`, [
              brand,
              blankTemplate.code,
            ])
          );
          if (!blank)
            throw new LabelStudioError(
              "template_seed_failed",
              `A(z) ${blankTemplate.name} sablon nem hozható létre.`,
              500
            );
          const currentBlankVersionId = stringValue(blank.current_version_id);
          const currentBlankVersion = currentBlankVersionId
            ? first(
                await raw(`SELECT scene FROM label_template_versions WHERE id = $1`, [
                  currentBlankVersionId,
                ])
              )
            : null;
          if (
            !currentBlankVersionId ||
            shouldRefreshSystemBlankTemplate(
              blankTemplate.code,
              currentBlankVersion?.scene,
              blankTemplate.scene
            )
          ) {
            const nextVersion = Number(
              first(
                await raw(
                  `SELECT COALESCE(MAX(version), 0) + 1 AS version FROM label_template_versions WHERE template_id = $1`,
                  [blank.id]
                )
              )?.version ?? 1
            );
            const version = first(
              await raw(
                `INSERT INTO label_template_versions (template_id, version, scene, field_schema, note) VALUES ($1, $2, $3::jsonb, $4::jsonb, $5) RETURNING id`,
                [
                  blank.id,
                  nextVersion,
                  JSON.stringify(blankTemplate.scene),
                  JSON.stringify(blankTemplate.scene.fieldSchema),
                  blankTemplate.note,
                ]
              )
            );
            await raw(
              `UPDATE label_templates SET current_version_id = $2, updated_at = now() WHERE id = $1`,
              [blank.id, version?.id]
            );
          }
          if (brand === "utopia" && blankTemplate.code === "utopia-empty") {
            const blankDesigns = rows(
              await raw(
                `SELECT d.id, d.revision, dv.version, dv.scene, dv.template_version_id
                 FROM label_designs d
                 JOIN label_design_versions dv ON dv.id = d.current_version_id
                 WHERE d.template_id = $1
                 FOR UPDATE OF d`,
                [blank.id]
              )
            );
            for (const design of blankDesigns) {
              const repaired = repairBlankUtopiaTypography(design.scene, blankTemplate.scene);
              if (!repaired) continue;
              const nextVersion = Number(design.version ?? 0) + 1;
              const version = first(
                await raw(
                  `INSERT INTO label_design_versions (design_id, template_version_id, version, scene, note)
                   VALUES ($1, $2, $3, $4::jsonb, $5) RETURNING id`,
                  [
                    design.id,
                    design.template_version_id,
                    nextVersion,
                    JSON.stringify(repaired),
                    "Utopia üres sablon referencia-lábléc javítás",
                  ]
                )
              );
              await raw(
                `UPDATE label_designs
                 SET current_version_id = $2, revision = revision + 1, updated_at = now()
                 WHERE id = $1`,
                [design.id, version?.id]
              );
            }
          }
        }
        await raw(
          `INSERT INTO label_orders (brand, status, active) VALUES ($1::label_brand, 'draft', true) ON CONFLICT DO NOTHING`,
          [brand]
        );
      }
      await migrateStoredLabelScenes(raw, (scene) => remapCatalogScene(scene, bundledAssetIds));
    });
    this.seeded = true;
  }

  private async installBundledAssets(
    raw: LooseQuery,
    catalog: BundledLabelCatalog
  ): Promise<Map<string, string>> {
    const effectiveIds = new Map<string, string>();
    for (const asset of catalog.assets) {
      const bytes = readCatalogAssetBytes(asset);
      const existing = first(
        await raw(
          `SELECT id FROM label_assets WHERE id=$1 OR sha256=$2 ORDER BY CASE WHEN id=$1 THEN 0 ELSE 1 END LIMIT 1`,
          [asset.id, asset.sha256]
        )
      );
      const existingId = stringValue(existing?.id);
      if (existingId && existingId !== asset.id) {
        effectiveIds.set(asset.id, existingId);
        continue;
      }
      if (existingId) {
        await raw(
          `UPDATE label_assets
           SET brand=$2::label_brand, kind=$3::label_asset_kind, filename=$4, mime_type=$5,
               sha256=$6, family=$7, style=$8, weight=$9, active=$10, data=$11,
               metadata=$12::jsonb, updated_at=now()
           WHERE id=$1`,
          [
            asset.id,
            asset.brand,
            asset.kind,
            asset.filename,
            asset.mimeType,
            asset.sha256,
            asset.family,
            asset.style,
            asset.weight,
            asset.active,
            bytes,
            JSON.stringify(asset.metadata),
          ]
        );
      } else {
        await raw(
          `INSERT INTO label_assets
           (id,brand,kind,filename,mime_type,sha256,family,style,weight,active,data,metadata)
           VALUES ($1,$2::label_brand,$3::label_asset_kind,$4,$5,$6,$7,$8,$9,$10,$11,$12::jsonb)`,
          [
            asset.id,
            asset.brand,
            asset.kind,
            asset.filename,
            asset.mimeType,
            asset.sha256,
            asset.family,
            asset.style,
            asset.weight,
            asset.active,
            bytes,
            JSON.stringify(asset.metadata),
          ]
        );
      }
      effectiveIds.set(asset.id, asset.id);
    }
    return effectiveIds;
  }

  private async syncBundledCatalog(
    raw: LooseQuery,
    bundled: LoadedBundledLabelCatalog,
    assetIds: Map<string, string>
  ): Promise<void> {
    const synced = first(
      await raw(`SELECT digest FROM label_catalog_syncs WHERE catalog_id=$1`, [
        bundled.catalog.catalogId,
      ])
    );
    if (stringValue(synced?.digest) === bundled.digest) return;

    const templateIds = new Map<string, { id: string; versionId: string }>();
    for (const template of bundled.catalog.templates) {
      let stored = first(
        await raw(`SELECT id FROM label_templates WHERE brand=$1::label_brand AND code=$2`, [
          template.brand,
          template.code,
        ])
      );
      if (!stored) {
        stored = first(
          await raw(
            `INSERT INTO label_templates (brand, code, name, active) VALUES ($1::label_brand,$2,$3,$4) RETURNING id`,
            [template.brand, template.code, template.name, template.active]
          )
        );
      }
      const templateId = stringValue(stored?.id);
      const nextVersion = Number(
        first(
          await raw(
            `SELECT COALESCE(MAX(version), 0) + 1 AS version FROM label_template_versions WHERE template_id=$1`,
            [templateId]
          )
        )?.version ?? 1
      );
      const version = first(
        await raw(
          `INSERT INTO label_template_versions (template_id,version,scene,field_schema,note)
           VALUES ($1,$2,$3::jsonb,$4::jsonb,$5) RETURNING id`,
          [
            templateId,
            nextVersion,
            JSON.stringify(remapCatalogScene(template.scene, assetIds)),
            JSON.stringify(template.scene.fieldSchema),
            `VerziĂłzott cĂ­mkekatalĂłgus: ${bundled.catalog.catalogId}`,
          ]
        )
      );
      const versionId = stringValue(version?.id);
      await raw(
        `UPDATE label_templates SET name=$2, active=$3, current_version_id=$4, updated_at=now() WHERE id=$1`,
        [templateId, template.name, template.active, versionId]
      );
      templateIds.set(`${template.brand}:${template.code}`, { id: templateId, versionId });
    }

    for (const design of bundled.catalog.designs) {
      const template = templateIds.get(`${design.brand}:${design.templateCode}`);
      if (!template)
        throw new LabelStudioError(
          "catalog_template_missing",
          `A(z) ${design.internalCode} címkekatalógus-sablonja hiányzik.`,
          500
        );
      let stored = first(
        await raw(
          `SELECT id,revision FROM label_designs WHERE brand=$1::label_brand AND internal_code=$2`,
          [design.brand, design.internalCode]
        )
      );
      // A release catalog supplies missing labels, never overwrites locally authored versions.
      if (stored) continue;
      if (!stored) {
        stored = first(
          await raw(
            `INSERT INTO label_designs (brand,name,internal_code,template_id,visible,sort_order,status)
             VALUES ($1::label_brand,$2,$3,$4,$5,$6,$7::label_design_status) RETURNING id,revision`,
            [
              design.brand,
              design.name,
              design.internalCode,
              template.id,
              design.visible,
              design.sortOrder,
              design.status,
            ]
          )
        );
      }
      const designId = stringValue(stored?.id);
      const nextVersion = Number(
        first(
          await raw(
            `SELECT COALESCE(MAX(version), 0) + 1 AS version FROM label_design_versions WHERE design_id=$1`,
            [designId]
          )
        )?.version ?? 1
      );
      const version = first(
        await raw(
          `INSERT INTO label_design_versions (design_id,template_version_id,version,scene,note)
           VALUES ($1,$2,$3,$4::jsonb,$5) RETURNING id`,
          [
            designId,
            template.versionId,
            nextVersion,
            JSON.stringify(remapCatalogScene(design.scene, assetIds)),
            `VerziĂłzott cĂ­mkekatalĂłgus: ${bundled.catalog.catalogId}`,
          ]
        )
      );
      const revision = Math.max(1, design.revision);
      await raw(
        `UPDATE label_designs
         SET name=$2, template_id=$3, visible=$4, sort_order=$5, status=$6::label_design_status,
             current_version_id=$7, revision=$8, updated_at=now()
         WHERE id=$1`,
        [
          designId,
          design.name,
          template.id,
          design.visible,
          design.sortOrder,
          design.status,
          version?.id,
          revision,
        ]
      );
    }
    await raw(
      `INSERT INTO label_catalog_syncs (catalog_id,digest,applied_at) VALUES ($1,$2,now())
       ON CONFLICT (catalog_id) DO UPDATE SET digest=EXCLUDED.digest, applied_at=EXCLUDED.applied_at`,
      [bundled.catalog.catalogId, bundled.digest]
    );
  }

  async listTemplates(brand?: LabelBrand): Promise<Row[]> {
    await this.ensureSeeded();
    return rows(
      await this.raw(
        `SELECT t.*, tv.version, tv.field_schema, tv.scene FROM label_templates t LEFT JOIN label_template_versions tv ON tv.id = t.current_version_id WHERE ($1::text IS NULL OR t.brand::text = $1) ORDER BY t.brand, t.name`,
        [brand ?? null]
      )
    );
  }

  async createTemplate(input: Row): Promise<Row> {
    const brand = readBrand(input.brand);
    const code = requiredString(input.code, "A sablonkód kötelező.");
    const name = requiredString(input.name, "A sablonnév kötelező.");
    const scene = readScene(input.scene ?? createTemplateScene(brand));
    if (scene.brand !== brand)
      throw new LabelStudioError("brand_mismatch", "A sablon címkecsoportja eltér.");
    const template = first(
      await this.raw(
        `INSERT INTO label_templates (brand, code, name) VALUES ($1::label_brand, $2, $3) RETURNING *`,
        [brand, code, name]
      )
    );
    const version = first(
      await this.raw(
        `INSERT INTO label_template_versions (template_id, version, scene, field_schema, note) VALUES ($1, 1, $2::jsonb, $3::jsonb, $4) RETURNING *`,
        [
          template?.id,
          JSON.stringify(scene),
          JSON.stringify(scene.fieldSchema),
          optionalString(input.note),
        ]
      )
    );
    await this.raw(`UPDATE label_templates SET current_version_id = $2 WHERE id = $1`, [
      template?.id,
      version?.id,
    ]);
    return { ...template, current_version_id: version?.id, version: 1 };
  }

  async patchTemplate(id: string, input: Row): Promise<Row> {
    let template = first(
      await this.raw(
        `UPDATE label_templates SET name = COALESCE($2, name), active = COALESCE($3, active), updated_at = now() WHERE id = $1 RETURNING *`,
        [id, optionalString(input.name), optionalBoolean(input.active)]
      )
    );
    if (!template) throw notFound("Sablon");
    if (input.scene) {
      const validation = validateScene(input.scene);
      if (!validation.scene)
        throw new LabelStudioError(
          "scene_invalid",
          validation.issues.map((issue) => issue.message).join(" ")
        );
      const version = first(
        await this.raw(
          `INSERT INTO label_template_versions (template_id, version, scene, field_schema, note) SELECT $1, COALESCE(max(version),0)+1, $2::jsonb, $3::jsonb, $4 FROM label_template_versions WHERE template_id=$1 RETURNING id,version`,
          [
            id,
            JSON.stringify(validation.scene),
            JSON.stringify(validation.scene.fieldSchema),
            optionalString(input.note) ?? "Referenciafontok szinkronizálása",
          ]
        )
      );
      template = first(
        await this.raw(
          `UPDATE label_templates SET current_version_id=$2, updated_at=now() WHERE id=$1 RETURNING *`,
          [id, version?.id]
        )
      );
      return { ...template, version: version?.version };
    }
    return template;
  }

  async getOverview(): Promise<Row[]> {
    await this.ensureSeeded();
    const rows = await this.sql.unsafe(`
      SELECT b.brand,
        (SELECT count(*)::int FROM label_designs d WHERE d.brand=b.brand AND d.visible=true AND d.status<>'archived') AS design_count,
        (SELECT count(*)::int FROM label_order_items i JOIN label_orders o ON o.id=i.order_id WHERE o.brand=b.brand AND o.active=true AND o.status='draft' AND i.included=true) AS order_items,
        (SELECT COALESCE(sum(i.quantity),0)::int FROM label_order_items i JOIN label_orders o ON o.id=i.order_id WHERE o.brand=b.brand AND o.active=true AND o.status='draft' AND i.included=true) AS order_quantity,
        (SELECT max(d.updated_at) FROM label_designs d WHERE d.brand=b.brand) AS updated_at
      FROM (SELECT unnest(enum_range(NULL::label_brand)) AS brand) b ORDER BY b.brand
    `);
    return rows;
  }

  async listDesigns(query: Row = {}): Promise<Row[]> {
    await this.ensureSeeded();
    const brand = query.brand ? readBrand(query.brand) : null;
    const status = optionalString(query.status);
    const search = optionalString(query.search);
    const orderOnly = query.orderOnly === true || query.orderOnly === "true";
    const templateId = optionalString(query.templateId);
    return rows(
      await this.raw(
        `
      SELECT d.*, t.name AS template_name, dv.version, dv.scene,
        EXISTS (SELECT 1 FROM label_order_items oi JOIN label_orders o ON o.id = oi.order_id WHERE oi.design_id = d.id AND o.active = true AND o.status = 'draft' AND oi.included = true) AS in_order,
        COALESCE((SELECT oi.quantity FROM label_order_items oi JOIN label_orders o ON o.id = oi.order_id WHERE oi.design_id = d.id AND o.active = true AND o.status = 'draft' LIMIT 1), 0) AS order_quantity
      FROM label_designs d JOIN label_templates t ON t.id = d.template_id JOIN label_design_versions dv ON dv.id = d.current_version_id
      WHERE ($1::text IS NULL OR d.brand::text = $1)
        AND ($2::text IS NULL OR d.status::text = $2)
        AND ($3::text IS NULL OR d.name ILIKE '%' || $3 || '%' OR d.internal_code ILIKE '%' || $3 || '%')
        AND ($4::uuid IS NULL OR d.template_id = $4)
        AND ($5::boolean = false OR EXISTS (SELECT 1 FROM label_order_items oi JOIN label_orders o ON o.id = oi.order_id WHERE oi.design_id = d.id AND o.active = true AND o.status = 'draft' AND oi.included = true))
      ORDER BY d.sort_order, d.name`,
        [brand, status, search, templateId, orderOnly]
      )
    );
  }

  async getDesign(id: string): Promise<Row> {
    await this.ensureSeeded();
    const design = first(
      await this.raw(
        `SELECT d.*, t.name AS template_name, dv.version, dv.scene, dv.template_version_id FROM label_designs d JOIN label_templates t ON t.id = d.template_id JOIN label_design_versions dv ON dv.id = d.current_version_id WHERE d.id = $1`,
        [id]
      )
    );
    if (!design) throw notFound("Címke");
    return design;
  }

  async createDesign(input: Row): Promise<Row> {
    await this.ensureSeeded();
    const brand = readBrand(input.brand);
    const templateId = requiredString(input.templateId, "A sablon kiválasztása kötelező.");
    const name = requiredString(input.name, "A címke neve kötelező.");
    const internalCode = requiredString(input.internalCode, "A belső kód kötelező.");
    const template = first(
      await this.raw(
        `SELECT t.*, tv.scene FROM label_templates t JOIN label_template_versions tv ON tv.id = t.current_version_id WHERE t.id = $1 AND t.brand = $2::label_brand`,
        [templateId, brand]
      )
    );
    if (!template) throw notFound("Sablon");
    const sourceScene = readScene(input.scene ?? template.scene);
    if (sourceScene.brand !== brand)
      throw new LabelStudioError("brand_mismatch", "A címke és a sablon csoportja eltér.");
    const scene = structuredClone(sourceScene);
    scene.metadata.name = name;
    const design = first(
      await this.raw(
        `INSERT INTO label_designs (brand, name, internal_code, template_id, visible, sort_order, status) VALUES ($1::label_brand, $2, $3, $4, true, COALESCE((SELECT max(sort_order)+1 FROM label_designs WHERE brand=$1::label_brand),0), 'draft') RETURNING *`,
        [brand, name, internalCode, templateId]
      )
    );
    const version = first(
      await this.raw(
        `INSERT INTO label_design_versions (design_id, template_version_id, version, scene, note) VALUES ($1, $2, 1, $3::jsonb, 'Új címke') RETURNING *`,
        [design?.id, template.current_version_id, JSON.stringify(scene)]
      )
    );
    await this.raw(`UPDATE label_designs SET current_version_id=$2 WHERE id=$1`, [
      design?.id,
      version?.id,
    ]);
    return this.getDesign(stringValue(design?.id));
  }

  async patchDesign(id: string, input: Row): Promise<Row> {
    const current = await this.getDesign(id);
    const expectedRevision = requiredInteger(
      input.expectedRevision,
      "Az expectedRevision kötelező.",
      1
    );
    if (Number(current.revision) !== expectedRevision)
      throw new LabelStudioError(
        "revision_conflict",
        "A címkét közben másik mentés módosította. Töltsd újra, majd egyesítsd a változtatásokat.",
        409
      );
    if (input.scene) {
      const scene = readScene(input.scene);
      if (scene.brand !== current.brand)
        throw new LabelStudioError("brand_mismatch", "Mentéskor a címkecsoport nem változhat.");
      const nextVersion = Number(current.version) + 1;
      const version = first(
        await this.raw(
          `INSERT INTO label_design_versions (design_id, template_version_id, version, scene, note) VALUES ($1, $2, $3, $4::jsonb, $5) RETURNING id`,
          [
            id,
            current.template_version_id,
            nextVersion,
            JSON.stringify(input.scene),
            optionalString(input.note) ?? "Automatikus mentés",
          ]
        )
      );
      await this.raw(
        `UPDATE label_designs SET current_version_id=$2, revision=revision+1, name=COALESCE($3,name), visible=COALESCE($4,visible), sort_order=COALESCE($5,sort_order), status=COALESCE($6::label_design_status,status), updated_at=now() WHERE id=$1`,
        [
          id,
          version?.id,
          optionalString(input.name),
          optionalBoolean(input.visible),
          optionalInteger(input.sortOrder),
          optionalString(input.status),
        ]
      );
    } else {
      await this.raw(
        `UPDATE label_designs SET revision=revision+1, name=COALESCE($2,name), visible=COALESCE($3,visible), sort_order=COALESCE($4,sort_order), status=COALESCE($5::label_design_status,status), updated_at=now() WHERE id=$1`,
        [
          id,
          optionalString(input.name),
          optionalBoolean(input.visible),
          optionalInteger(input.sortOrder),
          optionalString(input.status),
        ]
      );
    }
    return this.getDesign(id);
  }

  async duplicateDesign(id: string, input: Row): Promise<Row> {
    const source = await this.getDesign(id);
    return this.createDesign({
      brand: source.brand,
      templateId: source.template_id,
      name: optionalString(input.name) ?? `${source.name} másolat`,
      internalCode: requiredString(input.internalCode, "Az új belső kód kötelező."),
      scene: source.scene,
    });
  }

  async createDesignVersion(id: string, input: Row): Promise<Row> {
    const current = await this.getDesign(id);
    return this.patchDesign(id, {
      expectedRevision: current.revision,
      scene: input.scene ?? current.scene,
      note: optionalString(input.note) ?? "Kézi verzió",
    });
  }

  async listDesignVersions(id: string): Promise<Row[]> {
    await this.getDesign(id);
    return rows(
      await this.raw(
        `SELECT id, design_id, template_version_id, version, note, created_at, scene FROM label_design_versions WHERE design_id=$1 ORDER BY version DESC`,
        [id]
      )
    );
  }

  async restoreDesignVersion(id: string, versionId: string): Promise<Row> {
    const current = await this.getDesign(id);
    const version = first(
      await this.raw(`SELECT scene FROM label_design_versions WHERE id=$1 AND design_id=$2`, [
        versionId,
        id,
      ])
    );
    if (!version) throw notFound("Címkeverzió");
    return this.patchDesign(id, {
      expectedRevision: current.revision,
      scene: version.scene,
      note: `Visszaállítás: ${versionId}`,
    });
  }

  async validateDesign(id: string): Promise<{ issues: unknown[]; valid: boolean }> {
    const design = await this.getDesign(id);
    const fonts = await this.loadFonts([design.scene as LabelScene]);
    const issues = preflightScene(design.scene as LabelScene, fonts);
    return { issues, valid: !hasBlockingIssues(issues) };
  }

  async previewSvg(id: string, outlined = false): Promise<string> {
    const design = await this.getDesign(id);
    const scene = design.scene as LabelScene;
    return renderSvg(scene, await this.loadFonts([scene]), { outlineText: outlined });
  }

  async listAssets(): Promise<Row[]> {
    await this.ensureSeeded();
    const assets = rows(
      await this.raw(
        `SELECT id, brand, kind, filename, mime_type, sha256, family, style, weight, active, metadata, created_at, updated_at, octet_length(data) AS byte_size FROM label_assets ORDER BY kind, family, filename`
      )
    );
    const usages = rows(
      await this.raw(
        `SELECT a.id AS asset_id,d.id,d.name,d.internal_code FROM label_assets a JOIN label_designs d ON true JOIN label_design_versions v ON v.id=d.current_version_id AND v.scene::text LIKE '%' || a.id::text || '%' GROUP BY a.id,d.id,d.name,d.internal_code ORDER BY d.name`
      )
    );
    for (const asset of assets)
      asset.usages = usages
        .filter((usage) => usage.asset_id === asset.id)
        .map(({ asset_id, ...usage }) => usage);
    return assets;
  }

  async uploadFont(
    file: { filename: string; mimetype: string; bytes: Buffer },
    requestedId = ""
  ): Promise<Row> {
    if (file.bytes.length === 0 || file.bytes.length > 20 * 1024 * 1024)
      throw new LabelStudioError("font_size", "A fontfájl mérete 1 bájt és 20 MB között lehet.");
    const extension = extname(file.filename).slice(1).toLowerCase();
    if (!["otf", "ttf", "woff", "woff2"].includes(extension))
      throw new LabelStudioError(
        "font_format",
        "Csak OTF, TTF, WOFF vagy WOFF2 font tölthető fel."
      );
    let parsed;
    try {
      parsed = await parseFontFile(file.bytes, extension as FontAsset["format"]);
    } catch {
      throw new LabelStudioError(
        "font_invalid",
        "A fontfájl nem olvasható vagy sérült. Ellenőrizd, majd válassz másik fájlt."
      );
    }
    const assetId = requestedId || undefined;
    if (
      assetId &&
      !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(assetId)
    )
      throw new LabelStudioError("asset_id", "A megadott font asset ID nem érvényes UUID v4.");
    const existing = first(
      await this.raw(
        `UPDATE label_assets SET active=true, metadata=COALESCE(metadata, '{}'::jsonb) || $2::jsonb, updated_at=now() WHERE kind='font' AND sha256=$1 RETURNING id, filename, mime_type, sha256, family, style, weight, active, metadata, created_at`,
        [parsed.metadata.sha256, JSON.stringify(fontMetadata(parsed.font, extension))]
      )
    );
    if (existing) return existing;
    const result = first(
      await this.raw(
        `INSERT INTO label_assets (id, kind, filename, mime_type, sha256, family, style, weight, active, data, metadata) VALUES (COALESCE($1::uuid, gen_random_uuid()), 'font',$2,$3,$4,$5,$6,$7,true,$8,$9::jsonb) ON CONFLICT (id) DO UPDATE SET filename=EXCLUDED.filename, mime_type=EXCLUDED.mime_type, sha256=EXCLUDED.sha256, family=EXCLUDED.family, style=EXCLUDED.style, weight=EXCLUDED.weight, active=true, data=EXCLUDED.data, metadata=EXCLUDED.metadata, updated_at=now() RETURNING id, filename, mime_type, sha256, family, style, weight, active, metadata, created_at`,
        [
          assetId,
          basename(file.filename),
          file.mimetype,
          parsed.metadata.sha256,
          parsed.metadata.family,
          parsed.metadata.style,
          parsed.metadata.weight,
          file.bytes,
          JSON.stringify(fontMetadata(parsed.font, extension, assetId)),
        ]
      )
    );
    return result ?? {};
  }

  async uploadFonts(
    files: Array<{ filename: string; mimetype: string; bytes: Buffer }>,
    requestedId = ""
  ): Promise<Row[]> {
    if (!files.length) throw new LabelStudioError("font_missing", "Válassz feltöltendő fontfájlt.");
    if (requestedId && files.length !== 1)
      throw new LabelStudioError(
        "font_archive_id",
        "ZIP feltöltéshez nem adható egyetlen font asset azonosító."
      );
    const imported: Row[] = [];
    for (const file of files) imported.push(await this.uploadFont(file, requestedId));
    return imported;
  }

  async patchAsset(id: string, input: Row): Promise<Row> {
    const asset = first(
      await this.raw(
        `UPDATE label_assets SET active=COALESCE($2,active), updated_at=now() WHERE id=$1 RETURNING id, filename, family, style, weight, active, metadata`,
        [id, optionalBoolean(input.active)]
      )
    );
    if (!asset) throw notFound("Asset");
    return asset;
  }

  async downloadAsset(id: string): Promise<{ row: Row; bytes: Buffer }> {
    const row = first(await this.raw(`SELECT * FROM label_assets WHERE id=$1`, [id]));
    if (!row) throw notFound("Asset");
    return { row, bytes: Buffer.from(row.data as Uint8Array) };
  }

  async deleteAsset(id: string): Promise<void> {
    const uses = first(
      await this.raw(
        `SELECT count(*)::int AS count FROM label_design_versions WHERE scene::text LIKE '%' || $1 || '%'`,
        [id]
      )
    );
    if (Number(uses?.count ?? 0) > 0)
      throw new LabelStudioError(
        "font_in_use",
        "A font használatban van, ezért nem törölhető. Előbb cseréld le az érintett címkéken.",
        409
      );
    const deleted = await this.raw(`DELETE FROM label_assets WHERE id=$1 AND id<>$2 RETURNING id`, [
      id,
      DEFAULT_LABEL_FONT_ID,
    ]);
    if (!first(deleted))
      throw new LabelStudioError("asset_delete_blocked", "Az alapfont nem törölhető.", 409);
  }

  async listOrders(brand?: LabelBrand): Promise<Row[]> {
    await this.ensureSeeded();
    return rows(
      await this.raw(
        `SELECT o.*, COALESCE(count(oi.id),0)::int AS item_count, COALESCE(sum(CASE WHEN oi.included THEN oi.quantity ELSE 0 END),0)::int AS total_quantity FROM label_orders o LEFT JOIN label_order_items oi ON oi.order_id=o.id WHERE ($1::text IS NULL OR o.brand::text=$1) GROUP BY o.id ORDER BY o.created_at DESC`,
        [brand ?? null]
      )
    );
  }

  async getOrder(id: string): Promise<Row> {
    await this.ensureSeeded();
    const order = first(await this.raw(`SELECT * FROM label_orders WHERE id=$1`, [id]));
    if (!order) throw notFound("Rendelés");
    const items = rows(
      await this.raw(
        `SELECT oi.*, d.name, d.internal_code, t.name AS template_name, dv.version, dv.scene, dv.template_version_id FROM label_order_items oi JOIN label_designs d ON d.id=oi.design_id JOIN label_design_versions dv ON dv.id=oi.design_version_id JOIN label_templates t ON t.id=d.template_id WHERE oi.order_id=$1 ORDER BY oi.sort_order, oi.created_at`,
        [id]
      )
    );
    return { ...order, items };
  }

  async getActiveOrder(brand: LabelBrand): Promise<Row> {
    await this.ensureSeeded();
    let order = first(
      await this.raw(
        `SELECT id FROM label_orders WHERE brand=$1::label_brand AND status='draft' AND active=true ORDER BY created_at DESC LIMIT 1`,
        [brand]
      )
    );
    if (!order)
      order = first(
        await this.raw(
          `INSERT INTO label_orders (brand,status,active) VALUES ($1::label_brand,'draft',true) RETURNING id`,
          [brand]
        )
      );
    return this.getOrder(stringValue(order?.id));
  }

  async createOrder(input: Row): Promise<Row> {
    return this.getActiveOrder(readBrand(input.brand));
  }

  async patchOrder(id: string, input: Row): Promise<Row> {
    const order = await this.getOrder(id);
    if (order.status !== "draft")
      throw new LabelStudioError(
        "order_immutable",
        "A lezárt rendelés nem módosítható. Nyisd újra új draftként.",
        409
      );
    await this.raw(`UPDATE label_orders SET revision=revision+1, updated_at=now() WHERE id=$1`, [
      id,
    ]);
    return this.getOrder(id);
  }

  async addOrderItem(id: string, input: Row): Promise<Row> {
    const order = await this.getOrder(id);
    if (order.status !== "draft")
      throw new LabelStudioError("order_immutable", "Csak draft rendelés módosítható.", 409);
    const design = await this.getDesign(
      requiredString(input.designId, "A címkeazonosító kötelező.")
    );
    if (design.brand !== order.brand)
      throw new LabelStudioError(
        "brand_mismatch",
        "Másik márka címkéje nem adható ehhez a rendeléshez."
      );
    const quantity = optionalInteger(input.quantity) ?? 1;
    if (quantity < 1)
      throw new LabelStudioError("quantity_invalid", "A mennyiség legalább 1 legyen.");
    await this.raw(
      `INSERT INTO label_order_items (order_id,design_id,design_version_id,included,quantity,variant,note,sort_order) VALUES ($1,$2,$3,true,$4,$5,$6,COALESCE((SELECT max(sort_order)+1 FROM label_order_items WHERE order_id=$1),0)) ON CONFLICT (order_id,design_id) DO UPDATE SET included=true, design_version_id=EXCLUDED.design_version_id, quantity=EXCLUDED.quantity, updated_at=now()`,
      [
        id,
        design.id,
        design.current_version_id,
        quantity,
        optionalString(input.variant) ?? "",
        optionalString(input.note) ?? "",
      ]
    );
    await this.raw(`UPDATE label_orders SET revision=revision+1, updated_at=now() WHERE id=$1`, [
      id,
    ]);
    return this.getOrder(id);
  }

  async patchOrderItem(id: string, itemId: string, input: Row): Promise<Row> {
    const order = await this.getOrder(id);
    if (order.status !== "draft")
      throw new LabelStudioError("order_immutable", "Csak draft rendelés módosítható.", 409);
    const quantity = optionalInteger(input.quantity);
    if (quantity !== undefined && quantity < 1)
      throw new LabelStudioError("quantity_invalid", "A mennyiség legalább 1 legyen.");
    const updated = first(
      await this.raw(
        `UPDATE label_order_items SET included=COALESCE($3,included), quantity=COALESCE($4,quantity), quantity_200g=COALESCE($5,quantity_200g), quantity_1000g=COALESCE($6,quantity_1000g), variant=COALESCE($7,variant), note=COALESCE($8,note), sort_order=COALESCE($9,sort_order), updated_at=now() WHERE id=$2 AND order_id=$1 RETURNING id`,
        [
          id,
          itemId,
          optionalBoolean(input.included),
          quantity,
          optionalInteger(input.quantity200g),
          optionalInteger(input.quantity1000g),
          optionalString(input.variant),
          optionalString(input.note),
          optionalInteger(input.sortOrder),
        ]
      )
    );
    if (!updated) throw notFound("Rendelési tétel");
    await this.raw(`UPDATE label_orders SET revision=revision+1, updated_at=now() WHERE id=$1`, [
      id,
    ]);
    return this.getOrder(id);
  }

  async deleteOrderItem(id: string, itemId: string): Promise<Row> {
    const deleted = first(
      await this.raw(`DELETE FROM label_order_items WHERE id=$2 AND order_id=$1 RETURNING id`, [
        id,
        itemId,
      ])
    );
    if (!deleted) throw notFound("Rendelési tétel");
    await this.raw(`UPDATE label_orders SET revision=revision+1,updated_at=now() WHERE id=$1`, [
      id,
    ]);
    return this.getOrder(id);
  }

  async freezeOrder(id: string): Promise<Row> {
    const order = await this.getOrder(id);
    const items = order.items as Row[];
    if (!items.length || items.some((item) => item.included && Number(item.quantity) < 1))
      throw new LabelStudioError(
        "order_invalid",
        "A lezáráshoz legalább egy érvényes, pozitív mennyiségű tétel szükséges."
      );
    await this.raw(
      `UPDATE label_orders SET status='frozen', active=false, frozen_at=now(), revision=revision+1, updated_at=now() WHERE id=$1 AND status='draft'`,
      [id]
    );
    return this.getOrder(id);
  }

  async exportOrder(id: string, profile?: Partial<ExportProfile>): Promise<Row> {
    let order = await this.getOrder(id);
    const wasDraft = order.status === "draft";
    const rowsInput = (order.items as Row[]).filter((item) => item.included === true);
    const items: ExportOrderItem[] = rowsInput.map((item) => ({
      designId: stringValue(item.design_id),
      designVersionId: stringValue(item.design_version_id),
      templateVersionId: stringValue(item.template_version_id),
      name: stringValue(item.name),
      internalCode: stringValue(item.internal_code),
      variant: stringValue(item.variant),
      quantity: Number(item.quantity),
      note: optionalString(item.note),
      scene: item.scene as LabelScene,
    }));
    const fonts = await this.loadFonts(items.map((item) => item.scene));
    if (wasDraft) order = await this.freezeOrder(id);
    let exportCommitted = false;
    try {
      const result = await createPrintSheetExport(
        {
          brand: order.brand as LabelBrand,
          orderId: id,
          orderRevision: Number(order.revision),
          items,
          profile: {
            ...profile,
            cropMarks: false,
            colorMode: "cmyk",
            separateFiles: false,
          },
          generatedAt: this.now(),
        },
        fonts
      );
      const exportRow = await this.sql.begin(async (tx) => {
        const unsafe = tx.unsafe.bind(tx) as unknown as LooseQuery;
        const raw: LooseQuery = (query, parameters) =>
          unsafe(query, normalizeParameters(parameters));
        const stored = first(
          await raw(
            `INSERT INTO label_exports (order_id,order_revision,status,filename,mime_type,sha256,data,manifest,completed_at) VALUES ($1,$2,'ready',$3,'application/pdf',$4,$5,$6::jsonb,now()) RETURNING id,order_id,order_revision,status,filename,mime_type,sha256,manifest,created_at,completed_at`,
            [
              id,
              order.revision,
              result.filename,
              result.sha256,
              result.bytes,
              JSON.stringify(result.manifest),
            ]
          )
        );
        if (!stored)
          throw new LabelStudioError("export_store_failed", "Az export nem menthető el.", 500);
        await raw(
          `UPDATE label_orders SET status='exported',active=false,updated_at=now() WHERE id=$1`,
          [id]
        );
        await raw(
          `INSERT INTO label_orders (brand,status,active) VALUES ($1::label_brand,'draft',true) ON CONFLICT DO NOTHING`,
          [order.brand]
        );
        return stored;
      });
      exportCommitted = true;
      return exportRow;
    } catch (error) {
      if (wasDraft && !exportCommitted)
        await this.raw(
          `UPDATE label_orders SET status='draft',active=true,frozen_at=NULL,updated_at=now() WHERE id=$1 AND status='frozen'`,
          [id]
        );
      throw error;
    }
  }

  async listExports(orderId?: string): Promise<Row[]> {
    const exports = rows(
      await this.raw(
        `SELECT id,order_id,order_revision,status,filename,mime_type,sha256,manifest,error_message,created_at,completed_at FROM label_exports WHERE ($1::uuid IS NULL OR order_id=$1) ORDER BY created_at DESC`,
        [orderId ?? null]
      )
    );
    return exports;
  }
  async downloadExport(id: string): Promise<{ row: Row; bytes: Buffer }> {
    const row = first(
      await this.raw(`SELECT * FROM label_exports WHERE id=$1 AND status='ready'`, [id])
    );
    if (!row || !row.data) throw notFound("Export");
    return { row, bytes: Buffer.from(row.data as Uint8Array) };
  }

  private async ensureDefaultFont(raw: LooseQuery = this.raw): Promise<void> {
    const existing = first(
      await raw(`SELECT id FROM label_assets WHERE id=$1`, [DEFAULT_LABEL_FONT_ID])
    );
    if (existing) return;
    const candidates = [
      "C:\\Windows\\Fonts\\ARIALN.TTF",
      "C:\\Windows\\Fonts\\arial.ttf",
      "C:\\Windows\\Fonts\\segoeui.ttf",
    ];
    const path = candidates.find(existsSync);
    if (!path)
      throw new LabelStudioError(
        "default_font_missing",
        "Az alap rendszerfont nem található. Telepíts Arial vagy Segoe UI fontot, majd indítsd újra a Címkestúdiót.",
        503
      );
    const bytes = readFileSync(path);
    const parsed = parseFont(bytes);
    await raw(
      `INSERT INTO label_assets (id,kind,filename,mime_type,sha256,family,style,weight,active,data,metadata) VALUES ($1,'font',$2,'font/ttf',$3,$4,$5,$6,true,$7,$8::jsonb) ON CONFLICT DO NOTHING`,
      [
        DEFAULT_LABEL_FONT_ID,
        basename(path),
        parsed.metadata.sha256,
        parsed.metadata.family,
        parsed.metadata.style,
        parsed.metadata.weight,
        bytes,
        JSON.stringify({
          systemSeed: true,
          format: "ttf",
          glyphCount: parsed.metadata.glyphCount,
          hungarianGlyphs: missingHungarian(parsed.font),
        }),
      ]
    );
  }

  private async loadFonts(
    scenes?: LabelScene[]
  ): Promise<Map<string, Awaited<ReturnType<typeof loadFontAssetFile>>>> {
    await this.ensureDefaultFont();
    const fontIds = scenes
      ? [
          DEFAULT_LABEL_FONT_ID,
          ...new Set(
            scenes.flatMap((scene) =>
              scene.nodes.flatMap((node) =>
                node.type === "text" && node.fontAssetId ? [node.fontAssetId] : []
              )
            )
          ),
        ]
      : null;
    const result = new Map<string, Awaited<ReturnType<typeof loadFontAssetFile>>>();
    for (const row of rows(
      await this.raw(
        `SELECT id,filename,sha256,family,style,weight,metadata,data FROM label_assets WHERE kind='font' AND active=true AND ($1::uuid[] IS NULL OR id=ANY($1::uuid[]))`,
        [fontIds]
      )
    )) {
      try {
        const format = String(
          (row.metadata as Row)?.format ?? extname(String(row.filename)).slice(1)
        ).toLowerCase() as FontAsset["format"];
        result.set(
          stringValue(row.id),
          await loadFontAssetFile({
            id: stringValue(row.id),
            family: stringValue(row.family),
            style: stringValue(row.style),
            weight: Number(row.weight ?? 400),
            format,
            sha256: stringValue(row.sha256),
            bytes: new Uint8Array(row.data as Uint8Array),
          })
        );
      } catch {
        /* Broken fonts stay visible in the font library and fail preflight when referenced. */
      }
    }
    const fallbackFont = result.get(DEFAULT_LABEL_FONT_ID);
    if (fallbackFont && fontIds)
      for (const fontId of fontIds) if (!result.has(fontId)) result.set(fontId, fallbackFont);
    return result;
  }
}

function loadBundledLabelCatalog(): LoadedBundledLabelCatalog {
  const catalogRoot = labelCatalogRoot();
  const catalogPath = resolve(catalogRoot, "catalog.json");
  if (!existsSync(catalogPath))
    throw new LabelStudioError(
      "catalog_missing",
      "A kiadott címkekatalógus hiányzik. Telepítsd újra a legfrissebb Danetti frissítést.",
      503
    );
  const bytes = readFileSync(catalogPath);
  let raw: unknown;
  try {
    raw = JSON.parse(bytes.toString("utf8"));
  } catch {
    throw new LabelStudioError(
      "catalog_invalid",
      "A kiadott címkekatalógus nem olvasható. Telepítsd újra a legfrissebb Danetti frissítést.",
      503
    );
  }
  if (!raw || typeof raw !== "object") throw invalidCatalog();
  const catalog = raw as Partial<BundledLabelCatalog>;
  if (
    catalog.schemaVersion !== "1.0.0" ||
    catalog.catalogId !== "danetti-label-studio" ||
    !Array.isArray(catalog.assets) ||
    !Array.isArray(catalog.templates) ||
    !Array.isArray(catalog.designs)
  )
    throw invalidCatalog();
  const assetIds = new Set<string>();
  const assets: BundledLabelAsset[] = catalog.assets.map((asset) => {
    if (!asset || typeof asset !== "object") throw invalidCatalog();
    const candidate = asset as Partial<BundledLabelAsset>;
    if (
      !isUuid(candidate.id) ||
      assetIds.has(candidate.id) ||
      !["font", "svg", "binary"].includes(String(candidate.kind)) ||
      !isSafeCatalogFile(candidate.file) ||
      !/^[a-f0-9]{64}$/i.test(String(candidate.sha256))
    )
      throw invalidCatalog();
    assetIds.add(candidate.id);
    const path = resolve(catalogRoot, candidate.file);
    if (!existsSync(path)) throw invalidCatalog();
    return {
      id: candidate.id,
      brand:
        candidate.brand === null || candidate.brand === undefined
          ? null
          : readBrand(candidate.brand),
      kind: candidate.kind as BundledLabelAsset["kind"],
      filename: requiredCatalogString(candidate.filename),
      mimeType: requiredCatalogString(candidate.mimeType),
      sha256: requiredCatalogString(candidate.sha256),
      family: typeof candidate.family === "string" ? candidate.family : null,
      style: typeof candidate.style === "string" ? candidate.style : null,
      weight: typeof candidate.weight === "number" ? candidate.weight : null,
      active: candidate.active === true,
      metadata: isRow(candidate.metadata) ? candidate.metadata : {},
      file: candidate.file,
    };
  });
  const templates: BundledLabelTemplate[] = catalog.templates.map((template) => {
    if (!template || typeof template !== "object") throw invalidCatalog();
    const candidate = template as Partial<BundledLabelTemplate>;
    return {
      brand: readBrand(candidate.brand),
      code: requiredCatalogString(candidate.code),
      name: requiredCatalogString(candidate.name),
      active: candidate.active !== false,
      scene: catalogScene(candidate.scene),
    };
  });
  const templateCodes = new Set(templates.map((template) => `${template.brand}:${template.code}`));
  for (const template of templates)
    for (const node of template.scene.nodes)
      if (node.type === "text" && node.fontAssetId && !assetIds.has(node.fontAssetId))
        throw invalidCatalog();
  const designs: BundledLabelDesign[] = catalog.designs.map((design) => {
    if (!design || typeof design !== "object") throw invalidCatalog();
    const candidate = design as Partial<BundledLabelDesign>;
    const brand = readBrand(candidate.brand);
    const templateCode = requiredCatalogString(candidate.templateCode);
    const status = candidate.status;
    if (
      !templateCodes.has(`${brand}:${templateCode}`) ||
      !["draft", "approved", "archived"].includes(String(status))
    )
      throw invalidCatalog();
    const normalizedScene = catalogScene(candidate.scene);
    for (const node of normalizedScene.nodes)
      if (node.type === "text" && node.fontAssetId && !assetIds.has(node.fontAssetId))
        throw invalidCatalog();
    const sortOrder =
      typeof candidate.sortOrder === "number" && Number.isInteger(candidate.sortOrder)
        ? candidate.sortOrder
        : 0;
    const revision =
      typeof candidate.revision === "number" &&
      Number.isInteger(candidate.revision) &&
      candidate.revision > 0
        ? candidate.revision
        : 1;
    return {
      brand,
      name: requiredCatalogString(candidate.name),
      internalCode: requiredCatalogString(candidate.internalCode),
      templateCode,
      visible: candidate.visible !== false,
      sortOrder,
      status: status as BundledLabelDesign["status"],
      revision,
      scene: normalizedScene,
    };
  });
  return {
    catalog: {
      schemaVersion: "1.0.0",
      catalogId: "danetti-label-studio",
      assets,
      templates,
      designs,
    },
    digest: createHash("sha256").update(bytes).digest("hex"),
  };
}

function readCatalogAssetBytes(asset: BundledLabelAsset): Buffer {
  const path = resolve(labelCatalogRoot(), asset.file);
  const bytes = readFileSync(path);
  if (createHash("sha256").update(bytes).digest("hex") !== asset.sha256)
    throw new LabelStudioError(
      "catalog_asset_invalid",
      `A kiadott ${asset.filename} címke-asset sérült. Telepítsd újra a legfrissebb Danetti frissítést.`,
      503
    );
  return bytes;
}

function remapCatalogScene(scene: LabelScene, assetIds: Map<string, string>): LabelScene {
  const result = structuredClone(scene);
  for (const node of result.nodes) {
    if (node.type !== "text" || !node.fontAssetId) continue;
    const effectiveId = assetIds.get(node.fontAssetId);
    if (effectiveId) node.fontAssetId = effectiveId;
  }
  return result;
}

function catalogScene(value: unknown): LabelScene {
  if (!value || typeof value !== "object") throw invalidCatalog();
  const validation = validateScene(value);
  if (!validation.scene) throw invalidCatalog();
  return validation.scene;
}

function readScene(value: unknown): LabelScene {
  const result = validateScene(value);
  if (!result.scene)
    throw new LabelStudioError(
      "scene_invalid",
      result.issues.map((issue) => issue.message).join(" ")
    );
  return result.scene;
}

function isSafeCatalogFile(value: unknown): value is string {
  if (typeof value !== "string" || !value || /^[A-Za-z]:/.test(value)) return false;
  const root = labelCatalogRoot();
  const file = resolve(root, value);
  const path = relative(root, file);
  return Boolean(path) && !path.startsWith("..") && !path.includes(":");
}

function labelCatalogRoot(): string {
  const candidates = [
    resolve(process.cwd(), "assets", "label-catalog"),
    resolve(process.cwd(), "..", "..", "assets", "label-catalog"),
  ];
  return (
    candidates.find((candidate) => existsSync(resolve(candidate, "catalog.json"))) ?? candidates[0]!
  );
}

function isUuid(value: unknown): value is string {
  return (
    typeof value === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)
  );
}

function isRow(value: unknown): value is Row {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function requiredCatalogString(value: unknown): string {
  if (typeof value !== "string" || !value.trim()) throw invalidCatalog();
  return value;
}

function invalidCatalog(): LabelStudioError {
  return new LabelStudioError(
    "catalog_invalid",
    "A kiadott címkekatalógus érvénytelen. Telepítsd újra a legfrissebb Danetti frissítést.",
    503
  );
}

function shouldRefreshSystemBlankTemplate(
  code: string,
  currentScene: unknown,
  targetScene: unknown
): boolean {
  if (
    !new Set(["utopia-empty", "bean-on-single-origin", "bean-on-blend"]).has(code) ||
    !currentScene ||
    typeof currentScene !== "object" ||
    !targetScene ||
    typeof targetScene !== "object"
  )
    return false;
  const currentSource = String(
    (currentScene as { metadata?: { source?: unknown } }).metadata?.source ?? ""
  );
  const targetSource = String(
    (targetScene as { metadata?: { source?: unknown } }).metadata?.source ?? ""
  );
  const currentNodes =
    typeof currentScene === "object" &&
    currentScene &&
    Array.isArray((currentScene as { nodes?: unknown }).nodes)
      ? (currentScene as { nodes: unknown[] }).nodes
      : [];
  const targetNodes =
    typeof targetScene === "object" &&
    targetScene &&
    Array.isArray((targetScene as { nodes?: unknown }).nodes)
      ? (targetScene as { nodes: unknown[] }).nodes
      : [];
  const currentUsesShrink = currentNodes.some(
    (node) =>
      typeof node === "object" &&
      node !== null &&
      (node as { type?: unknown; overflow?: unknown }).type === "text" &&
      (node as { overflow?: unknown }).overflow === "shrink"
  );
  const targetUsesFixedSize = targetNodes
    .filter(
      (node) =>
        typeof node === "object" && node !== null && (node as { type?: unknown }).type === "text"
    )
    .every((node) => (node as { overflow?: unknown }).overflow === "error");
  return Boolean(
    (targetSource && currentSource !== targetSource) ||
    (currentUsesShrink && targetUsesFixedSize) ||
    stableJson((currentScene as LabelScene).fields) !==
      stableJson((targetScene as LabelScene).fields) ||
    (currentScene as LabelScene).metadata?.layoutVersion !==
      (targetScene as LabelScene).metadata?.layoutVersion
  );
}

function shouldRefreshSystemReferenceScene(
  currentScene: unknown,
  targetScene: LabelScene
): boolean {
  if (!currentScene || typeof currentScene !== "object") return false;
  const current = currentScene as LabelScene;
  if (
    current.metadata?.layoutVersion ||
    stableJson(current.fields) !== stableJson(targetScene.fields)
  )
    return false;
  const currentSource = String(
    (currentScene as { metadata?: { source?: unknown } }).metadata?.source ?? ""
  );
  const targetSource = String(targetScene.metadata.source ?? "");
  const isReferenceScene =
    currentSource.startsWith("Utopia golden master / artwork ") ||
    currentSource.startsWith("Bean On source page ") ||
    currentSource.includes("CorelDRAW");
  const targetValidationMarker = targetSource.match(/\[validated-[^\]]+\]/)?.[0];
  return Boolean(
    isReferenceScene && targetValidationMarker && !currentSource.includes(targetValidationMarker)
  );
}

function repairBlankUtopiaTypography(
  currentScene: unknown,
  targetScene: LabelScene
): LabelScene | null {
  if (!currentScene || typeof currentScene !== "object") return null;
  const current = currentScene as LabelScene;
  if (
    current.metadata?.templateCode !== "utopia-empty" ||
    current.metadata?.source === targetScene.metadata.source
  )
    return null;
  const placeholderValueIds = new Set([
    "country",
    "name",
    "value-region",
    "value-farm",
    "value-altitude",
    "value-variety",
    "value-process",
    "value-notes",
  ]);
  const targetText = new Map(
    targetScene.nodes
      .filter((node) => node.type === "text" && !placeholderValueIds.has(node.id))
      .map((node) => [node.id, node] as const)
  );
  return {
    ...current,
    metadata: { ...current.metadata, source: targetScene.metadata.source },
    nodes: current.nodes.map((node) => {
      const target = targetText.get(node.id);
      if (node.type !== "text" || !target || target.type !== "text") return node;
      return {
        ...node,
        fontAssetId: target.fontAssetId,
        fontFamily: target.fontFamily,
        fontStyle: target.fontStyle,
        fontWeight: target.fontWeight,
        fontSizePt: target.fontSizePt,
        trackingPt: target.trackingPt,
        lineHeight: target.lineHeight,
        maxWidth: target.maxWidth,
        overflow: target.overflow,
        minFontSizePt: target.minFontSizePt,
      };
    }),
  };
}

function rows(value: unknown): Row[] {
  return value as Row[];
}
function normalizeParameters(parameters: unknown[] | undefined): unknown[] | undefined {
  return parameters?.map((value) => (value === undefined ? null : value));
}
function first(value: unknown): Row | undefined {
  return rows(value)[0];
}
function stringValue(value: unknown): string {
  return String(value ?? "");
}
function requiredString(value: unknown, message: string): string {
  const result = optionalString(value);
  if (!result) throw new LabelStudioError("validation", message);
  return result;
}
function optionalString(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}
function optionalBoolean(value: unknown): boolean | undefined {
  return typeof value === "boolean" ? value : undefined;
}
function optionalInteger(value: unknown): number | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  const parsed = Number(value);
  if (!Number.isInteger(parsed)) throw new LabelStudioError("validation", "Egész szám szükséges.");
  return parsed;
}
function requiredInteger(value: unknown, message: string, min: number): number {
  const parsed = optionalInteger(value);
  if (parsed === undefined || parsed < min) throw new LabelStudioError("validation", message);
  return parsed;
}
function readBrand(value: unknown): LabelBrand {
  if (value === "utopia" || value === "bean_on" || value === "custom") return value;
  throw new LabelStudioError("brand_invalid", "Ismeretlen címkecsoport.");
}
function notFound(entity: string): LabelStudioError {
  return new LabelStudioError("not_found", `${entity} nem található.`, 404);
}
function missingHungarian(font: ReturnType<typeof parseFont>["font"]): string[] {
  return Array.from("ÁÉÍÓÖŐÚÜŰáéíóöőúüű").filter(
    (character) => font.charToGlyphIndex(character) === 0
  );
}

function fontMetadata(
  font: ReturnType<typeof parseFont>["font"],
  format: string,
  assetId?: string
): Row {
  const latinUppercaseMissing = missingGlyphs(font, LATIN_UPPERCASE);
  const latinLowercaseMissing = missingGlyphs(font, LATIN_LOWERCASE);
  const isCompleteLatinAlphabet =
    latinUppercaseMissing.length === 0 && latinLowercaseMissing.length === 0;
  return {
    format,
    glyphCount: font.glyphs.length,
    hungarianGlyphs: missingHungarian(font),
    latinUppercaseMissing,
    latinLowercaseMissing,
    isCompleteLatinAlphabet,
    referenceSubset: Boolean(
      assetId && REFERENCE_SUBSET_FONT_IDS.has(assetId) && !isCompleteLatinAlphabet
    ),
  };
}
