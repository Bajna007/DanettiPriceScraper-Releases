import { timingSafeEqual } from "node:crypto";
import {
  GIT_MANIFEST_URL,
  validateReleaseManifest,
  type ReleaseManifest,
} from "../../../../../scripts/updates/release-manifest.mjs";
import { existsSync, readFileSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { execFile } from "node:child_process";
import { dirname, join, resolve } from "node:path";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

export class AppUpdateError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode = 400
  ) {
    super(message);
    this.name = "AppUpdateError";
  }
}

export interface AppUpdateConfig {
  product: string;
  channel: "stable";
  manifestUrl: string;
  releaseRepository: string;
  publicKeys: string[];
  allowGitDistribution?: boolean;
}

export type SignedUpdateManifest = ReleaseManifest;

export interface AppUpdateCheck {
  status: "available" | "current" | "unavailable";
  currentVersion: string;
  availableVersion?: string;
  changelog?: string;
  publishedAt?: string;
  message: string;
}

export interface AppUpdateInstallCheck {
  state: "idle" | "queued" | "downloading" | "installing" | "finalizing" | "complete" | "failed";
  version: string;
  message: string;
  updatedAt?: string;
}

interface UpdateLaunchRequest {
  executable: string;
  launcherScript: string;
  rootDirectory: string;
  manifestUrl: string;
  expectedVersion: string;
  publicKey: string;
}

type UpdateLauncher = (request: UpdateLaunchRequest) => Promise<void>;

export const DEFAULT_APP_UPDATE_CONFIG: AppUpdateConfig = {
  product: "danetti-price-scraper",
  channel: "stable",
  manifestUrl: GIT_MANIFEST_URL,
  allowGitDistribution: true,
  releaseRepository: "Bajna007/DanettiPriceScraper-Releases",
  publicKeys: ["b1lkLdDw9CaJ+62oHEcGAmQgw9so6E+nxiyuCWkJUp4="],
};

interface AppUpdateServiceOptions {
  config?: AppUpdateConfig;
  rootDirectory?: string;
  fetcher?: typeof fetch;
  launcher?: UpdateLauncher;
}

export class AppUpdateService {
  private readonly config: AppUpdateConfig;
  private readonly rootDirectory: string;
  private readonly fetcher: typeof fetch;
  private readonly launcher: UpdateLauncher;

  constructor(options: AppUpdateServiceOptions = {}) {
    this.config = options.config ?? DEFAULT_APP_UPDATE_CONFIG;
    this.rootDirectory = options.rootDirectory ?? resolveAppRootDirectory();
    this.fetcher = options.fetcher ?? fetch;
    this.launcher = options.launcher ?? launchUpdateBootstrap;
  }

  async check(force = false): Promise<AppUpdateCheck> {
    const currentVersion = await readPackageVersion(this.rootDirectory);
    let response: Response;
    try {
      const cacheBust = force
        ? `${this.config.manifestUrl.includes("?") ? "&" : "?"}check=${Date.now()}`
        : "";
      response = await this.fetcher(`${this.config.manifestUrl}${cacheBust}`, {
        signal: AbortSignal.timeout(15_000),
        headers: {
          Accept: "application/vnd.github.raw+json",
          "Cache-Control": force ? "no-cache" : "max-age=300",
          "User-Agent": `Danetti-Updater/${currentVersion}`,
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
    } catch {
      return {
        status: "unavailable",
        currentVersion,
        message:
          "A frissítési szolgáltatás nem érhető el. Ellenőrizd az internetkapcsolatot, majd próbáld újra.",
      };
    }
    if (!response.ok)
      return {
        status: "unavailable",
        currentVersion,
        message: "A frissítési szolgáltatás még nem adott ki ellenőrizhető csomagot.",
      };
    try {
      const manifest = validateManifest(await response.json(), this.config);
      if (compareVersions(manifest.version, currentVersion) <= 0)
        return {
          status: "current",
          currentVersion,
          availableVersion: manifest.version,
          publishedAt: manifest.published_at,
          message: "A Danetti naprakész.",
        };
      return {
        status: "available",
        currentVersion,
        availableVersion: manifest.version,
        changelog: manifest.changelog,
        publishedAt: manifest.published_at,
        message: `Elérhető a ${manifest.version} verzió.`,
      };
    } catch {
      return {
        status: "unavailable",
        currentVersion,
        message: "A frissítési jegyzék aláírása vagy csomagadata érvénytelen; frissítés nem indul.",
      };
    }
  }

  async queueInstall(expectedVersion?: string): Promise<AppUpdateCheck> {
    const update = await this.check(true);
    if (update.status === "unavailable")
      throw new AppUpdateError("update_unavailable", update.message, 503);
    if (update.status !== "available" || !update.availableVersion)
      throw new AppUpdateError("update_current", "Nincs telepíthető új Danetti-verzió.", 409);
    if (expectedVersion && expectedVersion !== update.availableVersion)
      throw new AppUpdateError(
        "update_version_changed",
        "Közben új frissítés jelent meg. Ellenőrizd újra, majd indítsd el a megfelelő verziót.",
        409
      );
    const launcherScript = resolve(
      this.rootDirectory,
      "scripts",
      "updates",
      "launch-signed-update.ps1"
    );
    if (!existsSync(launcherScript))
      throw new AppUpdateError(
        "update_script_missing",
        "A Danetti frissítő segédprogram hiányzik.",
        500
      );
    const executable = resolvePowerShell();
    try {
      await this.launcher({
        executable,
        launcherScript,
        rootDirectory: this.rootDirectory,
        manifestUrl: this.config.manifestUrl,
        expectedVersion: update.availableVersion,
        publicKey: this.config.publicKeys[0]!,
      });
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      throw new AppUpdateError(
        "update_launch_failed",
        `A frissítő háttérfolyamata nem indult el. Részletek: ${detail}`,
        500
      );
    }
    return {
      ...update,
      message: `A ${update.availableVersion} frissítője elindult. Az állapotot ez az ablak követi, majd az alkalmazás újraindul.`,
    };
  }

  async installStatus(): Promise<AppUpdateInstallCheck> {
    const currentVersion = await readPackageVersion(this.rootDirectory);
    const statePath = resolve(this.rootDirectory, "logs", "danetti-update-state.json");
    if (!existsSync(statePath)) {
      return {
        state: "idle",
        version: currentVersion,
        message: "Nincs folyamatban Danetti-frissítés.",
      };
    }
    try {
      const source = await readFile(statePath, "utf8");
      const value = JSON.parse(source.replace(/^\uFEFF/, "")) as Record<string, unknown>;
      const states = new Set<AppUpdateInstallCheck["state"]>([
        "queued",
        "downloading",
        "installing",
        "finalizing",
        "complete",
        "failed",
      ]);
      const state = typeof value.state === "string" ? value.state : "";
      if (!states.has(state as AppUpdateInstallCheck["state"])) throw new Error("invalid state");
      return {
        state: state as AppUpdateInstallCheck["state"],
        version: typeof value.version === "string" ? value.version : currentVersion,
        message:
          typeof value.message === "string" ? value.message : "A frissítés állapota frissült.",
        updatedAt: typeof value.updated_at === "string" ? value.updated_at : undefined,
      };
    } catch {
      return {
        state: "failed",
        version: currentVersion,
        message:
          "A frissítési állapotfájl nem olvasható. Indítsd újra a Danettit, majd próbáld újra.",
      };
    }
  }
}

async function launchUpdateBootstrap(request: UpdateLaunchRequest): Promise<void> {
  await execFileAsync(
    request.executable,
    [
      "-NoProfile",
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      request.launcherScript,
      "-ManifestUrl",
      request.manifestUrl,
      "-ExpectedVersion",
      request.expectedVersion,
      "-PublicKey",
      request.publicKey,
    ],
    {
      cwd: request.rootDirectory,
      windowsHide: true,
      timeout: 15_000,
      maxBuffer: 64 * 1024,
    }
  );
}

export function validateManifest(value: unknown, config: AppUpdateConfig): SignedUpdateManifest {
  return validateReleaseManifest(value, config);
}

function compareVersions(left: string, right: string): number {
  const leftParts = readSemver(left);
  const rightParts = readSemver(right);
  for (let index = 0; index < 3; index += 1) {
    const delta = leftParts.numbers[index]! - rightParts.numbers[index]!;
    if (delta) return Math.sign(delta);
  }
  if (leftParts.pre === rightParts.pre) return 0;
  if (!leftParts.pre) return 1;
  if (!rightParts.pre) return -1;
  return leftParts.pre.localeCompare(rightParts.pre, undefined, { numeric: true });
}

function readSemver(value: string): { numbers: number[]; pre: string } {
  const match = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(value);
  if (!match) throw new Error("invalid semver");
  return { numbers: [Number(match[1]), Number(match[2]), Number(match[3])], pre: match[4] ?? "" };
}

function isSemver(value: unknown): value is string {
  return typeof value === "string" && /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.test(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

async function readPackageVersion(rootDirectory: string): Promise<string> {
  const source = await readFile(join(rootDirectory, "package.json"), "utf8");
  const parsed = JSON.parse(source) as { version?: unknown };
  if (!isSemver(parsed.version)) throw new Error("A telepített Danetti verziója érvénytelen.");
  return parsed.version;
}

function resolvePowerShell(): string {
  const systemRoot = process.env.SystemRoot;
  const candidate = systemRoot
    ? join(systemRoot, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
    : "";
  return candidate && existsSync(candidate) ? candidate : "powershell.exe";
}

/** npm workspaces run the API from apps/api; updates must use the installed app root version. */
export function resolveAppRootDirectory(startDirectory = process.cwd()): string {
  const initial = resolve(startDirectory);
  let current = initial;
  while (true) {
    const packagePath = join(current, "package.json");
    if (existsSync(packagePath)) {
      try {
        const packageJson = JSON.parse(readFileSync(packagePath, "utf8")) as { name?: unknown };
        if (packageJson.name === "danetti-price-scraper") return current;
      } catch {
        // Keep walking: an unrelated parent package must not select the wrong release root.
      }
    }
    const parent = dirname(current);
    if (parent === current) return initial;
    current = parent;
  }
}

export function hashesEqual(left: string, right: string): boolean {
  const a = Buffer.from(left, "hex");
  const b = Buffer.from(right, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}
