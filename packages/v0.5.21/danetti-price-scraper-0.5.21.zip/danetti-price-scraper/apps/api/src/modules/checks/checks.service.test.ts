import assert from "node:assert/strict";
import { buildDryRunSupplierJob, validateDryRunRequestBody } from "./checks.service.js";
import { CheckValidationError } from "./checks.types.js";

validateDryRunRequestBody(undefined);
validateDryRunRequestBody({ note: "safe" });
assert.throws(() => validateDryRunRequestBody({ connectorId: "real" }), CheckValidationError);
assert.throws(
  () => validateDryRunRequestBody({ url: "https://supplier.example" }),
  CheckValidationError
);
assert.throws(
  () => validateDryRunRequestBody({ nested: { password: "secret" } }),
  CheckValidationError
);

const job = buildDryRunSupplierJob("dummy-supplier");
assert.equal(job.dryRun, true);
assert.equal(job.connectorId, "dummy-supplier");
assert.equal(job.jobType, "dry_run_supplier_check");

console.log("Check dry-run validation tests passed");
