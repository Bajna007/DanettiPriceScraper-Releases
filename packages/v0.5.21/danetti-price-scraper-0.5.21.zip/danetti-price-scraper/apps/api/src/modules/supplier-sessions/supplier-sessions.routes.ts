import { randomUUID } from "node:crypto";
import {
  DVG_CONNECTOR_ID,
  DVG_LOGIN_URL,
  DvgHeadedBrowserRuntime,
  SupplierBrowserRuntimeError,
  buildDvgDetailUrl,
  decideDvgMappingReview,
  decideDvgPriceSnapshotGate,
  maskSupplierBrowserProfilePolicy,
  readOneDvgDetailFromSupplierSession,
  type BrowserRuntime,
  type DvgMappingReviewDecision,
  type DvgPriceSnapshotGateResult,
  type DvgSupplierSessionReadOneResult,
  type SupplierSessionState,
} from "@danetti/connectors";
import {
  createDbClient,
  type DanettiDbClient,
  type ManualOperatorRunItemSummary,
  type ManualOperatorRunMode,
  type SupplierMapping,
} from "@danetti/db";
import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import {
  ManualOperatorRunsRepository,
  sanitizeManualOperatorRunItems,
  summarizeManualOperatorRun,
  type ManualOperatorRunListFilters,
  type ManualOperatorRunSummary,
  type ManualOperatorRunsRepositoryLike,
} from "../manual-operator-runs/manual-operator-runs.repository.js";
import {
  SupplierSnapshotsRepository,
  type SupplierSnapshotsRepositoryLike,
} from "../supplier-snapshots/supplier-snapshots.repository.js";
import {
  SupplierSnapshotDatabaseError,
  SupplierSnapshotValidationError,
  persistSupplierPriceSnapshot,
  type SupplierSnapshotSummary,
} from "../supplier-snapshots/supplier-snapshots.service.js";

type SupplierSessionLifecycleState =
  | "idle"
  | "opening"
  | "open"
  | "authenticated"
  | "blocked"
  | "closed"
  | "error";

interface SupplierSessionRouteOptions {
  env?: Record<string, string | undefined>;
  runtimeFactory?: SupplierSessionRuntimeFactory;
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  snapshotRepository?: SupplierSnapshotsRepositoryLike;
  manualRunRepository?: ManualOperatorRunsRepositoryLike;
  now?: () => Date;
  manualBatchDelayMs?: number;
  maxManualBatchSize?: number;
  sleep?: (ms: number) => Promise<void>;
}

interface SupplierSessionParams {
  supplierId: string;
}

interface SupplierSessionOpenInput {
  connectorId: typeof DVG_CONNECTOR_ID;
  loginUrl: string;
}

interface SupplierSessionReadOneInput {
  supplierArticleNumber: string | null;
  supplierMappingId: string | null;
  catalogProductId: string | null;
  dryRun: boolean;
  saveSnapshot: boolean;
  blockReadOnlyRisks: boolean;
}

interface SupplierSessionRunSelectedInput {
  supplierMappingIds: string[];
  saveSnapshots: boolean;
  maxItems: number;
}

interface SupplierSessionRecord {
  runtime: BrowserRuntime;
  state: SupplierSessionLifecycleState;
  createdAt: Date;
  updatedAt: Date;
  lastSessionState: SupplierSessionState | null;
  lastKnownUrl: string | null;
  lastError: { code: string; message: string } | null;
}

interface SupplierSessionStatusResponse {
  supplierId: string;
  connectorId: typeof DVG_CONNECTOR_ID;
  state: SupplierSessionLifecycleState;
  browserOpen: boolean;
  authenticatedLikely: boolean;
  profileMode: "persistent_local_browser_profile";
  maskedProfilePath: string;
  lastKnownUrl: string | null;
  safetyEventCodes: string[];
  blockingSafetyFlags: string[];
  lastError: { code: string; message: string } | null;
  reused?: boolean;
  warnings: string[];
}

interface SupplierSessionOperatorReadinessResponse {
  supplierId: string;
  status: "ready" | "degraded";
  apiReachable: boolean;
  databaseReachable: boolean;
  sessionLabEnabled: boolean;
  browserRuntimeAvailable: boolean;
  currentLocalGuardMode: "loopback_header_localhost_origin_production_opt_in";
  manualAcceptanceStatus: "not_started" | "in_progress" | "needs_operator_action";
  normalizedErrorCodes: OperatorErrorCode[];
  warnings: string[];
}

interface SupplierSessionReadOneResponse {
  runId: string;
  startedAt: string;
  finishedAt: string;
  status: "parsed" | "blocked" | "failed";
  supplierId: string;
  supplierMappingId: string | null;
  catalogProductId: string | null;
  requestedArticle: string;
  finalUrl: string | null;
  parsed: DvgSupplierSessionReadOneResult["parsed"];
  mappingReview: Pick<
    DvgMappingReviewDecision,
    | "outcome"
    | "suggestedSupplierArticle"
    | "discoveredSupplierArticle"
    | "priceSnapshotAllowed"
    | "reason"
    | "warnings"
  >;
  snapshotGate: DvgPriceSnapshotGateResult;
  safety: {
    safetyEventCodes: string[];
    readOnlyRiskCodes: string[];
    blockingSafetyFlags: string[];
    stopReason: string | null;
  };
  persistence: {
    attempted: boolean;
    saved: boolean;
    snapshotId: string | null;
    observedAt: string | null;
    snapshot: SupplierSnapshotSummary | null;
    reason: string;
  };
  warnings: string[];
}

interface SupplierSessionRunSelectedItem {
  mappingId: string;
  supplierArticleNumber: string;
  status: "saved" | "parsed" | "blocked" | "failed";
  parsed: {
    dvgArticle: string | null;
    originalCode: string | null;
    productName: string | null;
    currentPrice: number | null;
    currency: string | null;
    stockStatus: string;
  } | null;
  snapshotGate: DvgPriceSnapshotGateResult;
  snapshotId: string | null;
  safety: {
    safetyEventCodes: string[];
    readOnlyRiskCodes: string[];
    blockingSafetyFlags: string[];
    stopReason: string | null;
  };
  reason: string;
}

interface SupplierSessionRunSelectedResponse {
  runId: string;
  startedAt: string;
  finishedAt: string;
  status: "completed" | "stopped" | "failed";
  totalRequested: number;
  processed: number;
  savedCount: number;
  blockedCount: number;
  failedCount: number;
  stoppedReason: string | null;
  items: SupplierSessionRunSelectedItem[];
}

interface SupplierSessionRetryItemInput {
  sourceRunId: string;
  supplierMappingId: string;
  saveSnapshot: boolean;
}

interface SupplierSessionRunParams extends SupplierSessionParams {
  runId: string;
}

type OperatorErrorCode =
  | "api_unavailable"
  | "database_unavailable"
  | "session_not_open"
  | "session_not_authenticated"
  | "supplier_login_required"
  | "captcha_or_2fa_detected"
  | "account_lock_risk"
  | "unsafe_domain"
  | "unsafe_url"
  | "unsafe_method"
  | "state_change_risk"
  | "mapping_not_found"
  | "mapping_disabled"
  | "mapping_supplier_mismatch"
  | "mapping_not_trusted"
  | "snapshot_gate_blocked"
  | "price_missing"
  | "currency_not_eur"
  | "sensitive_output_blocked"
  | "profile_reset_failed";

type SupplierSessionRuntimeFactory = (input: {
  supplierId: string;
  connectorId: typeof DVG_CONNECTOR_ID;
}) => BrowserRuntime;

const SESSION_LAB_HEADER = "x-danetti-local-lab";
const SESSION_TTL_MS = 30 * 60 * 1000;
const DEFAULT_MANUAL_BATCH_DELAY_MS = 6_000;
const DEFAULT_MAX_MANUAL_BATCH_SIZE = 5;
const records = new Map<string, SupplierSessionRecord>();
let processCleanupInstalled = false;

export async function registerSupplierSessionRoutes(
  server: FastifyInstance,
  options: SupplierSessionRouteOptions = {}
): Promise<void> {
  const env = options.env ?? process.env;
  const now = options.now ?? (() => new Date());
  const manualBatchDelayMs = options.manualBatchDelayMs ?? DEFAULT_MANUAL_BATCH_DELAY_MS;
  const maxManualBatchSize = Math.min(
    options.maxManualBatchSize ?? DEFAULT_MAX_MANUAL_BATCH_SIZE,
    DEFAULT_MAX_MANUAL_BATCH_SIZE
  );
  const sleep = options.sleep ?? delay;
  let dbClient = options.dbClient ?? null;
  const runtimeFactory =
    options.runtimeFactory ??
    ((input) => new DvgHeadedBrowserRuntime({ supplierId: input.supplierId, env }));
  installProcessCleanup();

  server.addHook("onClose", async () => {
    await closeAllSupplierSessions();
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getSnapshotRepository(): SupplierSnapshotsRepositoryLike {
    if (options.snapshotRepository) return options.snapshotRepository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new SupplierSnapshotsRepository(dbClient.db);
    } catch (error) {
      throw new SupplierSnapshotDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  function getManualRunRepository(): ManualOperatorRunsRepositoryLike {
    if (options.manualRunRepository) return options.manualRunRepository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new ManualOperatorRunsRepository(dbClient.db);
    } catch (error) {
      throw new SupplierSnapshotDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/supplier-sessions/:supplierId/operator-readiness", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const response = await buildOperatorReadiness({
        supplierId,
        env,
        getManualRunRepository,
      });
      return scrubSupplierSessionPayload(response);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-sessions/:supplierId/status", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const record = records.get(supplierId) ?? null;
      if (!record) return idleStatus(supplierId);
      if (isStale(record, now())) await closeAndMarkRecord(supplierId, record, now());
      return statusFromRecord(supplierId, records.get(supplierId) ?? record);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-sessions/:supplierId/open", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const input = validateOpenInput(request.body);
      let record = records.get(supplierId) ?? null;
      if (record && isStale(record, now())) {
        await closeAndDeleteRecord(supplierId, record);
        record = null;
      }
      if (!record) {
        record = createRecord(
          runtimeFactory({ supplierId, connectorId: input.connectorId }),
          now()
        );
        records.set(supplierId, record);
      }

      record.state = "opening";
      record.updatedAt = now();
      try {
        const state = await record.runtime.openSupplierSession(supplierId, input.loginUrl);
        updateRecordFromSessionState(record, state, now());
        return sanitizeSupplierSessionPayload(statusFromRecord(supplierId, record));
      } catch (error) {
        setRecordError(record, error, now());
        throw error;
      }
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-sessions/:supplierId/check", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      assertNoSensitiveKeys(request.body);
      const record = await getActiveRecord(supplierId, now());
      const state = await record.runtime.checkAuthenticatedSession();
      updateRecordFromSessionState(record, state, now());
      return sanitizeSupplierSessionPayload(statusFromRecord(supplierId, record));
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-sessions/:supplierId/read-one", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const input = validateReadOneInput(request.body);
      const repository = getSnapshotRepository();
      const manualRunRepository = getManualRunRepository();
      const runId = randomUUID();
      const startedAt = now();
      const resolved = await resolveReadOneInput(supplierId, input, repository);
      const record = await getActiveRecord(supplierId, now());
      const readResult = await readOneDvgDetailFromSupplierSession(
        record.runtime,
        resolved.requestedArticle
      );
      const sessionState = await record.runtime.checkAuthenticatedSession().catch(() => null);
      if (sessionState) updateRecordFromSessionState(record, sessionState, now());
      const finishedAt = now();
      const response = await buildReadOneResponse({
        runId,
        startedAt,
        finishedAt,
        supplierId,
        input,
        resolved,
        readResult,
        repository,
        observedAt: finishedAt,
      });
      await persistManualOperatorRun({
        repository: manualRunRepository,
        supplierId,
        mode: "read_one",
        runId,
        startedAt,
        finishedAt,
        requestedCount: 1,
        processedCount: 1,
        stoppedReason: response.safety.stopReason,
        items: [manualRunItemFromReadOne(response)],
      });
      return sanitizeSupplierSessionPayload(response);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-sessions/:supplierId/run-selected", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const input = validateRunSelectedInput(request.body, maxManualBatchSize);
      const repository = getSnapshotRepository();
      const manualRunRepository = getManualRunRepository();
      const record = await getActiveRecord(supplierId, now());
      const sessionState = await record.runtime.checkAuthenticatedSession();
      updateRecordFromSessionState(record, sessionState, now());

      if (!sessionState.authenticated) {
        throw new SupplierSessionsRouteError(
          "supplier_session_not_authenticated",
          "Supplier browser session is not authenticated",
          400
        );
      }

      const sessionBlockingFlags = uniqueCodes(sessionState.blockingReasons);
      if (sessionBlockingFlags.length > 0) {
        const startedAt = now();
        const response = {
          runId: randomUUID(),
          startedAt: startedAt.toISOString(),
          finishedAt: startedAt.toISOString(),
          status: "stopped",
          totalRequested: input.supplierMappingIds.length,
          processed: 0,
          savedCount: 0,
          blockedCount: 0,
          failedCount: 0,
          stoppedReason: sessionBlockingFlags[0] ?? "blocking_safety_flag",
          items: [],
        } satisfies SupplierSessionRunSelectedResponse;
        await persistManualOperatorRun({
          repository: manualRunRepository,
          supplierId,
          mode: "selected_micro_batch",
          runId: response.runId,
          startedAt,
          finishedAt: startedAt,
          requestedCount: input.supplierMappingIds.length,
          processedCount: 0,
          stoppedReason: response.stoppedReason,
          items: [],
        });
        return scrubSupplierSessionPayload(response);
      }

      const mappings = await resolveRunSelectedMappings(supplierId, input, repository);
      const response = await runSelectedMappings({
        supplierId,
        input,
        mappings,
        record,
        repository,
        now,
        delayMs: manualBatchDelayMs,
        sleep,
      });
      await persistManualOperatorRun({
        repository: manualRunRepository,
        supplierId,
        mode: "selected_micro_batch",
        runId: response.runId,
        startedAt: new Date(response.startedAt),
        finishedAt: new Date(response.finishedAt),
        requestedCount: response.totalRequested,
        processedCount: response.processed,
        stoppedReason: response.stoppedReason,
        items: response.items.map(manualRunItemFromRunSelectedItem),
      });
      return scrubSupplierSessionPayload(response);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-sessions/:supplierId/manual-runs", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const filters = validateManualRunListQuery(request.query, supplierId);
      const runs = await getManualRunRepository().listRuns(filters);
      return scrubSupplierSessionPayload({
        supplierId,
        runs: runs.map(summarizeManualOperatorRun),
        pagination: { limit: filters.limit, offset: filters.offset },
      });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-sessions/:supplierId/manual-runs/:runId/export", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const runId = readRunId(request.params);
      const format = validateManualRunExportFormat(request.query);
      const run = await getManualRunRepository().getRun(runId);
      if (!run || run.supplierId !== supplierId) {
        throw new SupplierSessionsRouteError("manual_run_not_found", "Manual run not found", 404);
      }
      const summary = scrubSupplierSessionPayload(summarizeManualOperatorRun(run));
      const safeFileName = `danetti-dvg-manual-run-${sanitizeCode(run.runId)}.${format}`;
      reply.header("content-disposition", `attachment; filename="${safeFileName}"`);
      if (format === "csv") {
        reply.header("content-type", "text/csv; charset=utf-8");
        return reply.send(manualRunSummaryToCsv(summary));
      }
      reply.header("content-type", "application/json; charset=utf-8");
      return reply.send(summary);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-sessions/:supplierId/manual-runs/:runId", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const runId = readRunId(request.params);
      const run = await getManualRunRepository().getRun(runId);
      if (!run || run.supplierId !== supplierId) {
        throw new SupplierSessionsRouteError("manual_run_not_found", "Manual run not found", 404);
      }
      return scrubSupplierSessionPayload(summarizeManualOperatorRun(run));
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-sessions/:supplierId/retry-one", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      const input = validateRetryItemInput(request.body);
      const repository = getSnapshotRepository();
      const manualRunRepository = getManualRunRepository();
      const sourceRun = await manualRunRepository.getRun(input.sourceRunId);
      assertRetryAllowed({
        supplierId,
        input,
        sourceRun: sourceRun && summarizeManualOperatorRun(sourceRun),
      });

      const record = await getActiveRecord(supplierId, now());
      const sessionState = await record.runtime.checkAuthenticatedSession();
      updateRecordFromSessionState(record, sessionState, now());
      if (!sessionState.authenticated) {
        throw new SupplierSessionsRouteError(
          "supplier_session_not_authenticated",
          "Supplier browser session is not authenticated",
          400
        );
      }

      const sessionBlockingFlags = uniqueCodes(sessionState.blockingReasons);
      if (sessionBlockingFlags.length > 0) {
        const startedAt = now();
        const response = {
          runId: randomUUID(),
          startedAt: startedAt.toISOString(),
          finishedAt: startedAt.toISOString(),
          status: "stopped",
          totalRequested: 1,
          processed: 0,
          savedCount: 0,
          blockedCount: 0,
          failedCount: 0,
          stoppedReason: sessionBlockingFlags[0] ?? "blocking_safety_flag",
          items: [],
        } satisfies SupplierSessionRunSelectedResponse;
        await persistManualOperatorRun({
          repository: manualRunRepository,
          supplierId,
          mode: "selected_micro_batch",
          runId: response.runId,
          startedAt,
          finishedAt: startedAt,
          requestedCount: 1,
          processedCount: 0,
          stoppedReason: response.stoppedReason,
          items: [],
        });
        return scrubSupplierSessionPayload(response);
      }

      const runInput: SupplierSessionRunSelectedInput = {
        supplierMappingIds: [input.supplierMappingId],
        saveSnapshots: input.saveSnapshot,
        maxItems: 1,
      };
      const mappings = await resolveRunSelectedMappings(supplierId, runInput, repository);
      const response = await runSelectedMappings({
        supplierId,
        input: runInput,
        mappings,
        record,
        repository,
        now,
        delayMs: 0,
        sleep,
      });
      await persistManualOperatorRun({
        repository: manualRunRepository,
        supplierId,
        mode: "selected_micro_batch",
        runId: response.runId,
        startedAt: new Date(response.startedAt),
        finishedAt: new Date(response.finishedAt),
        requestedCount: response.totalRequested,
        processedCount: response.processed,
        stoppedReason: response.stoppedReason,
        items: response.items.map(manualRunItemFromRunSelectedItem),
      });
      return scrubSupplierSessionPayload(response);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-sessions/:supplierId/close", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      assertNoSensitiveKeys(request.body);
      const record = records.get(supplierId) ?? null;
      if (!record) return idleStatus(supplierId);
      await closeAndMarkRecord(supplierId, record, now());
      return sanitizeSupplierSessionPayload(statusFromRecord(supplierId, record));
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-sessions/:supplierId/reset-profile", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const supplierId = readSupplierId(request.params);
      assertNoSensitiveKeys(request.body);
      const record =
        records.get(supplierId) ??
        createRecord(runtimeFactory({ supplierId, connectorId: DVG_CONNECTOR_ID }), now());
      records.set(supplierId, record);
      const result = await record.runtime.resetLocalProfile().catch(() => {
        throw new SupplierSessionsRouteError(
          "profile_reset_failed",
          "Supplier browser profile reset failed",
          500
        );
      });
      records.delete(supplierId);
      return sanitizeSupplierSessionPayload({
        supplierId,
        connectorId: DVG_CONNECTOR_ID,
        reset: result.reset,
        profilePolicy: maskSupplierBrowserProfilePolicy(result.profilePolicy),
        warnings: result.warnings,
      });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

async function buildOperatorReadiness(input: {
  supplierId: string;
  env: Record<string, string | undefined>;
  getManualRunRepository: () => ManualOperatorRunsRepositoryLike;
}): Promise<SupplierSessionOperatorReadinessResponse> {
  const warnings: string[] = [];
  const normalizedErrorCodes: OperatorErrorCode[] = [];
  let databaseReachable = false;
  let recentRunCount = 0;
  try {
    const runs = await input.getManualRunRepository().listRuns({
      supplierId: input.supplierId,
      limit: 1,
      offset: 0,
    });
    databaseReachable = true;
    recentRunCount = runs.length;
  } catch {
    warnings.push("database_unavailable");
    normalizedErrorCodes.push("database_unavailable");
  }

  const browserRuntimeAvailable = true;

  const sessionLabEnabled =
    input.env.NODE_ENV !== "production" ||
    input.env.ENABLE_SUPPLIER_SESSION_LAB?.trim().toLowerCase() === "true";
  const record = records.get(input.supplierId) ?? null;
  const manualAcceptanceStatus =
    record?.state === "authenticated"
      ? "in_progress"
      : recentRunCount > 0
        ? "in_progress"
        : "not_started";
  if (!sessionLabEnabled) warnings.push("supplier_session_disabled");

  return {
    supplierId: input.supplierId,
    status:
      databaseReachable && browserRuntimeAvailable && sessionLabEnabled ? "ready" : "degraded",
    apiReachable: true,
    databaseReachable,
    sessionLabEnabled,
    browserRuntimeAvailable,
    currentLocalGuardMode: "loopback_header_localhost_origin_production_opt_in",
    manualAcceptanceStatus,
    normalizedErrorCodes: uniqueCodes(normalizedErrorCodes) as OperatorErrorCode[],
    warnings: uniqueCodes(warnings),
  };
}

async function buildReadOneResponse(input: {
  runId: string;
  startedAt: Date;
  finishedAt: Date;
  supplierId: string;
  input: SupplierSessionReadOneInput;
  resolved: {
    requestedArticle: string;
    supplierMappingId: string | null;
    catalogProductId: string | null;
    mappingSource: "saved_mapping" | "manual_article_input";
    mapping: SupplierMapping | null;
  };
  readResult: DvgSupplierSessionReadOneResult;
  repository: SupplierSnapshotsRepositoryLike;
  observedAt: Date;
}): Promise<SupplierSessionReadOneResponse> {
  const { readResult, resolved } = input;
  const parsed = readResult.parsed;
  const readOnlyRiskCodes = readResult.safetyFlags?.readOnlyRiskCodes ?? [];
  const blockingSafetyFlags = uniqueCodes([
    ...readResult.blockingReasons,
    ...(input.input.blockReadOnlyRisks ? readOnlyRiskCodes : []),
  ]);
  const mappingReview = decideDvgMappingReview({
    expectedArticle: resolved.requestedArticle,
    parsedDvgArticle: parsed?.dvgArticle ?? null,
    parsedOriginalCode: parsed?.originalCode ?? null,
    mappingSource: resolved.mappingSource,
    existingMapping: resolved.mapping
      ? { supplierArticleNumber: resolved.mapping.supplierArticleNumber }
      : null,
    invalidOrAccessDenied: parsed?.matchConfidence === "invalid_or_accessdenied",
  });
  const snapshotGate = decideDvgPriceSnapshotGate({
    loginSucceeded: readResult.authenticated && readResult.detailFetchOk,
    currentPriceNetEur: parsed?.currentPrice ?? null,
    currency: parsed?.currency ?? null,
    reviewOutcome: mappingReview.outcome,
    blockingSafetyFlags,
  });
  const resultUrl = safeBuildDvgDetailUrl(resolved.requestedArticle);
  const persistence = await maybePersistSnapshot({
    supplierId: input.supplierId,
    input: input.input,
    resolved,
    parsed,
    mappingReview,
    snapshotGate,
    blockingSafetyFlags,
    repository: input.repository,
    resultUrl,
    observedAt: input.observedAt,
  });
  const status =
    readResult.status === "blocked" || blockingSafetyFlags.length > 0
      ? "blocked"
      : readResult.status === "success"
        ? "parsed"
        : "failed";
  const warnings = uniqueCodes([
    ...readResult.warnings,
    ...mappingReview.warnings,
    ...snapshotGate.warnings,
    persistence.reason === "not_requested" ? null : persistence.reason,
  ]);

  return {
    runId: input.runId,
    startedAt: input.startedAt.toISOString(),
    finishedAt: input.finishedAt.toISOString(),
    status,
    supplierId: input.supplierId,
    supplierMappingId: resolved.supplierMappingId,
    catalogProductId: resolved.catalogProductId,
    requestedArticle: resolved.requestedArticle,
    finalUrl: readResult.detailFetchOk ? resultUrl : readResult.finalPath,
    parsed,
    mappingReview: {
      outcome: mappingReview.outcome,
      suggestedSupplierArticle: mappingReview.suggestedSupplierArticle,
      discoveredSupplierArticle: mappingReview.discoveredSupplierArticle,
      priceSnapshotAllowed: mappingReview.priceSnapshotAllowed,
      reason: mappingReview.reason,
      warnings: mappingReview.warnings,
    },
    snapshotGate,
    safety: {
      safetyEventCodes: readResult.safetyFlags.safetyEventCodes,
      readOnlyRiskCodes,
      blockingSafetyFlags,
      stopReason: blockingSafetyFlags[0] ?? null,
    },
    persistence,
    warnings,
  };
}

async function maybePersistSnapshot(input: {
  supplierId: string;
  input: SupplierSessionReadOneInput;
  resolved: {
    requestedArticle: string;
    supplierMappingId: string | null;
    catalogProductId: string | null;
    mapping: SupplierMapping | null;
  };
  parsed: DvgSupplierSessionReadOneResult["parsed"];
  mappingReview: DvgMappingReviewDecision;
  snapshotGate: DvgPriceSnapshotGateResult;
  blockingSafetyFlags: string[];
  repository: SupplierSnapshotsRepositoryLike;
  resultUrl: string | null;
  observedAt: Date;
}): Promise<SupplierSessionReadOneResponse["persistence"]> {
  if (!input.input.saveSnapshot) return emptyPersistence("not_requested", false);
  if (input.input.dryRun) return emptyPersistence("dry_run", true);
  if (!input.resolved.supplierMappingId || !input.resolved.mapping) {
    return emptyPersistence("supplier_mapping_required", true);
  }
  if (!input.parsed) return emptyPersistence("parsed_result_missing", true);
  if (!input.snapshotGate.allowed) return emptyPersistence(input.snapshotGate.reason, true);

  try {
    const persisted = await persistSupplierPriceSnapshot({
      repository: input.repository,
      data: {
        saveSnapshot: true,
        supplierId: input.supplierId,
        supplierMappingId: input.resolved.supplierMappingId,
        catalogProductId: input.resolved.catalogProductId,
        supplierArticleNumber: input.resolved.requestedArticle,
        supplierProductName: input.parsed.productName,
        priceNetEur: input.parsed.currentPrice,
        priceGrossEur: null,
        currency: input.parsed.currency,
        stockStatus: input.parsed.stockStatus,
        availabilityText: input.parsed.availabilityText,
        mappingReviewOutcome: input.mappingReview.outcome,
        snapshotGateAllowed: input.snapshotGate.allowed,
        blockingSafetyFlags: input.blockingSafetyFlags,
        resultUrl: input.resultUrl,
        observedAt: input.observedAt,
      },
    });
    return {
      attempted: true,
      saved: true,
      snapshotId: persisted.snapshotId,
      observedAt: persisted.observedAt,
      snapshot: persisted.snapshot,
      reason: "saved",
    };
  } catch (error) {
    if (error instanceof SupplierSnapshotValidationError) {
      return emptyPersistence(error.code, true);
    }
    throw error;
  }
}

function emptyPersistence(
  reason: string,
  attempted: boolean
): SupplierSessionReadOneResponse["persistence"] {
  return { attempted, saved: false, snapshotId: null, observedAt: null, snapshot: null, reason };
}

async function resolveReadOneInput(
  supplierId: string,
  input: SupplierSessionReadOneInput,
  repository: SupplierSnapshotsRepositoryLike
): Promise<{
  requestedArticle: string;
  supplierMappingId: string | null;
  catalogProductId: string | null;
  mappingSource: "saved_mapping" | "manual_article_input";
  mapping: SupplierMapping | null;
}> {
  if (input.supplierMappingId) {
    const mapping = await repository.getMappingById(input.supplierMappingId);
    if (!mapping) {
      throw new SupplierSessionsRouteError("mapping_not_found", "Supplier mapping not found", 404);
    }
    if (mapping.supplierId !== supplierId) {
      throw new SupplierSessionsRouteError(
        "mapping_supplier_mismatch",
        "Supplier mapping does not belong to requested supplier",
        403
      );
    }
    if (!mapping.enabled) {
      throw new SupplierSessionsRouteError("mapping_disabled", "Supplier mapping is disabled", 400);
    }
    return {
      requestedArticle: mapping.supplierArticleNumber,
      supplierMappingId: mapping.id,
      catalogProductId: mapping.catalogProductId,
      mappingSource: "saved_mapping",
      mapping,
    };
  }

  if (!input.supplierArticleNumber) {
    throw new SupplierSessionsRouteError(
      "dvg_test_article_missing",
      "supplierArticleNumber or supplierMappingId is required",
      400
    );
  }
  return {
    requestedArticle: input.supplierArticleNumber,
    supplierMappingId: null,
    catalogProductId: input.catalogProductId,
    mappingSource: "manual_article_input",
    mapping: null,
  };
}

async function resolveRunSelectedMappings(
  supplierId: string,
  input: SupplierSessionRunSelectedInput,
  repository: SupplierSnapshotsRepositoryLike
): Promise<SupplierMapping[]> {
  const mappings: SupplierMapping[] = [];
  for (const mappingId of input.supplierMappingIds) {
    const mapping = await repository.getMappingById(mappingId);
    if (!mapping) {
      throw new SupplierSessionsRouteError("mapping_not_found", "Supplier mapping not found", 404);
    }
    if (mapping.supplierId !== supplierId) {
      throw new SupplierSessionsRouteError(
        "mapping_supplier_mismatch",
        "Supplier mapping does not belong to requested supplier",
        403
      );
    }
    if (!mapping.enabled) {
      throw new SupplierSessionsRouteError("mapping_disabled", "Supplier mapping is disabled", 400);
    }
    mappings.push(mapping);
  }
  return mappings;
}

async function runSelectedMappings(input: {
  supplierId: string;
  input: SupplierSessionRunSelectedInput;
  mappings: SupplierMapping[];
  record: SupplierSessionRecord;
  repository: SupplierSnapshotsRepositoryLike;
  now: () => Date;
  delayMs: number;
  sleep: (ms: number) => Promise<void>;
}): Promise<SupplierSessionRunSelectedResponse> {
  const startedAt = input.now();
  const response: SupplierSessionRunSelectedResponse = {
    runId: randomUUID(),
    startedAt: startedAt.toISOString(),
    finishedAt: startedAt.toISOString(),
    status: "completed",
    totalRequested: input.input.supplierMappingIds.length,
    processed: 0,
    savedCount: 0,
    blockedCount: 0,
    failedCount: 0,
    stoppedReason: null,
    items: [],
  };

  for (let index = 0; index < input.mappings.length; index += 1) {
    const mapping = input.mappings[index];
    const readInput: SupplierSessionReadOneInput = {
      supplierArticleNumber: null,
      supplierMappingId: mapping.id,
      catalogProductId: null,
      dryRun: !input.input.saveSnapshots,
      saveSnapshot: input.input.saveSnapshots,
      blockReadOnlyRisks: true,
    };
    try {
      const readResult = await readOneDvgDetailFromSupplierSession(
        input.record.runtime,
        mapping.supplierArticleNumber
      );
      const sessionState = await input.record.runtime.checkAuthenticatedSession().catch(() => null);
      if (sessionState) updateRecordFromSessionState(input.record, sessionState, input.now());
      const observedAt = input.now();
      const readResponse = await buildReadOneResponse({
        runId: response.runId,
        startedAt,
        finishedAt: observedAt,
        supplierId: input.supplierId,
        input: readInput,
        resolved: {
          requestedArticle: mapping.supplierArticleNumber,
          supplierMappingId: mapping.id,
          catalogProductId: mapping.catalogProductId,
          mappingSource: "saved_mapping",
          mapping,
        },
        readResult,
        repository: input.repository,
        observedAt,
      });
      const item = runSelectedItemFromReadOne(mapping, readResponse);
      response.items.push(item);
      response.processed += 1;
      if (item.status === "saved") response.savedCount += 1;
      if (item.status === "blocked") response.blockedCount += 1;
      if (item.status === "failed") response.failedCount += 1;

      const stopReason = getRunSelectedStopReason(readResponse);
      if (stopReason) {
        response.status = "stopped";
        response.stoppedReason = stopReason;
        break;
      }
    } catch (error) {
      response.items.push(runSelectedFailedItem(mapping, error));
      response.processed += 1;
      response.failedCount += 1;
    }

    if (response.status === "completed" && index < input.mappings.length - 1 && input.delayMs > 0) {
      await input.sleep(input.delayMs);
    }
  }

  response.finishedAt = input.now().toISOString();
  return response;
}

function runSelectedItemFromReadOne(
  mapping: SupplierMapping,
  readResponse: SupplierSessionReadOneResponse
): SupplierSessionRunSelectedItem {
  const status = readResponse.persistence.saved ? "saved" : readResponse.status;
  return {
    mappingId: mapping.id,
    supplierArticleNumber: mapping.supplierArticleNumber,
    status,
    parsed: readResponse.parsed
      ? {
          dvgArticle: readResponse.parsed.dvgArticle,
          originalCode: readResponse.parsed.originalCode,
          productName: readResponse.parsed.productName,
          currentPrice: readResponse.parsed.currentPrice,
          currency: readResponse.parsed.currency,
          stockStatus: readResponse.parsed.stockStatus,
        }
      : null,
    snapshotGate: readResponse.snapshotGate,
    snapshotId: readResponse.persistence.snapshotId,
    safety: readResponse.safety,
    reason: readResponse.persistence.saved
      ? "saved"
      : (readResponse.safety.stopReason ??
        readResponse.safety.readOnlyRiskCodes[0] ??
        readResponse.persistence.reason ??
        readResponse.snapshotGate.reason),
  };
}

function runSelectedFailedItem(
  mapping: SupplierMapping,
  error: unknown
): SupplierSessionRunSelectedItem {
  const reason =
    error instanceof SupplierSessionsRouteError
      ? error.code
      : error instanceof SupplierBrowserRuntimeError
        ? error.code
        : "supplier_session_read_failed";
  return {
    mappingId: mapping.id,
    supplierArticleNumber: mapping.supplierArticleNumber,
    status: "failed",
    parsed: null,
    snapshotGate: { allowed: false, reason, warnings: [reason] },
    snapshotId: null,
    safety: {
      safetyEventCodes: [],
      readOnlyRiskCodes: [],
      blockingSafetyFlags: [],
      stopReason: null,
    },
    reason,
  };
}

function getRunSelectedStopReason(response: SupplierSessionReadOneResponse): string | null {
  if (response.safety.blockingSafetyFlags.length > 0) {
    return (
      response.safety.stopReason ?? response.safety.blockingSafetyFlags[0] ?? "blocking_safety_flag"
    );
  }
  if (response.safety.readOnlyRiskCodes.length > 0) {
    return response.safety.readOnlyRiskCodes[0] ?? "read_only_risk_present";
  }
  if (response.status === "blocked")
    return response.safety.stopReason ?? "supplier_session_blocked";
  if (response.snapshotGate.reason === "dvg_login_required") return "dvg_login_required";
  return null;
}

async function persistManualOperatorRun(input: {
  repository: ManualOperatorRunsRepositoryLike;
  supplierId: string;
  mode: ManualOperatorRunMode;
  runId: string;
  startedAt: Date;
  finishedAt: Date;
  requestedCount: number;
  processedCount: number;
  stoppedReason: string | null;
  items: ManualOperatorRunItemSummary[];
}): Promise<void> {
  const itemSummaries = sanitizeManualOperatorRunItems(input.items);
  await input.repository.insertRun({
    runId: input.runId,
    supplierId: input.supplierId,
    startedAt: input.startedAt,
    finishedAt: input.finishedAt,
    mode: input.mode,
    requestedCount: input.requestedCount,
    processedCount: input.processedCount,
    savedCount: itemSummaries.filter((item) => item.status === "saved").length,
    blockedCount: itemSummaries.filter((item) => item.status === "blocked").length,
    failedCount: itemSummaries.filter((item) => item.status === "failed").length,
    stoppedReason: input.stoppedReason,
    itemSummaries,
  });
}

function manualRunItemFromReadOne(
  response: SupplierSessionReadOneResponse
): ManualOperatorRunItemSummary {
  const status = response.persistence.saved ? "saved" : response.status;
  return {
    mappingId: response.supplierMappingId,
    supplierArticleNumber: response.requestedArticle,
    status,
    price: response.parsed?.currentPrice ?? null,
    currency: response.parsed?.currency ?? null,
    snapshotId: response.persistence.snapshotId,
    safetyFlags: uniqueCodes([
      ...response.safety.safetyEventCodes,
      ...response.safety.readOnlyRiskCodes,
      ...response.safety.blockingSafetyFlags,
      response.safety.stopReason,
    ]),
    reason: response.persistence.saved
      ? "saved"
      : (response.safety.stopReason ??
        response.safety.readOnlyRiskCodes[0] ??
        response.persistence.reason ??
        response.snapshotGate.reason),
  };
}

function manualRunItemFromRunSelectedItem(
  item: SupplierSessionRunSelectedItem
): ManualOperatorRunItemSummary {
  return {
    mappingId: item.mappingId,
    supplierArticleNumber: item.supplierArticleNumber,
    status: item.status,
    price: item.parsed?.currentPrice ?? null,
    currency: item.parsed?.currency ?? null,
    snapshotId: item.snapshotId,
    safetyFlags: uniqueCodes([
      ...item.safety.safetyEventCodes,
      ...item.safety.readOnlyRiskCodes,
      ...item.safety.blockingSafetyFlags,
      item.safety.stopReason,
    ]),
    reason: item.reason,
  };
}

function validateManualRunListQuery(
  query: unknown,
  supplierId: string
): ManualOperatorRunListFilters {
  const input = isRecord(query) ? query : {};
  const mode = optionalString(input.mode, null, "mode");
  if (mode !== null && mode !== "read_one" && mode !== "selected_micro_batch") {
    throw new SupplierSessionsRouteError(
      "manual_run_mode_invalid",
      "mode must be read_one or selected_micro_batch",
      400
    );
  }
  const validatedMode = mode === null ? undefined : (mode as ManualOperatorRunMode);
  return {
    supplierId,
    mode: validatedMode,
    limit: boundedInteger(input.limit, 20, 1, 100, "limit"),
    offset: boundedInteger(input.offset, 0, 0, Number.MAX_SAFE_INTEGER, "offset"),
  };
}

function validateManualRunExportFormat(query: unknown): "json" | "csv" {
  const input = isRecord(query) ? query : {};
  const format = optionalString(input.format, "json", "format");
  if (format !== "json" && format !== "csv") {
    throw new SupplierSessionsRouteError(
      "manual_run_export_format_invalid",
      "format must be json or csv",
      400
    );
  }
  return format;
}

function validateRetryItemInput(body: unknown): SupplierSessionRetryItemInput {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  const sourceRunId = optionalUuid(input.sourceRunId, "sourceRunId");
  const supplierMappingId = optionalUuid(input.supplierMappingId, "supplierMappingId");
  if (!sourceRunId || !supplierMappingId) {
    throw new SupplierSessionsRouteError(
      "retry_one_input_required",
      "sourceRunId and supplierMappingId are required",
      400
    );
  }
  return {
    sourceRunId,
    supplierMappingId,
    saveSnapshot: optionalBoolean(input.saveSnapshot, false, "saveSnapshot"),
  };
}

function assertRetryAllowed(input: {
  supplierId: string;
  input: SupplierSessionRetryItemInput;
  sourceRun: ManualOperatorRunSummary | null;
}): void {
  const sourceRun = input.sourceRun;
  if (!sourceRun || sourceRun.supplierId !== input.supplierId) {
    throw new SupplierSessionsRouteError("manual_run_not_found", "Manual run not found", 404);
  }
  const item = sourceRun.itemSummaries.find(
    (summary) => summary.mappingId === input.input.supplierMappingId
  );
  if (!item) {
    throw new SupplierSessionsRouteError(
      "retry_item_not_found",
      "Supplier mapping was not part of source run",
      400
    );
  }
  if (item.status !== "blocked" && item.status !== "failed") {
    throw new SupplierSessionsRouteError(
      "retry_item_not_failed_or_blocked",
      "Only failed or blocked manual run items can be retried",
      400
    );
  }
}

function readRunId(params: unknown): string {
  const runId = (params as SupplierSessionRunParams).runId?.trim();
  if (!runId) {
    throw new SupplierSessionsRouteError("manual_run_id_required", "runId is required", 400);
  }
  validateUuid(runId, "runId");
  return runId;
}

function manualRunSummaryToCsv(summary: ManualOperatorRunSummary): string {
  const rows = [
    [
      "runId",
      "supplierId",
      "mode",
      "startedAt",
      "finishedAt",
      "mappingId",
      "supplierArticleNumber",
      "status",
      "price",
      "currency",
      "snapshotId",
      "safetyFlags",
      "reason",
    ],
    ...summary.itemSummaries.map((item) => [
      summary.runId,
      summary.supplierId,
      summary.mode,
      summary.startedAt,
      summary.finishedAt,
      item.mappingId ?? "",
      item.supplierArticleNumber,
      item.status,
      item.price === null ? "" : String(item.price),
      item.currency ?? "",
      item.snapshotId ?? "",
      item.safetyFlags.join("|"),
      item.reason,
    ]),
  ];
  return `${rows.map((row) => row.map(csvCell).join(",")).join("\n")}\n`;
}

function csvCell(value: string): string {
  if (!/[",\n\r]/.test(value)) return value;
  return `"${value.replace(/"/g, '""')}"`;
}

async function getActiveRecord(supplierId: string, now: Date): Promise<SupplierSessionRecord> {
  const record = records.get(supplierId);
  if (!record || record.state === "closed" || record.state === "idle") {
    throw new SupplierSessionsRouteError(
      "supplier_session_not_open",
      "Supplier browser session is not open",
      400
    );
  }
  if (isStale(record, now)) {
    await closeAndDeleteRecord(supplierId, record);
    throw new SupplierSessionsRouteError(
      "supplier_session_stale",
      "Supplier browser session is stale and was closed",
      400
    );
  }
  return record;
}

function createRecord(runtime: BrowserRuntime, now: Date): SupplierSessionRecord {
  return {
    runtime,
    state: "idle",
    createdAt: now,
    updatedAt: now,
    lastSessionState: null,
    lastKnownUrl: null,
    lastError: null,
  };
}

function updateRecordFromSessionState(
  record: SupplierSessionRecord,
  state: SupplierSessionState,
  now: Date
): void {
  record.lastSessionState = state;
  record.lastKnownUrl = state.finalPath;
  record.state = state.status === "closed" || state.status === "idle" ? "closed" : state.status;
  record.updatedAt = now;
  record.lastError = null;
}

function setRecordError(record: SupplierSessionRecord, error: unknown, now: Date): void {
  record.state = "error";
  record.updatedAt = now;
  record.lastError = {
    code:
      error instanceof SupplierBrowserRuntimeError
        ? error.code
        : error instanceof Error
          ? sanitizeCode(error.name)
          : "supplier_session_error",
    message:
      error instanceof SupplierBrowserRuntimeError ? error.message : "Supplier session failed",
  };
}

async function closeAndMarkRecord(
  supplierId: string,
  record: SupplierSessionRecord,
  now: Date
): Promise<void> {
  const state = await record.runtime.closeSession().catch(() => null);
  record.state = "closed";
  record.updatedAt = now;
  record.lastKnownUrl = null;
  if (state) record.lastSessionState = state;
  records.set(supplierId, record);
}

async function closeAndDeleteRecord(
  supplierId: string,
  record: SupplierSessionRecord
): Promise<void> {
  await record.runtime.closeSession().catch(() => undefined);
  records.delete(supplierId);
}

async function closeAllSupplierSessions(): Promise<void> {
  await Promise.all(
    Array.from(records.entries()).map(([id, record]) => closeAndDeleteRecord(id, record))
  );
}

function isStale(record: SupplierSessionRecord, now: Date): boolean {
  return now.getTime() - record.updatedAt.getTime() > SESSION_TTL_MS;
}

function installProcessCleanup(): void {
  if (processCleanupInstalled) return;
  processCleanupInstalled = true;
  process.once("beforeExit", () => {
    void closeAllSupplierSessions();
  });
}

function idleStatus(supplierId: string): SupplierSessionStatusResponse {
  return {
    supplierId,
    connectorId: DVG_CONNECTOR_ID,
    state: "idle",
    browserOpen: false,
    authenticatedLikely: false,
    profileMode: "persistent_local_browser_profile",
    maskedProfilePath: `DanettiPriceScraper/supplier-browser-profiles/${sanitizeCode(supplierId)}`,
    lastKnownUrl: null,
    safetyEventCodes: [],
    blockingSafetyFlags: [],
    lastError: null,
    warnings: [],
  };
}

function statusFromRecord(
  supplierId: string,
  record: SupplierSessionRecord
): SupplierSessionStatusResponse {
  const state = record.lastSessionState;
  const masked = state?.profilePolicy
    ? maskSupplierBrowserProfilePolicy(state.profilePolicy).maskedProfilePath
    : `DanettiPriceScraper/supplier-browser-profiles/${sanitizeCode(supplierId)}`;
  return {
    supplierId,
    connectorId: DVG_CONNECTOR_ID,
    state: record.state,
    browserOpen: record.state !== "idle" && record.state !== "closed" && record.state !== "error",
    authenticatedLikely: Boolean(state?.authenticated),
    profileMode: "persistent_local_browser_profile",
    maskedProfilePath: masked,
    lastKnownUrl: sanitizeLastKnownUrl(record.lastKnownUrl),
    safetyEventCodes: state?.safetyFlags.safetyEventCodes ?? [],
    blockingSafetyFlags: state?.blockingReasons ?? [],
    lastError: record.lastError,
    reused: state?.reused,
    warnings: state?.warnings ?? [],
  };
}

function validateOpenInput(body: unknown): SupplierSessionOpenInput {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  const connectorId =
    optionalString(input.connectorId, DVG_CONNECTOR_ID, "connectorId") ?? DVG_CONNECTOR_ID;
  if (connectorId !== DVG_CONNECTOR_ID) {
    throw new SupplierSessionsRouteError(
      "unsupported_supplier_session_connector",
      "Only DVG supplier browser session is supported in this lab",
      400
    );
  }
  const loginUrl = optionalString(input.loginUrl, DVG_LOGIN_URL, "loginUrl") ?? DVG_LOGIN_URL;
  if (!isDvgLoginUrl(loginUrl)) {
    throw new SupplierSessionsRouteError(
      "unsupported_supplier_session_login_url",
      "Unsupported supplier login URL",
      400
    );
  }
  return { connectorId, loginUrl };
}

function validateReadOneInput(body: unknown): SupplierSessionReadOneInput {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  const supplierMappingId = optionalUuid(input.supplierMappingId, "supplierMappingId") ?? null;
  const catalogProductId = optionalUuid(input.catalogProductId, "catalogProductId") ?? null;
  const supplierArticleNumber =
    optionalString(
      input.supplierArticleNumber ?? input.article ?? input.testArticle,
      null,
      "supplierArticleNumber"
    ) ?? null;
  if (!supplierMappingId && !supplierArticleNumber) {
    throw new SupplierSessionsRouteError(
      "dvg_test_article_missing",
      "supplierArticleNumber or supplierMappingId is required",
      400
    );
  }
  return {
    supplierArticleNumber,
    supplierMappingId,
    catalogProductId,
    dryRun: optionalBoolean(input.dryRun, true, "dryRun"),
    saveSnapshot: optionalBoolean(input.saveSnapshot, false, "saveSnapshot"),
    blockReadOnlyRisks: false,
  };
}

function validateRunSelectedInput(
  body: unknown,
  maxManualBatchSize: number
): SupplierSessionRunSelectedInput {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  if (!Array.isArray(input.supplierMappingIds)) {
    throw new SupplierSessionsRouteError(
      "supplier_mapping_ids_required",
      "supplierMappingIds must be an array",
      400
    );
  }
  const supplierMappingIds = input.supplierMappingIds.map((value, index) => {
    if (typeof value !== "string") {
      throw new SupplierSessionsRouteError(
        "invalid_uuid",
        `supplierMappingIds[${index}] must be a UUID`,
        400
      );
    }
    const trimmed = value.trim();
    validateUuid(trimmed, `supplierMappingIds[${index}]`);
    return trimmed;
  });

  if (supplierMappingIds.length === 0) {
    throw new SupplierSessionsRouteError(
      "supplier_mapping_ids_empty",
      "At least one supplier mapping is required",
      400
    );
  }
  if (supplierMappingIds.length > maxManualBatchSize) {
    throw new SupplierSessionsRouteError(
      "manual_batch_too_large",
      `Manual batch is limited to ${maxManualBatchSize} mappings`,
      400
    );
  }
  if (new Set(supplierMappingIds).size !== supplierMappingIds.length) {
    throw new SupplierSessionsRouteError(
      "duplicate_supplier_mapping",
      "Duplicate supplier mappings are not allowed",
      400
    );
  }

  const maxItems = boundedInteger(
    input.maxItems,
    maxManualBatchSize,
    1,
    maxManualBatchSize,
    "maxItems"
  );
  return {
    supplierMappingIds: supplierMappingIds.slice(0, maxItems),
    saveSnapshots: optionalBoolean(input.saveSnapshots, false, "saveSnapshots"),
    maxItems,
  };
}

function readSupplierId(params: unknown): string {
  const supplierId = (params as SupplierSessionParams).supplierId?.trim();
  if (!supplierId || !/^[A-Za-z0-9._:-]+$/.test(supplierId)) {
    throw new SupplierSessionsRouteError(
      "supplier_session_supplier_invalid",
      "Invalid supplier id",
      400
    );
  }
  return supplierId;
}

function assertRouteAllowed(
  request: FastifyRequest,
  env: Record<string, string | undefined>
): void {
  if (!isLoopbackIp(request.ip)) {
    throw new SupplierSessionsRouteError(
      "supplier_session_local_only",
      "Supplier browser sessions are local-only",
      403
    );
  }
  if (request.headers[SESSION_LAB_HEADER] !== "true") {
    throw new SupplierSessionsRouteError(
      "supplier_session_header_missing",
      "Supplier browser sessions require local lab header",
      403
    );
  }
  const origin = stringHeader(request.headers.origin);
  if (origin && !isAllowedLocalWebOrigin(origin)) {
    throw new SupplierSessionsRouteError(
      "supplier_session_origin_forbidden",
      "Supplier browser sessions require localhost dashboard origin",
      403
    );
  }
  const referer = stringHeader(request.headers.referer);
  if (!origin && referer && !isAllowedLocalWebOrigin(referer)) {
    throw new SupplierSessionsRouteError(
      "supplier_session_origin_forbidden",
      "Supplier browser sessions require localhost dashboard origin",
      403
    );
  }
  const explicitlyEnabled = env.ENABLE_SUPPLIER_SESSION_LAB?.trim().toLowerCase() === "true";
  if (env.NODE_ENV === "production" && !explicitlyEnabled) {
    throw new SupplierSessionsRouteError(
      "supplier_session_disabled",
      "Supplier browser session lab is disabled in production unless explicitly enabled",
      403
    );
  }
}

function assertNoSensitiveKeys(value: unknown): void {
  if (!isRecord(value)) return;
  for (const [key, child] of Object.entries(value)) {
    if (isSensitiveSupplierSessionKey(key)) {
      throw new SupplierSessionsRouteError(
        "sensitive_field",
        "Sensitive field is not accepted",
        400
      );
    }
    if (isRecord(child)) assertNoSensitiveKeys(child);
  }
}

function isDvgLoginUrl(value: string): boolean {
  try {
    const url = new URL(value);
    const expected = new URL(DVG_LOGIN_URL);
    return (
      url.protocol === expected.protocol &&
      url.username === "" &&
      url.password === "" &&
      url.hostname === expected.hostname &&
      url.port === expected.port &&
      url.pathname === expected.pathname &&
      url.search === expected.search &&
      url.hash === ""
    );
  } catch {
    return false;
  }
}

function sanitizeLastKnownUrl(value: string | null): string | null {
  if (!value) return null;
  if (value.startsWith("/e-commerce/")) return value;
  try {
    const url = new URL(value);
    return url.hostname === "devecchigiuseppesrl.com" ? url.pathname : null;
  } catch {
    return null;
  }
}

function safeBuildDvgDetailUrl(article: string): string | null {
  try {
    return buildDvgDetailUrl(article).toString();
  } catch {
    return null;
  }
}

function isAllowedLocalWebOrigin(value: string): boolean {
  try {
    const url = new URL(value);
    return (
      url.protocol === "http:" &&
      url.port === "3000" &&
      (url.hostname === "localhost" ||
        url.hostname === "127.0.0.1" ||
        url.hostname === "::1" ||
        url.hostname === "[::1]")
    );
  } catch {
    return false;
  }
}

function stringHeader(value: string | string[] | undefined): string | null {
  if (Array.isArray(value)) return value[0] ?? null;
  return value ?? null;
}

function isLoopbackIp(value: string): boolean {
  return value === "127.0.0.1" || value === "::1" || value === "::ffff:127.0.0.1";
}

function optionalString(value: unknown, fallback: string | null, field: string): string | null {
  if (value === undefined || value === null || value === "") return fallback;
  if (typeof value !== "string") {
    throw new SupplierSessionsRouteError(
      "supplier_session_invalid_input",
      `${field} must be a string`,
      400
    );
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : fallback;
}

function optionalUuid(value: unknown, field: string): string | undefined {
  const text = optionalString(value, null, field);
  if (text === null) return undefined;
  validateUuid(text, field);
  return text;
}

function validateUuid(value: string, field: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new SupplierSessionsRouteError("invalid_uuid", `${field} must be a UUID`, 400);
  }
}

function optionalBoolean(value: unknown, fallback: boolean, field: string): boolean {
  if (value === undefined || value === null || value === "") return fallback;
  if (typeof value === "boolean") return value;
  throw new SupplierSessionsRouteError(
    "supplier_session_invalid_input",
    `${field} must be boolean`,
    400
  );
}

function boundedInteger(
  value: unknown,
  fallback: number,
  min: number,
  max: number,
  field: string
): number {
  if (value === undefined || value === null || value === "") return fallback;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new SupplierSessionsRouteError(
      "supplier_session_invalid_input",
      `${field} must be an integer between ${min} and ${max}`,
      400
    );
  }
  return parsed;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function sanitizeSupplierSessionPayload<T>(value: T): T {
  return scrubSupplierSessionPayload(value);
}

export function scrubSupplierSessionPayload<T>(value: T): T {
  if (Array.isArray(value)) return value.map((item) => scrubSupplierSessionPayload(item)) as T;
  if (typeof value === "string") {
    return (isSensitiveStringValue(value) ? "[redacted]" : value) as T;
  }
  if (!isRecord(value)) return value;
  const sanitized: Record<string, unknown> = {};
  for (const [key, child] of Object.entries(value)) {
    if (isSensitiveSupplierSessionKey(key)) continue;
    sanitized[key] = scrubSupplierSessionPayload(child);
  }
  return sanitized as T;
}

function isSensitiveSupplierSessionKey(key: string): boolean {
  const normalized = key.replace(/[^a-z0-9]/gi, "").toLowerCase();
  return sensitiveSupplierSessionKeys.has(normalized);
}

function isSensitiveStringValue(value: string): boolean {
  const trimmed = value.trim();
  if (/[A-Za-z]:[\\/][^\s"']+/.test(trimmed)) return true;
  if (/\\\\[^\\/\s"']+[\\/][^\s"']+/.test(trimmed)) return true;
  return /(^|\s)\/(?:Users|home|root|tmp|var|private|opt|mnt|Volumes)\/[^\s"']+/.test(trimmed);
}

const sensitiveSupplierSessionKeys = new Set([
  "authorization",
  "bearer",
  "cookie",
  "cookies",
  "credential",
  "credentials",
  "har",
  "html",
  "localstorage",
  "mhtml",
  "password",
  "profiledir",
  "profilepath",
  "profilerootdir",
  "rawhtml",
  "screenshot",
  "secret",
  "session",
  "sessionstorage",
  "setcookie",
  "storageState".toLowerCase(),
  "token",
  "trace",
  "userdatadir",
]);

function uniqueCodes(values: Array<string | null | undefined>): string[] {
  return Array.from(
    new Set(values.filter((value): value is string => Boolean(value)).map(sanitizeCode))
  ).sort();
}

function sanitizeCode(value: string): string {
  return value.replace(/[^A-Za-z0-9._:-]/g, "_").slice(0, 120) || "supplier_session_warning";
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof SupplierSessionsRouteError) {
    return reply.code(error.statusCode).send({
      error: {
        code: error.code,
        operatorCode: normalizeOperatorErrorCode(error.code),
        message: sanitizeErrorMessage(error.message),
      },
    });
  }
  if (error instanceof SupplierBrowserRuntimeError) {
    return reply.code(400).send({
      error: {
        code: error.code,
        operatorCode: normalizeOperatorErrorCode(error.code),
        message: sanitizeErrorMessage(error.message),
      },
    });
  }
  if (error instanceof SupplierSnapshotValidationError) {
    return reply.code(error.httpStatus).send({
      error: {
        code: error.code,
        operatorCode: normalizeOperatorErrorCode(error.code),
        message: sanitizeErrorMessage(error.message),
      },
    });
  }
  if (error instanceof SupplierSnapshotDatabaseError) {
    return reply.code(503).send({
      error: {
        code: "database_unavailable",
        operatorCode: "database_unavailable",
        message: sanitizeErrorMessage(error.message),
      },
    });
  }
  return reply.code(500).send({
    error: {
      code: "supplier_session_failed",
      operatorCode: "api_unavailable",
      message: "Supplier browser session failed",
    },
  });
}

function sanitizeErrorMessage(message: string): string {
  return isSensitiveStringValue(message) ? "Sensitive error detail redacted" : message;
}

function normalizeOperatorErrorCode(code: string): OperatorErrorCode | null {
  const direct: Partial<Record<string, OperatorErrorCode>> = {
    database_unavailable: "database_unavailable",
    supplier_session_not_open: "session_not_open",
    dvg_session_not_open: "session_not_open",
    supplier_session_stale: "session_not_open",
    supplier_session_not_authenticated: "session_not_authenticated",
    dvg_session_not_authenticated: "session_not_authenticated",
    dvg_detail_redirected_to_login: "supplier_login_required",
    dvg_login_required: "supplier_login_required",
    supplier_session_safety_blocked: "state_change_risk",
    dvg_session_safety_blocked: "state_change_risk",
    supplier_session_local_only: "unsafe_domain",
    supplier_session_origin_forbidden: "unsafe_domain",
    unsupported_supplier_session_login_url: "unsafe_url",
    mapping_not_found: "mapping_not_found",
    mapping_disabled: "mapping_disabled",
    mapping_supplier_mismatch: "mapping_supplier_mismatch",
    mapping_review_required: "mapping_not_trusted",
    snapshot_gate_blocked: "snapshot_gate_blocked",
    dvg_price_not_found: "price_missing",
    invalid_price: "price_missing",
    currency_not_eur: "currency_not_eur",
    sensitive_field: "sensitive_output_blocked",
    profile_reset_failed: "profile_reset_failed",
  };
  if (direct[code]) return direct[code] ?? null;
  if (/unsafe.*method|method.*forbidden/i.test(code)) return "unsafe_method";
  if (/unsafe.*url|url.*forbidden/i.test(code)) return "unsafe_url";
  return null;
}

class SupplierSessionsRouteError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode: number
  ) {
    super(message);
    this.name = "SupplierSessionsRouteError";
  }
}
