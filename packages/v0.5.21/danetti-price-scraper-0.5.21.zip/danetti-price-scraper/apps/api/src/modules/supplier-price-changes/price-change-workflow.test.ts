import assert from "node:assert/strict";
import Fastify from "fastify";
import { registerSupplierPriceChangeRoutes } from "./supplier-price-changes.routes.js";
import type {
  PriceChangeReview,
  SupplierPriceChangeSnapshotRow,
  ImportedPriceCorrection,
} from "./supplier-price-changes.repository.js";

let woo = 7620;
const rows: SupplierPriceChangeSnapshotRow[] = [];
const reviews = new Map<string, PriceChangeReview>();
let proofs: ImportedPriceCorrection[] = [];
function observe(price: number, day: number, capturedWoo?: number) {
  rows.push({
    snapshotId: `observation-${day}`,
    supplierId: "supplier",
    supplierName: "DVG",
    supplierMappingId: "mapping",
    catalogProductId: "product",
    sku: "TEST",
    productName: "Fixture",
    supplierArticleNumber: "ARTICLE",
    priceNetEur: price,
    observedAt: new Date(`2026-01-${String(day).padStart(2, "0")}T12:00:00Z`),
    createdAt: new Date(`2026-01-${String(day).padStart(2, "0")}T12:00:00Z`),
    currentPrice: woo,
    salePrice: null,
    regularPrice: null,
    observedWooGrossHuf: capturedWoo,
  });
}
const server = Fastify();
await registerSupplierPriceChangeRoutes(server, {
  repository: {
    getLatestEurHufRate: async () => 400,
    findImportedPriceCorrections: async () => proofs,
    listRecentCatalogSnapshots: async () => rows.map((row) => ({ ...row, currentPrice: woo })),
    ensureReviews: async (inputs) =>
      inputs.map((input) => {
        if (!reviews.has(input.eventId)) reviews.set(input.eventId, structuredClone(input));
        return reviews.get(input.eventId)!;
      }),
    decideReview: async (id, decision, now) => {
      const review = reviews.get(id);
      if (!review) return false;
      review.decision = decision;
      review.decidedAt = now;
      return true;
    },
  },
});
const read = async (query = "") => {
  const response = await server.inject(`/supplier-price-changes?${query}`);
  assert.equal(response.statusCode, 200, response.body);
  return response.json();
};
const decide = async (
  eventId: string,
  decision: string,
  headers: Record<string, string> = { "x-danetti-local-lab": "true" }
) =>
  server.inject({
    method: "POST",
    url: "/supplier-price-changes/review",
    headers,
    payload: { eventId, decision },
  });
try {
  observe(4, 1, 7620);
  observe(5, 2, 7620);
  const first = (await read()).items[0];
  assert.equal(first.changeObservedAt, "2026-01-02T12:00:00.000Z");
  assert.equal(first.baselineSource, "observation");
  assert.equal((await read("view=latest")).total, 1);
  observe(5, 3, 7620);
  assert.equal(
    (await read()).items[0].eventId,
    first.eventId,
    "unchanged fetch retains event identity and pending work"
  );
  assert.equal(
    (await read("view=latest")).total,
    0,
    "equal latest successful checks hide old event only in latest view"
  );
  woo = 9600;
  const corrected = (await read()).items[0];
  assert.equal(corrected.reviewStatus, "price_updated");
  assert.equal(
    corrected.suggestedGrossPriceRoundedHuf,
    first.suggestedGrossPriceRoundedHuf,
    "catalog correction must not move recommendation baseline"
  );
  assert.equal(corrected.currentWooPriceHuf, 9600);
  assert.equal((await decide(first.eventId, "resolved", {})).statusCode, 403);
  assert.equal(
    (
      await decide(first.eventId, "resolved", {
        "x-danetti-local-lab": "true",
        origin: "https://foreign.example",
      })
    ).statusCode,
    403
  );
  assert.equal((await decide(first.eventId, "bad")).statusCode, 400);
  assert.equal((await decide(first.eventId, "resolved")).statusCode, 200);
  assert.equal((await read()).total, 0);
  observe(5, 4, 9600);
  assert.equal((await read()).total, 0, "unchanged fetch does not reopen resolved work");
  assert.equal((await read("view=all")).items[0].reviewStatus, "resolved");
  assert.equal((await decide(first.eventId, "open")).statusCode, 200);
  assert.equal((await read()).items[0].reviewStatus, "pending");
  observe(4, 5, 9600);
  const returned = (await read()).items[0];
  assert.notEqual(returned.eventId, first.eventId);
  assert.equal(returned.oldSupplierNetEur, 5);
  assert.equal(returned.newSupplierNetEur, 4);
  const history = await read("view=all");
  assert.equal(history.total, 2);
  assert.equal(history.items[1].reviewStatus, "superseded");
  assert.equal((await read("view=all&fromDate=2026-01-05&toDate=2026-01-05")).total, 1);
  for (const query of [
    "view=unknown",
    "fromDate=2026-02-31",
    "fromDate=2026-02-01&toDate=2026-01-01",
  ])
    assert.equal((await server.inject(`/supplier-price-changes?${query}`)).statusCode, 400);
  assert.equal((await decide("a".repeat(64), "resolved")).statusCode, 404);
  woo = 123;
  proofs = [
    {
      eventId: returned.eventId,
      priceHuf: 123,
      finishedAt: new Date("2026-10-19T12:00:00Z"),
      importRunId: "actual-completed-csv",
    },
  ];
  assert.equal(
    (await read()).total,
    0,
    "any changed imported price closes the current event, even far from the suggested price"
  );
  const imported = (await read("view=all")).items.find(
    (row: { eventId: string }) => row.eventId === returned.eventId
  );
  assert.equal(imported.reviewStatus, "resolved");
  assert.match(imported.reviewStatusLabel, /CSV/);
  await decide(returned.eventId, "open");
  assert.equal((await read()).total, 1, "same older CSV cannot close a reopened event");
  reviews.get(returned.eventId)!.baselineWooGrossHuf = 123.45;
  woo = 123.46;
  proofs = [{ ...proofs[0]!, priceHuf: 123.46, finishedAt: new Date(Date.now() + 1000) }];
  assert.equal(
    (await read()).total,
    0,
    "even a one-cent imported own-price correction closes without floating-point loss"
  );
} finally {
  await server.close();
}
console.log(
  "Price-change lifecycle, frozen baseline, correction detection, history and review guards passed"
);
