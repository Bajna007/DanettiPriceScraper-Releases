import assert from "node:assert/strict";
import { DVG_ALLOWED_DOMAIN, DVG_CONNECTOR_ID } from "@danetti/connectors";
import { InMemorySupplierCredentialStore } from "./supplier-credentials.store.js";
import {
  applyCredentialTestResult,
  assertCredentialConnectorSupported,
  createSupplierCredentialSecret,
  getSupplierCredentialStatus,
  inferCredentialConnectorId,
  maskUsername,
  resolveSupplierCredentialForDvg,
  sanitizeCredentialTestCode,
  validateSupplierCredentialSaveInput,
  type CredentialSupplier,
} from "./supplier-credentials.service.js";
import { SupplierCredentialError } from "./supplier-credentials.types.js";

const supplier: CredentialSupplier = {
  id: "11111111-1111-4111-8111-111111111111",
  code: DVG_CONNECTOR_ID,
  name: "DVG De Vecchi",
  baseUrl: "https://devecchigiuseppesrl.com",
  allowedDomains: [DVG_ALLOWED_DOMAIN],
};

const unsupportedSupplier: CredentialSupplier = {
  id: "22222222-2222-4222-8222-222222222222",
  code: "other-supplier",
  name: "Other Supplier",
  baseUrl: "https://other.example",
  allowedDomains: ["other.example"],
};

assert.equal(inferCredentialConnectorId(supplier), DVG_CONNECTOR_ID);
assert.equal(inferCredentialConnectorId(unsupportedSupplier), null);
assert.equal(assertCredentialConnectorSupported(supplier, DVG_CONNECTOR_ID), DVG_CONNECTOR_ID);
assert.throws(
  () => assertCredentialConnectorSupported(supplier, "dummy-supplier"),
  SupplierCredentialError
);
assert.throws(
  () => assertCredentialConnectorSupported(unsupportedSupplier, DVG_CONNECTOR_ID),
  SupplierCredentialError
);

assert.deepEqual(
  validateSupplierCredentialSaveInput({
    connectorId: DVG_CONNECTOR_ID,
    username: "stored-user",
    password: "stored-password",
  }),
  {
    connectorId: DVG_CONNECTOR_ID,
    kind: "username_password",
    username: "stored-user",
    password: "stored-password",
  }
);
assert.throws(
  () =>
    validateSupplierCredentialSaveInput({
      connectorId: DVG_CONNECTOR_ID,
      username: "stored-user",
      password: "stored-password",
      token: "not-allowed",
    }),
  SupplierCredentialError
);

assert.equal(maskUsername("ab"), "**");
assert.equal(maskUsername("stored-user"), "st***r");
assert.equal(maskUsername("user@example.test"), "u***@example.test");

const store = new InMemorySupplierCredentialStore();
const missingStatus = await getSupplierCredentialStatus({ supplier, store, env: {} });
assert.equal(missingStatus.configured, false);
assert.equal(missingStatus.source, "missing");
assert.equal(missingStatus.usernameDisplay, null);

const envStatus = await getSupplierCredentialStatus({
  supplier,
  store,
  env: { DVG_USERNAME: "env-user", DVG_PASSWORD: "env-password" },
});
assert.equal(envStatus.configured, true);
assert.equal(envStatus.source, "env");
assert.equal(envStatus.usernameDisplay, "en***r");

const secret = createSupplierCredentialSecret({
  supplierId: supplier.id,
  connectorId: DVG_CONNECTOR_ID,
  username: "stored-user",
  password: "stored-password",
  now: new Date("2026-05-07T00:00:00.000Z"),
});
await store.put(secret);

const storedStatus = await getSupplierCredentialStatus({
  supplier,
  store,
  env: { DVG_USERNAME: "env-user", DVG_PASSWORD: "env-password" },
});
assert.equal(storedStatus.configured, true);
assert.equal(storedStatus.source, "stored");
assert.equal(storedStatus.usernameDisplay, "st***r");
assert.equal(JSON.stringify(storedStatus).includes("stored-password"), false);

const resolved = await resolveSupplierCredentialForDvg({
  supplier,
  store,
  env: { DVG_USERNAME: "env-user", DVG_PASSWORD: "env-password" },
});
assert.equal(resolved.source, "stored");
assert.deepEqual(resolved.credentials, { username: "stored-user", password: "stored-password" });

const testedSecret = applyCredentialTestResult(secret, {
  status: "failed",
  code: "unexpected-network-detail",
});
assert.equal(testedSecret.lastTestStatus, "failed");
assert.equal(testedSecret.lastErrorCode, "credential_test_failed");
assert.equal(
  sanitizeCredentialTestCode("dvg_login_submit_no_effect"),
  "dvg_login_submit_no_effect"
);
assert.equal(sanitizeCredentialTestCode("dvg_login_post_not_sent"), "dvg_login_post_not_sent");

console.log("Supplier credential service tests passed");
