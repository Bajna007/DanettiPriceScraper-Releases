import { createDbClient, type DanettiDbClient, type ExchangeRate } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import {
  PricingSettingsRepository,
  type PricingSettingsRepositoryLike,
} from "./pricing-settings.repository.js";

interface PricingSettingsRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  repository?: PricingSettingsRepositoryLike;
  now?: () => Date;
}

export interface PricingSettingsCurrentResponse {
  eurHufRate: number | null;
  source: string | null;
  effectiveAt: string | null;
  createdAt: string | null;
  notes: string | null;
}

export async function registerPricingSettingsRoutes(
  server: FastifyInstance,
  options: PricingSettingsRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;
  const now = options.now ?? (() => new Date());

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getRepository(): PricingSettingsRepositoryLike {
    if (options.repository) return options.repository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new PricingSettingsRepository(dbClient.db);
    } catch (error) {
      throw new PricingSettingsRouteError(
        "database_unavailable",
        error instanceof Error ? error.message : "Database unavailable",
        503
      );
    }
  }

  server.get("/pricing-settings/current", async (_request, reply) => {
    try {
      const latest = await getRepository().getLatestExchangeRate();
      return exchangeRateResponse(latest);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/pricing-settings/exchange-rate", async (request, reply) => {
    try {
      assertNoSensitiveKeys(request.body);
      const input = isRecord(request.body) ? request.body : {};
      const rate = boundedNumber(input.eurHufRate, 100, 1000, "eurHufRate");
      const effectiveAt = readOptionalDate(input.effectiveAt, now(), "effectiveAt");
      const notes = readOptionalString(input.notes, "notes");
      const created = await getRepository().createExchangeRate({
        source: "manual_operator",
        eurHufRate: rate.toFixed(4),
        effectiveAt,
        createdBy: "local_operator",
        notes,
      });
      return reply.code(201).send(exchangeRateResponse(created));
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

export function exchangeRateResponse(rate: ExchangeRate | null): PricingSettingsCurrentResponse {
  return {
    eurHufRate: rate ? Number(rate.eurHufRate) : null,
    source: rate?.source ?? null,
    effectiveAt: rate?.effectiveAt.toISOString() ?? null,
    createdAt: rate?.createdAt.toISOString() ?? null,
    notes: rate?.notes ?? null,
  };
}

function assertNoSensitiveKeys(value: unknown): void {
  if (!isRecord(value)) return;
  for (const key of Object.keys(value)) {
    if (/password|credential|cookie|session|storageState|token|secret/i.test(key)) {
      throw new PricingSettingsRouteError(
        "sensitive_field",
        "Sensitive field is not accepted",
        400
      );
    }
  }
}

function boundedNumber(value: unknown, min: number, max: number, field: string): number {
  const parsed = Number(value);
  if (value === undefined || value === null || value === "" || !Number.isFinite(parsed)) {
    throw new PricingSettingsRouteError(
      "pricing_exchange_rate_required",
      `${field} is required`,
      400
    );
  }
  if (parsed < min || parsed > max) {
    throw new PricingSettingsRouteError(
      "pricing_exchange_rate_invalid",
      `${field} must be a number between ${min} and ${max}`,
      400
    );
  }
  return parsed;
}

function readOptionalDate(value: unknown, defaultValue: Date, field: string): Date {
  if (value === undefined || value === null || value === "") return defaultValue;
  if (typeof value !== "string") {
    throw new PricingSettingsRouteError(
      "invalid_field",
      `${field} must be an ISO date string`,
      400
    );
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    throw new PricingSettingsRouteError(
      "invalid_field",
      `${field} must be an ISO date string`,
      400
    );
  }
  return date;
}

function readOptionalString(value: unknown, field: string): string | null {
  if (value === undefined || value === null) return null;
  if (typeof value !== "string") {
    throw new PricingSettingsRouteError("invalid_field", `${field} must be a string`, 400);
  }
  const trimmed = value.trim();
  return trimmed ? trimmed : null;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

class PricingSettingsRouteError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus: number
  ) {
    super(message);
    this.name = "PricingSettingsRouteError";
  }
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof PricingSettingsRouteError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  return reply
    .code(500)
    .send({ error: { code: "internal_error", message: "Unexpected pricing settings API error" } });
}
