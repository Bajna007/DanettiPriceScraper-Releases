import type { NewSupplier, SupplierCheckSettings } from "@danetti/db";
import {
  type CreateSupplierInput,
  type LookupStrategy,
  type SupplierCheckSettingsUpdateRecord,
  SupplierValidationError,
  type UpdateSupplierCheckSettingsInput,
  type UpdateSupplierInput,
} from "./suppliers.types.js";

const LOOKUP_STRATEGIES: LookupStrategy[] = [
  "search_result",
  "search_then_detail",
  "direct_url",
  "export_file",
  "network_response",
];

const SENSITIVE_KEY_PATTERN = /(credential|password|secret|token|cookie|session|storageState)/i;
const SUPPLIER_CODE_PATTERN = /^[a-z0-9_-]+$/;
const DOMAIN_PATTERN = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i;

export function validateCreateSupplierInput(input: unknown): NewSupplier {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  const code = readRequiredString(record, "code");
  const name = readRequiredString(record, "name");

  if (!SUPPLIER_CODE_PATTERN.test(code)) {
    throw new SupplierValidationError(
      "invalid_code",
      "Supplier code must use lowercase letters, numbers, dash or underscore"
    );
  }

  return {
    code,
    name,
    baseUrl: readOptionalBaseUrl(record, "baseUrl"),
    enabled: readOptionalBoolean(record, "enabled") ?? true,
    allowedDomains: readOptionalDomainArray(record, "allowedDomains") ?? [],
    supportedLookupStrategies: readLookupStrategies(record) ?? ["search_result"],
    defaultRateLimitPerMinute:
      readOptionalPositiveInteger(record, "defaultRateLimitPerMinute") ?? 6,
    healthStatus: "unknown",
  };
}

export function validateUpdateSupplierInput(input: unknown): Partial<NewSupplier> {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  const update: Partial<NewSupplier> = { updatedAt: new Date() };

  if ("name" in record) update.name = readRequiredString(record, "name");
  if ("baseUrl" in record) update.baseUrl = readOptionalBaseUrl(record, "baseUrl");
  if ("enabled" in record) update.enabled = readRequiredBoolean(record, "enabled");
  if ("allowedDomains" in record) {
    update.allowedDomains = readOptionalDomainArray(record, "allowedDomains") ?? [];
  }
  if ("supportedLookupStrategies" in record) {
    update.supportedLookupStrategies = readLookupStrategies(record) ?? ["search_result"];
  }
  if ("defaultRateLimitPerMinute" in record) {
    update.defaultRateLimitPerMinute =
      readOptionalPositiveInteger(record, "defaultRateLimitPerMinute") ?? 6;
  }

  return update;
}

export function validateUpdateSupplierCheckSettingsInput(
  input: unknown
): SupplierCheckSettingsUpdateRecord {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  const update: SupplierCheckSettingsUpdateRecord = { updatedAt: new Date() };

  if ("productsPerMinute" in record) {
    update.productsPerMinute = readIntegerInRange(record, "productsPerMinute", 1, 60);
  }
  if ("delayBetweenProductsSeconds" in record) {
    update.delayBetweenProductsSeconds = readIntegerInRange(
      record,
      "delayBetweenProductsSeconds",
      0,
      3_600
    );
  }
  if ("jitterMinSeconds" in record) {
    update.jitterMinSeconds = readIntegerInRange(record, "jitterMinSeconds", 0, 3_600);
  }
  if ("jitterMaxSeconds" in record) {
    update.jitterMaxSeconds = readIntegerInRange(record, "jitterMaxSeconds", 0, 3_600);
  }
  if ("maxRetriesPerItem" in record) {
    update.maxRetriesPerItem = readIntegerInRange(record, "maxRetriesPerItem", 0, 10);
  }
  if ("navigationTimeoutSeconds" in record) {
    update.navigationTimeoutSeconds = readIntegerInRange(
      record,
      "navigationTimeoutSeconds",
      1,
      600
    );
  }
  if ("itemTimeoutSeconds" in record) {
    update.itemTimeoutSeconds = readIntegerInRange(record, "itemTimeoutSeconds", 1, 600);
  }
  if ("stopAfterConsecutiveFailures" in record) {
    update.stopAfterConsecutiveFailures = readIntegerInRange(
      record,
      "stopAfterConsecutiveFailures",
      1,
      100
    );
  }
  if ("stopOnSafetyEvent" in record) {
    update.stopOnSafetyEvent = readRequiredBoolean(record, "stopOnSafetyEvent");
  }
  if ("stopOnCartChange" in record) {
    update.stopOnCartChange = readRequiredBoolean(record, "stopOnCartChange");
  }
  if ("enabled" in record) update.enabled = readRequiredBoolean(record, "enabled");

  if (
    update.jitterMinSeconds !== undefined &&
    update.jitterMaxSeconds !== undefined &&
    update.jitterMinSeconds > update.jitterMaxSeconds
  ) {
    throw new SupplierValidationError(
      "invalid_jitter_range",
      "jitterMinSeconds must be less than or equal to jitterMaxSeconds"
    );
  }

  return update;
}

export function assertValidSupplierCheckSettingsMerge(
  current: SupplierCheckSettings,
  update: UpdateSupplierCheckSettingsInput
): void {
  const jitterMin = update.jitterMinSeconds ?? current.jitterMinSeconds;
  const jitterMax = update.jitterMaxSeconds ?? current.jitterMaxSeconds;

  if (jitterMin > jitterMax) {
    throw new SupplierValidationError(
      "invalid_jitter_range",
      "jitterMinSeconds must be less than or equal to jitterMaxSeconds"
    );
  }
}

export function assertNoSensitiveFields(input: unknown): void {
  if (input === null || typeof input !== "object") return;

  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (SENSITIVE_KEY_PATTERN.test(key)) {
      throw new SupplierValidationError(
        "sensitive_field",
        `Sensitive field is not allowed: ${key}`
      );
    }
    assertNoSensitiveFields(value);
  }
}

function asRecord(input: unknown): Record<string, unknown> {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    throw new SupplierValidationError("invalid_body", "Request body must be an object");
  }
  return input as Record<string, unknown>;
}

function readRequiredString(record: Record<string, unknown>, key: string): string {
  const value = readOptionalString(record, key);
  if (value === null) {
    throw new SupplierValidationError("missing_field", `${key} is required`);
  }
  return value;
}

function readOptionalString(record: Record<string, unknown>, key: string): string | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "string") {
    throw new SupplierValidationError("invalid_field", `${key} must be a string`);
  }
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

function readRequiredBoolean(record: Record<string, unknown>, key: string): boolean {
  const value = record[key];
  if (typeof value !== "boolean") {
    throw new SupplierValidationError("invalid_field", `${key} must be a boolean`);
  }
  return value;
}

function readOptionalBoolean(record: Record<string, unknown>, key: string): boolean | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "boolean") {
    throw new SupplierValidationError("invalid_field", `${key} must be a boolean`);
  }
  return value;
}

function readOptionalStringArray(record: Record<string, unknown>, key: string): string[] | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (!Array.isArray(value)) {
    throw new SupplierValidationError("invalid_field", `${key} must be an array`);
  }
  return value
    .map((item) => {
      if (typeof item !== "string") {
        throw new SupplierValidationError("invalid_field", `${key} must contain strings`);
      }
      return item.trim();
    })
    .filter(Boolean);
}

function readOptionalBaseUrl(record: Record<string, unknown>, key: string): string | null {
  const value = readOptionalString(record, key);
  if (value === null) return null;

  try {
    const url = new URL(value);
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      throw new Error("Unsupported supplier URL protocol");
    }
    if (!isAllowedDomainValue(url.hostname)) {
      throw new Error("Invalid supplier URL hostname");
    }
    return url.toString().replace(/\/$/, "");
  } catch {
    throw new SupplierValidationError(
      "invalid_base_url",
      `${key} must be a valid http or https URL`
    );
  }
}

function readOptionalDomainArray(record: Record<string, unknown>, key: string): string[] | null {
  const values = readOptionalStringArray(record, key);
  if (values === null) return null;

  return values.map((value) => normalizeAllowedDomain(value, key));
}

function normalizeAllowedDomain(value: string, key: string): string {
  const normalized = value.trim().toLowerCase();
  if (!isAllowedDomainValue(normalized)) {
    throw new SupplierValidationError(
      "invalid_allowed_domain",
      `${key} contains invalid domain: ${value}`
    );
  }
  return normalized;
}

function isAllowedDomainValue(value: string): boolean {
  if (!value || value.includes("://") || /[\s/:?#\\]/.test(value)) return false;
  return value === "localhost" || DOMAIN_PATTERN.test(value);
}

function readLookupStrategies(record: Record<string, unknown>): LookupStrategy[] | null {
  const values = readOptionalStringArray(record, "supportedLookupStrategies");
  if (values === null) return null;

  for (const value of values) {
    if (!LOOKUP_STRATEGIES.includes(value as LookupStrategy)) {
      throw new SupplierValidationError(
        "invalid_lookup_strategy",
        `Invalid lookup strategy: ${value}`
      );
    }
  }

  return values as LookupStrategy[];
}

function readOptionalPositiveInteger(record: Record<string, unknown>, key: string): number | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "number" || !Number.isInteger(value) || value <= 0) {
    throw new SupplierValidationError("invalid_field", `${key} must be a positive integer`);
  }
  return value;
}

function readIntegerInRange(
  record: Record<string, unknown>,
  key: string,
  minValue: number,
  maxValue: number
): number {
  const value = record[key];
  if (
    typeof value !== "number" ||
    !Number.isInteger(value) ||
    value < minValue ||
    value > maxValue
  ) {
    throw new SupplierValidationError(
      "invalid_field",
      `${key} must be an integer between ${minValue} and ${maxValue}`
    );
  }
  return value;
}
