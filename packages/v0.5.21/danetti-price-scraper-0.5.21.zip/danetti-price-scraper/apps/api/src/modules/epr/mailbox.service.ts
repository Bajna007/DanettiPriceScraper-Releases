import { ImapFlow } from "imapflow";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import {
  mailboxAccounts,
  mailboxFolders,
  mailboxMessages,
  type DanettiDbClient,
} from "@danetti/db";
import type { SecretStore } from "../../security/secret-store.js";
import { EprError } from "./epr.errors.js";
import { discoverySignals } from "./epr.domain.js";

export const mailboxSchema = z
  .object({
    name: z.string().trim().min(1).max(100),
    host: z
      .string()
      .trim()
      .min(1)
      .max(253)
      .regex(/^[a-zA-Z0-9.-]+$/),
    port: z.number().int().min(1).max(65535),
    security: z.enum(["STARTTLS", "TLS"]),
    folders: z.array(z.string().min(1).max(500)).min(1).max(50).default(["INBOX"]),
    username: z.string().min(1).max(500),
    password: z.string().min(1).max(1500),
    enabled: z.boolean().default(true),
  })
  .strict();
type Mailbox = typeof mailboxAccounts.$inferSelect;
type MailboxCredential = { username: string; password: string };
const secretKey = (id: string) => `DanettiPriceScraper:mailbox:${id}`;
export function imapOptions(
  mailbox: Pick<Mailbox, "host" | "port" | "security">,
  auth: MailboxCredential
) {
  return {
    host: mailbox.host,
    port: mailbox.port,
    secure: mailbox.security === "TLS",
    doSTARTTLS: mailbox.security === "STARTTLS" ? true : undefined,
    auth: { user: auth.username, pass: auth.password },
    tls: { rejectUnauthorized: true, minVersion: "TLSv1.2" as const },
    logger: false as const,
    logRaw: false,
    disableAutoIdle: true,
    connectionTimeout: 15_000,
    greetingTimeout: 15_000,
    socketTimeout: 30_000,
  };
}
export function mailboxError(error: unknown): EprError {
  const code = (error as { code?: string })?.code ?? "";
  if (/CERT|TLS|SELF_SIGNED|UNABLE_TO_VERIFY|DEPTH_ZERO/.test(code))
    return new EprError("mailbox_tls_certificate_invalid", 502);
  if ((error as { tlsFailed?: boolean })?.tlsFailed)
    return new EprError("mailbox_starttls_required", 502);
  if ((error as { authenticationFailed?: boolean })?.authenticationFailed)
    return new EprError("mailbox_auth_failed", 401);
  if (/STARTTLS|ESECURE/.test(code)) return new EprError("mailbox_starttls_required", 502);
  return new EprError("mailbox_connection_failed", 502);
}
export class MailboxService {
  constructor(
    private readonly client: DanettiDbClient,
    private readonly secrets: SecretStore,
    private readonly factory = (options: ReturnType<typeof imapOptions>) => new ImapFlow(options)
  ) {}
  async list() {
    return this.client.db.select().from(mailboxAccounts);
  }
  async save(input: unknown, id?: string) {
    const parsed = mailboxSchema.safeParse(input);
    if (!parsed.success) throw new EprError("mailbox_configuration_invalid");
    const { username, password, ...values } = parsed.data;
    const maskedIdentity = `${username[0]}***${username.includes("@") ? username.slice(username.indexOf("@")) : ""}`;
    if (id) {
      const [old] = await this.client.db
        .select()
        .from(mailboxAccounts)
        .where(eq(mailboxAccounts.id, id));
      if (!old) throw new EprError("mailbox_not_found", 404);
      // A new server/account gets a new source identity; old message identities remain historical.
      const oldSecret = await this.secrets.get(secretKey(id));
      if (
        old.host !== values.host ||
        !oldSecret ||
        (JSON.parse(oldSecret) as MailboxCredential).username !== username
      )
        throw new EprError("mailbox_identity_change_requires_new_account", 409);
      await this.secrets.put(secretKey(id), JSON.stringify({ username, password }));
      const [saved] = await this.client.db
        .update(mailboxAccounts)
        .set({ ...values, maskedIdentity, status: "not_tested" })
        .where(eq(mailboxAccounts.id, id))
        .returning();
      return saved;
    }
    const { randomUUID } = await import("node:crypto");
    const newId = randomUUID();
    await this.secrets.put(secretKey(newId), JSON.stringify({ username, password }));
    try {
      const [saved] = await this.client.db
        .insert(mailboxAccounts)
        .values({ ...values, id: newId, maskedIdentity })
        .returning();
      return saved;
    } catch (error) {
      await this.secrets.delete(secretKey(newId));
      throw error;
    }
  }
  async remove(id: string) {
    await this.secrets.delete(secretKey(id));
    // Message rows deliberately have no cascading account FK: provenance survives disconnection.
    await this.client.db.delete(mailboxAccounts).where(eq(mailboxAccounts.id, id));
  }
  private async connect(mailbox: Mailbox) {
    const raw = await this.secrets.get(secretKey(mailbox.id));
    if (!raw) throw new EprError("mailbox_credentials_missing", 409);
    const auth = JSON.parse(raw) as MailboxCredential;
    const connection = this.factory(imapOptions(mailbox, auth));
    connection.on("error", () => undefined);
    try {
      await connection.connect();
      return connection;
    } catch (error) {
      connection.close();
      throw mailboxError(error);
    }
  }
  async test(id: string) {
    const [mailbox] = await this.client.db
      .select()
      .from(mailboxAccounts)
      .where(eq(mailboxAccounts.id, id));
    if (!mailbox) throw new EprError("mailbox_not_found", 404);
    let connection: ImapFlow | undefined;
    try {
      connection = await this.connect(mailbox);
      const folders = (await connection.list())
        .filter((f) => !f.flags.has("\\Noselect"))
        .map((f) => ({
          path: f.path,
          selected: mailbox.folders.includes(f.path),
          excludedByDefault:
            /\\(Trash|Junk)/i.test(f.specialUse ?? "") || /(^|\/)(trash|junk|spam)$/i.test(f.path),
        }));
      await this.client.db
        .update(mailboxAccounts)
        .set({ status: "ok", lastErrorCode: null })
        .where(eq(mailboxAccounts.id, id));
      return { success: true, folders };
    } catch (error) {
      const safe = error instanceof EprError ? error : mailboxError(error);
      await this.client.db
        .update(mailboxAccounts)
        .set({ status: "failed", lastErrorCode: safe.code })
        .where(eq(mailboxAccounts.id, id));
      throw safe;
    } finally {
      if (connection) await connection.logout().catch(() => connection?.close());
    }
  }
  async setFolders(id: string, folders: string[], enabled: boolean) {
    if (
      !folders.length ||
      folders.length > 50 ||
      folders.some((f) => typeof f !== "string" || !f || f.length > 500)
    )
      throw new EprError("mailbox_folder_invalid");
    const [saved] = await this.client.db
      .update(mailboxAccounts)
      .set({ folders, enabled })
      .where(eq(mailboxAccounts.id, id))
      .returning();
    return saved;
  }
  async scan(
    mailbox: Mailbox,
    onMessage: (
      messageId: string,
      source: Buffer,
      metadata: Record<string, unknown>
    ) => Promise<void>,
    progress: (count: number, checkpoint: Record<string, unknown>) => Promise<void>,
    onOversized?: (messageId: string, metadata: Record<string, unknown>) => Promise<void>
  ) {
    const connection = await this.connect(mailbox);
    const deadline = Date.now() + 20 * 60_000;
    try {
      for (const path of mailbox.folders) {
        const lock = await connection.getMailboxLock(path, { readOnly: true });
        try {
          if (!connection.mailbox) throw new EprError("mailbox_folder_unavailable");
          const uidValidity = String(connection.mailbox.uidValidity);
          await this.client.db
            .insert(mailboxFolders)
            .values({ mailboxId: mailbox.id, path, uidValidity })
            .onConflictDoNothing();
          const [folder] = await this.client.db
            .select()
            .from(mailboxFolders)
            .where(
              and(
                eq(mailboxFolders.mailboxId, mailbox.id),
                eq(mailboxFolders.path, path),
                eq(mailboxFolders.uidValidity, uidValidity)
              )
            );
          const lastUid = Number(connection.mailbox.uidNext) - 1;
          for (let firstUid = folder.lastUid + 1; firstUid <= lastUid; firstUid += 100) {
            if (Date.now() > deadline) throw new EprError("mailbox_scan_time_limit", 503);
            const endUid = Math.min(firstUid + 99, lastUid);
            const messages = await connection.fetchAll(
              `${firstUid}:${endUid}`,
              { uid: true, envelope: true, internalDate: true, size: true, bodyStructure: true },
              { uid: true }
            );
            for (const message of messages.sort((a, b) => a.uid - b.uid)) {
              const envelope = message.envelope;
              const metadata: Record<string, unknown> = {
                subject: envelope?.subject ?? "",
                from: envelope?.from?.map((f) => ({ name: f.name, address: f.address })),
                to: envelope?.to?.map((f) => ({ name: f.name, address: f.address })),
                headerDate:
                  envelope?.date instanceof Date
                    ? envelope.date.toISOString()
                    : (envelope?.date ?? null),
                attachmentNames: attachmentNames(message.bodyStructure),
              };
              const [old] = await this.client.db
                .select()
                .from(mailboxMessages)
                .where(
                  and(
                    eq(mailboxMessages.mailboxId, mailbox.id),
                    eq(mailboxMessages.folder, path),
                    eq(mailboxMessages.uidValidity, uidValidity),
                    eq(mailboxMessages.uid, message.uid)
                  )
                );
              const [stored] = old
                ? [old]
                : await this.client.db
                    .insert(mailboxMessages)
                    .values({
                      mailboxId: mailbox.id,
                      folder: path,
                      uidValidity,
                      uid: message.uid,
                      messageId: envelope?.messageId ?? null,
                      internalDate:
                        message.internalDate instanceof Date ? message.internalDate : null,
                      metadata,
                      status: "indexed",
                    })
                    .returning();
              if (
                stored.status === "indexed" &&
                discoverySignals(String(metadata.subject), metadata.attachmentNames as string[])
                  .length
              ) {
                if ((message.size ?? 0) > 30_000_000) {
                  await onOversized?.(stored.id, { ...metadata, size: message.size });
                  await this.client.db
                    .update(mailboxMessages)
                    .set({ status: "oversized_review" })
                    .where(eq(mailboxMessages.id, stored.id));
                } else {
                  const result = await connection.download(String(message.uid), undefined, {
                    uid: true,
                  });
                  if (!result.content) throw new EprError("mailbox_message_unavailable");
                  const chunks: Buffer[] = [];
                  let bytes = 0;
                  for await (const chunk of result.content) {
                    bytes += chunk.length;
                    if (bytes > 30_000_000) {
                      result.content.destroy();
                      throw new EprError("mailbox_message_too_large");
                    }
                    chunks.push(Buffer.from(chunk));
                  }
                  await onMessage(stored.id, Buffer.concat(chunks), metadata);
                  await this.client.db
                    .update(mailboxMessages)
                    .set({ status: "processed" })
                    .where(eq(mailboxMessages.id, stored.id));
                }
              }
              await this.client.db
                .update(mailboxFolders)
                .set({ lastUid: message.uid })
                .where(eq(mailboxFolders.id, folder.id));
              await progress(1, {
                mailboxId: mailbox.id,
                folder: path,
                uidValidity,
                uid: message.uid,
              });
            }
            await this.client.db
              .update(mailboxFolders)
              .set({ lastUid: endUid })
              .where(eq(mailboxFolders.id, folder.id));
          }
        } finally {
          lock.release();
        }
      }
      await this.client.db
        .update(mailboxAccounts)
        .set({ lastSyncAt: new Date(), status: "ok", lastErrorCode: null })
        .where(eq(mailboxAccounts.id, mailbox.id));
    } finally {
      await connection.logout().catch(() => connection.close());
    }
  }
}
function attachmentNames(node: unknown): string[] {
  if (!node || typeof node !== "object") return [];
  const item = node as {
    type?: string;
    dispositionParameters?: { filename?: string };
    parameters?: { name?: string };
    childNodes?: unknown[];
  };
  return [
    item.dispositionParameters?.filename,
    item.parameters?.name,
    item.type === "application/pdf" ? "attachment.pdf" : undefined,
    ...(item.childNodes ?? []).flatMap(attachmentNames),
  ].filter((v): v is string => typeof v === "string");
}
