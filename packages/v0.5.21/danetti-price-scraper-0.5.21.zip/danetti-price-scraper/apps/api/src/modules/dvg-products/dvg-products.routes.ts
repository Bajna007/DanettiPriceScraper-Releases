import { isSupplierRunTerminal } from "@danetti/shared";
import {
  DVG_MANUAL_BATCH_SPEED_PROFILES,
  DvgManualSessionBatchRunner,
  type DvgShopMode,
  type DvgManualBatchCallbacks,
  type DvgManualBatchCandidate,
  type DvgManualBatchEvent,
  type DvgManualBatchRunStatus,
  type DvgManualBatchSettings,
  type DvgManualBatchSpeedMode,
  type DvgManualBatchState,
} from "@danetti/connectors";
import { createDbClient, type DanettiDbClient } from "@danetti/db";
import { acquireDvgSession, releaseDvgSession } from "./dvg-session-lock.js";
import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import {
  canWriteDvgTrustedPricing,
  DvgProductsRepository,
  type DvgCatalogRunProgress,
  type DvgOperatorPreferences,
  type DvgProductsCandidateRepository,
} from "./dvg-products.repository.js";
import {
  PricingSettingsRepository,
  type PricingSettingsRepositoryLike,
} from "../pricing-settings/pricing-settings.repository.js";

interface DvgProductsRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  env?: Record<string, string | undefined>;
  repository?: DvgProductsCandidateRepository;
  pricingSettingsRepository?: PricingSettingsRepositoryLike;
  runnerFactory?: DvgManualBatchRunnerFactory;
  now?: () => Date;
}

interface DvgManualBatchRunnerLike {
  openBrowser(): Promise<void>;
  waitForManualLogin(timeoutMs?: number): Promise<boolean>;
  runCandidates(
    candidates: readonly DvgManualBatchCandidate[],
    settings: DvgManualBatchSettings
  ): Promise<void>;
  cancel(): Promise<void>;
  close(): Promise<void>;
}

type DvgManualBatchRunnerFactory = (
  callbacks: DvgManualBatchCallbacks,
  settings: DvgManualBatchSettings
) => DvgManualBatchRunnerLike;

interface RunParams {
  runId: string;
}

interface ValidatedStartInput {
  settings: DvgManualBatchSettings;
  manualLoginTimeoutMs: number;
}

interface DvgManualBatchRunRecord {
  state: DvgManualBatchState;
  runner: DvgManualBatchRunnerLike;
  repository: DvgProductsCandidateRepository;
  candidates: DvgManualBatchCandidate[];
  manualLoginTimeoutMs: number;
  promise: Promise<void> | null;
  rowPersistencePromises: Promise<void>[];
  statePersistencePromises: Promise<void>[];
}

type ManualBatchResumeAction =
  | "start_new"
  | "continue_after_login"
  | "retry_from_next_offset"
  | "login_again"
  | "wait_for_current_run";

interface ManualBatchResumeAdvice {
  canResume: boolean;
  action: ManualBatchResumeAction;
  runId: string | null;
  nextOffset: number | null;
  reason: string;
}

interface ManualBatchExportMetadata {
  available: boolean;
  format: "sanitized_rows_json";
  suggestedFilename: string | null;
  rowCount: number;
  totals: {
    checked: number;
    ok: number;
    failed: number;
    skipped: number;
    safetyStopped: number;
  };
  nextOffset: number | null;
  containsSecrets: false;
}

type DvgManualBatchStateResponse = DvgManualBatchState & {
  resume: ManualBatchResumeAdvice;
  export: ManualBatchExportMetadata;
};

type DvgManualBatchProgressResponse = DvgCatalogRunProgress & {
  resume: ManualBatchResumeAdvice;
  export: ManualBatchExportMetadata;
};

const DEFAULT_MANUAL_LOGIN_TIMEOUT_MS = 300_000;
const MAX_DVG_BATCH_ITEMS = 10_000;
const MAX_DVG_BATCH_OFFSET = 50_000;
const MAX_EVENTS = 300;
const DVG_LOCAL_LAB_HEADER = "x-danetti-local-lab";
const TERMINAL_STATUSES = new Set<DvgManualBatchRunStatus>([
  "login_timeout",
  "detached_session_failed",
  "completed",
  "cancelled",
  "security_stopped",
  "session_lost",
  "interrupted",
  "failed",
]);

export async function registerDvgProductsRoutes(
  server: FastifyInstance,
  options: DvgProductsRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;
  let activeRun: DvgManualBatchRunRecord | null = null;
  const env = options.env ?? process.env;
  const now = options.now ?? (() => new Date());
  const runnerFactory =
    options.runnerFactory ??
    ((callbacks, settings) =>
      new DvgManualSessionBatchRunner(callbacks, settings.shopMode ?? "legacy"));

  server.addHook("onClose", async () => {
    await activeRun?.runner.close().catch(() => undefined);
    if (activeRun) releaseDvgSession(activeRun.state.runId);
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getRepository(): DvgProductsCandidateRepository {
    if (options.repository) return options.repository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new DvgProductsRepository(dbClient.db);
    } catch (error) {
      throw new DvgProductsRouteError(
        "database_unavailable",
        error instanceof Error ? error.message : "Database unavailable",
        503
      );
    }
  }

  function getPricingSettingsRepository(): PricingSettingsRepositoryLike {
    if (options.pricingSettingsRepository) return options.pricingSettingsRepository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new PricingSettingsRepository(dbClient.db);
    } catch (error) {
      throw new DvgProductsRouteError(
        "database_unavailable",
        error instanceof Error ? error.message : "Database unavailable",
        503
      );
    }
  }

  server.post("/dvg-products/manual-batch/start", async (request, reply) => {
    let acquiredRunId: string | null = null;
    try {
      assertRouteAllowed(request, env);
      const input = await validateStartInput(request.body, async () => {
        const latest = await getPricingSettingsRepository().getLatestExchangeRate();
        return latest ? Number(latest.eurHufRate) : null;
      });
      if (activeRun && !isTerminalStatus(activeRun.state.status)) {
        throw new DvgProductsRouteError(
          "dvg_manual_batch_active",
          "DVG manual batch already active",
          409
        );
      }

      const repository = getRepository();
      const candidates = await repository.listCandidates(input.settings);
      if (candidates.length === 0) {
        throw new DvgProductsRouteError(
          "dvg_candidates_missing",
          "No DVG candidate product found",
          400
        );
      }

      const runId = `dvg-manual-${now().getTime()}`;
      if (!acquireDvgSession(runId))
        throw new DvgProductsRouteError(
          "dvg_manual_batch_active",
          "Another DVG check is using the browser",
          409
        );
      acquiredRunId = runId;
      const state = createInitialState(runId, input.settings, candidates.length, now());
      const rowPersistencePromises: Promise<void>[] = [];
      const statePersistencePromises: Promise<void>[] = [];
      let rowPersistenceChain = Promise.resolve();
      let statePersistenceChain = Promise.resolve();
      const queueRowPersistence = (row: DvgManualBatchState["rows"][number], rowNumber: number) => {
        const promise = rowPersistenceChain.then(() =>
          persistCatalogDvgRunRow(repository, state, row, state.settings.offset + rowNumber, now)
        );
        rowPersistenceChain = promise.catch(() => undefined);
        rowPersistencePromises.push(promise);
      };
      const queueStatePersistence = () => {
        const promise = statePersistenceChain.then(() =>
          persistDvgOperatorRunState(repository, state, now)
        );
        statePersistenceChain = promise.catch(() => undefined);
        statePersistencePromises.push(promise);
      };
      const callbacks = createStateCallbacks(
        state,
        now,
        queueRowPersistence,
        queueStatePersistence
      );
      const runner = runnerFactory(callbacks, input.settings);
      activeRun = {
        state,
        runner,
        repository,
        candidates,
        manualLoginTimeoutMs: input.manualLoginTimeoutMs,
        promise: null,
        rowPersistencePromises,
        statePersistencePromises,
      };
      callbacks.onEvent?.({ type: "runStarted", message: "DVG manual batch run created" });

      await runner.openBrowser();
      return reply.code(201).send(toDvgManualBatchStateResponse(state));
    } catch (error) {
      if (acquiredRunId) releaseDvgSession(acquiredRunId);
      if (activeRun && activeRun.state.status === "opening_browser") {
        setStatus(activeRun.state, "failed", now);
        const runtimeError = safeRuntimeError(error);
        addEvent(activeRun.state, now, {
          type: "runStopped",
          message: `DVG browser open failed: ${runtimeError.code}`,
        });
        activeRun.statePersistencePromises.push(
          persistDvgOperatorRunState(activeRun.repository, activeRun.state, now)
        );
        await activeRun.runner.close().catch(() => undefined);
        return reply
          .code(runtimeError.httpStatus)
          .send({ error: { code: runtimeError.code, message: runtimeError.message } });
      }
      return handleRouteError(reply, error);
    }
  });

  server.get("/dvg-products/manual-batch/current", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      return { run: activeRun ? toDvgManualBatchStateResponse(activeRun.state) : null };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/dvg-products/manual-batch/progress", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const repository = getRepository();
      const modeValue = (request.query as Record<string, unknown>)?.shopMode;
      if (modeValue !== undefined) {
        const mode = readDvgShopMode(modeValue);
        const saved = await repository.getLatestDvgOperatorRunState?.(mode);
        const run =
          activeRun && (activeRun.state.settings.shopMode ?? "legacy") === mode
            ? activeRun.state
            : saved;
        const progress = run
          ? {
              runId: run.runId,
              ...run.totals,
              nextOffset: getDvgStateNextOffset(run),
              updatedAt: run.completedAt ?? run.startedAt,
            }
          : null;
        return { progress: progress ? toDvgManualBatchProgressResponse(progress) : null };
      }
      const progress = (await repository.getLatestDvgRunProgress?.()) ?? null;
      return { progress: progress ? toDvgManualBatchProgressResponse(progress) : null };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/dvg-products/manual-batch/saved-state", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const repository = getRepository();
      const modeValue = (request.query as Record<string, unknown>)?.shopMode;
      const mode = modeValue === undefined ? undefined : readDvgShopMode(modeValue);
      const [run, preferences] = await Promise.all([
        repository.getLatestDvgOperatorRunState?.(mode) ?? Promise.resolve(null),
        repository.getDvgOperatorPreferences?.() ?? Promise.resolve(null),
      ]);
      const normalizedRun = run ? normalizeSavedDvgOperatorRunState(run, now) : null;
      if (run && normalizedRun && run.status !== normalizedRun.status) {
        await repository.saveDvgOperatorRunState?.(normalizedRun, now()).catch(() => undefined);
      }
      return {
        run: normalizedRun ? toDvgManualBatchStateResponse(normalizedRun) : null,
        preferences: preferences ?? defaultDvgOperatorPreferences(),
      };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/dvg-products/manual-batch/preferences", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const preferences = await getRepository().getDvgOperatorPreferences?.();
      return { preferences: preferences ?? defaultDvgOperatorPreferences() };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.put("/dvg-products/manual-batch/preferences", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const preferences = validateOperatorPreferences(request.body);
      await getRepository().saveDvgOperatorPreferences?.(preferences, now());
      return { preferences };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/dvg-products/manual-batch/:runId/continue-after-login", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const record = getRunRecord(activeRun, request.params);
      if (isTerminalStatus(record.state.status)) return toDvgManualBatchStateResponse(record.state);
      if (record.promise === null) {
        record.promise = runManualBatch(record, now);
      }
      return reply.code(202).send(toDvgManualBatchStateResponse(record.state));
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/dvg-products/manual-batch/:runId", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      return toDvgManualBatchStateResponse(getRunRecord(activeRun, request.params).state);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/dvg-products/manual-batch/:runId/cancel", async (request, reply) => {
    try {
      assertRouteAllowed(request, env);
      const record = getRunRecord(activeRun, request.params);
      await record.runner.cancel();
      releaseDvgSession(record.state.runId);
      setStatus(record.state, "cancelled", now);
      addEvent(record.state, now, { type: "runStopped", message: "Run cancelled" });
      return toDvgManualBatchStateResponse(record.state);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

async function runManualBatch(record: DvgManualBatchRunRecord, now: () => Date): Promise<void> {
  try {
    const loginOk = await record.runner.waitForManualLogin(record.manualLoginTimeoutMs);
    if (!loginOk) {
      if (!isTerminalStatus(record.state.status)) {
        setStatus(record.state, "login_timeout", now);
        addEvent(record.state, now, { type: "runStopped", message: "Manual login timeout" });
      }
      return;
    }

    await record.runner.runCandidates(record.candidates, record.state.settings);
  } catch (error) {
    if (!isTerminalStatus(record.state.status)) {
      setStatus(record.state, "failed", now);
      addEvent(record.state, now, {
        type: "runStopped",
        message: `Run failed: ${sanitizeCode(error instanceof Error ? error.name : "dvg_manual_batch_failed")}`,
      });
    }
  } finally {
    if (isTerminalStatus(record.state.status) && record.state.completedAt === null) {
      record.state.completedAt = now().toISOString();
    }
    await record.runner.close().catch(() => undefined);
    releaseDvgSession(record.state.runId);
    await Promise.all(record.rowPersistencePromises);
    record.statePersistencePromises.push(
      persistDvgOperatorRunState(record.repository, record.state, now)
    );
    await Promise.all(record.statePersistencePromises);
    if (!record.repository.saveCatalogProductDvgRunRow) {
      await persistCatalogDvgPricing(record, now);
    }
  }
}

async function persistCatalogDvgRunRow(
  repository: DvgProductsCandidateRepository,
  state: DvgManualBatchState,
  row: DvgManualBatchState["rows"][number],
  globalIndex: number,
  now: () => Date
): Promise<void> {
  if (!repository.saveCatalogProductDvgRunRow) return;
  try {
    const result = await repository.saveCatalogProductDvgRunRow(row, {
      runId: state.runId,
      globalIndex,
      observedAt: now(),
      settings: state.settings,
    });
    if (result.pricingSaved) {
      addEvent(state, now, {
        type: "calculationDone",
        message: `Catalog DVG pricing saved: ${row.wooSku}`,
      });
    }
  } catch (error) {
    addEvent(state, now, {
      type: "runStopped",
      message: `Catalog DVG progress save failed: ${sanitizeCode(
        error instanceof Error ? error.name : "dvg_catalog_progress_save_failed"
      )}`,
    });
  }
}

async function persistDvgOperatorRunState(
  repository: DvgProductsCandidateRepository,
  state: DvgManualBatchState,
  now: () => Date
): Promise<void> {
  await repository.saveDvgOperatorRunState?.(cloneState(state), now()).catch(() => undefined);
}

async function persistCatalogDvgPricing(
  record: DvgManualBatchRunRecord,
  now: () => Date
): Promise<void> {
  if (!canWriteDvgTrustedPricing(record.state.settings)) return;

  try {
    const updatedCount = await record.repository.updateCatalogProductDvgPricing?.(
      record.state.rows,
      now(),
      record.state.settings
    );
    if (updatedCount && updatedCount > 0) {
      addEvent(record.state, now, {
        type: "calculationDone",
        message: `Catalog DVG pricing saved: ${updatedCount}`,
      });
    }
  } catch (error) {
    addEvent(record.state, now, {
      type: "runStopped",
      message: `Catalog DVG pricing save failed: ${sanitizeCode(
        error instanceof Error ? error.name : "dvg_catalog_pricing_save_failed"
      )}`,
    });
  }
}

function createInitialState(
  runId: string,
  settings: DvgManualBatchSettings,
  candidateCount: number,
  startedAt: Date
): DvgManualBatchState {
  return {
    runId,
    status: "not_started",
    startedAt: startedAt.toISOString(),
    completedAt: null,
    settings,
    currentItem: null,
    totals: {
      candidates: candidateCount,
      checked: 0,
      ok: 0,
      failed: 0,
      skipped: 0,
      safetyStopped: 0,
    },
    telemetry: createInitialTelemetry(startedAt),
    summary: createRunSummary([], candidateCount),
    events: [],
    rows: [],
  };
}

function createInitialTelemetry(startedAt: Date): NonNullable<DvgManualBatchState["telemetry"]> {
  return {
    statusChangedAt: startedAt.toISOString(),
    lastEventAt: null,
    durationMs: 0,
    detailFetchStarted: 0,
    detailFetchCompleted: 0,
    avgDetailFetchMs: null,
    p95DetailFetchMs: null,
    itemsPerMinute: null,
    estimatedRemainingMinutes: null,
    httpStatus2xx: 0,
    httpStatus4xx: 0,
    httpStatus5xx: 0,
    httpStatusOther: 0,
    itemTimeouts: 0,
    sessionLostEvents: 0,
    sessionRecoveries: 0,
    rateLimitWaits: 0,
  };
}

function refreshRunDerivedData(state: DvgManualBatchState, now?: () => Date): void {
  state.summary = createRunSummary(state.rows, state.totals.candidates);
  state.telemetry = createRunTelemetry(state, now);
}

function createRunSummary(
  rows: readonly DvgManualBatchState["rows"][number][],
  candidateCount: number
): NonNullable<DvgManualBatchState["summary"]> {
  const checked = rows.length;
  const ok = rows.filter((row) => row.status === "ok").length;
  const failed = rows.filter(
    (row) => row.status !== "ok" && !row.status.startsWith("skipped_")
  ).length;
  const pricedRows = rows.filter(
    (row) => row.actualProfitNetHuf !== null && row.actualProfitPercentOnCost !== null
  );
  const totalProfitNetHuf =
    pricedRows.length === 0
      ? null
      : pricedRows.reduce((sum, row) => sum + (row.actualProfitNetHuf ?? 0), 0);
  const averageProfitPercent =
    pricedRows.length === 0
      ? null
      : pricedRows.reduce((sum, row) => sum + (row.actualProfitPercentOnCost ?? 0), 0) /
        pricedRows.length;

  return {
    checkedPercent: percent(checked, candidateCount),
    okPercent: percent(ok, checked),
    failedPercent: percent(failed, checked),
    priceMissing: rows.filter((row) => row.status === "price_missing").length,
    needsMappingReview: rows.filter(
      (row) => row.status === "needs_mapping_review" || row.status === "ambiguous_match"
    ).length,
    itemTimeouts: rows.filter((row) => row.status === "item_timeout").length,
    redirectedToLogin: rows.filter((row) => row.status === "redirected_to_login").length,
    totalProfitNetHuf,
    averageProfitPercent,
  };
}

function createRunTelemetry(
  state: DvgManualBatchState,
  now?: () => Date
): NonNullable<DvgManualBatchState["telemetry"]> {
  const previous = state.telemetry ?? createInitialTelemetry(new Date(state.startedAt));
  const endAt = state.completedAt ?? (now ? now().toISOString() : null);
  const durationMs = calculateDurationMs(state.startedAt, endAt);
  const detailFetchDurations = calculateDetailFetchDurations(state.events);
  const httpStatusBuckets = countDetailFetchHttpStatuses(state.events);
  const itemsPerMinute = calculateItemsPerMinute(state.rows.length, durationMs);
  return {
    statusChangedAt: previous.statusChangedAt,
    lastEventAt: state.events.at(-1)?.createdAt ?? previous.lastEventAt,
    durationMs,
    detailFetchStarted: state.events.filter((event) => event.type === "detailFetchStarted").length,
    detailFetchCompleted: state.events.filter((event) => event.type === "detailFetchDone").length,
    avgDetailFetchMs: average(detailFetchDurations),
    p95DetailFetchMs: percentile(detailFetchDurations, 95),
    itemsPerMinute,
    estimatedRemainingMinutes: estimateRemainingMinutes(
      state.totals.candidates,
      state.rows.length,
      itemsPerMinute
    ),
    ...httpStatusBuckets,
    itemTimeouts: state.rows.filter((row) => row.status === "item_timeout").length,
    sessionLostEvents: state.rows.filter((row) => row.status === "redirected_to_login").length,
    sessionRecoveries: state.events.filter((event) => event.type === "browserRecovery").length,
    rateLimitWaits: state.events.filter((event) => event.type === "rateLimitWait").length,
  };
}

function calculateDetailFetchDurations(events: readonly DvgManualBatchEvent[]): number[] {
  const startsByArticle = new Map<string, number[]>();
  const durations: number[] = [];

  for (const event of events) {
    if (event.type === "detailFetchStarted" && event.article) {
      const startedAt = Date.parse(event.createdAt);
      if (!Number.isFinite(startedAt)) continue;
      const starts = startsByArticle.get(event.article) ?? [];
      starts.push(startedAt);
      startsByArticle.set(event.article, starts);
      continue;
    }

    if (event.type !== "detailFetchDone" || !event.article) continue;
    const starts = startsByArticle.get(event.article);
    if (!starts?.length) continue;
    const startedAt = starts.shift();
    const endedAt = Date.parse(event.createdAt);
    if (startedAt === undefined || !Number.isFinite(endedAt) || endedAt < startedAt) continue;
    durations.push(endedAt - startedAt);
  }

  return durations;
}

function countDetailFetchHttpStatuses(events: readonly DvgManualBatchEvent[]): {
  httpStatus2xx: number;
  httpStatus4xx: number;
  httpStatus5xx: number;
  httpStatusOther: number;
} {
  const buckets = { httpStatus2xx: 0, httpStatus4xx: 0, httpStatus5xx: 0, httpStatusOther: 0 };
  for (const event of events) {
    if (event.type !== "detailFetchDone") continue;
    const status = readDetailFetchHttpStatus(event);
    if (status === null) {
      buckets.httpStatusOther += 1;
    } else if (status >= 200 && status < 300) {
      buckets.httpStatus2xx += 1;
    } else if (status >= 400 && status < 500) {
      buckets.httpStatus4xx += 1;
    } else if (status >= 500 && status < 600) {
      buckets.httpStatus5xx += 1;
    } else {
      buckets.httpStatusOther += 1;
    }
  }
  return buckets;
}

function readDetailFetchHttpStatus(event: DvgManualBatchEvent): number | null {
  if (Number.isInteger(event.httpStatus)) return Number(event.httpStatus);
  const match = /HTTP\s+(\d{3})/i.exec(event.message);
  if (!match) return null;
  const parsed = Number(match[1]);
  return Number.isInteger(parsed) ? parsed : null;
}

function average(values: readonly number[]): number | null {
  if (values.length === 0) return null;
  return Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function percentile(values: readonly number[], percentileValue: number): number | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((left, right) => left - right);
  const index = Math.ceil((percentileValue / 100) * sorted.length) - 1;
  return Math.round(sorted[Math.max(0, Math.min(index, sorted.length - 1))] ?? 0);
}

function calculateItemsPerMinute(checked: number, durationMs: number | null): number | null {
  if (!durationMs || durationMs <= 0 || checked <= 0) return null;
  return Number((checked / (durationMs / 60_000)).toFixed(2));
}

function estimateRemainingMinutes(
  total: number,
  checked: number,
  itemsPerMinute: number | null
): number | null {
  if (!itemsPerMinute || itemsPerMinute <= 0) return null;
  return Number((Math.max(total - checked, 0) / itemsPerMinute).toFixed(1));
}

function percent(value: number, total: number): number {
  if (total <= 0) return 0;
  return Number(((value / total) * 100).toFixed(2));
}

function calculateDurationMs(startedAt: string, endedAt: string | null): number | null {
  if (!endedAt) return null;
  const started = Date.parse(startedAt);
  const ended = Date.parse(endedAt);
  if (!Number.isFinite(started) || !Number.isFinite(ended) || ended < started) return null;
  return ended - started;
}

function normalizeSavedDvgOperatorRunState(
  run: DvgManualBatchState,
  now: () => Date
): DvgManualBatchState {
  const normalized = cloneState(run);
  if (isTerminalStatus(normalized.status)) return normalized;

  setStatus(normalized, "interrupted", now);
  addEvent(normalized, now, {
    type: "runStopped",
    message: "DVG run interrupted after API/runtime restart",
  });
  return normalized;
}

function toDvgManualBatchStateResponse(state: DvgManualBatchState): DvgManualBatchStateResponse {
  const snapshot = cloneState(state);
  return {
    ...snapshot,
    resume: buildDvgResumeAdvice(snapshot),
    export: buildDvgExportMetadata(snapshot),
  };
}

function toDvgManualBatchProgressResponse(
  progress: DvgCatalogRunProgress
): DvgManualBatchProgressResponse {
  return {
    ...progress,
    resume: buildDvgProgressResumeAdvice(progress),
    export: buildDvgProgressExportMetadata(progress),
  };
}

function buildDvgResumeAdvice(state: DvgManualBatchState): ManualBatchResumeAdvice {
  const nextOffset = getDvgStateNextOffset(state);
  if (state.status === "waiting_for_manual_login" || state.status === "login_detected") {
    return {
      canResume: true,
      action: "continue_after_login",
      runId: state.runId,
      nextOffset,
      reason: "A DVG böngészőfutás bejelentkezés után folytatható.",
    };
  }
  if (state.status === "running" || state.status === "opening_browser") {
    return {
      canResume: false,
      action: "wait_for_current_run",
      runId: state.runId,
      nextOffset,
      reason: "DVG futás aktív, várd meg az aktuális lépést vagy állítsd le kézzel.",
    };
  }
  if (["session_lost", "login_timeout", "detached_session_failed"].includes(state.status)) {
    return {
      canResume: true,
      action: "login_again",
      runId: state.runId,
      nextOffset,
      reason: "A DVG session új belépést igényel; indíts új futást a következő offsettel.",
    };
  }
  if (["interrupted", "failed", "security_stopped"].includes(state.status)) {
    return {
      canResume: true,
      action: "retry_from_next_offset",
      runId: state.runId,
      nextOffset,
      reason: "A mentett DVG futás újraindítható a következő nem feldolgozott offset környékéről.",
    };
  }
  return {
    canResume: false,
    action: "start_new",
    runId: state.runId,
    nextOffset,
    reason: "Nincs folytatandó aktív DVG futás; indítható új batch.",
  };
}

function buildDvgProgressResumeAdvice(progress: DvgCatalogRunProgress): ManualBatchResumeAdvice {
  return {
    canResume: progress.checked > 0,
    action: progress.checked > 0 ? "retry_from_next_offset" : "start_new",
    runId: progress.runId,
    nextOffset: progress.nextOffset,
    reason:
      progress.checked > 0
        ? "Mentett DVG progress alapján a következő offset használható új batch indításához."
        : "Nincs mentett DVG progress.",
  };
}

function buildDvgExportMetadata(state: DvgManualBatchState): ManualBatchExportMetadata {
  return {
    available: state.rows.length > 0,
    format: "sanitized_rows_json",
    suggestedFilename:
      state.rows.length > 0 ? `dvg-${sanitizeCode(state.runId)}-sanitized-results.json` : null,
    rowCount: state.rows.length,
    totals: {
      checked: state.totals.checked,
      ok: state.totals.ok,
      failed: state.totals.failed,
      skipped: state.totals.skipped,
      safetyStopped: state.totals.safetyStopped,
    },
    nextOffset: getDvgStateNextOffset(state),
    containsSecrets: false,
  };
}

function buildDvgProgressExportMetadata(
  progress: DvgCatalogRunProgress
): ManualBatchExportMetadata {
  return {
    available: progress.checked > 0,
    format: "sanitized_rows_json",
    suggestedFilename:
      progress.checked > 0 ? `dvg-${sanitizeCode(progress.runId)}-progress-summary.json` : null,
    rowCount: progress.checked,
    totals: {
      checked: progress.checked,
      ok: progress.ok,
      failed: progress.failed,
      skipped: progress.skipped,
      safetyStopped: progress.safetyStopped,
    },
    nextOffset: progress.nextOffset,
    containsSecrets: false,
  };
}

function getDvgStateNextOffset(state: DvgManualBatchState): number {
  const progressRows = state.rows.filter((row) => row.status !== "redirected_to_login").length;
  return state.settings.offset + progressRows;
}

function createStateCallbacks(
  state: DvgManualBatchState,
  now: () => Date,
  onRowSaved?: (row: DvgManualBatchState["rows"][number], rowNumber: number) => void,
  onStateChanged?: () => void
): DvgManualBatchCallbacks {
  return {
    onStatus(status) {
      setStatus(state, status, now);
      onStateChanged?.();
    },
    onEvent(event) {
      addEvent(state, now, event);
    },
    onCurrentItem(currentItem) {
      state.currentItem = currentItem;
    },
    onRow(row) {
      state.rows.push(row);
      updateTotals(state);
      onRowSaved?.(row, state.rows.length);
      onStateChanged?.();
    },
    onRowUpdate(rowNumber, row) {
      const index = rowNumber - 1;
      if (index < 0 || index >= state.rows.length) return;
      state.rows[index] = row;
      updateTotals(state);
      onRowSaved?.(row, rowNumber);
      onStateChanged?.();
    },
  };
}

function addEvent(
  state: DvgManualBatchState,
  now: () => Date,
  event: Omit<DvgManualBatchEvent, "id" | "createdAt">
): void {
  const nextId = (state.events.at(-1)?.id ?? 0) + 1;
  const createdAt = now().toISOString();
  state.events.push({ ...event, id: nextId, createdAt });
  if (state.events.length > MAX_EVENTS) state.events.splice(0, state.events.length - MAX_EVENTS);
  refreshRunDerivedData(state, now);
}

function setStatus(
  state: DvgManualBatchState,
  status: DvgManualBatchRunStatus,
  now: () => Date
): void {
  state.telemetry ??= createInitialTelemetry(new Date(state.startedAt));
  state.summary ??= createRunSummary(state.rows, state.totals.candidates);
  const changed = state.status !== status;
  state.status = status;
  if (changed) {
    state.telemetry.statusChangedAt = now().toISOString();
  }
  if (isTerminalStatus(status) && state.completedAt === null) {
    state.completedAt = now().toISOString();
  }
  refreshRunDerivedData(state, now);
}

function updateTotals(state: DvgManualBatchState): void {
  state.totals.checked = state.rows.length;
  state.totals.ok = state.rows.filter((row) => row.status === "ok").length;
  state.totals.skipped = state.rows.filter((row) => row.status.startsWith("skipped_")).length;
  state.totals.safetyStopped = state.rows.filter((row) => row.status === "safety_stopped").length;
  state.totals.failed = state.rows.filter(
    (row) => row.status !== "ok" && !row.status.startsWith("skipped_")
  ).length;
  refreshRunDerivedData(state);
}

function getRunRecord(
  activeRun: DvgManualBatchRunRecord | null,
  params: unknown
): DvgManualBatchRunRecord {
  const runId = (params as RunParams).runId;
  if (!activeRun || activeRun.state.runId !== runId) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_not_found",
      "DVG manual batch not found",
      404
    );
  }
  return activeRun;
}

function assertRouteAllowed(
  request: FastifyRequest,
  env: Record<string, string | undefined>
): void {
  if (!isLoopbackIp(request.ip)) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_local_only",
      "DVG manual batch is local-only",
      403
    );
  }
  if (request.headers[DVG_LOCAL_LAB_HEADER] !== "true") {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_header_missing",
      "DVG manual batch requires local lab header",
      403
    );
  }
  const origin = stringHeader(request.headers.origin);
  if (origin && !isAllowedLocalWebOrigin(origin)) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_origin_forbidden",
      "DVG manual batch requires localhost dashboard origin",
      403
    );
  }
  const referer = stringHeader(request.headers.referer);
  if (!origin && referer && !isAllowedLocalWebOrigin(referer)) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_origin_forbidden",
      "DVG manual batch requires localhost dashboard origin",
      403
    );
  }
  const explicitlyEnabled = env.ENABLE_SUPPLIER_SESSION_LAB?.trim().toLowerCase() === "true";
  if (env.NODE_ENV === "production" && !explicitlyEnabled) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_disabled",
      "DVG manual batch is disabled in production unless explicitly enabled",
      403
    );
  }
}

async function validateStartInput(
  body: unknown,
  loadDefaultEurHufRate: () => Promise<number | null>
): Promise<ValidatedStartInput> {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  const shopMode = input.shopMode === undefined ? undefined : readDvgShopMode(input.shopMode);
  const eurHufRate = await readEurHufRate(input.eurHufRate, loadDefaultEurHufRate);
  const speedMode = readDvgManualBatchSpeedMode(input.speedMode);
  const speedDefaults = DVG_MANUAL_BATCH_SPEED_PROFILES[speedMode];
  const onlyMappedDvg = optionalBoolean(input.onlyMappedDvg, true, "onlyMappedDvg");
  const rerunPreviousNonOkOnly = optionalBoolean(
    input.rerunPreviousNonOkOnly,
    false,
    "rerunPreviousNonOkOnly"
  );
  const allowSuggestedDvgArticle = optionalBoolean(
    input.allowSuggestedDvgArticle,
    false,
    "allowSuggestedDvgArticle"
  );
  const allowSkuPrefixCandidate = optionalBoolean(
    input.allowSkuPrefixCandidate,
    false,
    "allowSkuPrefixCandidate"
  );
  if (
    rerunPreviousNonOkOnly &&
    (!onlyMappedDvg || allowSuggestedDvgArticle || allowSkuPrefixCandidate)
  ) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_invalid_settings",
      "DVG previous non-OK rerun requires saved mapped DVG candidates only",
      400
    );
  }
  const settings: DvgManualBatchSettings = {
    ...(shopMode ? { shopMode } : {}),
    speedMode,
    markupPercent: boundedNumber(input.markupPercent, 30, 0, 500, "markupPercent"),
    vatPercent: boundedNumber(input.vatPercent, 27, 0, 50, "vatPercent"),
    eurHufRate,
    wooPricesIncludeVat: optionalBoolean(input.wooPricesIncludeVat, true, "wooPricesIncludeVat"),
    limit: boundedInteger(input.limit, 20, 1, MAX_DVG_BATCH_ITEMS, "limit"),
    offset: boundedInteger(input.offset, 0, 0, MAX_DVG_BATCH_OFFSET, "offset"),
    onlyMappedDvg,
    rerunPreviousNonOkOnly,
    allowSuggestedDvgArticle,
    allowSkuPrefixCandidate,
    dryRun: optionalBoolean(input.dryRun, true, "dryRun"),
    allowSnapshotWrite: optionalBoolean(input.allowSnapshotWrite, false, "allowSnapshotWrite"),
    itemTimeoutMs: boundedInteger(
      input.itemTimeoutMs,
      shopMode === "new_shop" ? 30_000 : speedDefaults.itemTimeoutMs,
      5_000,
      120_000,
      "itemTimeoutMs"
    ),
    detailFetchTimeoutMs: boundedInteger(
      input.detailFetchTimeoutMs,
      shopMode === "new_shop" ? 10_000 : speedDefaults.detailFetchTimeoutMs,
      1_000,
      60_000,
      "detailFetchTimeoutMs"
    ),
    fallbackNavigationTimeoutMs: boundedInteger(
      input.fallbackNavigationTimeoutMs,
      shopMode === "new_shop" ? 20_000 : speedDefaults.fallbackNavigationTimeoutMs,
      5_000,
      120_000,
      "fallbackNavigationTimeoutMs"
    ),
    recoverAfterConsecutiveTimeouts: boundedInteger(
      input.recoverAfterConsecutiveTimeouts,
      0,
      0,
      20,
      "recoverAfterConsecutiveTimeouts"
    ),
  };

  return {
    settings,
    manualLoginTimeoutMs: boundedInteger(
      input.manualLoginTimeoutMs,
      DEFAULT_MANUAL_LOGIN_TIMEOUT_MS,
      30_000,
      900_000,
      "manualLoginTimeoutMs"
    ),
  };
}

function readDvgManualBatchSpeedMode(value: unknown): DvgManualBatchSpeedMode {
  if (value === undefined || value === null || value === "") return "normal";
  if (value === "normal" || value === "fast" || value === "very_fast") return value;
  throw new DvgProductsRouteError(
    "dvg_manual_batch_invalid_settings",
    "speedMode must be normal, fast or very_fast",
    400
  );
}

function validateOperatorPreferences(body: unknown): DvgOperatorPreferences {
  assertNoSensitiveKeys(body);
  const input = isRecord(body) ? body : {};
  return {
    ...(input.shopMode !== undefined ? { shopMode: readDvgShopMode(input.shopMode) } : {}),
    autoResume: optionalBoolean(input.autoResume, true, "autoResume"),
    vatPercent: boundedNumber(input.vatPercent, 27, 0, 50, "vatPercent"),
    targetProfitMultiplier: optionalNullableNumber(
      input.targetProfitMultiplier,
      1,
      20,
      "targetProfitMultiplier"
    ),
    minimumProfitPercent: optionalNullableNumber(
      input.minimumProfitPercent,
      -1000,
      10000,
      "minimumProfitPercent"
    ),
  };
}

function readDvgShopMode(value: unknown): DvgShopMode {
  if (value === "legacy" || value === "new_shop") return value;
  throw new DvgProductsRouteError(
    "dvg_shop_mode_invalid",
    "Válassz Legacy vagy New shop módot.",
    400
  );
}

function defaultDvgOperatorPreferences(): DvgOperatorPreferences {
  return {
    autoResume: true,
    vatPercent: 27,
    targetProfitMultiplier: null,
    minimumProfitPercent: null,
  };
}

async function readEurHufRate(
  value: unknown,
  loadDefaultEurHufRate: () => Promise<number | null>
): Promise<number> {
  if (value === undefined || value === null || value === "") {
    const latest = await loadDefaultEurHufRate();
    if (latest === null) {
      throw new DvgProductsRouteError(
        "pricing_exchange_rate_required",
        "EUR/HUF exchange rate must be provided or saved before starting DVG batch",
        400
      );
    }
    return boundedRequiredNumber(latest, 100, 1000, "eurHufRate");
  }
  return boundedRequiredNumber(value, 100, 1000, "eurHufRate");
}

function assertNoSensitiveKeys(value: unknown): void {
  if (!isRecord(value)) return;
  for (const key of Object.keys(value)) {
    if (/password|credential|cookie|session|storageState|token|secret/i.test(key)) {
      throw new DvgProductsRouteError("sensitive_field", "Sensitive field is not accepted", 400);
    }
  }
}

function boundedInteger(
  value: unknown,
  defaultValue: number,
  min: number,
  max: number,
  field: string
): number {
  if (value === undefined || value === null || value === "") return defaultValue;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_invalid_settings",
      `${field} must be an integer between ${min} and ${max}`,
      400
    );
  }
  return parsed;
}

function boundedNumber(
  value: unknown,
  defaultValue: number,
  min: number,
  max: number,
  field: string
): number {
  if (value === undefined || value === null || value === "") return defaultValue;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_invalid_settings",
      `${field} must be a number between ${min} and ${max}`,
      400
    );
  }
  return parsed;
}

function boundedRequiredNumber(value: unknown, min: number, max: number, field: string): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new DvgProductsRouteError(
      "dvg_manual_batch_invalid_settings",
      `${field} must be a number between ${min} and ${max}`,
      400
    );
  }
  return parsed;
}

function optionalNullableNumber(
  value: unknown,
  min: number,
  max: number,
  field: string
): number | null {
  if (value === undefined || value === null || value === "") return null;
  return boundedRequiredNumber(value, min, max, field);
}

function optionalBoolean(value: unknown, defaultValue: boolean, field: string): boolean {
  if (value === undefined || value === null || value === "") return defaultValue;
  if (typeof value === "boolean") return value;
  throw new DvgProductsRouteError(
    "dvg_manual_batch_invalid_settings",
    `${field} must be boolean`,
    400
  );
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isAllowedLocalWebOrigin(value: string): boolean {
  try {
    const url = new URL(value);
    return (
      url.protocol === "http:" &&
      url.port === "3000" &&
      (url.hostname === "localhost" ||
        url.hostname === "127.0.0.1" ||
        url.hostname === "::1" ||
        url.hostname === "[::1]")
    );
  } catch {
    return false;
  }
}

function stringHeader(value: string | string[] | undefined): string | null {
  if (Array.isArray(value)) return value[0] ?? null;
  return value ?? null;
}

function isLoopbackIp(value: string): boolean {
  return value === "127.0.0.1" || value === "::1" || value === "::ffff:127.0.0.1";
}

const isTerminalStatus = isSupplierRunTerminal;

function sanitizeCode(value: string): string {
  return value.replace(/[^A-Za-z0-9._:-]/g, "_").slice(0, 120) || "dvg_manual_batch_failed";
}

function cloneState(state: DvgManualBatchState): DvgManualBatchState {
  const telemetry = state.telemetry ?? createRunTelemetry(state);
  const summary = state.summary ?? createRunSummary(state.rows, state.totals.candidates);
  return {
    ...state,
    settings: { ...state.settings },
    currentItem: state.currentItem ? { ...state.currentItem } : null,
    totals: { ...state.totals },
    telemetry: { ...telemetry },
    summary: { ...summary },
    events: state.events.map((event) => ({ ...event })),
    rows: state.rows.map((row) => ({ ...row, warnings: [...row.warnings] })),
  };
}

function safeRuntimeError(error: unknown): { code: string; message: string; httpStatus: number } {
  if (isRecord(error)) {
    const code = typeof error.code === "string" ? sanitizeCode(error.code) : null;
    if (code?.startsWith("cloakbrowser_")) {
      return {
        code,
        message: `CloakBrowser runtime failed: ${code}`,
        httpStatus: 503,
      };
    }
  }
  return {
    code: "dvg_manual_batch_open_failed",
    message: "DVG browser could not be opened. Check CloakBrowser Manager and retry.",
    httpStatus: 503,
  };
}

class DvgProductsRouteError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus: number
  ) {
    super(message);
    this.name = "DvgProductsRouteError";
  }
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof DvgProductsRouteError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  return reply
    .code(500)
    .send({ error: { code: "internal_error", message: "Unexpected DVG products API error" } });
}
