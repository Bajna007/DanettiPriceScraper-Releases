import type {
  DvgCredentialDetailTestParsed,
  DvgCredentials,
  DvgLoginAttemptDiagnostic,
  DvgLoginForensicSummary,
  DvgSubmitCandidateSummary,
} from "@danetti/connectors";

export type SupplierCredentialKind = "username_password";
export type SupplierCredentialSource = "stored" | "env" | "missing";
export type SupplierCredentialTestStatus = "not_tested" | "success" | "failed";

export interface SupplierCredentialSecret {
  supplierId: string;
  connectorId: string;
  kind: SupplierCredentialKind;
  username: string;
  password: string;
  updatedAt: string;
  lastTestedAt: string | null;
  lastTestStatus: SupplierCredentialTestStatus;
  lastErrorCode: string | null;
}

export interface SupplierCredentialStatus {
  supplierId: string;
  connectorId: string;
  kind: SupplierCredentialKind;
  configured: boolean;
  source: SupplierCredentialSource;
  usernameDisplay: string | null;
  lastTestedAt: string | null;
  lastTestStatus: SupplierCredentialTestStatus;
  lastErrorCode: string | null;
}

export interface SupplierCredentialSaveInput {
  connectorId: string;
  kind?: SupplierCredentialKind;
  username: string;
  password: string;
}

export interface SupplierCredentialTestInput {
  testArticle?: string;
  forensicMode?: "prevent_default_v3";
}

export interface ResolvedSupplierCredential {
  credentials: DvgCredentials;
  source: Exclude<SupplierCredentialSource, "missing">;
  storedSecret: SupplierCredentialSecret | null;
}

export interface SupplierCredentialTestResult {
  status: Extract<SupplierCredentialTestStatus, "success" | "failed">;
  code: string;
}

export interface SupplierCredentialDetailTestResponse {
  status: "success" | "failed" | "configuration_error";
  supplierId: string;
  connectorId: string;
  credentialConfigured: boolean;
  loginOk: boolean;
  detailFetchOk: boolean;
  parsed: DvgCredentialDetailTestParsed | null;
  warnings: string[];
  errorCode: string | null;
  stage: string;
  safeMessage: string;
  selectorHint: string | null;
  loginPageMessage: string | null;
  finalPath: string | null;
  loginLandingDetected: boolean;
  fillStrategy?: string | null;
  usernameFilled: boolean | null;
  passwordFilled: boolean | null;
  formActionHost: string | null;
  formMethod: string | null;
  submitEnabled: boolean | null;
  submitEnabledAfterFill?: boolean | null;
  submitEnabledBeforeSubmit?: boolean | null;
  submitStrategy: string | null;
  submitCandidateSummary?: DvgSubmitCandidateSummary[];
  attemptedStrategies?: DvgLoginAttemptDiagnostic[];
  winningStrategy?: string | null;
  activeElementSummary?: {
    tagName: string | null;
    id: string | null;
    name: string | null;
    type: string | null;
    formId: string | null;
  } | null;
  forensic?: DvgLoginForensicSummary | null;
}

export class SupplierCredentialError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus = 400
  ) {
    super(message);
    this.name = "SupplierCredentialError";
  }
}
