import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import { SupplierPortalAuditsRepository } from "./supplier-portal-audits.repository.js";
import {
  PortalAuditDatabaseError,
  PortalAuditValidationError,
  type PortalAuditStatus,
} from "./supplier-portal-audits.types.js";
import {
  assertAuditCanBeApproved,
  buildSafePortalAuditExport,
  buildSupplierPortalConnectorPlan,
  createDefaultChecklistRows,
  evaluateSupplierPortalAuditReadiness,
  validateApproveInput,
  validateCheckUpdateInput,
  validateCreatePortalAuditInput,
  validateEvidenceNoteInput,
  validateRejectInput,
  validateUpdatePortalAuditInput,
  validateUuid,
} from "./supplier-portal-audits.service.js";

interface PortalAuditRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
}

interface ListQuery {
  supplierId?: string;
  status?: PortalAuditStatus;
  limit?: string;
  offset?: string;
}

interface IdParams {
  id: string;
  checkId?: string;
}

const AUDIT_STATUSES: PortalAuditStatus[] = [
  "draft",
  "in_review",
  "approved",
  "rejected",
  "needs_update",
];

export async function registerSupplierPortalAuditRoutes(
  server: FastifyInstance,
  options: PortalAuditRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) await dbClient.close();
  });

  function getRepository(): SupplierPortalAuditsRepository {
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new SupplierPortalAuditsRepository(dbClient.db);
    } catch (error) {
      throw new PortalAuditDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/supplier-portal-audits", async (request, reply) => {
    try {
      const query = request.query as ListQuery;
      const supplierId = optionalUuid(query.supplierId, "supplierId");
      const limit = parseBoundedInteger(query.limit, 50, 200, "limit");
      const offset = parseBoundedInteger(query.offset, 0, Number.MAX_SAFE_INTEGER, "offset");
      const status = optionalAuditStatus(query.status);
      return {
        items: await getRepository().list({ supplierId, status, limit, offset }),
        limit,
        offset,
      };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-portal-audits", async (request, reply) => {
    try {
      const input = validateCreatePortalAuditInput(request.body);
      const repository = getRepository();
      const supplier = await repository.getSupplierById(input.supplierId);
      if (supplier === null)
        throw new PortalAuditValidationError("missing_supplier", "Supplier not found", 404);
      const audit = await repository.transaction(async (tx) => {
        const created = await tx.create(input);
        await tx.createChecks(createDefaultChecklistRows(created.id));
        return created;
      });
      return reply.code(201).send(audit);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-portal-audits/:id/connector-readiness", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const audit = await getRepository().getById(params.id);
      if (audit === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      return evaluateSupplierPortalAuditReadiness(audit, audit.checks);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-portal-audits/:id/connector-plan", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const repository = getRepository();
      const audit = await repository.getById(params.id);
      if (audit === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      const settings = await repository.getCheckSettingsBySupplierId(audit.supplierId);
      return buildSupplierPortalConnectorPlan(audit, settings);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-portal-audits/:id/export-safe-summary", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const repository = getRepository();
      const audit = await repository.getById(params.id);
      if (audit === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      const settings = await repository.getCheckSettingsBySupplierId(audit.supplierId);
      return buildSafePortalAuditExport(audit, settings);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-portal-audits/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const audit = await getRepository().getById(params.id);
      if (audit === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      return audit;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.patch("/supplier-portal-audits/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const audit = await getRepository().update(
        params.id,
        validateUpdatePortalAuditInput(request.body)
      );
      if (audit === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      return audit;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.patch("/supplier-portal-audits/:id/checks/:checkId", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      validateUuid(params.checkId ?? "", "checkId");
      const repository = getRepository();
      const audit = await repository.getById(params.id);
      if (audit === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      const check = await repository.updateCheck(
        params.id,
        params.checkId ?? "",
        validateCheckUpdateInput(request.body)
      );
      if (check === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Check not found" } });
      return check;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-portal-audits/:id/evidence-notes", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const input = validateEvidenceNoteInput(request.body);
      const repository = getRepository();
      const audit = await repository.getById(params.id);
      if (audit === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      const note = await repository.createEvidenceNote({ ...input, auditId: params.id });
      return reply.code(201).send({
        note,
        warning: note.containsSensitiveData
          ? "Sensitive data flag set. Do not store raw sensitive evidence."
          : null,
      });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-portal-audits/:id/submit-review", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const repository = getRepository();
      const current = await repository.getById(params.id);
      if (current === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      if (current.status !== "draft" && current.status !== "needs_update")
        throw new PortalAuditValidationError(
          "invalid_status",
          "Only draft/needs_update audits can be submitted"
        );
      return repository.update(params.id, { status: "in_review", updatedAt: new Date() });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-portal-audits/:id/approve", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const { approvedBy } = validateApproveInput(request.body);
      const repository = getRepository();
      const current = await repository.getById(params.id);
      if (current === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      assertAuditCanBeApproved(current, current.checks);
      return repository.update(params.id, {
        status: "approved",
        approvedBy,
        approvedAt: new Date(),
        updatedAt: new Date(),
      });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-portal-audits/:id/reject", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const { reviewedBy, safetyNotes } = validateRejectInput(request.body);
      const audit = await getRepository().update(params.id, {
        status: "rejected",
        reviewedBy,
        reviewedAt: new Date(),
        safetyNotes,
        updatedAt: new Date(),
      });
      if (audit === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Audit not found" } });
      return audit;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

function optionalUuid(value: string | undefined, field: string): string | undefined {
  if (value === undefined || value.trim().length === 0) return undefined;
  validateUuid(value, field);
  return value;
}

function optionalAuditStatus(value: PortalAuditStatus | undefined): PortalAuditStatus | undefined {
  if (value === undefined) return undefined;
  if (!AUDIT_STATUSES.includes(value)) {
    throw new PortalAuditValidationError("invalid_query", "status is invalid");
  }
  return value;
}

function parseBoundedInteger(
  value: string | undefined,
  defaultValue: number,
  maxValue: number,
  field: string
): number {
  if (value === undefined) return defaultValue;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0 || parsed > maxValue) {
    throw new PortalAuditValidationError(
      "invalid_query",
      `${field} must be an integer between 0 and ${maxValue}`
    );
  }
  return parsed;
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof PortalAuditValidationError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  if (error instanceof PortalAuditDatabaseError) {
    return reply
      .code(503)
      .send({ error: { code: "database_unavailable", message: error.message } });
  }
  return reply
    .code(500)
    .send({ error: { code: "internal_error", message: "Unexpected portal audit API error" } });
}
