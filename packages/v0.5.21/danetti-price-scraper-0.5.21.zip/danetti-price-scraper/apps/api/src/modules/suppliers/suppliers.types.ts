import type {
  NewSupplier,
  NewSupplierCheckSettings,
  Supplier,
  SupplierCheckSettings,
} from "@danetti/db";

export type LookupStrategy =
  | "search_result"
  | "search_then_detail"
  | "direct_url"
  | "export_file"
  | "network_response";

export interface CreateSupplierInput {
  code: string;
  name: string;
  baseUrl?: string | null;
  enabled?: boolean;
  allowedDomains?: string[];
  supportedLookupStrategies?: LookupStrategy[];
  defaultRateLimitPerMinute?: number;
}

export interface UpdateSupplierInput {
  name?: string;
  baseUrl?: string | null;
  enabled?: boolean;
  allowedDomains?: string[];
  supportedLookupStrategies?: LookupStrategy[];
  defaultRateLimitPerMinute?: number;
}

export type SupplierCreateRecord = NewSupplier;
export type SupplierRecord = Supplier;
export type SupplierCheckSettingsRecord = SupplierCheckSettings;
export type SupplierCheckSettingsUpdateRecord = Partial<NewSupplierCheckSettings>;

export interface UpdateSupplierCheckSettingsInput {
  productsPerMinute?: number;
  delayBetweenProductsSeconds?: number;
  jitterMinSeconds?: number;
  jitterMaxSeconds?: number;
  maxRetriesPerItem?: number;
  navigationTimeoutSeconds?: number;
  itemTimeoutSeconds?: number;
  stopAfterConsecutiveFailures?: number;
  stopOnSafetyEvent?: boolean;
  stopOnCartChange?: boolean;
  enabled?: boolean;
}

export class SupplierValidationError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus = 400
  ) {
    super(message);
    this.name = "SupplierValidationError";
  }
}

export class SupplierDatabaseError extends Error {
  constructor(message = "Database unavailable") {
    super(message);
    this.name = "SupplierDatabaseError";
  }
}
