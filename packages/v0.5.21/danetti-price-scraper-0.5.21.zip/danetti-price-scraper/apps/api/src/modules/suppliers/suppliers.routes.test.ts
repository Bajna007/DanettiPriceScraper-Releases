import assert from "node:assert/strict";
import type {
  NewSupplier,
  NewSupplierCheckSettings,
  Supplier,
  SupplierCheckSettings,
} from "@danetti/db";
import Fastify from "fastify";
import { registerSupplierRoutes } from "./suppliers.routes.js";

class InMemorySuppliersRepository {
  private readonly suppliers = new Map<string, Supplier>();
  private readonly checkSettings = new Map<string, SupplierCheckSettings>();

  async list(input: { limit: number; offset: number }): Promise<Supplier[]> {
    return Array.from(this.suppliers.values()).slice(input.offset, input.offset + input.limit);
  }

  async getById(id: string): Promise<Supplier | null> {
    return this.suppliers.get(id) ?? null;
  }

  async create(input: NewSupplier): Promise<Supplier> {
    const existing = Array.from(this.suppliers.values()).find(
      (supplier) => supplier.code === input.code
    );
    if (existing) {
      const error = new Error("duplicate key value violates unique constraint");
      Object.assign(error, { code: "23505", constraint: "suppliers_code_unique" });
      throw error;
    }

    const now = new Date("2026-05-07T00:00:00.000Z");
    const supplier: Supplier = {
      id: `11111111-1111-4111-8111-${String(this.suppliers.size + 1).padStart(12, "0")}`,
      code: input.code,
      name: input.name,
      baseUrl: input.baseUrl ?? null,
      enabled: input.enabled ?? true,
      allowedDomains: input.allowedDomains ?? [],
      supportedLookupStrategies: input.supportedLookupStrategies ?? [],
      defaultRateLimitPerMinute: input.defaultRateLimitPerMinute ?? 6,
      healthStatus: input.healthStatus ?? "unknown",
      lastSuccessAt: null,
      lastFailureAt: null,
      createdAt: now,
      updatedAt: now,
    };
    this.suppliers.set(supplier.id, supplier);
    return supplier;
  }

  async update(id: string, input: Partial<NewSupplier>): Promise<Supplier | null> {
    const supplier = this.suppliers.get(id);
    if (!supplier) return null;
    const updated = { ...supplier, ...input, updatedAt: input.updatedAt ?? supplier.updatedAt };
    this.suppliers.set(id, updated);
    return updated;
  }

  async getOrCreateCheckSettingsBySupplierId(supplierId: string): Promise<SupplierCheckSettings> {
    const existing = this.checkSettings.get(supplierId);
    if (existing) return existing;
    const now = new Date("2026-05-07T00:00:00.000Z");
    const settings: SupplierCheckSettings = {
      id: `22222222-2222-4222-8222-${String(this.checkSettings.size + 1).padStart(12, "0")}`,
      supplierId,
      productsPerMinute: 6,
      delayBetweenProductsSeconds: 10,
      jitterMinSeconds: 1,
      jitterMaxSeconds: 5,
      maxRetriesPerItem: 1,
      navigationTimeoutSeconds: 30,
      itemTimeoutSeconds: 60,
      stopAfterConsecutiveFailures: 5,
      stopOnSafetyEvent: true,
      stopOnCartChange: true,
      enabled: true,
      createdAt: now,
      updatedAt: now,
    };
    this.checkSettings.set(supplierId, settings);
    return settings;
  }

  async updateCheckSettings(
    supplierId: string,
    input: Partial<NewSupplierCheckSettings>
  ): Promise<SupplierCheckSettings | null> {
    const settings = await this.getOrCreateCheckSettingsBySupplierId(supplierId);
    const updated = { ...settings, ...input, updatedAt: input.updatedAt ?? settings.updatedAt };
    this.checkSettings.set(supplierId, updated);
    return updated;
  }
}

const server = Fastify({ logger: false });
const repository = new InMemorySuppliersRepository();
await registerSupplierRoutes(server, { repository });

try {
  const dvgPayload = {
    code: "dvg-devecchi",
    name: "DVG De Vecchi",
    baseUrl: "https://devecchigiuseppesrl.com",
    allowedDomains: ["devecchigiuseppesrl.com"],
    supportedLookupStrategies: ["direct_url"],
    defaultRateLimitPerMinute: 6,
  };

  const created = await server.inject({
    method: "POST",
    url: "/suppliers",
    payload: dvgPayload,
  });
  assert.equal(created.statusCode, 201);
  assert.equal(created.json().code, "dvg-devecchi");
  assert.deepEqual(created.json().supportedLookupStrategies, ["direct_url"]);
  assert.equal(JSON.stringify(created.json()).includes("password"), false);
  assert.equal(JSON.stringify(created.json()).includes("credential"), false);

  const duplicate = await server.inject({
    method: "POST",
    url: "/suppliers",
    payload: dvgPayload,
  });
  assert.equal(duplicate.statusCode, 409);
  assert.equal(duplicate.json().error.code, "duplicate_supplier_code");
  assert.equal(duplicate.json().error.message, "Supplier code already exists: dvg-devecchi");

  const invalidDomain = await server.inject({
    method: "POST",
    url: "/suppliers",
    payload: {
      code: "bad-domain",
      name: "Bad Domain",
      allowedDomains: ["https://bad.example"],
    },
  });
  assert.equal(invalidDomain.statusCode, 400);
  assert.equal(invalidDomain.json().error.code, "invalid_allowed_domain");
  assert.equal(
    invalidDomain.json().error.message,
    "allowedDomains contains invalid domain: https://bad.example"
  );
} finally {
  await server.close();
}

console.log("Supplier route tests passed");
