import { WindowsSecretStore } from "../../security/secret-store.js";
import type { SupplierCredentialSecret } from "./supplier-credentials.types.js";
import { SupplierCredentialError } from "./supplier-credentials.types.js";

export interface SupplierCredentialStore {
  get(supplierId: string, connectorId: string): Promise<SupplierCredentialSecret | null>;
  put(secret: SupplierCredentialSecret): Promise<void>;
  delete(supplierId: string, connectorId: string): Promise<void>;
}

export class InMemorySupplierCredentialStore implements SupplierCredentialStore {
  private readonly secrets = new Map<string, SupplierCredentialSecret>();

  async get(supplierId: string, connectorId: string): Promise<SupplierCredentialSecret | null> {
    const value = this.secrets.get(makeStoreKey(supplierId, connectorId));
    return value ? cloneSecret(value) : null;
  }

  async put(secret: SupplierCredentialSecret): Promise<void> {
    this.secrets.set(makeStoreKey(secret.supplierId, secret.connectorId), cloneSecret(secret));
  }

  async delete(supplierId: string, connectorId: string): Promise<void> {
    this.secrets.delete(makeStoreKey(supplierId, connectorId));
  }
}

export class WindowsCredentialManagerSupplierCredentialStore implements SupplierCredentialStore {
  private readonly store = new WindowsSecretStore();
  async get(supplierId: string, connectorId: string): Promise<SupplierCredentialSecret | null> {
    const value = await this.store.get(makeWindowsTargetName(supplierId, connectorId));
    return value === null ? null : parseStoredSecret(value, supplierId, connectorId);
  }
  async put(secret: SupplierCredentialSecret): Promise<void> {
    await this.store.put(
      makeWindowsTargetName(secret.supplierId, secret.connectorId),
      JSON.stringify(secret)
    );
  }
  async delete(supplierId: string, connectorId: string): Promise<void> {
    await this.store.delete(makeWindowsTargetName(supplierId, connectorId));
  }
}

export function createDefaultSupplierCredentialStore(): SupplierCredentialStore {
  return new WindowsCredentialManagerSupplierCredentialStore();
}

function makeStoreKey(supplierId: string, connectorId: string): string {
  return `${supplierId}:${connectorId}`;
}

function makeWindowsTargetName(supplierId: string, connectorId: string): string {
  return `DanettiPriceScraper:supplier-credentials:${supplierId}:${connectorId}`;
}

function cloneSecret(secret: SupplierCredentialSecret): SupplierCredentialSecret {
  return { ...secret };
}

function parseStoredSecret(
  value: string,
  supplierId: string,
  connectorId: string
): SupplierCredentialSecret {
  try {
    const parsed = JSON.parse(value) as SupplierCredentialSecret;
    if (
      parsed.supplierId !== supplierId ||
      parsed.connectorId !== connectorId ||
      parsed.kind !== "username_password" ||
      typeof parsed.username !== "string" ||
      typeof parsed.password !== "string"
    ) {
      throw new Error("Stored credential payload mismatch");
    }
    return {
      ...parsed,
      lastTestedAt: parsed.lastTestedAt ?? null,
      lastTestStatus: parsed.lastTestStatus ?? "not_tested",
      lastErrorCode: parsed.lastErrorCode ?? null,
    };
  } catch {
    throw new SupplierCredentialError(
      "credential_store_corrupt",
      "Stored supplier credential payload is invalid.",
      500
    );
  }
}
