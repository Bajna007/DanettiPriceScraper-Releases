import multipart from "@fastify/multipart";
import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance } from "fastify";
import { registerLabelAssetRoutes } from "./assets/assets.routes.js";
import { registerLabelDesignRoutes } from "./designs/designs.routes.js";
import { registerLabelExportRoutes } from "./exports/exports.routes.js";
import { LabelStudioService } from "./labels.service.js";
import { registerLabelOrderRoutes } from "./orders/orders.routes.js";
import { registerLabelTemplateRoutes } from "./templates/templates.routes.js";

interface LabelRouteOptions {
  dbClient?: DanettiDbClient;
  service?: LabelStudioService;
  databaseUrl?: string;
  now?: () => Date;
}

export async function registerLabelRoutes(
  server: FastifyInstance,
  options: LabelRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;
  let service = options.service ?? null;
  await server.register(multipart, { limits: { files: 1, fileSize: 20 * 1024 * 1024 } });
  server.addHook("onClose", async () => {
    if (!options.dbClient && dbClient) await dbClient.close();
  });
  const context = {
    getService: () => {
      if (service) return service;
      dbClient ??= createDbClient(options.databaseUrl);
      service = new LabelStudioService(dbClient.sql, options.now);
      return service;
    },
  };
  await registerLabelTemplateRoutes(server, context);
  await registerLabelDesignRoutes(server, context);
  await registerLabelAssetRoutes(server, context);
  await registerLabelOrderRoutes(server, context);
  await registerLabelExportRoutes(server, context);
}
