import type { MultipartFile } from "@fastify/multipart";
import type { FastifyInstance } from "fastify";
import JSZip from "jszip";
import { basename, extname } from "node:path";
import {
  bodyRecord,
  handleLabelError,
  paramsRecord,
  queryRecord,
  type LabelRouteContext,
} from "../route-utils.js";
import { LabelStudioError } from "../labels.service.js";

export async function registerLabelAssetRoutes(
  server: FastifyInstance,
  context: LabelRouteContext
): Promise<void> {
  server.get("/label-assets", async (_request, reply) => {
    try {
      return { items: await context.getService().listAssets() };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/label-assets", async (request, reply) => {
    try {
      const body = bodyRecord(request.body);
      return reply
        .code(201)
        .send({ item: await context.getService().patchAsset(String(body.id ?? ""), body) });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/label-assets/fonts", async (request, reply) => {
    try {
      const file = await request.file();
      const uploads = await readFontUploads(file);
      const query = queryRecord(request.query);
      const requestedId = String(query.id ?? "");
      if (requestedId && uploads.length !== 1)
        throw new LabelStudioError(
          "font_archive_id",
          "ZIP feltöltéshez nem adható egyetlen font asset azonosító; töltsd fel külön a fontot."
        );
      const items = await context.getService().uploadFonts(uploads, requestedId);
      return reply.code(201).send({ item: items[0], items });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.patch("/label-assets/:id", async (request, reply) => {
    try {
      return {
        item: await context
          .getService()
          .patchAsset(paramsRecord(request.params).id!, bodyRecord(request.body)),
      };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.delete("/label-assets/:id", async (request, reply) => {
    try {
      await context.getService().deleteAsset(paramsRecord(request.params).id!);
      return reply.code(204).send();
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.get("/label-assets/:id/download", async (request, reply) => {
    try {
      const result = await context.getService().downloadAsset(paramsRecord(request.params).id!);
      return reply
        .header("content-type", String(result.row.mime_type))
        .header(
          "content-disposition",
          `attachment; filename*=UTF-8''${encodeURIComponent(String(result.row.filename))}`
        )
        .send(result.bytes);
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
}

async function readFont(
  file: MultipartFile | undefined
): Promise<{ filename: string; mimetype: string; bytes: Buffer }> {
  if (!file) throw new LabelStudioError("font_missing", "Válassz feltöltendő fontfájlt.");
  return { filename: file.filename, mimetype: file.mimetype, bytes: await file.toBuffer() };
}

async function readFontUploads(
  file: MultipartFile | undefined
): Promise<Array<{ filename: string; mimetype: string; bytes: Buffer }>> {
  const upload = await readFont(file);
  const extension = extname(upload.filename).toLowerCase();
  if (extension !== ".zip") return [upload];
  if (upload.bytes.length === 0 || upload.bytes.length > 20 * 1024 * 1024)
    throw new LabelStudioError(
      "font_archive_size",
      "A font ZIP mérete 1 bájt és 20 MB között lehet."
    );
  let archive: JSZip;
  try {
    archive = await JSZip.loadAsync(upload.bytes, { checkCRC32: true, createFolders: false });
  } catch {
    throw new LabelStudioError(
      "font_archive_invalid",
      "A feltöltött ZIP nem olvasható vagy sérült."
    );
  }
  const entries = Object.values(archive.files).filter((entry) => !entry.dir);
  if (!entries.length)
    throw new LabelStudioError("font_archive_empty", "A ZIP nem tartalmaz fontfájlt.");
  if (entries.length > 48)
    throw new LabelStudioError(
      "font_archive_entries",
      "Egy font ZIP legfeljebb 48 fájlt tartalmazhat."
    );
  const uploads: Array<{ filename: string; mimetype: string; bytes: Buffer }> = [];
  let uncompressedTotal = 0;
  for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name))) {
    const sourceName = entry.unsafeOriginalName ?? entry.name;
    if (isUnsafeArchivePath(sourceName))
      throw new LabelStudioError(
        "font_archive_path",
        "A ZIP nem tartalmazhat könyvtárból kilépő vagy abszolút fájlnevet."
      );
    const entryExtension = extname(sourceName).toLowerCase();
    if (!SUPPORTED_FONT_EXTENSIONS.has(entryExtension)) continue;
    const declaredSize = Number(
      (entry as unknown as { _data?: { uncompressedSize?: number } })._data?.uncompressedSize ?? 0
    );
    if (!Number.isSafeInteger(declaredSize) || declaredSize < 0 || declaredSize > 20 * 1024 * 1024)
      throw new LabelStudioError(
        "font_archive_entry_size",
        `A(z) ${basename(sourceName)} fontfájl túl nagy vagy érvénytelen.`
      );
    uncompressedTotal += declaredSize;
    if (uncompressedTotal > 60 * 1024 * 1024)
      throw new LabelStudioError(
        "font_archive_uncompressed_size",
        "A ZIP kibontott fontjai együtt legfeljebb 60 MB-osak lehetnek."
      );
    const bytes = await entry.async("nodebuffer");
    if (!bytes.length || bytes.length > 20 * 1024 * 1024)
      throw new LabelStudioError(
        "font_archive_entry_size",
        `A(z) ${basename(sourceName)} fontfájl mérete érvénytelen.`
      );
    uploads.push({
      filename: basename(sourceName),
      mimetype: mimeTypeForFont(entryExtension),
      bytes,
    });
  }
  if (!uploads.length)
    throw new LabelStudioError(
      "font_archive_no_fonts",
      "A ZIP-ben nincs támogatott OTF, TTF, WOFF vagy WOFF2 font."
    );
  return uploads;
}

const SUPPORTED_FONT_EXTENSIONS = new Set([".otf", ".ttf", ".woff", ".woff2"]);

function isUnsafeArchivePath(value: string): boolean {
  return (
    value.startsWith("/") ||
    value.startsWith("\\") ||
    /^[A-Za-z]:/.test(value) ||
    value.split(/[\\/]/).includes("..")
  );
}

function mimeTypeForFont(extension: string): string {
  return (
    {
      ".otf": "font/otf",
      ".ttf": "font/ttf",
      ".woff": "font/woff",
      ".woff2": "font/woff2",
    }[extension] ?? "application/octet-stream"
  );
}
