import { upgradeLabelScene, validateScene, type LabelScene } from "@danetti/label-engine";

type Query = (query: string, parameters?: unknown[]) => Promise<unknown>;
type Row = Record<string, unknown>;
export async function migrateStoredLabelScenes(
  query: Query,
  remap: (scene: LabelScene) => LabelScene
): Promise<void> {
  const result =
    await query(`SELECT d.id, d.current_version_id, dv.version, dv.scene, dv.template_version_id
    FROM label_designs d JOIN label_design_versions dv ON dv.id = d.current_version_id FOR UPDATE OF d`);
  for (const row of (Array.isArray(result) ? result : []) as Row[]) {
    const current = validateScene(row.scene).scene;
    if (!current) continue;
    let legacy: LabelScene | undefined;
    if (
      current.brand === "bean_on" &&
      (current.metadata.layoutVersion ?? 0) >= 2 &&
      (current.metadata.layoutVersion ?? 0) < 6
    ) {
      const versions = await query(
        `SELECT scene FROM label_design_versions WHERE design_id=$1
        AND COALESCE(scene->'metadata'->>'layoutVersion','0') IN ('0','1')
        ORDER BY version DESC LIMIT 1`,
        [row.id]
      );
      const old = (Array.isArray(versions) ? versions[0] : undefined) as Row | undefined;
      legacy = (old && validateScene(old.scene).scene) || undefined;
    }
    const upgraded = upgradeLabelScene(current, legacy);
    if (!upgraded) continue;
    const next = remap(upgraded);
    if (!validateScene(next).scene)
      throw new Error("A címke elrendezésfrissítése érvénytelen eredményt adott.");
    const counts = await query(
      "SELECT COALESCE(MAX(version),0)+1 AS version FROM label_design_versions WHERE design_id=$1",
      [row.id]
    );
    const nextVersion = Number(
      (Array.isArray(counts) ? (counts[0] as Row) : undefined)?.version ?? Number(row.version) + 1
    );
    const versions = await query(
      `INSERT INTO label_design_versions (design_id, template_version_id, version, scene, note)
      VALUES ($1,$2,$3,$4::jsonb,$5) RETURNING id`,
      [
        row.id,
        row.template_version_id,
        nextVersion,
        JSON.stringify(next),
        next.metadata.hondurasBackgroundRestored && !current.metadata.hondurasBackgroundRestored
          ? next.background.rgb !== current.background.rgb
            ? "Honduras eredeti #69FC0D referencia-háttérszínének helyreállítása – szöveg, QR, formázás és korábbi verziók megőrzésével"
            : "Honduras egyszeri háttérjavításának ellenőrzése – saját szín és formázás megőrzésével"
          : current.brand === "utopia"
            ? "Utopia 200 g, forgalmazó és QR lábléc – saját felső tartalom és korábbi verziók megőrzésével"
            : current.brand === "bean_on" && current.metadata.layoutVersion === 9
              ? "Felső függőleges szeparátor illesztése az alsó vízszinteshez – saját tartalom és korábbi verziók megőrzésével"
              : "Egységes 7 pt adat-, ízjegy- és alsó betűméret, illeszkedő szövegkeretek – saját címformázás, tartalom és korábbi verziók megőrzésével",
      ]
    );
    const versionId = (Array.isArray(versions) ? versions[0] : undefined) as Row | undefined;
    if (!versionId?.id) throw new Error("A címke frissítési verziója nem hozható létre.");
    await query(
      `UPDATE label_designs SET current_version_id=$2, revision=revision+1, updated_at=now() WHERE id=$1`,
      [row.id, versionId.id]
    );
    // Frozen orders and historical exports keep their original version; active drafts follow the upgraded label.
    await query(
      `WITH changed AS (
      UPDATE label_order_items i SET design_version_id=$2 FROM label_orders o
      WHERE i.order_id=o.id AND o.status='draft' AND i.design_id=$1 AND i.design_version_id=$3 RETURNING i.order_id
    ) UPDATE label_orders SET revision=revision+1, updated_at=now() WHERE id IN (SELECT order_id FROM changed)`,
      [row.id, versionId.id, row.current_version_id]
    );
  }
}
