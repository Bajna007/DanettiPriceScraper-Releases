import type { FastifyInstance } from "fastify";
import { createDbClient, type DanettiDbClient } from "@danetti/db";
import { WindowsSecretStore, type SecretStore } from "../../security/secret-store.js";
import { OpenAiChatGptPlanConnection } from "./openai.connection.js";
import { EprError, safeCode } from "./epr.errors.js";
import { EprService } from "./epr.service.js";
import { MailboxService } from "./mailbox.service.js";
import { DocumentArchive } from "./document.archive.js";
import {
  OpenAiDocumentIntelligenceProvider,
  DOCUMENT_SYSTEM_PROMPT,
  EXTRACTOR_VERSION,
} from "./document.provider.js";
import { EprScanCoordinator } from "./epr.scan.js";
import { z } from "zod";

export async function registerEprRoutes(
  server: FastifyInstance,
  options: { client?: DanettiDbClient; secrets?: SecretStore } = {}
) {
  let client = options.client;
  let connection: OpenAiChatGptPlanConnection | undefined;
  const secrets = options.secrets ?? new WindowsSecretStore();
  let service: EprService | undefined,
    mailboxes: MailboxService | undefined,
    coordinator: EprScanCoordinator | undefined;
  function ai() {
    client ??= createDbClient();
    connection ??= new OpenAiChatGptPlanConnection(client, secrets);
    return connection;
  }
  function domain() {
    ai();
    service ??= new EprService(
      client!,
      new DocumentArchive(),
      new OpenAiDocumentIntelligenceProvider(connection!)
    );
    return service;
  }
  function mailbox() {
    ai();
    mailboxes ??= new MailboxService(client!, secrets);
    return mailboxes;
  }
  function scans() {
    coordinator ??= new EprScanCoordinator(domain(), mailbox());
    return coordinator;
  }
  server.addHook("onListen", async () => {
    void scans()
      .recover()
      .catch(() => undefined);
  });
  server.addHook("onClose", async () => {
    if (coordinator) await coordinator.close();
    if (!options.client && client) await client.close();
  });
  server.addHook("onRequest", async (request, reply) => {
    if (!request.url.startsWith("/epr") || ["GET", "HEAD", "OPTIONS"].includes(request.method))
      return;
    const origin = request.headers.origin;
    if (origin && !/^http:\/\/(localhost|127\.0\.0\.1):3000$/.test(origin)) {
      return reply.code(403).send({
        error: {
          code: "epr_local_origin_required",
          message: "A művelet csak a helyi Danetti felületről indítható.",
        },
      });
    }
    if (request.headers["x-danetti-epr"] !== "1") {
      return reply.code(403).send({
        error: {
          code: "epr_local_header_required",
          message: "A művelet csak a helyi Danetti felületről indítható.",
        },
      });
    }
  });
  server.setErrorHandler((error, _request, reply) => {
    reply.code(error instanceof EprError ? error.httpStatus : 503).send({
      error: {
        code: safeCode(error),
        message: "A művelet nem fejeződött be. Ellenőrizd a kapcsolatot és próbáld újra.",
      },
    });
  });
  server.get("/epr/ai/status", async () => ai().getStatus());
  server.post("/epr/ai/auth/start", async () => ai().startAuthorization());
  server.get<{ Params: { id: string } }>("/epr/ai/auth/attempt/:id", async (request) =>
    ai().attemptStatus(request.params.id)
  );
  server.get<{ Params: { id: string } }>(
    "/epr/ai/auth/open/:id",
    { logLevel: "silent" },
    async (request, reply) => {
      reply.header("Cache-Control", "no-store").header("Referrer-Policy", "no-referrer");
      return reply.redirect(await ai().authorizationUrl(request.params.id));
    }
  );
  server.get<{ Querystring: Record<string, string | undefined> }>(
    "/auth/openai/callback",
    { logLevel: "silent" },
    async (request, reply) => {
      reply
        .header("Cache-Control", "no-store")
        .header("Referrer-Policy", "no-referrer")
        .header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'");
      let text = "ChatGPT kapcsolat létrejött. Ezt az ablakot bezárhatod.";
      try {
        await ai().callback(request.query);
      } catch (error) {
        text =
          safeCode(error) === "chatgpt_auth_cancelled"
            ? "A csatlakoztatás megszakadt."
            : "A ChatGPT kapcsolat nem jött létre. Térj vissza a Danetti beállításaihoz.";
        reply.code(400);
      }
      return reply
        .type("text/html; charset=utf-8")
        .send(
          `<!doctype html><html lang="hu"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Danetti</title><body style="font:16px Segoe UI,sans-serif;padding:48px;background:#eef4f2;color:#101820"><h1>Danetti</h1><p>${text}</p></body></html>`
        );
    }
  );
  server.post("/epr/ai/disconnect", async () => ai().disconnect());
  server.get("/epr/ai/models", async () => ({ items: await ai().models() }));
  server.put<{ Body: { model: string } }>("/epr/ai/model", async (request) => {
    if (typeof request.body?.model !== "string") throw new EprError("chatgpt_model_invalid");
    await ai().selectModel(request.body.model);
    return ai().getStatus();
  });
  server.post("/epr/ai/test", async () => {
    const result = await ai().infer(
      [{ role: "user", content: "Reply exactly: DANETTI_OK" }],
      "Return only the requested connection-test text."
    );
    if (result.trim() !== "DANETTI_OK") throw new EprError("chatgpt_connection_test_failed", 502);
    return { success: true };
  });
  type Id = { Params: { id: string } };
  function id(value: string) {
    if (!z.uuid().safeParse(value).success) throw new EprError("invalid_uuid");
    return value;
  }
  server.get("/epr/periods", async () => ({ items: await domain().periods() }));
  server.post<{ Body: { code: string } }>("/epr/periods", async (request) =>
    domain().createPeriod(request.body?.code ?? "")
  );
  server.put<Id>("/epr/periods/:id/settings", async (request) =>
    domain().configurePeriod(id(request.params.id), request.body)
  );
  server.get<Id>("/epr/periods/:id/summary", async (request) =>
    domain().summary(id(request.params.id))
  );
  server.get<Id>("/epr/periods/:id/purchases", async (request) => ({
    items: await domain().listPurchases(id(request.params.id)),
  }));
  server.post<Id>("/epr/periods/:id/scan", async (request) => {
    await scans().recover();
    return scans().enqueue(id(request.params.id));
  });
  server.get<Id>("/epr/periods/:id/scan", async (request) => scans().latest(id(request.params.id)));
  server.get<Id>("/epr/scan-runs/:id", async (request) => scans().status(id(request.params.id)));
  server.get<Id>("/epr/purchases/:id", async (request) => domain().detail(id(request.params.id)));
  server.post<Id>("/epr/purchases/:id/review", async (request) =>
    domain().reviewPurchase(id(request.params.id), request.body)
  );
  server.put<Id>("/epr/lines/:id", async (request) =>
    domain().editLine(id(request.params.id), request.body)
  );
  server.post<Id & { Body: { reason: string } }>("/epr/lines/:id/exclude", async (request) =>
    domain().excludeLine(id(request.params.id), request.body.reason)
  );
  server.post<Id & { Body: { targetPeriodId: string; reason: string } }>(
    "/epr/purchases/:id/move",
    async (request) =>
      domain().movePurchase(
        id(request.params.id),
        id(request.body.targetPeriodId),
        request.body.reason
      )
  );
  server.post<Id & { Body: { reason: string } }>("/epr/documents/:id/exclude", async (request) =>
    domain().resolveDocumentConflict(id(request.params.id), request.body.reason)
  );
  server.post<Id>("/epr/periods/:id/recalculate", async (request) => {
    await domain().recalculate(id(request.params.id));
    return domain().summary(id(request.params.id));
  });
  server.post<Id>("/epr/periods/:id/close", async (request) =>
    domain().close(id(request.params.id), "local-operator")
  );
  server.get<Id>("/epr/periods/:id/export", async (request, reply) => {
    const result = await domain().export(id(request.params.id));
    return reply
      .header("Cache-Control", "no-store")
      .header("Content-Disposition", `attachment; filename="${result.filename}"`)
      .type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
      .send(result.bytes);
  });
  server.get("/epr/rules", async () => ({ items: await domain().rules() }));
  server.get("/epr/unresolved-products", async () => ({
    items: await domain().unresolvedProducts(),
  }));
  server.get("/epr/archive/status", async () => domain().archiveStatus());
  server.post("/epr/rules", async (request) => domain().createRule(request.body));
  server.get("/epr/recognition-rules", async () => ({ items: await domain().recognitionRules() }));
  server.post("/epr/recognition-rules", async (request) => domain().saveRecognition(request.body));
  server.delete<Id>("/epr/recognition-rules/:id", async (request) => {
    await domain().removeRecognition(id(request.params.id));
    return { success: true };
  });
  server.get("/epr/conversions", async () => ({ items: await domain().conversions() }));
  server.post("/epr/conversions", async (request) => domain().saveConversion(request.body));
  server.get("/epr/mailboxes", async () => ({ items: await mailbox().list() }));
  server.post("/epr/mailboxes", async (request) => mailbox().save(request.body));
  server.put<Id>("/epr/mailboxes/:id", async (request) =>
    mailbox().save(request.body, id(request.params.id))
  );
  server.delete<Id>("/epr/mailboxes/:id", async (request) => {
    await mailbox().remove(id(request.params.id));
    return { success: true };
  });
  server.post<Id>("/epr/mailboxes/:id/test", async (request) =>
    mailbox().test(id(request.params.id))
  );
  server.put<Id & { Body: { folders: string[]; enabled: boolean } }>(
    "/epr/mailboxes/:id/folders",
    async (request) =>
      mailbox().setFolders(id(request.params.id), request.body.folders, request.body.enabled)
  );
  server.get<Id>("/epr/documents/:id", async (request) => domain().document(id(request.params.id)));
  server.get<Id>("/epr/documents/:id/content", async (request, reply) => {
    const document = await domain().document(id(request.params.id));
    const bytes = await domain().archive.read(document.hash);
    return reply
      .header("Cache-Control", "no-store")
      .header("X-Content-Type-Options", "nosniff")
      .header("Content-Security-Policy", "sandbox; default-src 'none'")
      .header(
        "Content-Disposition",
        `${document.mime === "application/pdf" ? "inline" : "attachment"}; filename="${document.mime === "application/pdf" ? "invoice.pdf" : "document.txt"}"`
      )
      .type(document.mime === "application/pdf" ? "application/pdf" : "application/octet-stream")
      .send(bytes);
  });
  server.get("/epr/processing-policy", async () => ({
    extractorVersion: EXTRACTOR_VERSION,
    systemPrompt: DOCUMENT_SYSTEM_PROMPT,
    automaticLearning: false,
  }));
  server.post<Id & { Body: { periodId: string; invoice: unknown } }>(
    "/epr/documents/:id/extraction",
    async (request) => {
      await domain().manualExtraction(
        id(request.params.id),
        id(request.body.periodId),
        request.body.invoice
      );
      return { success: true };
    }
  );
  server.post<Id & { Body: { periodId: string } }>(
    "/epr/documents/:id/reprocess",
    async (request) => domain().reprocess(id(request.params.id), id(request.body.periodId))
  );
  server.post<{ Body: { periodId: string; filename: string; mime: string; base64: string } }>(
    "/epr/documents/import",
    { bodyLimit: 28_000_000 },
    async (request) => {
      const parsed = z
        .object({
          periodId: z.uuid(),
          filename: z.string().min(1).max(500),
          mime: z.enum(["application/pdf", "application/json", "application/xml", "text/plain"]),
          base64: z.string().min(1).max(27_000_000),
        })
        .strict()
        .safeParse(request.body);
      if (!parsed.success) throw new EprError("document_upload_invalid");
      return domain().importDocument(parsed.data.periodId, {
        bytes: Buffer.from(parsed.data.base64, "base64"),
        filename: parsed.data.filename,
        mime: parsed.data.mime,
      });
    }
  );
}
