import assert from "node:assert/strict";
import Fastify from "fastify";
import { registerSupplierMappingRoutes } from "./supplier-mappings.routes.js";

const server = Fastify({ logger: false });
await registerSupplierMappingRoutes(server);

try {
  const exact = await server.inject({
    method: "POST",
    url: "/supplier-mappings/dvg/preview",
    payload: {
      expectedArticle: "CS-A2200247",
      parsedDvgArticle: "CS-A2200247",
      parsedOriginalCode: "A2200247",
      currentPriceNetEur: 4.72,
      currency: "EUR",
    },
  });
  assert.equal(exact.statusCode, 200);
  const exactBody = exact.json();
  assert.equal(exactBody.outcome, "trusted_exact_mapping");
  assert.equal(exactBody.priceSnapshotAllowed, true);

  const originalCode = await server.inject({
    method: "POST",
    url: "/supplier-mappings/dvg/preview",
    payload: {
      expectedArticle: "A2200247",
      parsedDvgArticle: "CS-A2200247",
      parsedOriginalCode: "A2200247",
      currentPriceNetEur: 4.72,
      currency: "EUR",
    },
  });
  assert.equal(originalCode.statusCode, 200);
  const originalCodeBody = originalCode.json();
  assert.equal(originalCodeBody.outcome, "needs_review_original_code_match");
  assert.equal(originalCodeBody.priceSnapshotAllowed, false);
  assert.equal(originalCodeBody.suggestedSupplierArticle, "CS-A2200247");

  const sensitive = await server.inject({
    method: "POST",
    url: "/supplier-mappings/dvg/preview",
    payload: {
      expectedArticle: "CS-A2200247",
      parsedDvgArticle: "CS-A2200247",
      credential: "x",
    },
  });
  assert.equal(sensitive.statusCode, 400);
  assert.equal(sensitive.json().error.code, "sensitive_field");
  assert.equal(JSON.stringify(sensitive.json()).includes("x"), false);
} finally {
  await server.close();
}

console.log("Supplier mapping DVG preview route tests passed");
