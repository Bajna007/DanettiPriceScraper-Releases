import assert from "node:assert/strict";
import type { NewSupplierPriceSnapshot, SupplierMapping, SupplierPriceSnapshot } from "@danetti/db";
import Fastify from "fastify";
import type { SupplierSnapshotListFilters } from "./supplier-snapshots.repository.js";
import { registerSupplierSnapshotRoutes } from "./supplier-snapshots.routes.js";
import { persistSupplierPriceSnapshot } from "./supplier-snapshots.service.js";

const supplierId = "11111111-1111-4111-8111-111111111111";
const supplierMappingId = "22222222-2222-4222-8222-222222222222";
const catalogProductId = "33333333-3333-4333-8333-333333333333";
const now = new Date("2026-06-10T10:00:00.000Z");

class InMemorySnapshotRepository {
  readonly snapshots: SupplierPriceSnapshot[] = [];
  failList = false;
  mapping: SupplierMapping | null = {
    id: supplierMappingId,
    catalogProductId,
    supplierId,
    supplierArticleNumber: "CS-A2200247",
    supplierProductNameOverride: null,
    lookupStrategy: "direct_url",
    directUrl: null,
    priority: 100,
    enabled: true,
    isPrimary: true,
    matchValidationMode: "exact_article_number",
    notes: null,
    createdBy: null,
    updatedBy: null,
    createdAt: now,
    updatedAt: now,
  };

  async getMappingById(): Promise<SupplierMapping | null> {
    return this.mapping;
  }

  async insertSnapshot(input: NewSupplierPriceSnapshot): Promise<SupplierPriceSnapshot> {
    const snapshot: SupplierPriceSnapshot = {
      id: `44444444-4444-4444-8444-${String(this.snapshots.length + 1).padStart(12, "0")}`,
      supplierId: input.supplierId,
      supplierMappingId: input.supplierMappingId ?? null,
      catalogProductId: input.catalogProductId ?? null,
      crawlerRunItemId: input.crawlerRunItemId ?? null,
      supplierArticleNumber: input.supplierArticleNumber,
      supplierProductName: input.supplierProductName ?? null,
      priceNetEur: input.priceNetEur ?? null,
      priceGrossEur: input.priceGrossEur ?? null,
      currency: input.currency ?? "EUR",
      stockStatus: input.stockStatus ?? "unknown",
      availabilityText: input.availabilityText ?? null,
      matchConfidence: input.matchConfidence ?? "none",
      resultUrl: input.resultUrl ?? null,
      observedAt: input.observedAt,
      evidenceArtifactId: input.evidenceArtifactId ?? null,
      createdAt: now,
    };
    this.snapshots.push(snapshot);
    return snapshot;
  }

  async listSnapshots(input: SupplierSnapshotListFilters): Promise<SupplierPriceSnapshot[]> {
    if (this.failList) throw new Error("db down password=secret");
    return this.snapshots
      .filter((snapshot) => !input.supplierId || snapshot.supplierId === input.supplierId)
      .filter(
        (snapshot) =>
          !input.supplierMappingId || snapshot.supplierMappingId === input.supplierMappingId
      )
      .filter(
        (snapshot) =>
          !input.catalogProductId || snapshot.catalogProductId === input.catalogProductId
      )
      .filter(
        (snapshot) =>
          !input.supplierArticleNumber ||
          snapshot.supplierArticleNumber === input.supplierArticleNumber
      )
      .slice(input.offset, input.offset + input.limit);
  }

  async getSnapshotById(id: string): Promise<SupplierPriceSnapshot | null> {
    return this.snapshots.find((snapshot) => snapshot.id === id) ?? null;
  }
}

const repository = new InMemorySnapshotRepository();
const persisted = await persistSupplierPriceSnapshot({
  repository,
  data: {
    saveSnapshot: true,
    supplierId,
    supplierMappingId,
    catalogProductId,
    supplierArticleNumber: "CS-A2200247",
    supplierProductName: "TAP VALVE PIAZZA SAN MARCO GROUP",
    priceNetEur: 4.72,
    priceGrossEur: null,
    currency: "EUR",
    stockStatus: "unknown",
    availabilityText: null,
    mappingReviewOutcome: "trusted_saved_mapping",
    snapshotGateAllowed: true,
    blockingSafetyFlags: [],
    resultUrl:
      "https://devecchigiuseppesrl.com/e-commerce/welcome/ordini/dettagli.asp?codice-articolo=CS-A2200247",
    observedAt: now,
  },
});
assert.equal(persisted.snapshot.priceNetEur, 4.72);
assert.equal(repository.snapshots.length, 1);

await assert.rejects(
  () =>
    persistSupplierPriceSnapshot({
      repository,
      data: {
        saveSnapshot: true,
        supplierId,
        supplierMappingId,
        catalogProductId,
        supplierArticleNumber: "CS-A2200247",
        supplierProductName: null,
        priceNetEur: 4.72,
        currency: "USD",
        stockStatus: "unknown",
        availabilityText: null,
        mappingReviewOutcome: "trusted_saved_mapping",
        snapshotGateAllowed: true,
        blockingSafetyFlags: [],
        resultUrl:
          "https://devecchigiuseppesrl.com/e-commerce/welcome/ordini/dettagli.asp?codice-articolo=CS-A2200247",
        observedAt: now,
      },
    }),
  /Only EUR snapshots are allowed/
);

await assert.rejects(
  () =>
    persistSupplierPriceSnapshot({
      repository,
      data: {
        saveSnapshot: true,
        supplierId,
        supplierMappingId,
        catalogProductId,
        supplierArticleNumber: "CS-A2200247",
        supplierProductName: null,
        priceNetEur: Number.NaN,
        currency: "EUR",
        stockStatus: "unknown",
        availabilityText: null,
        mappingReviewOutcome: "trusted_saved_mapping",
        snapshotGateAllowed: true,
        blockingSafetyFlags: [],
        resultUrl:
          "https://devecchigiuseppesrl.com/e-commerce/welcome/ordini/dettagli.asp?codice-articolo=CS-A2200247",
        observedAt: now,
      },
    }),
  /Current supplier price is invalid/
);

const server = Fastify({ logger: false });
await registerSupplierSnapshotRoutes(server, { repository });

try {
  const list = await server.inject({
    method: "GET",
    url: `/supplier-snapshots?supplierId=${supplierId}&supplierMappingId=${supplierMappingId}&catalogProductId=${catalogProductId}&supplierArticleNumber=CS-A2200247&limit=200&offset=0`,
  });
  assert.equal(list.statusCode, 200);
  assert.equal(list.json().items.length, 1);
  assert.equal(list.json().items[0].id, persisted.snapshotId);
  const listJson = JSON.stringify(list.json());
  assert.equal(
    /evidenceArtifactId|password|credential|cookie|storageState|rawHtml/i.test(listJson),
    false
  );

  const invalidUuid = await server.inject({
    method: "GET",
    url: "/supplier-snapshots?supplierId=bad-uuid",
  });
  assert.equal(invalidUuid.statusCode, 400);
  assert.equal(invalidUuid.json().error.code, "invalid_uuid");

  const invalidLimit = await server.inject({ method: "GET", url: "/supplier-snapshots?limit=201" });
  assert.equal(invalidLimit.statusCode, 400);
  assert.equal(invalidLimit.json().error.code, "invalid_query");

  const detail = await server.inject({
    method: "GET",
    url: `/supplier-snapshots/${persisted.snapshotId}`,
  });
  assert.equal(detail.statusCode, 200);
  assert.equal(detail.json().supplierArticleNumber, "CS-A2200247");

  const missing = await server.inject({
    method: "GET",
    url: "/supplier-snapshots/55555555-5555-4555-8555-555555555555",
  });
  assert.equal(missing.statusCode, 404);
  assert.equal(missing.json().error.code, "snapshot_not_found");
} finally {
  await server.close();
}

const unavailableServer = Fastify({ logger: false });
await registerSupplierSnapshotRoutes(unavailableServer, { databaseUrl: undefined });

try {
  const unavailable = await unavailableServer.inject({ method: "GET", url: "/supplier-snapshots" });
  assert.equal(unavailable.statusCode, 503);
  assert.equal(unavailable.json().error.code, "database_unavailable");
  assert.equal(JSON.stringify(unavailable.json()).includes("password"), false);
} finally {
  await unavailableServer.close();
}

console.log("Supplier snapshot route and service tests passed");
