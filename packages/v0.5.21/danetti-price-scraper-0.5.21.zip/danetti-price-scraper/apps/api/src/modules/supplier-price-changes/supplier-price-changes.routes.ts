import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import { guardArticleChanges } from "../dvg-article-changes/dvg-article-changes.routes.js";
import { ArticleChangesError } from "../dvg-article-changes/dvg-article-changes.service.js";
import {
  SupplierPriceChangesRepository,
  type SupplierPriceChangesRepositoryLike,
} from "./supplier-price-changes.repository.js";
import {
  buildSupplierPriceChangeResponse,
  SupplierPriceChangeDatabaseError,
  SupplierPriceChangeValidationError,
  validateSupplierPriceChangeQuery,
} from "./supplier-price-changes.service.js";

interface SupplierPriceChangeRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  repository?: SupplierPriceChangesRepositoryLike;
  now?: () => Date;
}

export async function registerSupplierPriceChangeRoutes(
  server: FastifyInstance,
  options: SupplierPriceChangeRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;
  const now = options.now ?? (() => new Date());

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getRepository(): SupplierPriceChangesRepositoryLike {
    if (options.repository) return options.repository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new SupplierPriceChangesRepository(dbClient.db);
    } catch (error) {
      throw new SupplierPriceChangeDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/supplier-price-changes", async (request, reply) => {
    try {
      const query = validateSupplierPriceChangeQuery(request.query);
      const repository = getRepository();
      const eurHufRate = query.eurHufRate ?? (await repository.getLatestEurHufRate());
      if (eurHufRate === null) {
        throw new SupplierPriceChangeValidationError(
          "eur_huf_rate_required",
          "EUR/HUF exchange rate is required for supplier price changes"
        );
      }
      const rows = await repository.listRecentCatalogSnapshots(
        query.maxSnapshotScan,
        query.supplierScope
      );
      const all = buildSupplierPriceChangeResponse({
        rows,
        query: {
          ...query,
          eurHufRate,
          view: "all",
          fromDate: undefined,
          toDate: undefined,
          direction: "all",
          minChangeHuf: 0,
          minChangePercent: 0,
          offset: 0,
          limit: Number.MAX_SAFE_INTEGER,
        },
      });
      const reviews = await repository.ensureReviews?.(
        all.items.map((row) => ({
          eventId: row.eventId,
          baselineWooGrossHuf: row.baselineWooGrossHuf,
          baselineSource: row.baselineSource,
          decision: "auto",
          decidedAt: null,
        }))
      );
      const corrections = (await repository.findImportedPriceCorrections?.(all.items)) ?? [];
      for (const proof of corrections) {
        const row = all.items.find((item) => item.eventId === proof.eventId);
        const review = reviews?.find((item) => item.eventId === proof.eventId);
        if (!row || !review) continue;
        // Any actual imported own-price change closes the event. Reopening holds
        // it open until a later import, so the same old CSV cannot re-close it.
        const after = Math.max(
          Date.parse(row.changeObservedAt),
          review.decision === "open" ? (review.decidedAt?.getTime() ?? 0) : 0
        );
        if (
          review.baselineWooGrossHuf !== null &&
          Math.round(Number(review.baselineWooGrossHuf) * 100) !==
            Math.round(proof.priceHuf * 100) &&
          proof.finishedAt.getTime() > after &&
          !["resolved", "csv"].includes(review.decision)
        ) {
          if (await repository.decideReview?.(proof.eventId, "csv", proof.finishedAt)) {
            review.decision = "csv";
            review.decidedAt = proof.finishedAt;
          }
        }
        for (const observation of rows)
          if (observation.catalogProductId === row.catalogProductId)
            observation.currentPrice = proof.priceHuf;
      }
      return buildSupplierPriceChangeResponse({
        rows,
        reviews,
        query: { ...query, eurHufRate },
        now: now(),
      });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
  server.post("/supplier-price-changes/review", async (request, reply) => {
    try {
      guardArticleChanges(request);
      const body = request.body as Record<string, unknown> | null;
      if (
        !body ||
        Object.keys(body).some((key) => !["eventId", "decision"].includes(key)) ||
        typeof body.eventId !== "string" ||
        !/^[a-f0-9]{64}$/.test(body.eventId) ||
        !["open", "resolved"].includes(String(body.decision))
      )
        throw new SupplierPriceChangeValidationError(
          "invalid_review",
          "Érvénytelen lezárási művelet."
        );
      const repository = getRepository();
      if (
        !repository.decideReview ||
        !(await repository.decideReview(body.eventId, body.decision as "open" | "resolved", now()))
      )
        throw new SupplierPriceChangeValidationError(
          "review_not_found",
          "A változás nem található. Frissítsd a listát.",
          404
        );
      return { saved: true };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof ArticleChangesError)
    return reply
      .code(error.statusCode)
      .send({ error: { code: "local_review_required", message: error.message } });
  if (error instanceof SupplierPriceChangeValidationError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  if (error instanceof SupplierPriceChangeDatabaseError) {
    return reply
      .code(503)
      .send({ error: { code: "database_unavailable", message: error.message } });
  }
  return reply.code(500).send({
    error: { code: "supplier_price_changes_failed", message: "Supplier price changes API failed" },
  });
}
