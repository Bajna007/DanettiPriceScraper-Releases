import type { FastifyInstance, FastifyRequest } from "fastify";
import type { DanettiDbClient } from "@danetti/db";
import { DvgArticleChangesRepository, createDbClient } from "./dvg-article-changes.repository.js";
import { ArticleChangesError, DvgArticleChangesService } from "./dvg-article-changes.service.js";

export async function registerDvgArticleChangesRoutes(
  server: FastifyInstance,
  options: { service?: DvgArticleChangesService } = {}
) {
  let client: DanettiDbClient | null = null;
  let service = options.service;
  const get = () =>
    (service ??= new DvgArticleChangesService(
      new DvgArticleChangesRepository((client ??= createDbClient()).db)
    ));
  server.addHook("onClose", async () => {
    await service?.close();
    await client?.close();
  });
  const run = async (
    request: FastifyRequest,
    reply: import("fastify").FastifyReply,
    action: () => Promise<unknown>
  ) => {
    try {
      guardArticleChanges(request);
      return await action();
    } catch (error) {
      return reply.code(error instanceof ArticleChangesError ? error.statusCode : 500).send({
        error: {
          code: "dvg_article_changes_error",
          message:
            error instanceof ArticleChangesError
              ? error.message
              : "A cikkszámváltozások nem érhetők el. Ellenőrizd a helyi alkalmazást.",
        },
      });
    }
  };
  server.get("/dvg-article-changes", (request, reply) => run(request, reply, () => get().list()));
  server.post("/dvg-article-changes/run", (request, reply) =>
    run(request, reply, async () => {
      const input = validateArticleChangesInput(request.body);
      reply.code(202);
      return get().start(input.catalogProductIds, input.speedMode);
    })
  );
  server.post("/dvg-article-changes/cancel", (request, reply) =>
    run(request, reply, () => get().cancel())
  );
}

export function guardArticleChanges(request: FastifyRequest) {
  if (request.headers["x-danetti-local-lab"] !== "true")
    throw new ArticleChangesError(403, "Ez a művelet csak a helyi operátorból indítható.");
  if (process.env.NODE_ENV === "production" && process.env.ENABLE_SUPPLIER_SESSION_LAB !== "true")
    throw new ArticleChangesError(403, "A beszállítói ellenőrzés nincs engedélyezve.");
  const origin = request.headers.origin ?? request.headers.referer;
  if (origin) {
    try {
      const url = new URL(origin);
      if (
        url.protocol !== "http:" ||
        url.port !== "3000" ||
        !["localhost", "127.0.0.1", "[::1]"].includes(url.hostname)
      )
        throw Error();
    } catch {
      throw new ArticleChangesError(403, "A helyi Danetti oldalt használd.");
    }
  }
}

export function validateArticleChangesInput(body: unknown): {
  catalogProductIds?: string[];
  speedMode?: "normal" | "fast" | "very_fast";
} {
  if (!body || typeof body !== "object" || Array.isArray(body))
    throw new ArticleChangesError(400, "Érvénytelen ellenőrzési beállítás.");
  const input = body as Record<string, unknown>;
  if (Object.keys(input).some((key) => !["catalogProductIds", "speedMode"].includes(key)))
    throw new ArticleChangesError(400, "Nem támogatott ellenőrzési beállítás.");
  if (
    input.speedMode !== undefined &&
    !["normal", "fast", "very_fast"].includes(String(input.speedMode))
  )
    throw new ArticleChangesError(400, "Érvénytelen sebesség.");
  const ids = input.catalogProductIds;
  if (
    ids !== undefined &&
    (!Array.isArray(ids) ||
      !ids.length ||
      ids.length > 500 ||
      ids.some(
        (id) =>
          typeof id !== "string" ||
          !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(id)
      ) ||
      new Set(ids).size !== ids.length)
  )
    throw new ArticleChangesError(400, "Érvénytelen termékkijelölés.");
  return {
    catalogProductIds: ids as string[] | undefined,
    speedMode: input.speedMode as "normal" | "fast" | "very_fast" | undefined,
  };
}
