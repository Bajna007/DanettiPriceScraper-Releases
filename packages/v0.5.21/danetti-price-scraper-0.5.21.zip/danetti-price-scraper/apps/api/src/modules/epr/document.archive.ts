import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile, realpath, lstat } from "node:fs/promises";
import { homedir } from "node:os";
import { join, resolve, relative, isAbsolute } from "node:path";
import { EprError } from "./epr.errors.js";

export const MAX_DOCUMENT_BYTES = 20_000_000;
export class DocumentArchive {
  readonly root: string;
  constructor(
    root = join(
      process.env.LOCALAPPDATA ?? join(homedir(), ".local", "share"),
      "DanettiPriceScraper",
      "documents"
    )
  ) {
    this.root = resolve(root);
  }
  private path(hash: string) {
    if (!/^[a-f0-9]{64}$/.test(hash)) throw new EprError("document_hash_invalid");
    return join(this.root, hash.slice(0, 2), hash);
  }
  async put(bytes: Buffer) {
    if (!bytes.length || bytes.length > MAX_DOCUMENT_BYTES)
      throw new EprError("document_size_invalid");
    const hash = createHash("sha256").update(bytes).digest("hex"),
      path = this.path(hash);
    await mkdir(join(this.root, hash.slice(0, 2)), { recursive: true });
    await this.assertContained(path);
    try {
      await writeFile(path, bytes, { flag: "wx", mode: 0o600 });
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      const existing = await this.read(hash);
      if (!existing.equals(bytes)) throw new EprError("document_archive_conflict");
    }
    return { hash, bytes: bytes.length };
  }
  private async assertContained(path: string) {
    const root = await realpath(this.root),
      parent = await realpath(join(this.root, path.slice(-64, -62)));
    const rel = relative(root, parent);
    if (rel.startsWith("..") || isAbsolute(rel))
      throw new EprError("document_archive_path_invalid");
  }
  async read(hash: string) {
    const path = this.path(hash);
    await this.assertContained(path);
    if ((await lstat(path)).isSymbolicLink()) throw new EprError("document_archive_path_invalid");
    const bytes = await readFile(path);
    if (
      bytes.length > MAX_DOCUMENT_BYTES ||
      createHash("sha256").update(bytes).digest("hex") !== hash
    )
      throw new EprError("document_archive_integrity_failed");
    return bytes;
  }
}
