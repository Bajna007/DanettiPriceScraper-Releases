import assert from "node:assert/strict";
import {
  buildDanettiDiagramHtml,
  extractDiagramCodes,
  parseCardHtmlName,
  parseDvgDiagramDetail,
  parseSelectOptions,
  slugify,
} from "./dvg-diagrams.service.js";

const listingHtml = `
  <select name="CategoriaMenu3">
    <option value="">Choose</option>
    <option value="ASTORIA">Astoria</option>
    <option value="SAN MARCO">La San Marco</option>
  </select>
  <script>showCard({ CodiceArticolo: 'EU01' });</script>
  <a href="/e-commerce/diagrams/index.asp?codice-articolo=EU02">diagram</a>
`;

assert.deepEqual(parseSelectOptions(listingHtml, "CategoriaMenu3"), [
  { value: "ASTORIA", label: "Astoria" },
  { value: "SAN MARCO", label: "La San Marco" },
]);
assert.deepEqual(extractDiagramCodes(listingHtml), ["EU01", "EU02"]);
assert.equal(slugify("Rancilio - Promac"), "rancilio-promac");
assert.equal(
  parseCardHtmlName(`<span class="price"><strong>
    969 - ELBA IV PUMPS AND VALVES
  </strong></span>`),
  "969 - ELBA IV PUMPS AND VALVES"
);

const linkOnlyHtml = `
  <div class="stile-categorie">
    <a href="/e-commerce/cerca.asp?c2=COFFEE%20MACHINES%20-%20Diagrams&c3=WEGA">Wega</a>
  </div>
`;

assert.deepEqual(parseSelectOptions(linkOnlyHtml, "CategoriaMenu3"), [
  { value: "WEGA", label: "Wega" },
]);

const detailHtml = `
  <img src="/e-commerce/welcome/assiemi/EU01.jpg" width="1200" height="900" usemap="#image-map" />
  <map name="image-map" id="image-map">
    <area shape="rect" coords="10,20,30,40" href="/e-commerce/welcome/ordini/dettagli.asp?codice-articolo=EU51040013" />
    <area shape="rect" coords="50,60,70,80" data-code="EU123" href="#" />
    <area shape="rect" coords=" 565, 569, 657, 584 " href="../ordini/dettagli.asp?CodiceArticolo=8C465285010" />
    <area shape="rect" coords="90,100,110,120" href="https://www.dvg.coffee/e-commerce/richiesta-articolo.asp?q=M.1.113" />
    <area shape="rect" coords="130,140,150,160" href="/e-commerce/welcome/ordini/dettagli.asp" />
    <area shape="rect" href="#" />
  </map>
`;

const parsed = parseDvgDiagramDetail(
  detailHtml,
  "https://devecchigiuseppesrl.com/e-commerce/diagrams/index.asp?codice-articolo=EU01"
);
assert.equal(
  parsed.imageSrc,
  "https://devecchigiuseppesrl.com/e-commerce/welcome/assiemi/EU01.jpg"
);
assert.equal(parsed.imageWidth, 1200);
assert.equal(parsed.imageHeight, 900);
assert.equal(parsed.areas.length, 4);
assert.equal(parsed.skippedAreaCount, 1);
assert.deepEqual(parsed.areas[0], { shape: "rect", coords: "10,20,30,40", code: "EU51040013" });
assert.deepEqual(parsed.areas[2], {
  shape: "rect",
  coords: "565,569,657,584",
  code: "8C465285010",
});
assert.deepEqual(parsed.areas[3], { shape: "rect", coords: "90,100,110,120", code: "M.1.113" });

const html = buildDanettiDiagramHtml({
  imageSrc: "__DANETTI_IMAGE_URL__/eu01.jpg",
  width: 1200,
  height: 900,
  alt: "EU01 alkatrész robbantott ábra",
  areas: parsed.areas,
});
assert.match(html, /usemap="#Map"/);
assert.match(html, /<map name="Map" id="Map">/);
assert.match(html, /href="\/search\/EU51040013"/);
assert.match(html, /coords="10,20,30,40"/);
assert.doesNotMatch(html, /dettagli\.asp/);

console.log("DVG diagram parser tests passed");
