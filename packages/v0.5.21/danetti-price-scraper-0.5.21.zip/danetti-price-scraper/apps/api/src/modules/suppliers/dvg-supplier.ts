import { DVG_ALLOWED_DOMAIN, DVG_CONNECTOR_ID, DVG_DISPLAY_NAME } from "@danetti/connectors";
import { suppliers, type DanettiDatabase, type NewSupplier, type Supplier } from "@danetti/db";
import { eq } from "drizzle-orm";

export const canonicalDvgSupplier = {
  code: DVG_CONNECTOR_ID,
  name: DVG_DISPLAY_NAME,
  baseUrl: `https://${DVG_ALLOWED_DOMAIN}`,
  enabled: true,
  allowedDomains: [DVG_ALLOWED_DOMAIN],
  supportedLookupStrategies: ["direct_url"],
  defaultRateLimitPerMinute: 6,
  healthStatus: "unknown",
} satisfies NewSupplier;

export async function getOrCreateDvgSupplier(db: DanettiDatabase): Promise<Supplier> {
  const existing = await findDvgSupplier(db);
  if (existing !== null) return existing;

  const [created] = await db
    .insert(suppliers)
    .values(canonicalDvgSupplier)
    .onConflictDoNothing({ target: suppliers.code })
    .returning();

  if (created !== undefined) return created;

  const concurrent = await findDvgSupplier(db);
  if (concurrent === null) throw new Error("Failed to create DVG supplier");
  return concurrent;
}

async function findDvgSupplier(db: DanettiDatabase): Promise<Supplier | null> {
  const [supplier] = await db
    .select()
    .from(suppliers)
    .where(eq(suppliers.code, DVG_CONNECTOR_ID))
    .limit(1);
  return supplier ?? null;
}
