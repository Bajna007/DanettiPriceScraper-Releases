import assert from "node:assert/strict";
import type { SupplierCheckSettings } from "@danetti/db";
import { DEFAULT_PORTAL_AUDIT_CHECKS } from "./supplier-portal-audits.checklist.js";
import {
  assertAuditCanBeApproved,
  buildSafePortalAuditExport,
  buildSupplierPortalConnectorPlan,
  createDefaultChecklistRows,
  evaluateSupplierPortalAuditReadiness,
  validateCreatePortalAuditInput,
  validateEvidenceNoteInput,
} from "./supplier-portal-audits.service.js";
import {
  PortalAuditValidationError,
  type PortalAuditDetail,
} from "./supplier-portal-audits.types.js";

const supplierId = "11111111-1111-4111-8111-111111111111";
const auditId = "22222222-2222-4222-8222-222222222222";

const audit = validateCreatePortalAuditInput({ supplierId, auditTitle: "Supplier audit" });
assert.equal(audit.status, "draft");
assert.equal(audit.supplierId, supplierId);

const defaultChecks = createDefaultChecklistRows(auditId);
assert.equal(defaultChecks.length, DEFAULT_PORTAL_AUDIT_CHECKS.length);

assert.throws(
  () => validateCreatePortalAuditInput({ supplierId, auditTitle: "Audit", password: "redacted" }),
  PortalAuditValidationError
);

for (const content of [
  "password=redacted",
  "cookie: redacted",
  "set-cookie: redacted",
  "authorization: redacted",
  "Bearer abcdefghijklmnop",
  "storageState data must never be stored",
  "localStorage dump must never be stored",
  "sessionId=redacted",
]) {
  assert.throws(
    () =>
      validateEvidenceNoteInput({
        title: "bad",
        evidenceType: "manual_note",
        content,
      }),
    PortalAuditValidationError
  );
}

const passedChecks = defaultChecks.map((check, index) => ({
  ...check,
  id: `33333333-3333-4333-8333-${String(index).padStart(12, "0")}`,
  status: "pass" as const,
  notes: null,
  createdAt: new Date(),
  updatedAt: new Date(),
}));

const settings: SupplierCheckSettings = {
  id: "44444444-4444-4444-8444-444444444444",
  supplierId,
  productsPerMinute: 6,
  delayBetweenProductsSeconds: 10,
  jitterMinSeconds: 1,
  jitterMaxSeconds: 5,
  maxRetriesPerItem: 1,
  navigationTimeoutSeconds: 30,
  itemTimeoutSeconds: 60,
  stopAfterConsecutiveFailures: 5,
  stopOnSafetyEvent: true,
  stopOnCartChange: true,
  enabled: true,
  createdAt: new Date(),
  updatedAt: new Date(),
};

const approvable = makeAudit({ status: "in_review" });
assert.doesNotThrow(() => assertAuditCanBeApproved(approvable, passedChecks));

const notApprovedReadiness = evaluateSupplierPortalAuditReadiness(
  makeAudit({ status: "in_review" }),
  passedChecks
);
assert.equal(notApprovedReadiness.ready, false);
assert.ok(notApprovedReadiness.missingRequiredFields.includes("status=approved"));

const missingSafetyReadiness = evaluateSupplierPortalAuditReadiness(
  makeAudit({ status: "approved", hasCaptcha: null, safetyNotes: null }),
  passedChecks
);
assert.equal(missingSafetyReadiness.ready, false);
assert.ok(missingSafetyReadiness.missingRequiredFields.includes("hasCaptcha"));
assert.ok(missingSafetyReadiness.missingRequiredFields.includes("safetyNotes"));

const incompleteChecklistReadiness = evaluateSupplierPortalAuditReadiness(
  makeAudit({ status: "approved" }),
  passedChecks.map((check, index) =>
    index === 0 ? { ...check, status: "unknown" as const } : check
  )
);
assert.equal(incompleteChecklistReadiness.ready, false);
assert.ok(incompleteChecklistReadiness.failingChecks.includes("login_flow_documented"));

const postWarningReadiness = evaluateSupplierPortalAuditReadiness(
  makeAudit({ status: "approved", searchMethod: "POST", allowedMethods: ["GET", "POST"] }),
  passedChecks
);
assert.equal(postWarningReadiness.ready, true);
assert.ok(
  postWarningReadiness.warnings.some((warning) => warning.includes("POST search is documented"))
);

const readyAudit = makeAudit({ status: "approved" });
const ready = evaluateSupplierPortalAuditReadiness(readyAudit, passedChecks);
assert.equal(ready.ready, true);
assert.equal(ready.recommendedStrategy, "search_result");
assert.deepEqual(ready.missingRequiredFields, []);
assert.deepEqual(ready.failingChecks, []);
assert.equal(ready.nextAction, "Ready for connector implementation prompt");

const connectorPlan = buildSupplierPortalConnectorPlan(readyAudit, settings);
assert.equal(connectorPlan.readiness.ready, true);
assert.equal(connectorPlan.connectorPlan.rateLimitSettings.productsPerMinute, 6);
assert.ok(connectorPlan.connectorPlan.safetyStopRules.some((rule) => rule.includes("cart change")));

const exportPayload = buildSafePortalAuditExport(
  {
    ...readyAudit,
    evidenceNotes: [
      {
        id: "55555555-5555-4555-8555-555555555555",
        auditId,
        title: "Selector note",
        evidenceType: "selector_note",
        content: "raw evidence note content omitted from export",
        containsSensitiveData: false,
        createdBy: "operator",
        createdAt: new Date(),
      },
    ],
  },
  settings
);
assert.equal(exportPayload.evidenceNotes.length, 1);
assert.equal("content" in exportPayload.evidenceNotes[0], false);
assert.equal(JSON.stringify(exportPayload).includes("raw evidence note content"), false);

function makeAudit(overrides: Partial<PortalAuditDetail> = {}): PortalAuditDetail {
  return {
    id: auditId,
    supplierId,
    supplierCode: "supplier_1",
    supplierName: "Supplier 1",
    status: "approved",
    auditTitle: "Audit",
    portalBaseUrl: "https://supplier.example.invalid",
    loginUrl: "https://supplier.example.invalid/login",
    has2fa: false,
    hasCaptcha: false,
    hasAccountLockRisk: false,
    loginFlowNotes: "Manual login documented without credentials.",
    sessionLifetimeNotes: "Manual session lifetime noted.",
    searchUrl: "/search?q={sku}",
    searchMethod: "GET",
    searchInputNotes: "Search field documented.",
    skuExactMatchRequired: true,
    resultPageType: "search_result",
    priceVisibleOn: "Search result price column.",
    stockVisibleOn: "Search result stock column.",
    availabilityTextNotes: "Availability text documented.",
    productIdentityNotes: "Article number and product name visible.",
    cartIndicatorSelector: "[data-cart-count]",
    dangerousUrlPatterns: ["/cart", "/checkout", "/order", "/quote"],
    allowedUrlPatterns: ["/login", "/search", "/product"],
    allowedDomains: ["supplier.example.invalid"],
    allowedMethods: ["GET"],
    allowedPostPatterns: [],
    suggestedRateLimitPerMinute: 6,
    parserNotes: "Parser notes documented.",
    evidenceExpectations: "Text-only evidence expected.",
    knownBlockers: "None.",
    goNoGoDecision: "Go when approved.",
    openQuestions: "",
    auditNotes: "Audit notes documented.",
    safetyNotes: "Stop on unsafe domain, unsafe method, CAPTCHA, account lock and cart change.",
    reviewedBy: null,
    reviewedAt: null,
    approvedBy: null,
    approvedAt: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    checks: passedChecks,
    evidenceNotes: [],
    ...overrides,
  };
}

console.log("Supplier portal audit validation tests passed");
