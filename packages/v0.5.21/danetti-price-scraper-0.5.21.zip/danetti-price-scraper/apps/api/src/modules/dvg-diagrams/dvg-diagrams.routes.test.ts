import assert from "node:assert/strict";
import Fastify from "fastify";
import { registerDvgDiagramRoutes } from "./dvg-diagrams.routes.js";
import type {
  DvgDiagramFamily,
  DvgDiagramGenerateInput,
  DvgDiagramListInput,
  DvgDiagramConvertInput,
  DvgDiagramServiceLike,
} from "./dvg-diagrams.service.js";

let capturedGenerateInput: DvgDiagramGenerateInput | null = null;

const service: DvgDiagramServiceLike = {
  async listBrands(family: DvgDiagramFamily) {
    return [{ family, label: "Astoria", value: "ASTORIA" }];
  },
  async listDiagrams(input: DvgDiagramListInput) {
    return {
      family: input.family,
      brand: input.brand,
      generatedAt: "2026-07-01T00:00:00.000Z",
      warnings: [],
      items: [
        {
          family: input.family,
          familyLabel: "Kávégép",
          brand: input.brand,
          model: "ARGENTA",
          diagramCode: "EU01",
          diagramName: null,
          sourcePageUrl:
            "https://devecchigiuseppesrl.com/e-commerce/diagrams/index.asp?codice-articolo=EU01",
        },
      ],
    };
  },
  async convertDiagram(input: DvgDiagramConvertInput) {
    return {
      family: input.family,
      familyLabel: "Kávégép",
      brand: input.brand,
      model: input.model ?? null,
      diagramCode: input.diagramCode,
      diagramName: "RANCILIO - GRUPPO EROGAZIONE",
      sourcePageUrl:
        "https://devecchigiuseppesrl.com/e-commerce/diagrams/index.asp?codice-articolo=EU01",
      sourceImageUrl: "https://devecchigiuseppesrl.com/e-commerce/welcome/assiemi/EU01.jpg",
      imageUrl: input.imageUrl ?? "__DANETTI_IMAGE_URL__/eu01.jpg",
      imageWidth: 1200,
      imageHeight: 900,
      areaCount: 1,
      skippedAreaCount: 0,
      html: `<img src="${input.imageUrl ?? "__DANETTI_IMAGE_URL__/eu01.jpg"}" usemap="#Map" width="1200" height="900" />`,
      outputImagePath: "artifacts/dvg-diagrams/astoria/EU01.jpg",
      warnings: [],
    };
  },
  async generate(input: DvgDiagramGenerateInput) {
    capturedGenerateInput = input;
    return {
      generatedAt: "2026-07-01T00:00:00.000Z",
      outputDir: "artifacts/dvg-diagrams/test",
      placeholderBaseUrl: input.placeholderBaseUrl ?? "__DANETTI_IMAGE_URL__",
      requestedBrands: input.brands,
      warnings: [],
      items: [
        {
          family: input.family,
          familyLabel: "Kávégép",
          brand: input.brands[0] ?? "ASTORIA",
          model: null,
          diagramCode: "EU01",
          sourcePageUrl:
            "https://devecchigiuseppesrl.com/e-commerce/diagrams/index.asp?codice-articolo=EU01",
          sourceImageUrl: "https://devecchigiuseppesrl.com/e-commerce/welcome/assiemi/EU01.jpg",
          outputImagePath: "artifacts/dvg-diagrams/test/eu01.jpg",
          outputHtmlPath: "artifacts/dvg-diagrams/test/eu01.html",
          imageFilename: "eu01.jpg",
          htmlFilename: "eu01.html",
          imageWidth: 1200,
          imageHeight: 900,
          areaCount: 1,
          skippedAreaCount: 0,
          html: "<map></map>",
          warnings: [],
        },
      ],
    };
  },
};

const server = Fastify({ logger: false });
await registerDvgDiagramRoutes(server, { service });

try {
  const brands = await server.inject({ method: "GET", url: "/dvg-diagrams/brands?family=coffee" });
  assert.equal(brands.statusCode, 200);
  assert.equal(brands.json().family, "coffee");
  assert.deepEqual(brands.json().items, [{ family: "coffee", label: "Astoria", value: "ASTORIA" }]);

  const missingFamily = await server.inject({ method: "GET", url: "/dvg-diagrams/brands" });
  assert.equal(missingFamily.statusCode, 400);
  assert.equal(missingFamily.json().error.code, "dvg_diagram_family_invalid");

  const diagrams = await server.inject({
    method: "GET",
    url: "/dvg-diagrams/diagrams?family=coffee&brand=ASTORIA&maxDiagrams=7",
  });
  assert.equal(diagrams.statusCode, 200);
  assert.equal(diagrams.json().items[0].diagramCode, "EU01");
  assert.equal(diagrams.json().items[0].model, "ARGENTA");

  const converted = await server.inject({
    method: "POST",
    url: "/dvg-diagrams/convert",
    payload: {
      family: "coffee",
      brand: "ASTORIA",
      model: "ARGENTA",
      diagramCode: "EU01",
      imageUrl: "https://danetti.hu/eu01.jpg",
    },
  });
  assert.equal(converted.statusCode, 200);
  assert.equal(converted.json().imageUrl, "https://danetti.hu/eu01.jpg");
  assert.match(converted.json().html, /https:\/\/danetti\.hu\/eu01\.jpg/);

  const missingImage = await server.inject({
    method: "GET",
    url: "/dvg-diagrams/image?brand=astoria&code=NOEXIST",
  });
  assert.equal(missingImage.statusCode, 500);

  const rawBrandImage = await server.inject({
    method: "GET",
    url: "/dvg-diagrams/image?brand=Rancilio%20-%20Promac&code=NOEXIST",
  });
  assert.equal(rawBrandImage.statusCode, 500);
  assert.notEqual(rawBrandImage.json().error.code, "dvg_diagram_image_invalid");

  const boundary = "----danetti-dvg-diagram-test";
  const body = [
    multipartField(boundary, "family", "coffee"),
    multipartField(boundary, "brands", JSON.stringify(["ASTORIA"])),
    multipartField(boundary, "maxDiagramsPerBrand", "7"),
    multipartField(boundary, "maxPagesPerListing", "2"),
    multipartField(boundary, "placeholderBaseUrl", "__UPLOAD__"),
    multipartFile(boundary, "logo", "logo.png", "image/png", "fake-logo"),
    `--${boundary}--\r\n`,
  ].join("");

  const generated = await server.inject({
    method: "POST",
    url: "/dvg-diagrams/generate",
    headers: { "content-type": `multipart/form-data; boundary=${boundary}` },
    payload: body,
  });
  assert.equal(generated.statusCode, 201);
  assert.equal(generated.json().items.length, 1);
  const captured = capturedGenerateInput as DvgDiagramGenerateInput | null;
  assert.ok(captured);
  assert.equal(captured.family, "coffee");
  assert.deepEqual(captured.brands, ["ASTORIA"]);
  assert.equal(captured.maxDiagramsPerBrand, 7);
  assert.equal(captured.maxPagesPerListing, 2);
  assert.equal(captured.placeholderBaseUrl, "__UPLOAD__");
  assert.equal(captured.logoBuffer.toString("utf8"), "fake-logo");
} finally {
  await server.close();
}

function multipartField(boundary: string, name: string, value: string): string {
  return `--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`;
}

function multipartFile(
  boundary: string,
  name: string,
  filename: string,
  contentType: string,
  value: string
): string {
  return `--${boundary}\r\nContent-Disposition: form-data; name="${name}"; filename="${filename}"\r\nContent-Type: ${contentType}\r\n\r\n${value}\r\n`;
}

console.log("DVG diagram route tests passed");
