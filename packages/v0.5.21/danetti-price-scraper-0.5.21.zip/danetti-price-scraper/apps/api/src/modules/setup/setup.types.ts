import type {
  RuntimeDependencyStatus,
  RuntimeWorkerHealth,
  RuntimeOverallStatus,
} from "../health/runtime-health.types.js";

export type SetupStepStatus =
  | RuntimeDependencyStatus
  | RuntimeOverallStatus
  | RuntimeWorkerHealth["status"];

export interface SetupStatusStep {
  key: string;
  label: string;
  status: SetupStepStatus;
  message: string;
  action: string | null;
}

export interface SetupStatusResponse {
  status: RuntimeOverallStatus;
  generatedAt: string;
  steps: SetupStatusStep[];
  commands: string[];
  safetyNotes: string[];
}
