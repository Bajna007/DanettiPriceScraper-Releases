import { LF_ALLOWED_DOMAIN, LF_CONNECTOR_ID, LF_DISPLAY_NAME } from "@danetti/connectors";
import { suppliers, type DanettiDatabase, type NewSupplier, type Supplier } from "@danetti/db";
import { eq } from "drizzle-orm";

export const canonicalLfSupplier = {
  code: LF_CONNECTOR_ID,
  name: LF_DISPLAY_NAME,
  baseUrl: `https://${LF_ALLOWED_DOMAIN}`,
  enabled: true,
  allowedDomains: [LF_ALLOWED_DOMAIN],
  supportedLookupStrategies: ["search_then_detail"],
  defaultRateLimitPerMinute: 6,
  healthStatus: "unknown",
} satisfies NewSupplier;

export async function getOrCreateLfSupplier(db: DanettiDatabase): Promise<Supplier> {
  const existing = await findLfSupplier(db);
  if (existing !== null) return existing;

  const [created] = await db
    .insert(suppliers)
    .values(canonicalLfSupplier)
    .onConflictDoNothing({ target: suppliers.code })
    .returning();

  if (created !== undefined) return created;

  const concurrent = await findLfSupplier(db);
  if (concurrent === null) throw new Error("Failed to create LF supplier");
  return concurrent;
}

async function findLfSupplier(db: DanettiDatabase): Promise<Supplier | null> {
  const [supplier] = await db
    .select()
    .from(suppliers)
    .where(eq(suppliers.code, LF_CONNECTOR_ID))
    .limit(1);
  return supplier ?? null;
}
