import assert from "node:assert/strict";
import { getRuntimeHealth } from "./runtime-health.service.js";

const missingAll = await getRuntimeHealth({ env: {} });
assert.equal(missingAll.status, "error");
assert.equal(missingAll.database.status, "missing_config");
assert.equal(missingAll.redis.status, "missing_config");

const failedDatabase = await getRuntimeHealth({
  env: {
    DATABASE_URL: "postgresql://user:pass@localhost:5432/db",
    REDIS_URL: "redis://localhost:6379",
  },
  checkDatabase: async () => {
    throw new Error("connection refused");
  },
  checkRedis: async () => undefined,
});
assert.equal(failedDatabase.status, "error");
assert.equal(failedDatabase.database.status, "unavailable");
assert.equal(failedDatabase.redis.status, "ok");

const failedRedis = await getRuntimeHealth({
  env: {
    DATABASE_URL: "postgresql://user:pass@localhost:5432/db",
    REDIS_URL: "redis://localhost:6379",
  },
  checkDatabase: async () => undefined,
  checkRedis: async () => {
    throw new Error("connection refused");
  },
});
assert.equal(failedRedis.status, "degraded");
assert.equal(failedRedis.database.status, "ok");
assert.equal(failedRedis.redis.status, "unavailable");

const missingRedis = await getRuntimeHealth({
  env: { DATABASE_URL: "postgresql://user:pass@localhost:5432/db" },
  checkDatabase: async () => undefined,
});
assert.equal(missingRedis.status, "degraded");
assert.equal(missingRedis.database.status, "ok");
assert.equal(missingRedis.redis.status, "missing_config");

const healthy = await getRuntimeHealth({
  env: {
    DATABASE_URL: "postgresql://user:pass@localhost:5432/db",
    REDIS_URL: "redis://localhost:6379",
    DANETTI_LAUNCHER_RUN_ID: "test-launcher-run",
  },
  checkDatabase: async () => undefined,
  checkRedis: async () => undefined,
});
assert.equal(healthy.status, "ok");
assert.equal(healthy.database.status, "ok");
assert.equal(healthy.redis.status, "ok");
assert.equal(healthy.worker.status, "not_checked");
assert.equal(healthy.launcher.runId, "test-launcher-run");

console.log("Runtime health checks passed");
