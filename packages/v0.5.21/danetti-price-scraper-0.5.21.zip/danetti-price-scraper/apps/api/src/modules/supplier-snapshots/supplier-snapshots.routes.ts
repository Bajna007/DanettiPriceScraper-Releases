import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import {
  SupplierSnapshotsRepository,
  type SupplierSnapshotsRepositoryLike,
} from "./supplier-snapshots.repository.js";
import {
  SupplierSnapshotDatabaseError,
  SupplierSnapshotValidationError,
  summarizeSnapshot,
  validateSnapshotIdParam,
  validateSupplierSnapshotListQuery,
} from "./supplier-snapshots.service.js";

interface SupplierSnapshotRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
  repository?: SupplierSnapshotsRepositoryLike;
}

interface IdParams {
  id: string;
}

export async function registerSupplierSnapshotRoutes(
  server: FastifyInstance,
  options: SupplierSnapshotRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getRepository(): SupplierSnapshotsRepositoryLike {
    if (options.repository) return options.repository;
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new SupplierSnapshotsRepository(dbClient.db);
    } catch (error) {
      throw new SupplierSnapshotDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/supplier-snapshots", async (request, reply) => {
    try {
      const query = validateSupplierSnapshotListQuery(request.query);
      const snapshots = await getRepository().listSnapshots(query);
      return {
        items: snapshots.map(summarizeSnapshot),
        limit: query.limit,
        offset: query.offset,
      };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-snapshots/:id", async (request, reply) => {
    try {
      const id = validateSnapshotIdParam((request.params as IdParams).id);
      const snapshot = await getRepository().getSnapshotById(id);
      if (snapshot === null) {
        return reply
          .code(404)
          .send({ error: { code: "snapshot_not_found", message: "Supplier snapshot not found" } });
      }
      return summarizeSnapshot(snapshot);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

export function handleSupplierSnapshotRouteError(reply: FastifyReply, error: unknown) {
  return handleRouteError(reply, error);
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof SupplierSnapshotValidationError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  if (error instanceof SupplierSnapshotDatabaseError) {
    return reply
      .code(503)
      .send({ error: { code: "database_unavailable", message: error.message } });
  }
  return reply
    .code(500)
    .send({ error: { code: "supplier_snapshot_failed", message: "Supplier snapshot API failed" } });
}
