import { randomUUID, createHash } from "node:crypto";
import { isSupplierRunActive } from "@danetti/shared";
import {
  DvgManualSessionBatchRunner,
  buildDvgShopDetailUrl,
  type DvgManualBatchSettings,
  type DvgManualBatchRow,
  type DvgManualBatchCallbacks,
} from "@danetti/connectors";
import type {
  SupplierArticleChangesState,
  SupplierArticleChangeItem,
  SupplierArticleChangeStatus,
} from "@danetti/shared";
import type {
  ArticleChangesRepository,
  ArticleReviewRow,
} from "./dvg-article-changes.repository.js";
import {
  acquireSupplierSession,
  releaseSupplierSession,
} from "../dvg-products/dvg-session-lock.js";

export interface ArticleChangeAdapter {
  supplier: "dvg" | "lf";
  originalUrl(row: ArticleReviewRow): string;
  validUrl(url: string): boolean;
  priceBasis: NonNullable<ArticleReviewRow["priceBasis"]>;
}
export const dvgArticleChangeAdapter: ArticleChangeAdapter = {
  supplier: "dvg",
  originalUrl: (row) => buildDvgShopDetailUrl(row.supplierArticleNumber, "new_shop").toString(),
  validUrl: (value) => {
    try {
      const u = new URL(value);
      return (
        u.origin === "https://shop.dvgdevecchi.com" &&
        !u.username &&
        !u.password &&
        !u.search &&
        !u.hash &&
        u.pathname.startsWith("/e-commerce/item-details/")
      );
    } catch {
      return false;
    }
  },
  priceBasis: "blue_unit_price_lowest_quantity",
};
type ReviewCallbacks = Omit<DvgManualBatchCallbacks, "onRow"> & {
  onRow?: (row: ArticleReviewRow) => void;
};

export const isArticleChangeJobActive = isSupplierRunActive;
type ReviewRunner = Pick<
  DvgManualSessionBatchRunner,
  "openBrowser" | "waitForManualLogin" | "runCandidates" | "cancel" | "close"
>;
export type ReviewRunnerFactory = (callbacks: ReviewCallbacks) => ReviewRunner;

export class ArticleChangesError extends Error {
  constructor(
    readonly statusCode: number,
    message: string
  ) {
    super(message);
  }
}

export class DvgArticleChangesService {
  private state: SupplierArticleChangesState = {
    items: [],
    job: null,
    sourceRunId: null,
    updatedAt: new Date().toISOString(),
  };
  private loaded: Promise<void> | null = null;
  private runner: ReviewRunner | null = null;
  private task: Promise<void> | null = null;
  private cancelRequested = false;
  constructor(
    private readonly repository: ArticleChangesRepository,
    private readonly factory: ReviewRunnerFactory = (callbacks) =>
      new DvgManualSessionBatchRunner(callbacks, "new_shop"),
    private readonly adapter: ArticleChangeAdapter = dvgArticleChangeAdapter
  ) {}

  private async load() {
    this.loaded ??= (async () => {
      const saved = await this.repository.load();
      if (saved) this.state = saved;
      this.state.resolved ??= [];
      this.state.closedItems ??= [];
      this.state.items = this.state.items.map((item) => ({
        ...item,
        supplier: this.adapter.supplier,
      }));
      if (isArticleChangeJobActive(this.state.job?.status)) {
        this.state.job!.status = "interrupted";
        this.state.job!.finishedAt = new Date().toISOString();
        this.state.job!.message =
          "Az alkalmazás újraindult. Az ellenőrzés újraindítható, a mentett eredmények megmaradtak.";
        await this.repository.save(this.state);
      }
    })();
    try {
      await this.loaded;
    } catch (error) {
      this.loaded = null;
      throw error;
    }
  }

  async list(): Promise<SupplierArticleChangesState> {
    await this.load();
    if (!this.runner) {
      const source = await this.repository.source();
      // Older local versions retained only the CSV proof. Keep that history
      // visible without inventing the price which was not archived with it.
      for (const proof of this.state.resolved ?? []) {
        if (
          this.state.closedItems!.some(
            (item) =>
              item.catalogProductId === proof.catalogProductId &&
              item.originalArticle === proof.originalArticle
          )
        )
          continue;
        const row = source?.rows.find(
          (item) =>
            item.catalogProductId === proof.catalogProductId &&
            item.supplierArticleNumber === proof.originalArticle
        );
        this.state.closedItems!.push({
          supplier: this.adapter.supplier,
          catalogProductId: proof.catalogProductId,
          wooSku: row?.wooSku ?? proof.newSku,
          wooName: row?.wooName ?? proof.newSku,
          originalArticle: proof.originalArticle,
          originalUrl: row ? this.adapter.originalUrl(row) : "",
          sourceStatus: row?.status ?? "article_changed",
          status: "needs_review",
          newArticle: proof.newArticle,
          newArticleVerified: proof.reason !== "manual" && !!proof.newArticle,
          newUrl: null,
          productName: null,
          chain: [],
          priceEur: null,
          priceHuf: null,
          wooGrossHuf: row?.wooGrossHuf ?? null,
          wooNetHuf: row?.wooNetHuf ?? null,
          profitNetHuf: null,
          profitPercent: null,
          eurHufRate: null,
          vatPercent: row?.vatPercent ?? 27,
          checkedAt: null,
          warnings: [],
          resolution: {
            reason: proof.reason ?? "csv",
            resolvedAt: proof.resolvedAt,
            importRunId: proof.importRunId,
          },
        });
      }
      const revision = source
        ? createHash("sha256")
            .update(
              JSON.stringify([
                source.runId,
                source.completedAt,
                source.rows.map((row) => [
                  row.catalogProductId,
                  row.supplierArticleNumber,
                  row.status,
                  row.dvgArticle,
                  row.dvgDetailUrl,
                  row.replacementTargets,
                  row.replacementResult,
                ]),
              ])
            )
            .digest("hex")
        : null;
      if (source && revision !== this.state.sourceRevision) {
        const byId = new Map(this.state.items.map((item) => [item.catalogProductId, item]));
        for (const row of source.rows) {
          if (
            this.state.resolved?.some(
              (item) =>
                item.catalogProductId === row.catalogProductId &&
                item.originalArticle === row.supplierArticleNumber
            )
          )
            continue;
          if (!["article_changed", "item_not_available", "article_not_found"].includes(row.status))
            continue;
          const previous = byId.get(row.catalogProductId);
          if (previous?.originalArticle === row.supplierArticleNumber) {
            previous.sourceStatus = row.status;
            if (previous.status === "pending") {
              const target = replacementCandidate(row, this.adapter);
              previous.newArticle ??= target?.article ?? null;
              previous.newUrl ??= target?.url ?? null;
              if (row.replacementResult)
                byId.set(
                  row.catalogProductId,
                  articleChangeResult(previous, row.replacementResult, this.adapter)
                );
            }
            continue;
          }
          const status: SupplierArticleChangeStatus =
            row.status === "item_not_available"
              ? "discontinued"
              : row.status === "article_not_found"
                ? "missing"
                : "pending";
          const target = replacementCandidate(row, this.adapter);
          const item: SupplierArticleChangeItem = {
            supplier: this.adapter.supplier,
            catalogProductId: row.catalogProductId,
            wooSku: row.wooSku,
            wooName: row.wooName,
            originalArticle: row.supplierArticleNumber,
            originalUrl: this.adapter.originalUrl(row),
            sourceStatus: row.status,
            status,
            newArticle:
              target?.article ??
              (row.status === "article_changed" &&
              row.dvgArticle &&
              row.dvgArticle !== row.supplierArticleNumber
                ? row.dvgArticle
                : null),
            newUrl:
              target?.url ??
              (row.status === "article_changed" &&
              row.dvgArticle &&
              row.dvgArticle !== row.supplierArticleNumber &&
              this.adapter.validUrl(row.dvgDetailUrl)
                ? row.dvgDetailUrl
                : null),
            newArticleVerified: false,
            productName: null,
            chain: [],
            priceEur: null,
            priceHuf: null,
            wooGrossHuf: row.wooGrossHuf,
            wooNetHuf: row.wooNetHuf,
            profitNetHuf: null,
            profitPercent: null,
            eurHufRate: null,
            vatPercent: row.vatPercent,
            checkedAt: status === "pending" ? null : source.completedAt,
            warnings: row.warnings,
          };
          byId.set(
            row.catalogProductId,
            row.replacementResult
              ? articleChangeResult(item, row.replacementResult, this.adapter)
              : item
          );
        }
        this.state.items = [...byId.values()];
        this.state.sourceRunId = source.runId;
        this.state.sourceRevision = revision!;
        await this.persist();
      }
      const missingIdentities = this.state.items.filter((item) => !item.wooProductId);
      const identities = missingIdentities.length
        ? await this.repository.catalogIdentities?.(
            missingIdentities.map((item) => item.catalogProductId)
          )
        : undefined;
      if (identities?.size) {
        for (const item of this.state.items)
          if (!item.wooProductId && identities.has(item.catalogProductId))
            item.wooProductId = identities.get(item.catalogProductId)!;
        await this.persist();
      }
      const corrections = (await this.repository.catalogCorrections?.(this.state.items)) ?? [];
      if (corrections.length) {
        for (const correction of corrections) {
          const item = this.state.items.find(
            (item) => item.catalogProductId === correction.catalogProductId
          );
          if (item?.newArticle) {
            const resolvedAt = new Date().toISOString();
            this.state.closedItems!.push({
              ...item,
              resolution: { reason: "csv", resolvedAt, importRunId: correction.importRunId },
            });
            this.state.resolved!.push({
              supplier: this.adapter.supplier,
              catalogProductId: item.catalogProductId,
              originalArticle: item.originalArticle,
              newArticle: item.newArticle,
              newSku: correction.newSku,
              importRunId: correction.importRunId,
              resolvedAt,
              reason: "csv",
            });
          }
        }
        const correctedIds = new Set(corrections.map((item) => item.catalogProductId));
        this.state.items = this.state.items.filter(
          (item) => !correctedIds.has(item.catalogProductId)
        );
        await this.persist();
      }
    }
    return structuredClone(this.state);
  }

  async review(catalogProductId: string, originalArticle: string, decision: "resolved" | "open") {
    await this.list();
    if (this.runner) throw new ArticleChangesError(409, "Várd meg az ellenőrzés végét.");
    const from = decision === "resolved" ? this.state.items : this.state.closedItems!;
    const index = from.findIndex(
      (item) =>
        item.catalogProductId === catalogProductId && item.originalArticle === originalArticle
    );
    if (index < 0)
      throw new ArticleChangesError(404, "A tétel állapota megváltozott. Frissítsd a listát.");
    const item = from.splice(index, 1)[0]!;
    if (decision === "resolved") {
      const resolvedAt = new Date().toISOString();
      this.state.closedItems!.push({ ...item, resolution: { reason: "manual", resolvedAt } });
      this.state.resolved!.push({
        supplier: this.adapter.supplier,
        catalogProductId,
        originalArticle,
        newArticle: item.newArticle,
        newSku: item.wooSku,
        importRunId: null,
        resolvedAt,
        reason: "manual",
      });
    } else {
      delete item.resolution;
      item.reviewOpenedAt = new Date().toISOString();
      this.state.items.push(item);
      this.state.resolved = this.state.resolved!.filter(
        (proof) =>
          proof.catalogProductId !== catalogProductId || proof.originalArticle !== originalArticle
      );
    }
    await this.persist();
    return structuredClone(this.state);
  }

  async start(
    ids: string[] | undefined,
    speedMode: DvgManualBatchSettings["speedMode"] = "very_fast"
  ) {
    await this.list();
    if (this.runner) throw new ArticleChangesError(409, "Már fut cikkszám-ellenőrzés.");
    const source = await this.repository.source();
    if (!source)
      throw new ArticleChangesError(
        400,
        "Előbb indíts lekérést a kiválasztott beszállító operátorában."
      );
    const settings: DvgManualBatchSettings = {
      ...source.settings,
      shopMode: "new_shop",
      speedMode,
      offset: 0,
      limit: 10000,
      onlyMappedDvg: true,
      rerunPreviousNonOkOnly: false,
      allowSuggestedDvgArticle: false,
      allowSkuPrefixCandidate: false,
      dryRun: true,
      allowSnapshotWrite: false,
      followReplacements: true,
      itemTimeoutMs: 90000,
      fallbackNavigationTimeoutMs: 20000,
    };
    const rate = await this.repository.exchangeRate();
    if (!(rate && rate > 0))
      throw new ArticleChangesError(
        400,
        "Állíts be érvényes EUR/HUF árfolyamot az Árváltozások oldalon."
      );
    settings.eurHufRate = rate;
    const selected = this.state.items.filter((item) =>
      ids ? ids.includes(item.catalogProductId) : item.sourceStatus === "article_changed"
    );
    if (!selected.length || (ids && selected.length !== new Set(ids).size))
      throw new ArticleChangesError(400, "Nincs ellenőrizhető kijelölt termék.");
    const candidates = await this.repository.candidates(settings);
    const selectedById = new Map(selected.map((item) => [item.catalogProductId, item]));
    const work = candidates.filter(
      (candidate) =>
        selectedById.get(candidate.catalogProductId)?.originalArticle ===
        candidate.supplierArticleNumber
    );
    if (work.length !== selected.length)
      throw new ArticleChangesError(
        409,
        "A termékpárosítás közben megváltozott. Frissítsd az oldalt és ellenőrizd a párosítást."
      );
    const runId = `dvg-article-changes-${randomUUID()}`;
    if (!acquireSupplierSession(this.adapter.supplier, runId))
      throw new ArticleChangesError(
        409,
        `Másik ${this.adapter.supplier.toUpperCase()} futás használja a böngészőt. Várd meg a végét.`
      );
    this.cancelRequested = false;
    let writes = Promise.resolve();
    let writeFailed = false;
    const save = () => {
      const snapshot = structuredClone(this.state);
      writes = writes
        .then(() => this.repository.save(snapshot))
        .catch(() => {
          writeFailed = true;
          void this.runner?.cancel().catch(() => undefined);
        });
    };
    this.state.job = {
      supplier: this.adapter.supplier,
      runId,
      status: "opening_browser",
      checked: 0,
      total: work.length,
      currentArticle: null,
      startedAt: new Date().toISOString(),
      finishedAt: null,
      message: null,
    };
    const callbacks: ReviewCallbacks = {
      onStatus: (status) => {
        if (this.cancelRequested) return;
        this.state.job!.status = status;
        save();
      },
      onCurrentItem: (item) => {
        this.state.job!.currentArticle = item?.supplierArticleNumber ?? null;
      },
      onRow: (row) => {
        if (this.cancelRequested) return;
        const original = selectedById.get(row.catalogProductId)!;
        const result = articleChangeResult(original, row, this.adapter);
        this.state.items = this.state.items.map((item) =>
          item.catalogProductId === row.catalogProductId ? result : item
        );
        this.state.job!.checked++;
        this.state.updatedAt = new Date().toISOString();
        save();
      },
    };
    try {
      this.runner = this.factory(callbacks);
      await this.persist();
    } catch (error) {
      this.runner = null;
      this.state.job!.status = "failed";
      this.state.job!.finishedAt = new Date().toISOString();
      this.state.job!.message =
        "Az ellenőrzés nem indult el. Próbáld újra a beszállítói profil ellenőrzése után.";
      await this.persist().catch(() => undefined);
      releaseSupplierSession(this.adapter.supplier, runId);
      throw error;
    }
    const runner = this.runner;
    this.task = (async () => {
      try {
        await runner.openBrowser();
        if (await runner.waitForManualLogin(120000)) await runner.runCandidates(work, settings);
        else if (isArticleChangeJobActive(this.state.job?.status))
          this.state.job!.status = "login_timeout";
      } catch {
        if (!this.cancelRequested) {
          this.state.job!.status = "failed";
          this.state.job!.message =
            "Az ellenőrzés nem fejeződött be. Ellenőrizd a beszállítói profilt, majd indítsd újra.";
        }
      } finally {
        await runner.close().catch(() => undefined);
        await writes;
        if (writeFailed) {
          this.state.job!.status = "failed";
          this.state.job!.message =
            "Az eredmények mentése sikertelen. Ellenőrizd a helyi adatbázist.";
        }
        this.state.job!.finishedAt = new Date().toISOString();
        this.state.job!.currentArticle = null;
        try {
          await this.persist();
        } catch {
          this.state.job!.status = "failed";
          this.state.job!.message = "A végső állapot mentése sikertelen.";
        }
        this.runner = null;
        releaseSupplierSession(this.adapter.supplier, runId);
      }
    })();
    return structuredClone(this.state);
  }

  async cancel() {
    await this.load();
    if (this.runner) {
      if (isArticleChangeJobActive(this.state.job?.status)) {
        this.cancelRequested = true;
        this.state.job!.status = "cancelled";
        await this.runner.cancel();
      }
      await this.task;
    }
    return structuredClone(this.state);
  }
  async close() {
    await this.cancel();
  }
  async settled() {
    await this.task;
  }
  private async persist() {
    this.state.updatedAt = new Date().toISOString();
    await this.repository.save(structuredClone(this.state));
  }
}

function replacementCandidate(row: ArticleReviewRow, adapter: ArticleChangeAdapter) {
  const targets = row.replacementTargets ?? [];
  return row.status === "article_changed" &&
    row.dvgArticle === row.supplierArticleNumber &&
    targets.length === 1 &&
    targets[0]!.article !== row.supplierArticleNumber &&
    adapter.validUrl(targets[0]!.url)
    ? targets[0]
    : undefined;
}

export function articleChangeResult(
  original: SupplierArticleChangeItem,
  row: ArticleReviewRow,
  adapter: ArticleChangeAdapter = dvgArticleChangeAdapter
): SupplierArticleChangeItem {
  const chain = row.replacementChain ?? [];
  const linked = chain.length > 1;
  const validChain =
    chain.length >= 1 &&
    chain.length <= 4 &&
    chain[0]?.article === original.originalArticle &&
    chain[0]?.url === original.originalUrl &&
    chain.at(-1)?.article === row.supplierArticleNumber &&
    chain.at(-1)?.url === row.dvgDetailUrl &&
    chain.every((link) => adapter.validUrl(link.url));
  const valid =
    validChain &&
    row.status === "ok" &&
    row.supplierNetEur !== null &&
    row.supplierNetEur > 0 &&
    row.currency === "EUR" &&
    row.dvgArticle === row.supplierArticleNumber &&
    row.priceBasis === adapter.priceBasis;
  const status: SupplierArticleChangeStatus = valid
    ? linked
      ? "priced"
      : "original_priced"
    : row.status === "item_not_available" ||
        (row.status === "article_changed" &&
          (row.warnings.includes("dvg_supplier_not_in_production") ||
            row.warnings.includes("lf_item_no_longer_in_production")) &&
          !row.replacementTargets?.length)
      ? "discontinued"
      : row.status === "article_not_found"
        ? "missing"
        : row.status === "price_missing"
          ? "unpriced"
          : row.status === "article_changed" || row.status === "ambiguous_match"
            ? "needs_review"
            : "failed";
  return {
    ...original,
    wooSku: row.wooSku,
    wooName: row.wooName,
    status,
    newArticle: linked ? row.supplierArticleNumber : null,
    newArticleVerified:
      validChain &&
      linked &&
      row.dvgArticle === row.supplierArticleNumber &&
      (row.status === "ok" || row.status === "price_missing"),
    newUrl: linked ? row.dvgDetailUrl : null,
    productName: row.dvgProductName,
    chain,
    priceEur: valid ? row.supplierNetEur : null,
    priceHuf: valid ? row.supplierNetHuf : null,
    wooGrossHuf: row.wooGrossHuf,
    wooNetHuf: row.wooNetHuf,
    profitNetHuf: valid ? row.actualProfitNetHuf : null,
    profitPercent: valid ? row.actualProfitPercentOnCost : null,
    eurHufRate: row.eurHufRate,
    vatPercent: row.vatPercent,
    checkedAt: new Date().toISOString(),
    warnings: row.warnings,
  };
}
