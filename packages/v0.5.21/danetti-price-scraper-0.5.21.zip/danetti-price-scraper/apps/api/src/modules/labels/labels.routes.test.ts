import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import Fastify from "fastify";
import JSZip from "jszip";
import { LabelStudioError, type LabelStudioService } from "./labels.service.js";
import { registerLabelRoutes } from "./labels.routes.js";

const BOUNDARY = "danetti-label-font-boundary";
const calls: Array<{ method: string; args: unknown[] }> = [];
const design = {
  id: "design-1",
  brand: "utopia",
  name: "Colombia El Renancer",
  internal_code: "UT-EL-RENANCER",
  revision: 2,
  visible: true,
  sort_order: 0,
};
const order = { id: "order-1", brand: "utopia", revision: 1, status: "draft", items: [] };
const fontBytes = await readFile(
  new URL(
    "../../../../../assets/label-catalog/fonts/00000000-0000-4000-8000-000000000001-ARIALN.TTF",
    import.meta.url
  )
);

const handlers: Record<string, (...args: unknown[]) => unknown> = {
  listTemplates: () => [{ id: "template-1", brand: "utopia", name: "Utopia 102 × 35 mm" }],
  createTemplate: (body) => ({ id: "template-2", ...record(body) }),
  patchTemplate: (id, body) => ({ id, ...record(body) }),
  listDesigns: () => [design],
  getDesign: () => design,
  createDesign: (body) => ({ ...design, ...record(body) }),
  patchDesign: (_id, body) => {
    const input = body as { expectedRevision?: number };
    if (input.expectedRevision !== design.revision) {
      throw new LabelStudioError(
        "revision_conflict",
        "A címkét időközben másik munkamenet módosította.",
        409
      );
    }
    return { ...design, ...record(body), revision: design.revision + 1 };
  },
  duplicateDesign: (_id, body) => ({ ...design, id: "design-2", ...record(body) }),
  createDesignVersion: () => ({ id: "version-2", version: 2 }),
  listDesignVersions: () => [{ id: "version-1", version: 1 }],
  restoreDesignVersion: () => ({ ...design, revision: 3 }),
  validateDesign: () => ({ issues: [] }),
  previewSvg: () => '<svg xmlns="http://www.w3.org/2000/svg"><path d="M0 0L1 1"/></svg>',
  listAssets: () => [{ id: "font-1", filename: "ARIALN.TTF", kind: "font" }],
  uploadFont: (upload) => ({ id: "font-1", filename: (upload as { filename: string }).filename }),
  uploadFonts: (uploads) =>
    (uploads as Array<{ filename: string }>).map((upload, index) => ({
      id: `font-${index + 1}`,
      filename: upload.filename,
    })),
  patchAsset: (id, body) => ({ id, ...record(body) }),
  deleteAsset: () => undefined,
  downloadAsset: () => ({
    row: { filename: "ARIALN.TTF", mime_type: "font/ttf" },
    bytes: fontBytes,
  }),
  listOrders: () => [order],
  getActiveOrder: () => order,
  createOrder: () => order,
  getOrder: () => order,
  patchOrder: () => ({ ...order, revision: 2 }),
  addOrderItem: () => ({
    ...order,
    items: [{ id: "item-1", design_version_id: "version-1", quantity: 4 }],
  }),
  patchOrderItem: () => ({
    ...order,
    items: [{ id: "item-1", design_version_id: "version-1", quantity: 8 }],
  }),
  deleteOrderItem: () => order,
  freezeOrder: () => ({ ...order, status: "frozen" }),
  exportOrder: () => ({
    id: "export-1",
    filename: "utopia-cimkerendeles-2026-08-12-v001-102x35mm-4db.pdf",
    sha256: "a".repeat(64),
  }),
  downloadExport: () => ({
    row: {
      filename: "utopia-cimkerendeles-2026-08-12-v001-102x35mm-4db.pdf",
      mime_type: "application/pdf",
      sha256: "a".repeat(64),
    },
    bytes: Buffer.from("pdf"),
  }),
};

const service = new Proxy(
  {},
  {
    get(_target, property) {
      const method = String(property);
      return (...args: unknown[]) => {
        calls.push({ method, args });
        const handler = handlers[method];
        if (!handler) throw new Error(`Hiányzó label route teszt handler: ${method}`);
        return handler(...args);
      };
    },
  }
) as unknown as LabelStudioService;

const server = Fastify({ logger: false });
await server.register(registerLabelRoutes, { service });

try {
  const templates = await server.inject({ method: "GET", url: "/label-templates?brand=utopia" });
  assert.equal(templates.statusCode, 200);
  assert.equal(templates.json().items[0].brand, "utopia");

  const labels = await server.inject({ method: "GET", url: "/labels?brand=utopia" });
  assert.equal(labels.statusCode, 200);
  assert.equal(labels.json().items[0].internal_code, "UT-EL-RENANCER");

  const update = await server.inject({
    method: "PATCH",
    url: "/labels/design-1",
    payload: { expectedRevision: 2, visible: false, sortOrder: 4 },
  });
  assert.equal(update.statusCode, 200);
  assert.equal(update.json().item.revision, 3);

  const conflict = await server.inject({
    method: "PATCH",
    url: "/labels/design-1",
    payload: { expectedRevision: 1, visible: false },
  });
  assert.equal(conflict.statusCode, 409);
  assert.equal(conflict.json().error.code, "revision_conflict");

  const duplicate = await server.inject({
    method: "POST",
    url: "/labels/design-1/duplicate",
    payload: { internalCode: "UT-COPY" },
  });
  assert.equal(duplicate.statusCode, 201);
  assert.equal(duplicate.json().item.id, "design-2");

  const preview = await server.inject({
    method: "GET",
    url: "/labels/design-1/preview.svg?outlined=true",
  });
  assert.equal(preview.statusCode, 200);
  assert.match(String(preview.headers["content-type"]), /image\/svg\+xml/);
  assert.match(preview.body, /<path/);

  const upload = await server.inject({
    method: "POST",
    url: "/label-assets/fonts",
    payload: multipart("font", "ARIALN.TTF", "font/ttf", fontBytes),
    headers: { "content-type": `multipart/form-data; boundary=${BOUNDARY}` },
  });
  assert.equal(upload.statusCode, 201);
  assert.equal(upload.json().item.filename, "ARIALN.TTF");
  assert.equal(upload.json().items.length, 1);

  const fontZip = new JSZip();
  fontZip.file("fonts/ARIALN.TTF", fontBytes);
  fontZip.file("notes.txt", "not a font");
  const zipUpload = await server.inject({
    method: "POST",
    url: "/label-assets/fonts",
    payload: multipart(
      "font",
      "font-package.zip",
      "application/zip",
      Buffer.from(await fontZip.generateAsync({ type: "nodebuffer" }))
    ),
    headers: { "content-type": `multipart/form-data; boundary=${BOUNDARY}` },
  });
  assert.equal(zipUpload.statusCode, 201);
  assert.equal(zipUpload.json().items.length, 1);
  assert.equal(zipUpload.json().items[0].filename, "ARIALN.TTF");

  const download = await server.inject({ method: "GET", url: "/label-assets/font-1/download" });
  assert.equal(download.statusCode, 200);
  assert.equal(download.rawPayload.byteLength, fontBytes.byteLength);

  const addItem = await server.inject({
    method: "POST",
    url: "/label-orders/order-1/items",
    payload: { designId: "design-1", quantity: 4 },
  });
  assert.equal(addItem.statusCode, 201);
  assert.equal(addItem.json().item.items[0].quantity, 4);

  const patchItem = await server.inject({
    method: "PATCH",
    url: "/label-orders/order-1/items/item-1",
    payload: { quantity: 8, sortOrder: 1 },
  });
  assert.equal(patchItem.statusCode, 200);
  assert.equal(patchItem.json().item.items[0].quantity, 8);

  const frozen = await server.inject({ method: "POST", url: "/label-orders/order-1/freeze" });
  assert.equal(frozen.statusCode, 200);
  assert.equal(frozen.json().item.status, "frozen");

  const exported = await server.inject({
    method: "POST",
    url: "/label-orders/order-1/export",
    payload: { bleedMm: 2.5 },
  });
  assert.equal(exported.statusCode, 201);
  assert.equal(exported.json().item.id, "export-1");

  const archive = await server.inject({ method: "GET", url: "/label-exports/export-1/download" });
  assert.equal(archive.statusCode, 200);
  assert.match(String(archive.headers["content-disposition"]), /utopia-cimkerendeles.*\.pdf/);

  assert.ok(calls.some((call) => call.method === "uploadFonts"));
  assert.ok(calls.some((call) => call.method === "exportOrder"));
} finally {
  await server.close();
}

function multipart(field: string, filename: string, contentType: string, bytes: Buffer): Buffer {
  return Buffer.concat([
    Buffer.from(
      `--${BOUNDARY}\r\nContent-Disposition: form-data; name="${field}"; filename="${filename}"\r\nContent-Type: ${contentType}\r\n\r\n`
    ),
    bytes,
    Buffer.from(`\r\n--${BOUNDARY}--\r\n`),
  ]);
}

function record(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === "object" ? (value as Record<string, unknown>) : {};
}

console.log("Label Studio API route tests passed");
