import {
  catalogImportRows,
  catalogImportRuns,
  catalogProducts,
  supplierMappings,
  suppliers,
  type CatalogImportRow,
  type CatalogImportRun,
  type CatalogProduct,
  type DanettiDatabase,
  type NewCatalogImportRow,
  type NewCatalogImportRun,
  type NewCatalogProduct,
} from "@danetti/db";
import {
  classifySupplierDisplayStatus,
  describeSupplierDisplayStatus,
  createEmptySupplierDisplayStatusCounts,
  incrementSupplierDisplayStatusCount,
  type SupplierDisplayStatus,
  type SupplierDisplayStatusCounts,
} from "@danetti/shared";
import { and, desc, eq, gte, ilike, inArray, isNotNull, lte, or, sql, type SQL } from "drizzle-orm";
import type { CatalogImportSummary } from "./catalog-import.types.js";

const LF_SUPPLIER_CODE = "lf-spare-parts-724";

export interface CatalogProductListFilters {
  limit: number;
  offset: number;
  search?: string;
  targetProfitMultiplier?: number;
  roundingEnabled?: boolean;
  roundingIncrementHuf?: number;
  roundingMode?: "up" | "nearest";
  sortBy?: CatalogProductSortBy;
  sortDirection?: "asc" | "desc";
  eurHufRate?: number;
  vatPercent?: number;
  supplierId?: string | "none";
  articleStructure?: "single" | "multiple";
  worklistView?: CatalogProductWorklistView;
  profitBandMode?: CatalogProductProfitBandMode;
  profitBandMinPercent?: number;
  profitBandMaxPercent?: number;
  calculability?: CatalogProductCalculabilityFilter;
  minProfitPercent?: number;
  maxProfitPercent?: number;
  minProfitHuf?: number;
  maxProfitHuf?: number;
  minDvgPurchaseHuf?: number;
  maxDvgPurchaseHuf?: number;
  minWooNetHuf?: number;
  maxWooNetHuf?: number;
  minRegularPrice?: number;
  maxRegularPrice?: number;
  hasDvgPrice?: "yes" | "no";
  unifiedStatus?: UnifiedStatusFilter;
}

export type CatalogProductWorklistView = "attention";

export type CatalogProductProfitBandMode = "inside" | "outside" | "below" | "above";

export type CatalogProductCalculabilityFilter = "calculable" | "not_calculable";

export type UnifiedStatusFilter = SupplierDisplayStatus | "not_ok";

export type CatalogProductDvgStatusFilter =
  | "ok"
  | "not_price_paired"
  | "dvg_faulty_or_not_found"
  | "price_missing_or_discontinued"
  | "no_product_page"
  | "missing_price"
  | "price_missing"
  | "article_changed"
  | "unavailable"
  | "not_supplier_own_article"
  | "ambiguous_match"
  | "login_required"
  | "timeout"
  | "item_not_available"
  | "needs_mapping_review"
  | "cross_reference_only"
  | "item_timeout"
  | "failed"
  | "safety_stopped"
  | "redirected_to_login"
  | "article_not_found"
  | "skipped"
  | "no_run"
  | "none";

export interface CatalogProductUpdateInput {
  sku?: string;
  name?: string;
  barcodeOrGlobalId?: string | null;
  suggestedSupplierArticle?: string | null;
  internalSkuSuffix?: string | null;
  type?: string | null;
  regularPrice?: string | null;
  salePrice?: string | null;
  currentPrice?: string | null;
  stockStatus?: string | null;
  stockQuantity?: string | null;
  dvgPurchasePriceEur?: string | null;
  dvgPurchasePriceHuf?: string | null;
  dvgWooGrossHuf?: string | null;
  dvgWooNetHuf?: string | null;
  dvgProfitNetHuf?: string | null;
  dvgProfitPercent?: string | null;
  dvgSupplierArticleNumber?: string | null;
  lfPurchasePriceEur?: string | null;
  lfPurchasePriceHuf?: string | null;
  lfWooGrossHuf?: string | null;
  lfWooNetHuf?: string | null;
  lfProfitNetHuf?: string | null;
  lfProfitPercent?: string | null;
  lfSupplierArticleNumber?: string | null;
}

export type CatalogProductSortBy =
  | "supplier"
  | "supplierArticle"
  | "url"
  | "targetWooGross"
  | "dvgSupplierArticle"
  | "dvgWooGross"
  | "currentPrice"
  | "sku"
  | "name"
  | "dvgPurchaseEur"
  | "dvgPurchaseHuf"
  | "dvgWooNet"
  | "dvgProfitHuf"
  | "dvgProfitPercent"
  | "dvgUpdated"
  | "dvgStatus"
  | "suggestedArticle"
  | "suffix"
  | "type"
  | "regularPrice"
  | "salePrice"
  | "stock"
  | "lastSeen";

export interface CatalogProductListResult {
  products: CatalogProduct[];
  total: number;
}

export interface CatalogImportRunListResult {
  runs: CatalogImportRun[];
  total: number;
}

export interface CatalogProductsMetricSummary {
  count: number;
  min: number | null;
  max: number | null;
  average: number | null;
  median: number | null;
  modeBucket: { label: string; count: number } | null;
}

export interface CatalogSupplierStatusCounts extends SupplierDisplayStatusCounts {
  needsReview: number;
  crossReferenceOnly: number;
  failedOrTimeout: number;
}

export interface CatalogSupplierSummary {
  productsWithPrice: number;
  productsWithProfit: number;
  missingPrice: number;
  lowProfitCount: number;
  negativeProfitCount: number;
  needsAttentionCount: number;
  latestPricingAt: Date | null;
  purchaseHuf: CatalogProductsMetricSummary;
  profitHuf: CatalogProductsMetricSummary;
  profitPercent: CatalogProductsMetricSummary;
  statusCounts: CatalogSupplierStatusCounts;
}

export interface CatalogProductsSummary {
  totalProducts: number;
  productsWithWooPrice: number;
  lowProfitThresholdPercent: number;
  wooPriceHuf: CatalogProductsMetricSummary;
  dvg: CatalogSupplierSummary;
  lf: CatalogSupplierSummary;
}

type ImportRunStatus =
  | "pending"
  | "parsing"
  | "preview_ready"
  | "importing"
  | "completed"
  | "failed"
  | "cancelled";

export class CatalogImportRepository {
  constructor(private readonly db: DanettiDatabase) {}

  async transaction<T>(handler: (repository: CatalogImportRepository) => Promise<T>): Promise<T> {
    return this.db.transaction(async (tx) =>
      handler(new CatalogImportRepository(tx as unknown as DanettiDatabase))
    );
  }

  async createImportRun(input: NewCatalogImportRun): Promise<CatalogImportRun> {
    const [importRun] = await this.db.insert(catalogImportRuns).values(input).returning();

    if (importRun === undefined) {
      throw new Error("Failed to create catalog import run");
    }

    return importRun;
  }

  async updateImportRunSummary(
    id: string,
    input: CatalogImportSummary & {
      status: ImportRunStatus;
      finishedAt: Date;
      errorSummary?: string | null;
    }
  ): Promise<void> {
    await this.db
      .update(catalogImportRuns)
      .set({
        status: input.status,
        totalRows: input.totalRows,
        insertedCount: input.insertedCount,
        updatedCount: input.updatedCount,
        deletedCount: input.deletedCount,
        skippedExistingCount: input.skippedExistingCount,
        skippedDuplicateCount: input.skippedDuplicateCount,
        skippedMissingSkuCount: input.skippedMissingSkuCount,
        invalidCount: input.invalidCount,
        failedCount: input.failedCount,
        finishedAt: input.finishedAt,
        errorSummary: input.errorSummary,
        updatedAt: new Date(),
      })
      .where(eq(catalogImportRuns.id, id));
  }

  async listExistingProductsBySku(
    skus: string[]
  ): Promise<Array<Pick<CatalogProduct, "id" | "sku">>> {
    if (skus.length === 0) {
      return [];
    }

    return this.db
      .select({ id: catalogProducts.id, sku: catalogProducts.sku })
      .from(catalogProducts)
      .where(inArray(catalogProducts.sku, skus));
  }

  async insertCatalogProductAddOnly(
    input: NewCatalogProduct
  ): Promise<Pick<CatalogProduct, "id" | "sku"> | null> {
    const [insertedProduct] = await this.db
      .insert(catalogProducts)
      .values(input)
      .onConflictDoNothing({ target: catalogProducts.sku })
      .returning({ id: catalogProducts.id, sku: catalogProducts.sku });

    return insertedProduct ?? null;
  }

  async upsertCatalogProductFromCsv(
    input: NewCatalogProduct
  ): Promise<Pick<CatalogProduct, "id" | "sku">> {
    const [product] = await this.db
      .insert(catalogProducts)
      .values(input)
      .onConflictDoUpdate({
        target: catalogProducts.sku,
        set: {
          sourcePlatform: input.sourcePlatform,
          sourceProductId: input.sourceProductId,
          sourceParentId: input.sourceParentId,
          sourceVariationId: input.sourceVariationId,
          barcodeOrGlobalId: input.barcodeOrGlobalId,
          suggestedSupplierArticle: input.suggestedSupplierArticle,
          internalSkuSuffix: input.internalSkuSuffix,
          type: input.type,
          name: input.name,
          publishedStatus: input.publishedStatus,
          catalogVisibility: input.catalogVisibility,
          permalink: input.permalink,
          categories: input.categories,
          tags: input.tags,
          attributes: input.attributes,
          regularPrice: input.regularPrice,
          salePrice: input.salePrice,
          currentPrice: input.currentPrice,
          stockStatus: input.stockStatus,
          stockQuantity: input.stockQuantity,
          parentSku: input.parentSku,
          rawRow: input.rawRow,
          lastImportRunId: input.lastImportRunId,
          lastSeenInImportAt: input.lastSeenInImportAt,
          updatedAt: input.updatedAt,
        },
      })
      .returning({ id: catalogProducts.id, sku: catalogProducts.sku });

    if (product === undefined) {
      throw new Error("Failed to upsert catalog product");
    }

    return product;
  }

  async createImportRows(rows: NewCatalogImportRow[]): Promise<void> {
    if (rows.length === 0) {
      return;
    }

    await this.db.insert(catalogImportRows).values(rows);
  }

  async listImportRuns(input: {
    limit: number;
    offset: number;
  }): Promise<CatalogImportRunListResult> {
    const [{ total } = { total: 0 }] = await this.db
      .select({ total: sql<number>`count(*)::int` })
      .from(catalogImportRuns);
    const runs = await this.db
      .select()
      .from(catalogImportRuns)
      .orderBy(desc(catalogImportRuns.createdAt))
      .limit(input.limit)
      .offset(input.offset);

    return { runs, total };
  }

  async getImportRun(id: string): Promise<CatalogImportRun | null> {
    const [importRun] = await this.db
      .select()
      .from(catalogImportRuns)
      .where(eq(catalogImportRuns.id, id))
      .limit(1);

    return importRun ?? null;
  }

  async listImportRows(importRunId: string, limit: number): Promise<CatalogImportRow[]> {
    return this.db
      .select()
      .from(catalogImportRows)
      .where(eq(catalogImportRows.catalogImportRunId, importRunId))
      .orderBy(catalogImportRows.rowNumber)
      .limit(limit);
  }

  async listProducts(input: CatalogProductListFilters): Promise<CatalogProductListResult> {
    const pricingScope = await this.readSupplierPricingScope(input.supplierId);
    const conditions = buildProductConditions(input, pricingScope);
    const where = conditions.length > 0 ? and(...conditions) : undefined;
    const [{ total } = { total: 0 }] = await this.db
      .select({ total: sql<number>`count(*)::int` })
      .from(catalogProducts)
      .where(where);
    const products = await this.db
      .select()
      .from(catalogProducts)
      .where(where)
      .orderBy(
        productOrderBy(input, pricingScope),
        desc(catalogProducts.createdAt),
        catalogProducts.id
      )
      .limit(input.limit)
      .offset(input.offset);

    return { products, total };
  }

  private async readSupplierPricingScope(
    supplierId: CatalogProductListFilters["supplierId"]
  ): Promise<CatalogPricingScope> {
    if (!supplierId || supplierId === "none") return "dvg";
    const [supplier] = await this.db
      .select({ code: suppliers.code })
      .from(suppliers)
      .where(eq(suppliers.id, supplierId))
      .limit(1);
    return supplier?.code === LF_SUPPLIER_CODE ? "lf" : "dvg";
  }

  async getProductsSummary(): Promise<CatalogProductsSummary> {
    const rows = await this.db
      .select({
        regularPrice: catalogProducts.regularPrice,
        salePrice: catalogProducts.salePrice,
        currentPrice: catalogProducts.currentPrice,
        dvgPurchasePriceHuf: catalogProducts.dvgPurchasePriceHuf,
        dvgPurchasePriceEur: catalogProducts.dvgPurchasePriceEur,
        dvgProfitNetHuf: catalogProducts.dvgProfitNetHuf,
        dvgProfitPercent: catalogProducts.dvgProfitPercent,
        dvgLastRunStatus: catalogProducts.dvgLastRunStatus,
        dvgLastRunMessage: catalogProducts.dvgLastRunMessage,
        dvgPricingUpdatedAt: catalogProducts.dvgPricingUpdatedAt,
        lfPurchasePriceHuf: catalogProducts.lfPurchasePriceHuf,
        lfPurchasePriceEur: catalogProducts.lfPurchasePriceEur,
        lfProfitNetHuf: catalogProducts.lfProfitNetHuf,
        lfProfitPercent: catalogProducts.lfProfitPercent,
        lfLastRunStatus: catalogProducts.lfLastRunStatus,
        lfLastRunMessage: catalogProducts.lfLastRunMessage,
        lfPricingUpdatedAt: catalogProducts.lfPricingUpdatedAt,
      })
      .from(catalogProducts);

    return buildCatalogProductsSummary(rows);
  }

  async updateCatalogProduct(
    id: string,
    input: CatalogProductUpdateInput,
    observedAt = new Date()
  ): Promise<CatalogProduct | null> {
    const values: Partial<NewCatalogProduct> = { ...input, updatedAt: observedAt };
    const [product] = await this.db
      .update(catalogProducts)
      .set(values)
      .where(eq(catalogProducts.id, id))
      .returning();

    return product ?? null;
  }
}

const LOW_PROFIT_THRESHOLD_PERCENT = 20;
const DEFAULT_TARGET_PROFIT_MIN_PERCENT = 20;
const DEFAULT_TARGET_PROFIT_MAX_PERCENT = 60;

type CatalogPricingScope = "dvg" | "lf";

type CatalogSummarySourceRow = {
  regularPrice: string | number | null;
  salePrice: string | number | null;
  currentPrice: string | number | null;
  dvgPurchasePriceHuf: string | number | null;
  dvgPurchasePriceEur: string | number | null;
  dvgProfitNetHuf: string | number | null;
  dvgProfitPercent: string | number | null;
  dvgLastRunStatus: string | null;
  dvgLastRunMessage: string | null;
  dvgPricingUpdatedAt: Date | null;
  lfPurchasePriceHuf: string | number | null;
  lfPurchasePriceEur: string | number | null;
  lfProfitNetHuf: string | number | null;
  lfProfitPercent: string | number | null;
  lfLastRunStatus: string | null;
  lfLastRunMessage: string | null;
  lfPricingUpdatedAt: Date | null;
};

export function buildCatalogProductsSummary(
  rows: readonly CatalogSummarySourceRow[]
): CatalogProductsSummary {
  const wooPrices = collectNumbers(
    rows.map((row) => firstPresent(row.currentPrice, row.salePrice, row.regularPrice))
  );

  return {
    totalProducts: rows.length,
    productsWithWooPrice: wooPrices.length,
    lowProfitThresholdPercent: LOW_PROFIT_THRESHOLD_PERCENT,
    wooPriceHuf: summarizeMetric(wooPrices, PRICE_BUCKETS_HUF),
    dvg: buildSupplierSummary(rows, "dvg"),
    lf: buildSupplierSummary(rows, "lf"),
  };
}

function buildSupplierSummary(
  rows: readonly CatalogSummarySourceRow[],
  scope: CatalogPricingScope
): CatalogSupplierSummary {
  const purchases = collectNumbers(rows.map((row) => readSupplierField(row, scope, "purchaseHuf")));
  const profitHuf = collectNumbers(rows.map((row) => readSupplierField(row, scope, "profitHuf")));
  const profitPercent = collectNumbers(
    rows.map((row) => readSupplierField(row, scope, "profitPercent"))
  );
  const productsWithPrice = rows.filter((row) => hasSupplierPrice(row, scope)).length;
  const lowProfitCount = profitPercent.filter(
    (value) => value < LOW_PROFIT_THRESHOLD_PERCENT
  ).length;
  const negativeProfitCount = profitPercent.filter((value) => value < 0).length;

  return {
    productsWithPrice,
    productsWithProfit: profitPercent.length,
    missingPrice: Math.max(rows.length - productsWithPrice, 0),
    lowProfitCount,
    negativeProfitCount,
    needsAttentionCount: rows.filter((row) => supplierNeedsAttention(row, scope)).length,
    latestPricingAt: latestDate(rows.map((row) => readSupplierDate(row, scope))),
    purchaseHuf: summarizeMetric(purchases, PRICE_BUCKETS_HUF),
    profitHuf: summarizeMetric(profitHuf, PROFIT_HUF_BUCKETS),
    profitPercent: summarizeMetric(profitPercent, PROFIT_PERCENT_BUCKETS),
    statusCounts: countSupplierStatuses(rows, scope),
  };
}

type MetricBucket = {
  label: string;
  min: number;
  max: number | null;
};

const PRICE_BUCKETS_HUF: MetricBucket[] = [
  { label: "0 - 10 ezer Ft", min: 0, max: 10_000 },
  { label: "10 - 25 ezer Ft", min: 10_000, max: 25_000 },
  { label: "25 - 50 ezer Ft", min: 25_000, max: 50_000 },
  { label: "50 - 100 ezer Ft", min: 50_000, max: 100_000 },
  { label: "100 - 250 ezer Ft", min: 100_000, max: 250_000 },
  { label: "250 ezer Ft felett", min: 250_000, max: null },
];

const PROFIT_HUF_BUCKETS: MetricBucket[] = [
  { label: "veszteséges", min: Number.NEGATIVE_INFINITY, max: 0 },
  { label: "0 - 5 ezer Ft", min: 0, max: 5_000 },
  { label: "5 - 15 ezer Ft", min: 5_000, max: 15_000 },
  { label: "15 - 30 ezer Ft", min: 15_000, max: 30_000 },
  { label: "30 - 75 ezer Ft", min: 30_000, max: 75_000 },
  { label: "75 ezer Ft felett", min: 75_000, max: null },
];

const PROFIT_PERCENT_BUCKETS: MetricBucket[] = [
  { label: "veszteséges", min: Number.NEGATIVE_INFINITY, max: 0 },
  { label: "0 - 10%", min: 0, max: 10 },
  { label: "10 - 20%", min: 10, max: 20 },
  { label: "20 - 30%", min: 20, max: 30 },
  { label: "30 - 40%", min: 30, max: 40 },
  { label: "40 - 60%", min: 40, max: 60 },
  { label: "60 - 100%", min: 60, max: 100 },
  { label: "100% felett", min: 100, max: null },
];

function collectNumbers(values: Array<string | number | null>): number[] {
  return values
    .map((value) => maybeNumber(value))
    .filter((value): value is number => value !== null);
}

function summarizeMetric(
  values: readonly number[],
  buckets: readonly MetricBucket[]
): CatalogProductsMetricSummary {
  if (values.length === 0) {
    return { count: 0, min: null, max: null, average: null, median: null, modeBucket: null };
  }

  const sorted = [...values].sort((a, b) => a - b);
  const total = sorted.reduce((sum, value) => sum + value, 0);
  return {
    count: sorted.length,
    min: sorted[0] ?? null,
    max: sorted.at(-1) ?? null,
    average: total / sorted.length,
    median: median(sorted),
    modeBucket: modeBucket(sorted, buckets),
  };
}

function median(sortedValues: readonly number[]): number | null {
  if (sortedValues.length === 0) return null;
  const middle = Math.floor(sortedValues.length / 2);
  if (sortedValues.length % 2 === 1) return sortedValues[middle] ?? null;
  const left = sortedValues[middle - 1];
  const right = sortedValues[middle];
  return left === undefined || right === undefined ? null : (left + right) / 2;
}

function modeBucket(
  values: readonly number[],
  buckets: readonly MetricBucket[]
): { label: string; count: number } | null {
  let best: { label: string; count: number } | null = null;
  for (const bucket of buckets) {
    const count = values.filter((value) => inBucket(value, bucket)).length;
    if (count === 0) continue;
    if (best === null || count > best.count) best = { label: bucket.label, count };
  }
  return best;
}

function inBucket(value: number, bucket: MetricBucket): boolean {
  return value >= bucket.min && (bucket.max === null || value < bucket.max);
}

function countSupplierStatuses(
  rows: readonly CatalogSummarySourceRow[],
  scope: CatalogPricingScope
): CatalogSupplierStatusCounts {
  const displayCounts = createEmptySupplierDisplayStatusCounts();
  for (const row of rows) {
    incrementSupplierDisplayStatusCount(displayCounts, readSupplierDisplayStatus(row, scope));
  }
  return {
    ...displayCounts,
    needsReview: displayCounts.ambiguousMatch,
    crossReferenceOnly: displayCounts.notSupplierOwnArticle,
    failedOrTimeout: displayCounts.failed + displayCounts.timeout + displayCounts.loginRequired,
  };
}

function supplierNeedsAttention(row: CatalogSummarySourceRow, scope: CatalogPricingScope): boolean {
  const status = readSupplierDisplayStatus(row, scope);
  const rowProfitPercent = maybeNumber(readSupplierField(row, scope, "profitPercent"));
  return (
    !hasSupplierPrice(row, scope) ||
    !["ok", "skipped", "no_run"].includes(status) ||
    (rowProfitPercent !== null && rowProfitPercent < LOW_PROFIT_THRESHOLD_PERCENT)
  );
}

function hasSupplierPrice(row: CatalogSummarySourceRow, scope: CatalogPricingScope): boolean {
  return (
    maybeNumber(readSupplierField(row, scope, "purchaseHuf")) !== null ||
    maybeNumber(readSupplierField(row, scope, "purchaseEur")) !== null
  );
}

function readSupplierField(
  row: CatalogSummarySourceRow,
  scope: CatalogPricingScope,
  field: "purchaseHuf" | "purchaseEur" | "profitHuf" | "profitPercent"
): string | number | null {
  if (scope === "lf") {
    const fields = {
      purchaseHuf: row.lfPurchasePriceHuf,
      purchaseEur: row.lfPurchasePriceEur,
      profitHuf: row.lfProfitNetHuf,
      profitPercent: row.lfProfitPercent,
    };
    return fields[field];
  }
  const fields = {
    purchaseHuf: row.dvgPurchasePriceHuf,
    purchaseEur: row.dvgPurchasePriceEur,
    profitHuf: row.dvgProfitNetHuf,
    profitPercent: row.dvgProfitPercent,
  };
  return fields[field];
}

function readSupplierDate(row: CatalogSummarySourceRow, scope: CatalogPricingScope): Date | null {
  return scope === "lf" ? row.lfPricingUpdatedAt : row.dvgPricingUpdatedAt;
}

function readSupplierStatus(
  row: CatalogSummarySourceRow,
  scope: CatalogPricingScope
): string | null {
  return scope === "lf" ? row.lfLastRunStatus : row.dvgLastRunStatus;
}

function readSupplierMessage(
  row: CatalogSummarySourceRow,
  scope: CatalogPricingScope
): string | null {
  return scope === "lf" ? row.lfLastRunMessage : row.dvgLastRunMessage;
}

function readSupplierDisplayStatus(row: CatalogSummarySourceRow, scope: CatalogPricingScope) {
  return classifySupplierDisplayStatus(
    scope,
    readSupplierStatus(row, scope),
    [],
    readSupplierMessage(row, scope) ?? ""
  );
}

function firstPresent<T>(...values: Array<T | null | undefined>): T | null {
  return values.find((value): value is T => value !== null && value !== undefined) ?? null;
}

function maybeNumber(value: string | number | null | undefined): number | null {
  if (value === null || value === undefined || value === "") return null;
  const numberValue = typeof value === "number" ? value : Number(value);
  return Number.isFinite(numberValue) ? numberValue : null;
}

function latestDate(values: Array<Date | null>): Date | null {
  return values.reduce<Date | null>((latest, value) => {
    if (value === null) return latest;
    if (latest === null || value.getTime() > latest.getTime()) return value;
    return latest;
  }, null);
}

function buildProductConditions(
  input: CatalogProductListFilters,
  pricingScope: CatalogPricingScope
): SQL[] {
  const conditions: SQL[] = [];
  const pricingColumns = catalogPricingColumns(pricingScope);
  const profitPercentExpression = liveProfitPercentExpression(
    input.eurHufRate,
    input.vatPercent,
    pricingScope
  );
  const search = input.search?.trim();
  if (search) {
    const escapedSearch = search.replace(/[\\%_]/g, (character) => "\\" + character);
    const pattern = `%${escapedSearch}%`;
    const searchCondition = or(
      ilike(catalogProducts.sku, pattern),
      ilike(catalogProducts.name, pattern),
      ilike(catalogProducts.suggestedSupplierArticle, pattern),
      ilike(catalogProducts.internalSkuSuffix, pattern),
      ilike(catalogProducts.type, pattern),
      ilike(catalogProducts.stockStatus, pattern),
      ilike(catalogProducts.dvgSupplierArticleNumber, pattern),
      ilike(catalogProducts.lfSupplierArticleNumber, pattern),
      ilike(catalogProducts.dvgLastRunStatus, pattern),
      ilike(catalogProducts.lfLastRunStatus, pattern),
      ilike(catalogProducts.dvgLastRunMessage, pattern),
      ilike(catalogProducts.lfLastRunMessage, pattern)
    );
    if (searchCondition) conditions.push(searchCondition);
  }

  if (input.articleStructure === "multiple")
    conditions.push(sql`position('__' in ${catalogProducts.sku}) > 0`);
  else if (input.articleStructure === "single")
    conditions.push(sql`position('__' in ${catalogProducts.sku}) = 0`);

  if (input.supplierId === "none") {
    conditions.push(
      sql`not exists (select 1 from ${supplierMappings} where ${supplierMappings.catalogProductId} = ${catalogProducts.id} and ${supplierMappings.enabled} = true)`
    );
  } else if (input.supplierId) {
    conditions.push(
      sql`exists (select 1 from ${supplierMappings} where ${supplierMappings.catalogProductId} = ${catalogProducts.id} and ${supplierMappings.supplierId} = ${input.supplierId} and ${supplierMappings.enabled} = true)`
    );
  }

  if (input.worklistView === "attention") {
    const attentionCondition = buildNeedsAttentionCondition(
      input,
      profitPercentExpression,
      pricingScope
    );
    if (attentionCondition) conditions.push(attentionCondition);
  }

  addProfitBandCondition(conditions, profitPercentExpression, {
    mode: input.profitBandMode,
    min: input.profitBandMinPercent,
    max: input.profitBandMaxPercent,
  });

  if (input.calculability === "calculable") {
    conditions.push(sql`${profitPercentExpression} is not null`);
  } else if (input.calculability === "not_calculable") {
    conditions.push(sql`${profitPercentExpression} is null`);
  }

  addNumberRange(conditions, profitPercentExpression, {
    min: input.minProfitPercent,
    max: input.maxProfitPercent,
  });
  addNumberRange(
    conditions,
    liveProfitHufExpression(input.eurHufRate, input.vatPercent, pricingScope),
    {
      min: input.minProfitHuf,
      max: input.maxProfitHuf,
    }
  );
  addNumberRange(conditions, liveDvgPurchaseHufExpression(input.eurHufRate, pricingScope), {
    min: input.minDvgPurchaseHuf,
    max: input.maxDvgPurchaseHuf,
  });
  addNumberRange(conditions, liveWooNetHufExpression(input.vatPercent, pricingScope), {
    min: input.minWooNetHuf,
    max: input.maxWooNetHuf,
  });
  addNumberRange(conditions, sql`${catalogProducts.regularPrice}`, {
    min: input.minRegularPrice,
    max: input.maxRegularPrice,
  });

  if (input.hasDvgPrice === "yes") conditions.push(isNotNull(pricingColumns.purchasePriceEur));
  if (input.hasDvgPrice === "no") conditions.push(sql`${pricingColumns.purchasePriceEur} is null`);

  if (input.unifiedStatus === "not_ok") {
    conditions.push(
      sql`(${pricingColumns.lastRunStatus} is distinct from 'ok' or ${pricingColumns.lastRunStatus} is null)`
    );
  } else if (input.unifiedStatus === "no_run") {
    conditions.push(sql`${pricingColumns.lastRunStatus} is null`);
  } else if (input.unifiedStatus === "skipped") {
    conditions.push(
      sql`(${pricingColumns.lastRunStatus} = 'skipped' or ${pricingColumns.lastRunStatus} like 'skipped_%')`
    );
  } else if (input.unifiedStatus) {
    conditions.push(eq(pricingColumns.lastRunStatus, input.unifiedStatus));
  }

  return conditions;
}

function buildNeedsAttentionCondition(
  input: CatalogProductListFilters,
  profitPercentExpression: SQL,
  pricingScope: CatalogPricingScope
): SQL | undefined {
  const pricingColumns = catalogPricingColumns(pricingScope);
  const profitOutside = buildProfitBandSql(profitPercentExpression, {
    mode: "outside",
    min: input.profitBandMinPercent ?? DEFAULT_TARGET_PROFIT_MIN_PERCENT,
    max: input.profitBandMaxPercent ?? DEFAULT_TARGET_PROFIT_MAX_PERCENT,
  });
  return or(
    sql`${pricingColumns.purchasePriceEur} is null and ${pricingColumns.purchasePriceHuf} is null`,
    inArray(pricingColumns.lastRunStatus, [
      "price_missing",
      "price_missing_or_discontinued",
      "article_changed",
      "item_not_available",
      "unavailable",
      "ambiguous_match",
      "needs_mapping_review",
      "cross_reference_only",
      "item_timeout",
      "failed",
      "redirected_to_login",
      "article_not_found",
      "dvg_faulty_or_not_found",
      "safety_stopped",
    ]),
    profitOutside
  );
}

function addCondition(conditions: SQL[], condition: SQL | undefined): void {
  if (condition) conditions.push(condition);
}

function addProfitBandCondition(
  conditions: SQL[],
  expression: SQL,
  input: { mode?: CatalogProductProfitBandMode; min?: number; max?: number }
): void {
  const condition = buildProfitBandSql(expression, input);
  if (condition) conditions.push(condition);
}

function buildProfitBandSql(
  expression: SQL,
  input: { mode?: CatalogProductProfitBandMode; min?: number; max?: number }
): SQL | undefined {
  const { mode, min, max } = input;
  if (!mode) return undefined;

  if (mode === "inside") {
    if (typeof min === "number" && typeof max === "number") {
      return and(sql`${expression} >= ${min}`, sql`${expression} <= ${max}`);
    }
    if (typeof min === "number") return sql`${expression} >= ${min}`;
    if (typeof max === "number") return sql`${expression} <= ${max}`;
    return undefined;
  }

  if (mode === "outside") {
    if (typeof min === "number" && typeof max === "number") {
      return or(sql`${expression} < ${min}`, sql`${expression} > ${max}`);
    }
    if (typeof min === "number") return sql`${expression} < ${min}`;
    if (typeof max === "number") return sql`${expression} > ${max}`;
    return undefined;
  }

  if (mode === "below") {
    const limit = typeof min === "number" ? min : max;
    return typeof limit === "number" ? sql`${expression} < ${limit}` : undefined;
  }

  const limit = typeof max === "number" ? max : min;
  return typeof limit === "number" ? sql`${expression} > ${limit}` : undefined;
}

function addNumberRange(
  conditions: SQL[],
  expression: SQL,
  input: { min?: number; max?: number }
): void {
  if (typeof input.min === "number") conditions.push(gte(expression, input.min));
  if (typeof input.max === "number") conditions.push(lte(expression, input.max));
}

function productOrderBy(input: CatalogProductListFilters, pricingScope: CatalogPricingScope): SQL {
  const expression = productSheetSortExpression(input, pricingScope);
  return input.sortDirection === "asc"
    ? sql`${expression} ASC NULLS LAST`
    : sql`${expression} DESC NULLS LAST`;
}

/** Uses the same preferred mapping and live pricing as the editable product sheet. */
export function productSheetSortExpression(
  input: CatalogProductListFilters,
  _scope: CatalogPricingScope = "dvg"
): SQL {
  const mapping = (field: "supplier_article_number" | "direct_url" | "supplier_id") =>
    sql`(select ${sql.raw(`sm.${field}`)} from supplier_mappings sm where sm.catalog_product_id = ${catalogProducts.id} order by sm.enabled desc, sm.is_primary desc, sm.created_at desc, sm.id asc limit 1)`;
  const supplierCode = sql`(select s.code from suppliers s where s.id = ${mapping("supplier_id")})`;
  const isLf = sql`${supplierCode} = 'lf-spare-parts-724'`;
  const dvg = catalogPricingColumns("dvg"),
    lf = catalogPricingColumns("lf");
  const field = (key: keyof typeof dvg) =>
    sql`case when ${isLf} then ${lf[key]} else ${dvg[key]} end`;
  const purchase =
    typeof input.eurHufRate === "number"
      ? sql`coalesce(${field("purchasePriceEur")} * ${input.eurHufRate}, ${field("purchasePriceHuf")})`
      : field("purchasePriceHuf");
  const gross = sql`coalesce(${catalogProducts.currentPrice}, ${catalogProducts.salePrice}, ${catalogProducts.regularPrice}, ${field("wooGrossHuf")})`;
  const net = sql`coalesce(${gross} / ${1 + (input.vatPercent ?? 27) / 100}, ${field("wooNetHuf")})`;
  const profit = sql`coalesce(${net} - ${purchase}, ${field("profitNetHuf")})`;
  const text = (expression: SQL) => sql`${expression} collate "hu-x-icu"`;
  switch (input.sortBy ?? "dvgProfitPercent") {
    case "sku":
      return text(sql`${catalogProducts.sku}`);
    case "name":
      return text(sql`${catalogProducts.name}`);
    case "supplier":
      return text(
        sql`(select s.code || ' - ' || s.name from suppliers s where s.id = ${mapping("supplier_id")})`
      );
    case "supplierArticle":
      return text(
        sql`coalesce(${mapping("supplier_article_number")}, ${field("supplierArticleNumber")}, ${catalogProducts.suggestedSupplierArticle})`
      );
    case "url":
      return text(mapping("direct_url"));
    case "dvgSupplierArticle":
      return text(field("supplierArticleNumber"));
    case "dvgPurchaseEur":
      return field("purchasePriceEur");
    case "dvgPurchaseHuf":
      return purchase;
    case "dvgWooGross":
      return gross;
    case "dvgWooNet":
      return net;
    case "dvgProfitHuf":
      return profit;
    case "dvgProfitPercent":
      return sql`case when ${purchase} > 0 and ${profit} is not null then ${profit} / ${purchase} * 100 else ${field("profitPercent")} end`;
    case "targetWooGross": {
      if (input.targetProfitMultiplier === undefined) return sql`null`;
      const value = sql`${purchase} * ${input.targetProfitMultiplier} * ${1 + (input.vatPercent ?? 27) / 100}`;
      if (input.roundingEnabled === false) return value;
      const increment = input.roundingIncrementHuf ?? 100;
      if (increment <= 1) return sql`floor(${value} + 0.5)`;
      return input.roundingMode === "nearest"
        ? sql`floor(${value} / ${increment} + 0.5) * ${increment}`
        : sql`ceil(${value} / ${increment}) * ${increment}`;
    }
    case "dvgUpdated":
      return field("pricingUpdatedAt");
    case "dvgStatus":
      return text(productStatusSortLabel(isLf, field("lastRunStatus"), field("lastRunMessage")));
    case "suggestedArticle":
      return text(sql`${catalogProducts.suggestedSupplierArticle}`);
    case "suffix":
      return text(sql`${catalogProducts.internalSkuSuffix}`);
    case "type":
      return text(sql`${catalogProducts.type}`);
    case "currentPrice":
      return sql`${catalogProducts.currentPrice}`;
    case "regularPrice":
      return sql`${catalogProducts.regularPrice}`;
    case "salePrice":
      return sql`${catalogProducts.salePrice}`;
    case "stock":
      return text(sql`${catalogProducts.stockStatus}`);
    case "lastSeen":
      return sql`${catalogProducts.lastSeenInImportAt}`;
  }
}

// The catalog has no warning array: match its shared display classifier's status/message rules.
function productStatusSortLabel(isLf: SQL, raw: SQL, message: SQL): SQL {
  const status = sql`nullif(btrim(${raw}), '')`;
  const normalized = sql`lower(translate(coalesce(${message}, ''), 'áéíóöőúüűÁÉÍÓÖŐÚÜŰ', 'aeiooouuuAEIOOOUUU'))`;
  const label = (value: SupplierDisplayStatus) =>
    sql`case when ${isLf} then ${describeSupplierDisplayStatus("lf", value).label} else ${describeSupplierDisplayStatus("dvg", value).label} end`;
  return sql`case
    when ${status} is null then ${label("no_run")}
    when ${status} = 'safety_stopped' then ${label("safety_stopped")}
    when ${status} = 'skipped' or left(${status}, 8) = 'skipped_' then ${label("skipped")}
    when ${status} in ('login_required', 'redirected_to_login') or ${normalized} ~ 'login|session|belepes|bejelentkezes' then ${label("login_required")}
    when ${status} in ('timeout', 'item_timeout') or ${normalized} ~ 'timeout|idotullepes' then ${label("timeout")}
    when ${status} = 'article_changed' or ${normalized} ~ 'cikkszam.*(megvaltozott|valtozott)|changed|replaced|superseded|sostituit' then ${label("article_changed")}
    when ${status} in ('item_not_available', 'unavailable') or ${normalized} ~ 'mar nem gyartott|nem rendelheto|not available|no longer in production|cancelled|canceled|torolt|kifutott' then ${label("unavailable")}
    when ${isLf} and (${status} in ('cross_reference_only', 'not_supplier_own_article') or ${normalized} ~ 'cross.reference|nem sajat lf|nem sajat termek') then ${label("not_supplier_own_article")}
    when ${status} in ('article_not_found', 'no_product_page', 'dvg_faulty_or_not_found') or ${normalized} ~ 'nem talalta|nincs termekoldal|nincs sajat|request.info|ures|keresesi oldal|no match|not found' then ${label("no_product_page")}
    when ${status} in ('missing_price', 'price_missing', 'price_missing_or_discontinued') or ${normalized} ~ 'ar hianyzik|ar nincs|nincs ar|netto ar nincs|nincs olvashato.*ar' then ${label("missing_price")}
    when ${status} in ('needs_mapping_review', 'ambiguous_match') or ${normalized} ~ 'nem egyertelmu|bizonytalan|mapping ellenorzes|tobb' then ${label("ambiguous_match")}
    when ${status} = 'ok' then ${label("ok")}
    else ${label("failed")} end`;
}

function catalogPricingColumns(scope: CatalogPricingScope) {
  if (scope === "lf") {
    return {
      purchasePriceEur: catalogProducts.lfPurchasePriceEur,
      purchasePriceHuf: catalogProducts.lfPurchasePriceHuf,
      wooGrossHuf: catalogProducts.lfWooGrossHuf,
      wooNetHuf: catalogProducts.lfWooNetHuf,
      profitNetHuf: catalogProducts.lfProfitNetHuf,
      profitPercent: catalogProducts.lfProfitPercent,
      supplierArticleNumber: catalogProducts.lfSupplierArticleNumber,
      pricingUpdatedAt: catalogProducts.lfPricingUpdatedAt,
      lastRunStatus: catalogProducts.lfLastRunStatus,
      lastRunMessage: catalogProducts.lfLastRunMessage,
    };
  }
  return {
    purchasePriceEur: catalogProducts.dvgPurchasePriceEur,
    purchasePriceHuf: catalogProducts.dvgPurchasePriceHuf,
    wooGrossHuf: catalogProducts.dvgWooGrossHuf,
    wooNetHuf: catalogProducts.dvgWooNetHuf,
    profitNetHuf: catalogProducts.dvgProfitNetHuf,
    profitPercent: catalogProducts.dvgProfitPercent,
    supplierArticleNumber: catalogProducts.dvgSupplierArticleNumber,
    pricingUpdatedAt: catalogProducts.dvgPricingUpdatedAt,
    lastRunStatus: catalogProducts.dvgLastRunStatus,
    lastRunMessage: catalogProducts.dvgLastRunMessage,
  };
}

function liveDvgPurchaseHufExpression(
  eurHufRate?: number,
  pricingScope: CatalogPricingScope = "dvg"
): SQL {
  const pricingColumns = catalogPricingColumns(pricingScope);
  return typeof eurHufRate === "number"
    ? sql`(${pricingColumns.purchasePriceEur} * ${eurHufRate})`
    : sql`${pricingColumns.purchasePriceHuf}`;
}

function liveWooGrossHufExpression(pricingScope: CatalogPricingScope = "dvg"): SQL {
  const pricingColumns = catalogPricingColumns(pricingScope);
  return sql`coalesce(${catalogProducts.currentPrice}, ${catalogProducts.salePrice}, ${catalogProducts.regularPrice}, ${pricingColumns.wooGrossHuf})`;
}

function liveWooNetHufExpression(
  vatPercent?: number,
  pricingScope: CatalogPricingScope = "dvg"
): SQL {
  const pricingColumns = catalogPricingColumns(pricingScope);
  if (typeof vatPercent !== "number") return sql`${pricingColumns.wooNetHuf}`;
  const vatMultiplier = 1 + vatPercent / 100;
  return sql`coalesce((${liveWooGrossHufExpression(pricingScope)} / ${vatMultiplier}), ${pricingColumns.wooNetHuf})`;
}

function liveProfitHufExpression(
  eurHufRate?: number,
  vatPercent?: number,
  pricingScope: CatalogPricingScope = "dvg"
): SQL {
  const pricingColumns = catalogPricingColumns(pricingScope);
  return typeof eurHufRate === "number"
    ? sql`(${liveWooNetHufExpression(vatPercent, pricingScope)} - (${pricingColumns.purchasePriceEur} * ${eurHufRate}))`
    : sql`${pricingColumns.profitNetHuf}`;
}

function liveProfitPercentExpression(
  eurHufRate?: number,
  vatPercent?: number,
  pricingScope: CatalogPricingScope = "dvg"
): SQL {
  const pricingColumns = catalogPricingColumns(pricingScope);
  return typeof eurHufRate === "number"
    ? sql`case when ${pricingColumns.purchasePriceEur} is null or ${pricingColumns.purchasePriceEur} = 0 then null else ((${liveWooNetHufExpression(vatPercent, pricingScope)} - (${pricingColumns.purchasePriceEur} * ${eurHufRate})) / (${pricingColumns.purchasePriceEur} * ${eurHufRate})) * 100 end`
    : sql`${pricingColumns.profitPercent}`;
}
