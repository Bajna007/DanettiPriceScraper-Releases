import type { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { createDbClient, type DanettiDbClient } from "@danetti/db";
import { DvgArticleChangesRepository } from "./dvg-article-changes.repository.js";
import { DvgArticleChangesService, ArticleChangesError } from "./dvg-article-changes.service.js";
import { guardArticleChanges, validateArticleChangesInput } from "./dvg-article-changes.routes.js";
import {
  LfArticleChangesRepository,
  lfArticleChangeAdapter,
  lfArticleReviewRunner,
} from "./lf-article-changes.adapter.js";
import { ArticleChangesCoordinator, articleReviewId } from "./article-changes.coordinator.js";
export async function registerSupplierArticleChangesRoutes(
  server: FastifyInstance,
  options: { coordinator?: ArticleChangesCoordinator } = {}
) {
  let client: DanettiDbClient | null = null;
  let coordinator = options.coordinator;
  const get = () => {
    if (!coordinator) {
      const db = (client ??= createDbClient()).db;
      coordinator = new ArticleChangesCoordinator(
        {
          dvg: new DvgArticleChangesService(new DvgArticleChangesRepository(db)),
          lf: new DvgArticleChangesService(
            new LfArticleChangesRepository(db),
            lfArticleReviewRunner,
            lfArticleChangeAdapter
          ),
        },
        new DvgArticleChangesRepository(db, "combined_job")
      );
    }
    return coordinator;
  };
  server.addHook("onClose", async () => {
    await coordinator?.close();
    await client?.close();
  });
  const action = async (
    request: FastifyRequest,
    reply: FastifyReply,
    fn: () => Promise<unknown>
  ) => {
    try {
      guardArticleChanges(request);
      return await fn();
    } catch (error) {
      return reply.code(error instanceof ArticleChangesError ? error.statusCode : 500).send({
        error: {
          code: "supplier_article_changes_error",
          message:
            error instanceof ArticleChangesError
              ? error.message
              : "A cikkszámváltozások nem érhetők el. Ellenőrizd a helyi alkalmazást.",
        },
      });
    }
  };
  server.get("/article-changes", (request, reply) => action(request, reply, () => get().list()));
  server.post("/article-changes/run", (request, reply) =>
    action(request, reply, () => {
      const input = validateSupplierArticleChangesInput(request.body);
      reply.code(202);
      return get().start(input.reviewIds, input.speedMode);
    })
  );
  server.post("/article-changes/cancel", (request, reply) =>
    action(request, reply, () => get().cancel())
  );
  server.post("/article-changes/review", (request, reply) =>
    action(request, reply, () => {
      const input = request.body as Record<string, unknown> | null;
      if (
        !input ||
        Object.keys(input).some(
          (key) => !["reviewId", "originalArticle", "decision"].includes(key)
        ) ||
        typeof input.reviewId !== "string" ||
        !/^(dvg|lf):[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(
          input.reviewId
        ) ||
        typeof input.originalArticle !== "string" ||
        !input.originalArticle.trim() ||
        input.originalArticle.length > 200 ||
        !["resolved", "open"].includes(String(input.decision))
      )
        throw new ArticleChangesError(400, "Érvénytelen lezárási művelet.");
      return get().review(
        input.reviewId,
        input.originalArticle,
        input.decision as "resolved" | "open"
      );
    })
  );
  server.get("/dvg-article-changes", (request, reply) =>
    action(request, reply, () => get().providerState("dvg"))
  );
  server.post("/dvg-article-changes/run", (request, reply) =>
    action(request, reply, async () => {
      const input = validateArticleChangesInput(request.body);
      const source = await get().providerState("dvg");
      const ids = source.items
        .filter((item) =>
          input.catalogProductIds
            ? input.catalogProductIds.includes(item.catalogProductId)
            : item.sourceStatus === "article_changed"
        )
        .map(articleReviewId);
      if (input.catalogProductIds && ids.length !== input.catalogProductIds.length)
        throw new ArticleChangesError(400, "Érvénytelen termékkijelölés.");
      reply.code(202);
      return get().start(ids, input.speedMode);
    })
  );
  server.post("/dvg-article-changes/cancel", (request, reply) =>
    action(request, reply, () => get().cancel())
  );
}
export function validateSupplierArticleChangesInput(body: unknown): {
  reviewIds?: string[];
  speedMode?: "normal" | "fast" | "very_fast";
} {
  if (!body || typeof body !== "object" || Array.isArray(body))
    throw new ArticleChangesError(400, "Érvénytelen ellenőrzési beállítás.");
  const input = body as Record<string, unknown>;
  if (Object.keys(input).some((key) => !["reviewIds", "speedMode"].includes(key)))
    throw new ArticleChangesError(400, "Nem támogatott ellenőrzési beállítás.");
  const ids = input.reviewIds;
  if (
    ids !== undefined &&
    (!Array.isArray(ids) ||
      !ids.length ||
      ids.length > 500 ||
      new Set(ids).size !== ids.length ||
      ids.some(
        (id) =>
          typeof id !== "string" ||
          !/^(dvg|lf):[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(id)
      ))
  )
    throw new ArticleChangesError(400, "Érvénytelen termékkijelölés.");
  const speed = input.speedMode;
  if (speed !== undefined && !["normal", "fast", "very_fast"].includes(String(speed)))
    throw new ArticleChangesError(400, "Érvénytelen sebesség.");
  return {
    reviewIds: ids as string[] | undefined,
    speedMode: speed as "normal" | "fast" | "very_fast" | undefined,
  };
}
