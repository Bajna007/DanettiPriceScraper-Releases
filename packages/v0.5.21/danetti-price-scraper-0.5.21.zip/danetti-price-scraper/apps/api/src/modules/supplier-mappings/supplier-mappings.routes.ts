import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import { SupplierMappingsRepository } from "./supplier-mappings.repository.js";
import {
  SupplierMappingDatabaseError,
  SupplierMappingValidationError,
} from "./supplier-mappings.types.js";
import {
  buildDvgMappingReviewPreview,
  buildMappingSuggestions,
  deriveDvgExpectedArticleFromCatalogProduct,
  validateDvgMappingReviewPreviewInput,
  validateCreateSupplierMappingInput,
  validateUpdateSupplierMappingInput,
  validateUuid,
} from "./supplier-mappings.service.js";

interface SupplierMappingRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
}

interface ListQuery {
  catalogProductId?: string;
  supplierId?: string;
  enabled?: string;
  limit?: string;
  offset?: string;
}

interface IdParams {
  id: string;
}

export async function registerSupplierMappingRoutes(
  server: FastifyInstance,
  options: SupplierMappingRouteOptions = {}
): Promise<void> {
  let dbClient = options.dbClient ?? null;

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getRepository(): SupplierMappingsRepository {
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new SupplierMappingsRepository(dbClient.db);
    } catch (error) {
      throw new SupplierMappingDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/supplier-mappings", async (request, reply) => {
    try {
      const query = request.query as ListQuery;
      const catalogProductId = optionalUuid(query.catalogProductId, "catalogProductId");
      const supplierId = optionalUuid(query.supplierId, "supplierId");
      const enabled = parseOptionalBoolean(query.enabled, "enabled");
      const limit = parseBoundedInteger(query.limit, 50, 200, "limit");
      const offset = parseBoundedInteger(query.offset, 0, Number.MAX_SAFE_INTEGER, "offset");
      const items = await getRepository().list({
        catalogProductId,
        supplierId,
        enabled,
        limit,
        offset,
      });
      return { items, limit, offset };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-mappings", async (request, reply) => {
    try {
      const repository = getRepository();
      const input = validateCreateSupplierMappingInput(request.body);
      await assertReferencesExist(repository, input.catalogProductId, input.supplierId);
      const duplicate = await repository.findActiveDuplicate(input);
      if (input.enabled !== false && duplicate !== null) {
        throw new SupplierMappingValidationError(
          "duplicate_mapping",
          "Active mapping already exists"
        );
      }
      await assertNoActivePrimaryDuplicate(repository, input);
      const mapping = await repository.create(input);
      return reply.code(201).send(mapping);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-mappings/dvg/preview", async (request, reply) => {
    try {
      const preview = validateDvgMappingReviewPreviewInput(request.body);
      let catalogFallback: {
        expectedArticle?: string | null;
        mappingSource?: string | null;
      } | null = null;

      if (preview.catalogProductId && !preview.expectedArticle) {
        const product = await getRepository().getCatalogProductById(preview.catalogProductId);
        if (product === null) {
          return reply
            .code(404)
            .send({ error: { code: "not_found", message: "Catalog product not found" } });
        }
        catalogFallback = deriveDvgExpectedArticleFromCatalogProduct(product);
      }

      return buildDvgMappingReviewPreview({ preview, catalogFallback });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/supplier-mappings/dvg/auto-pair", async (_request, reply) => {
    try {
      return await getRepository().autoPairDvgProducts();
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/supplier-mappings/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const mapping = await getRepository().getById(params.id);
      if (mapping === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Mapping not found" } });
      return mapping;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.patch("/supplier-mappings/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const repository = getRepository();
      const existing = await repository.getById(params.id);
      if (existing === null)
        return reply.code(404).send({ error: { code: "not_found", message: "Mapping not found" } });

      const input = validateUpdateSupplierMappingInput(
        request.body,
        existing.lookupStrategy,
        existing.directUrl
      );
      const merged = { ...existing, ...input };
      const duplicate = await repository.findActiveDuplicate({
        catalogProductId: merged.catalogProductId,
        supplierId: merged.supplierId,
        supplierArticleNumber: merged.supplierArticleNumber,
        excludeId: existing.id,
      });
      if (merged.enabled !== false && duplicate !== null) {
        throw new SupplierMappingValidationError(
          "duplicate_mapping",
          "Active mapping already exists"
        );
      }
      await assertNoActivePrimaryDuplicate(repository, merged, existing.id);
      const mapping = await repository.update(params.id, input);
      return mapping;
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/catalog/products/:id/mapping-suggestions", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");
      const repository = getRepository();
      const product = await repository.getCatalogProductById(params.id);
      if (product === null)
        return reply
          .code(404)
          .send({ error: { code: "not_found", message: "Catalog product not found" } });
      const activeSuppliers = await repository.listActiveSuppliers();
      return buildMappingSuggestions({ product, suppliers: activeSuppliers });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

async function assertNoActivePrimaryDuplicate(
  repository: SupplierMappingsRepository,
  input: { catalogProductId: string; supplierId: string; enabled?: boolean; isPrimary?: boolean },
  excludeId?: string
): Promise<void> {
  if (input.enabled === false || input.isPrimary !== true) return;
  const duplicate = await repository.findActivePrimary({
    catalogProductId: input.catalogProductId,
    supplierId: input.supplierId,
    excludeId,
  });
  if (duplicate !== null) {
    throw new SupplierMappingValidationError(
      "duplicate_primary_mapping",
      "Active primary mapping already exists for this product and supplier"
    );
  }
}

async function assertReferencesExist(
  repository: SupplierMappingsRepository,
  catalogProductId: string,
  supplierId: string
): Promise<void> {
  const [product, supplier] = await Promise.all([
    repository.getCatalogProductById(catalogProductId),
    repository.getSupplierById(supplierId),
  ]);
  if (product === null)
    throw new SupplierMappingValidationError(
      "missing_catalog_product",
      "Catalog product not found"
    );
  if (supplier === null)
    throw new SupplierMappingValidationError("missing_supplier", "Supplier not found");
}

function optionalUuid(value: string | undefined, field: string): string | undefined {
  if (value === undefined || value.trim().length === 0) return undefined;
  validateUuid(value, field);
  return value;
}

function parseOptionalBoolean(value: string | undefined, field: string): boolean | undefined {
  if (value === undefined) return undefined;
  if (value === "true") return true;
  if (value === "false") return false;
  throw new SupplierMappingValidationError("invalid_query", `${field} must be true or false`);
}

function parseBoundedInteger(
  value: string | undefined,
  defaultValue: number,
  maxValue: number,
  field: string
): number {
  if (value === undefined) return defaultValue;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0 || parsed > maxValue) {
    throw new SupplierMappingValidationError(
      "invalid_query",
      `${field} must be an integer between 0 and ${maxValue}`
    );
  }
  return parsed;
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof SupplierMappingValidationError) {
    return reply
      .code(error.httpStatus)
      .send({ error: { code: error.code, message: error.message } });
  }
  if (error instanceof SupplierMappingDatabaseError) {
    return reply
      .code(503)
      .send({ error: { code: "database_unavailable", message: error.message } });
  }
  return reply
    .code(500)
    .send({ error: { code: "internal_error", message: "Unexpected mapping API error" } });
}
