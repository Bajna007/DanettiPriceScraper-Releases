import { randomUUID } from "node:crypto";
import type {
  SupplierArticleChangesState,
  SupplierArticleChangeItem,
  SupplierArticleChangeJob,
} from "@danetti/shared";
import {
  ArticleChangesError,
  isArticleChangeJobActive,
  type DvgArticleChangesService,
} from "./dvg-article-changes.service.js";
type Supplier = "dvg" | "lf";
type Service = Pick<
  DvgArticleChangesService,
  "list" | "start" | "cancel" | "settled" | "close" | "review"
>;
export const articleReviewId = (
  item: Pick<SupplierArticleChangeItem, "supplier" | "catalogProductId">
) => `${item.supplier}:${item.catalogProductId}`;

/** One queue and one review model; supplier adapters own navigation and price validation. */
export class ArticleChangesCoordinator {
  private job: SupplierArticleChangeJob | null = null;
  private loaded: Promise<void> | null = null;
  private task: Promise<void> | null = null;
  private cancelled = false;
  private phase: Supplier | null = null;
  private phaseRunId: string | null = null;
  private completed = 0;
  constructor(
    private readonly services: Record<Supplier, Service>,
    private readonly storage: {
      load(): Promise<SupplierArticleChangesState | null>;
      save(state: SupplierArticleChangesState): Promise<void>;
    }
  ) {}
  private async load() {
    this.loaded ??= (async () => {
      this.job = (await this.storage.load())?.job ?? null;
      if (isArticleChangeJobActive(this.job?.status)) {
        this.job!.status = "interrupted";
        this.job!.finishedAt = new Date().toISOString();
        this.job!.message =
          "Az alkalmazás újraindult. A megmaradt tételek célzottan újraellenőrizhetők.";
        await this.persist();
      }
    })();
    try {
      await this.loaded;
    } catch (error) {
      this.loaded = null;
      throw error;
    }
  }
  async providerState(supplier: Supplier) {
    await this.load();
    return this.services[supplier].list();
  }
  async list(): Promise<SupplierArticleChangesState> {
    await this.load();
    const states = await Promise.all([this.services.dvg.list(), this.services.lf.list()]);
    if (this.job && this.task && this.phase && this.phaseRunId) {
      const active = states[this.phase === "dvg" ? 0 : 1]!.job;
      if (active?.runId === this.phaseRunId) {
        this.job.checked = this.completed + active.checked;
        this.job.currentArticle = active.currentArticle;
        this.job.status = active.status === "completed" ? "running" : active.status;
        this.job.supplier = this.phase;
        this.job.message = active.message;
      }
    }
    const latest =
      states
        .map((s) => s.job)
        .filter((j): j is SupplierArticleChangeJob => j !== null)
        .sort((a, b) => b.startedAt.localeCompare(a.startedAt))[0] ?? null;
    return {
      resolved: states.flatMap((state) => state.resolved ?? []),
      closedItems: states.flatMap((state) => state.closedItems ?? []),
      items: states.flatMap((s) => s.items),
      job: structuredClone(this.job ?? latest),
      sourceRunId: states.map((s) => s.sourceRunId ?? "").join("|"),
      updatedAt: new Date().toISOString(),
    };
  }
  async start(ids: string[] | undefined, speed: "normal" | "fast" | "very_fast" = "very_fast") {
    const state = await this.list();
    if (this.task) throw new ArticleChangesError(409, "Már fut cikkszám-ellenőrzés.");
    const selected = state.items.filter((item) =>
      ids ? ids.includes(articleReviewId(item)) : item.sourceStatus === "article_changed"
    );
    if (!selected.length || (ids && selected.length !== new Set(ids).size))
      throw new ArticleChangesError(400, "Nincs ellenőrizhető kijelölt termék.");
    this.cancelled = false;
    this.completed = 0;
    this.job = {
      runId: `supplier-article-changes-${randomUUID()}`,
      status: "opening_browser",
      checked: 0,
      total: selected.length,
      currentArticle: null,
      startedAt: new Date().toISOString(),
      finishedAt: null,
      message: null,
    };
    let release!: () => void;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    this.task = (async () => {
      await gate;
      try {
        for (const supplier of ["dvg", "lf"] as const) {
          const work = selected
            .filter((item) => item.supplier === supplier)
            .map((item) => item.catalogProductId);
          if (!work.length || this.cancelled) continue;
          this.phase = supplier;
          this.phaseRunId = null;
          this.job!.supplier = supplier;
          this.job!.status = "opening_browser";
          const started = await this.services[supplier].start(work, speed);
          this.phaseRunId = started.job!.runId;
          if (this.cancelled) await this.services[supplier].cancel();
          await this.services[supplier].settled();
          const finished = (await this.services[supplier].list()).job!;
          this.completed += finished.checked;
          this.job!.checked = this.completed;
          if (finished.status !== "completed") {
            this.job!.status = finished.status;
            this.job!.message = finished.message;
            break;
          }
          this.job!.status = "running";
          this.phase = null;
          this.phaseRunId = null;
        }
        if (this.cancelled) this.job!.status = "cancelled";
        else if (this.completed === selected.length) this.job!.status = "completed";
      } catch (error) {
        this.job!.status = this.cancelled ? "cancelled" : "failed";
        this.job!.message =
          error instanceof ArticleChangesError
            ? error.message
            : "Az ellenőrzés megszakadt. Az eredmények megmaradtak.";
      } finally {
        this.job!.finishedAt = new Date().toISOString();
        this.job!.currentArticle = null;
        try {
          await this.persist();
        } catch {
          this.job!.status = "failed";
          this.job!.message = "A végső állapot mentése sikertelen.";
        }
        this.phase = null;
        this.phaseRunId = null;
        this.task = null;
      }
    })();
    try {
      await this.persist();
    } catch (error) {
      this.cancelled = true;
      release();
      await this.task;
      throw error;
    }
    release();
    return this.list();
  }
  async cancel() {
    await this.load();
    this.cancelled = true;
    if (this.phase) await this.services[this.phase].cancel();
    await this.task;
    return this.list();
  }
  async review(id: string, originalArticle: string, decision: "resolved" | "open") {
    await this.load();
    if (this.task) throw new ArticleChangesError(409, "Várd meg az ellenőrzés végét.");
    const [supplier, catalogId] = id.toLowerCase().split(":") as [Supplier, string];
    await this.services[supplier].review(catalogId, originalArticle, decision);
    return this.list();
  }
  async settled() {
    await this.task;
  }
  async close() {
    await this.cancel();
    await Promise.all([this.services.dvg.close(), this.services.lf.close()]);
  }
  private persist() {
    return this.storage.save({
      items: [],
      job: structuredClone(this.job),
      sourceRunId: null,
      updatedAt: new Date().toISOString(),
    });
  }
}
