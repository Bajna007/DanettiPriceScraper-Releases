import type { FastifyInstance, FastifyReply } from "fastify";
import { getSetupStatus } from "./setup.service.js";

export async function registerSetupRoutes(server: FastifyInstance): Promise<void> {
  server.get("/setup/status", async (_request, reply) => {
    try {
      return await getSetupStatus();
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  return reply.code(503).send({
    error: {
      code: "setup_status_unavailable",
      message: error instanceof Error ? error.message : "Setup status unavailable",
    },
  });
}
