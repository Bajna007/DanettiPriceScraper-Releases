import assert from "node:assert/strict";
import {
  DVG_CONNECTOR_ID,
  DVG_DISPLAY_NAME,
  DVG_LOGIN_URL,
  readSupplierSessionSafetyFlagsFromContent,
  type BrowserRuntime,
  type SupplierBrowserProfilePolicy,
  type SupplierProfileResetResult,
  type SupplierReadOnlyPageResult,
  type SupplierSessionState,
} from "@danetti/connectors";
import type {
  ManualOperatorRun,
  NewManualOperatorRun,
  NewSupplierPriceSnapshot,
  SupplierMapping,
  SupplierPriceSnapshot,
} from "@danetti/db";
import Fastify from "fastify";
import type { ManualOperatorRunListFilters } from "../manual-operator-runs/manual-operator-runs.repository.js";
import type { SupplierSnapshotListFilters } from "../supplier-snapshots/supplier-snapshots.repository.js";
import {
  registerSupplierSessionRoutes,
  scrubSupplierSessionPayload,
} from "./supplier-sessions.routes.js";

const supplierId = "11111111-1111-4111-8111-111111111111";
const otherSupplierId = "11111111-1111-4111-8111-111111111112";
const mappingId = "22222222-2222-4222-8222-222222222222";
const mappingId2 = "22222222-2222-4222-8222-222222222225";
const mappingId3 = "22222222-2222-4222-8222-222222222226";
const mappingId4 = "22222222-2222-4222-8222-222222222227";
const mappingId5 = "22222222-2222-4222-8222-222222222228";
const mappingId6 = "22222222-2222-4222-8222-222222222229";
const disabledMappingId = "22222222-2222-4222-8222-222222222223";
const otherSupplierMappingId = "22222222-2222-4222-8222-222222222224";
const catalogProductId = "33333333-3333-4333-8333-333333333333";
const sessionHeaders = {
  "x-danetti-local-lab": "true",
  origin: "http://localhost:3000",
};
const profilePolicy: SupplierBrowserProfilePolicy = {
  persistence: "persistent_local_browser_profile",
  supplierId,
  profileRootDir:
    "C:\\Users\\local\\AppData\\Local\\DanettiPriceScraper\\supplier-browser-profiles",
  profileDir:
    "C:\\Users\\local\\AppData\\Local\\DanettiPriceScraper\\supplier-browser-profiles\\11111111-1111-4111-8111-111111111111",
  repoStorage: "forbidden",
  databaseStorage: "forbidden",
  defaultChromeProfile: "forbidden",
  stateExport: "forbidden",
  deletable: true,
};
const now = new Date("2026-06-10T10:00:00.000Z");

const scrubbed = scrubSupplierSessionPayload({
  ok: true,
  nested: {
    cookie: "secret-cookie",
    setCookie: "secret-set-cookie",
    "set-cookie": "secret-set-cookie-header",
    authorization: "Bearer secret",
    bearer: "secret-bearer",
    password: "secret-password",
    credential: "secret-credential",
    token: "secret-token",
    session: "secret-session",
    storageState: "secret-storage-state",
    localStorage: "secret-local-storage",
    sessionStorage: "secret-session-storage",
    rawHtml: "<main>secret raw</main>",
    html: "<main>secret</main>",
    screenshot: "secret.png",
    HAR: "secret.har",
    trace: "secret-trace.zip",
    MHTML: "secret.mhtml",
    profilePath: "C:\\Users\\local\\secret",
    userDataDir: "/home/local/secret-profile",
    windowsPathValue: "C:\\Users\\local\\secret-file.txt",
    unixPathValue: "/home/local/secret-file.txt",
    embeddedWindowsPath: "path C:\\Users\\local\\secret-file.txt",
    embeddedUnixPath: "path /home/local/secret-file.txt",
    deep: [
      { token: "deep-secret" },
      { safePath: "DanettiPriceScraper/supplier-browser-profiles/dvg" },
    ],
    maskedProfilePath: "DanettiPriceScraper/supplier-browser-profiles/dvg",
  },
});
assert.equal(JSON.stringify(scrubbed).includes("secret"), false);
assert.equal(JSON.stringify(scrubbed).includes("C:\\Users"), false);
assert.equal(JSON.stringify(scrubbed).includes("/home/local"), false);
assert.equal(
  scrubbed.nested.maskedProfilePath,
  "DanettiPriceScraper/supplier-browser-profiles/dvg"
);
assert.equal(scrubbed.nested.windowsPathValue, "[redacted]");
assert.equal(scrubbed.nested.unixPathValue, "[redacted]");
assert.equal(scrubbed.nested.embeddedWindowsPath, "[redacted]");
assert.equal(scrubbed.nested.embeddedUnixPath, "[redacted]");

class StubRuntime implements BrowserRuntime {
  openCalls = 0;
  openReadOnlyUrlCalls = 0;
  activeReadOnlyUrlCalls = 0;
  maxConcurrentReadOnlyUrlCalls = 0;
  closeCalls = 0;
  resetCalled = false;
  html = sampleDetailHtml("CS-A2200247", true);
  private state = createSessionState(true, false);

  async openSupplierSession(): Promise<SupplierSessionState> {
    this.openCalls += 1;
    this.state = createSessionState(true, this.openCalls > 1);
    return this.state;
  }

  async checkAuthenticatedSession(): Promise<SupplierSessionState> {
    return this.state;
  }

  setHistoricalLoginSafetyEvent(): void {
    this.state = createSessionState(true, false, ["unsafe_domain"]);
  }

  async openReadOnlyUrl(): Promise<SupplierReadOnlyPageResult> {
    this.openReadOnlyUrlCalls += 1;
    this.activeReadOnlyUrlCalls += 1;
    this.maxConcurrentReadOnlyUrlCalls = Math.max(
      this.maxConcurrentReadOnlyUrlCalls,
      this.activeReadOnlyUrlCalls
    );
    await Promise.resolve();
    this.activeReadOnlyUrlCalls -= 1;
    return {
      mode: "manual_host_browser_profile",
      supplierId,
      connectorId: DVG_CONNECTOR_ID,
      status: "opened",
      finalPath: "/e-commerce/welcome/ordini/dettagli.asp",
      safetyFlags: this.state.safetyFlags,
      blockingReasons: [],
      warnings: [],
    };
  }

  async readVisibleText(): Promise<string | null> {
    return this.html.replace(/<[^>]+>/g, " ");
  }

  async readHtml(): Promise<string | null> {
    return this.html;
  }

  async closeSession(): Promise<SupplierSessionState> {
    this.closeCalls += 1;
    this.state = { ...this.state, status: "closed", authenticated: false, reused: false };
    return this.state;
  }

  async resetLocalProfile(): Promise<SupplierProfileResetResult> {
    this.resetCalled = true;
    await this.closeSession();
    return {
      supplierId,
      connectorId: DVG_CONNECTOR_ID,
      profilePolicy,
      reset: true,
      warnings: [],
    };
  }
}

class InMemorySnapshotRepository {
  snapshots: SupplierPriceSnapshot[] = [];
  mappings = new Map<string, SupplierMapping>([
    [mappingId, createMapping(mappingId, supplierId, true)],
    [mappingId2, createMapping(mappingId2, supplierId, true)],
    [mappingId3, createMapping(mappingId3, supplierId, true)],
    [mappingId4, createMapping(mappingId4, supplierId, true)],
    [mappingId5, createMapping(mappingId5, supplierId, true)],
    [disabledMappingId, createMapping(disabledMappingId, supplierId, false)],
    [otherSupplierMappingId, createMapping(otherSupplierMappingId, otherSupplierId, true)],
  ]);

  async getMappingById(id: string): Promise<SupplierMapping | null> {
    return this.mappings.get(id) ?? null;
  }

  async insertSnapshot(input: NewSupplierPriceSnapshot): Promise<SupplierPriceSnapshot> {
    const snapshot: SupplierPriceSnapshot = {
      id: `44444444-4444-4444-8444-${String(this.snapshots.length + 1).padStart(12, "0")}`,
      supplierId: input.supplierId,
      supplierMappingId: input.supplierMappingId ?? null,
      catalogProductId: input.catalogProductId ?? null,
      crawlerRunItemId: input.crawlerRunItemId ?? null,
      supplierArticleNumber: input.supplierArticleNumber,
      supplierProductName: input.supplierProductName ?? null,
      priceNetEur: input.priceNetEur ?? null,
      priceGrossEur: input.priceGrossEur ?? null,
      currency: input.currency ?? "EUR",
      stockStatus: input.stockStatus ?? "unknown",
      availabilityText: input.availabilityText ?? null,
      matchConfidence: input.matchConfidence ?? "none",
      resultUrl: input.resultUrl ?? null,
      observedAt: input.observedAt,
      evidenceArtifactId: input.evidenceArtifactId ?? null,
      createdAt: now,
    };
    this.snapshots.push(snapshot);
    return snapshot;
  }

  async listSnapshots(input: SupplierSnapshotListFilters): Promise<SupplierPriceSnapshot[]> {
    return this.snapshots.slice(input.offset, input.offset + input.limit);
  }

  async getSnapshotById(id: string): Promise<SupplierPriceSnapshot | null> {
    return this.snapshots.find((snapshot) => snapshot.id === id) ?? null;
  }
}

class InMemoryManualRunRepository {
  runs: ManualOperatorRun[] = [];

  async insertRun(input: NewManualOperatorRun): Promise<ManualOperatorRun> {
    const run: ManualOperatorRun = {
      runId: input.runId,
      supplierId: input.supplierId,
      startedAt: input.startedAt,
      finishedAt: input.finishedAt,
      mode: input.mode,
      requestedCount: input.requestedCount ?? 0,
      processedCount: input.processedCount ?? 0,
      savedCount: input.savedCount ?? 0,
      blockedCount: input.blockedCount ?? 0,
      failedCount: input.failedCount ?? 0,
      stoppedReason: input.stoppedReason ?? null,
      itemSummaries: input.itemSummaries,
      createdAt: now,
    };
    this.runs.unshift(run);
    return run;
  }

  async listRuns(input: ManualOperatorRunListFilters): Promise<ManualOperatorRun[]> {
    return this.runs
      .filter((run) => !input.supplierId || run.supplierId === input.supplierId)
      .filter((run) => !input.mode || run.mode === input.mode)
      .slice(input.offset, input.offset + input.limit);
  }

  async getRun(runId: string): Promise<ManualOperatorRun | null> {
    return this.runs.find((run) => run.runId === runId) ?? null;
  }
}

let runtimeCreated = 0;
const runtime = new StubRuntime();
const repository = new InMemorySnapshotRepository();
const manualRunRepository = new InMemoryManualRunRepository();
const server = Fastify({ logger: false });

await registerSupplierSessionRoutes(server, {
  env: { NODE_ENV: "development" },
  now: () => now,
  manualBatchDelayMs: 0,
  snapshotRepository: repository,
  manualRunRepository,
  runtimeFactory(input) {
    runtimeCreated += 1;
    assert.equal(input.connectorId, DVG_CONNECTOR_ID);
    assert.equal(input.supplierId, supplierId);
    return runtime;
  },
});

try {
  const idle = await server.inject({
    method: "GET",
    url: `/supplier-sessions/${supplierId}/status`,
    headers: sessionHeaders,
  });
  assert.equal(idle.statusCode, 200);
  assert.equal(idle.json().state, "idle");

  const readiness = await server.inject({
    method: "GET",
    url: `/supplier-sessions/${supplierId}/operator-readiness`,
    headers: sessionHeaders,
  });
  assert.equal(readiness.statusCode, 200);
  assert.equal(readiness.json().apiReachable, true);
  assert.equal(readiness.json().databaseReachable, true);
  assert.equal(readiness.json().sessionLabEnabled, true);
  assert.equal(readiness.json().browserRuntimeAvailable, true);
  assert.equal(
    readiness.json().currentLocalGuardMode,
    "loopback_header_localhost_origin_production_opt_in"
  );

  const missingHeader = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/open`,
    payload: { connectorId: DVG_CONNECTOR_ID, loginUrl: DVG_LOGIN_URL },
  });
  assert.equal(missingHeader.statusCode, 403);
  assert.equal(missingHeader.json().error.code, "supplier_session_header_missing");
  assert.equal(missingHeader.json().error.operatorCode, null);

  const forbiddenOrigin = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/open`,
    headers: { "x-danetti-local-lab": "true", origin: "https://evil.example" },
    payload: { connectorId: DVG_CONNECTOR_ID, loginUrl: DVG_LOGIN_URL },
  });
  assert.equal(forbiddenOrigin.statusCode, 403);
  assert.equal(forbiddenOrigin.json().error.code, "supplier_session_origin_forbidden");
  assert.equal(forbiddenOrigin.json().error.operatorCode, "unsafe_domain");

  const blockedLan = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/open`,
    remoteAddress: "192.168.1.20",
    headers: sessionHeaders,
    payload: { connectorId: DVG_CONNECTOR_ID, loginUrl: DVG_LOGIN_URL },
  });
  assert.equal(blockedLan.statusCode, 403);
  assert.equal(blockedLan.json().error.code, "supplier_session_local_only");

  const badLoginUrl = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/open`,
    headers: sessionHeaders,
    payload: {
      connectorId: DVG_CONNECTOR_ID,
      loginUrl: "http://devecchigiuseppesrl.com/e-commerce/account/login.asp?x=1",
    },
  });
  assert.equal(badLoginUrl.statusCode, 400);
  assert.equal(badLoginUrl.json().error.code, "unsupported_supplier_session_login_url");

  const opened = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/open`,
    headers: sessionHeaders,
    payload: { connectorId: DVG_CONNECTOR_ID, loginUrl: DVG_LOGIN_URL },
  });
  assert.equal(opened.statusCode, 200);
  assert.equal(opened.json().state, "authenticated");
  assert.equal(opened.json().browserOpen, true);
  assert.deepEqual(opened.json().blockingSafetyFlags, []);
  assert.equal(opened.json().maskedProfilePath.includes("DanettiPriceScraper"), true);
  assert.equal(JSON.stringify(opened.json()).includes("C:\\Users"), false);
  assert.equal(runtimeCreated, 1);

  runtime.setHistoricalLoginSafetyEvent();
  const checkedWithHistoricalLoginEvent = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/check`,
    headers: sessionHeaders,
    payload: {},
  });
  assert.equal(checkedWithHistoricalLoginEvent.statusCode, 200);
  assert.equal(checkedWithHistoricalLoginEvent.json().authenticatedLikely, true);
  assert.deepEqual(checkedWithHistoricalLoginEvent.json().safetyEventCodes, ["unsafe_domain"]);
  assert.deepEqual(checkedWithHistoricalLoginEvent.json().blockingSafetyFlags, []);

  const historicalSafetyDryRunSelected = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/run-selected`,
    headers: sessionHeaders,
    payload: { supplierMappingIds: [mappingId], saveSnapshots: false },
  });
  assert.equal(historicalSafetyDryRunSelected.statusCode, 200);
  assert.equal(historicalSafetyDryRunSelected.json().status, "completed");
  assert.equal(historicalSafetyDryRunSelected.json().processed, 1);
  assert.equal(historicalSafetyDryRunSelected.json().stoppedReason, null);
  assert.deepEqual(historicalSafetyDryRunSelected.json().items[0].safety.safetyEventCodes, [
    "unsafe_domain",
  ]);
  assert.deepEqual(historicalSafetyDryRunSelected.json().items[0].safety.blockingSafetyFlags, []);

  const openedAgain = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/open`,
    headers: sessionHeaders,
    payload: { connectorId: DVG_CONNECTOR_ID, loginUrl: DVG_LOGIN_URL },
  });
  assert.equal(openedAgain.statusCode, 200);
  assert.equal(openedAgain.json().reused, true);
  assert.equal(runtimeCreated, 1);

  const manualPreview = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/read-one`,
    headers: sessionHeaders,
    payload: { supplierArticleNumber: "CS-A2200247" },
  });
  assert.equal(manualPreview.statusCode, 200);
  assert.equal(manualPreview.json().status, "parsed");
  assert.equal(typeof manualPreview.json().runId, "string");
  assert.equal(manualPreview.json().startedAt, now.toISOString());
  assert.equal(manualPreview.json().supplierMappingId, null);
  assert.equal(manualPreview.json().persistence.saved, false);
  assert.equal(manualPreview.json().persistence.reason, "not_requested");
  assert.equal(manualRunRepository.runs[0]?.mode, "read_one");
  assert.equal(manualRunRepository.runs[0]?.itemSummaries[0]?.status, "parsed");
  assert.equal(JSON.stringify(manualPreview.json()).includes("<main>"), false);
  assert.equal(
    /cookie|storageState|password|credential|rawHtml|screenshot/i.test(
      JSON.stringify(manualPreview.json())
    ),
    false
  );

  const manualSaveBlocked = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/read-one`,
    headers: sessionHeaders,
    payload: { supplierArticleNumber: "CS-A2200247", dryRun: false, saveSnapshot: true },
  });
  assert.equal(manualSaveBlocked.statusCode, 200);
  assert.equal(manualSaveBlocked.json().persistence.saved, false);
  assert.equal(manualSaveBlocked.json().persistence.reason, "supplier_mapping_required");

  const unknownMapping = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/read-one`,
    headers: sessionHeaders,
    payload: { supplierMappingId: "22222222-2222-4222-8222-999999999999" },
  });
  assert.equal(unknownMapping.statusCode, 404);
  assert.equal(unknownMapping.json().error.code, "mapping_not_found");

  const otherSupplierMapping = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/read-one`,
    headers: sessionHeaders,
    payload: { supplierMappingId: otherSupplierMappingId },
  });
  assert.equal(otherSupplierMapping.statusCode, 403);
  assert.equal(otherSupplierMapping.json().error.code, "mapping_supplier_mismatch");

  const disabledMapping = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/read-one`,
    headers: sessionHeaders,
    payload: { supplierMappingId: disabledMappingId },
  });
  assert.equal(disabledMapping.statusCode, 400);
  assert.equal(disabledMapping.json().error.code, "mapping_disabled");

  const dryRunMapping = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/read-one`,
    headers: sessionHeaders,
    payload: { supplierMappingId: mappingId, saveSnapshot: true },
  });
  assert.equal(dryRunMapping.statusCode, 200);
  assert.equal(dryRunMapping.json().persistence.saved, false);
  assert.equal(dryRunMapping.json().persistence.reason, "dry_run");
  assert.equal(repository.snapshots.length, 0);

  const saved = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/read-one`,
    headers: sessionHeaders,
    payload: { supplierMappingId: mappingId, dryRun: false, saveSnapshot: true },
  });
  assert.equal(saved.statusCode, 200);
  assert.equal(saved.json().persistence.saved, true);
  assert.equal(saved.json().persistence.snapshotId, repository.snapshots[0]?.id);
  assert.equal(repository.snapshots.length, 1);

  const emptySelected = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/run-selected`,
    headers: sessionHeaders,
    payload: { supplierMappingIds: [], saveSnapshots: false },
  });
  assert.equal(emptySelected.statusCode, 400);
  assert.equal(emptySelected.json().error.code, "supplier_mapping_ids_empty");

  const duplicateSelected = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/run-selected`,
    headers: sessionHeaders,
    payload: { supplierMappingIds: [mappingId, mappingId], saveSnapshots: false },
  });
  assert.equal(duplicateSelected.statusCode, 400);
  assert.equal(duplicateSelected.json().error.code, "duplicate_supplier_mapping");

  const tooLargeSelected = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/run-selected`,
    headers: sessionHeaders,
    payload: {
      supplierMappingIds: [mappingId, mappingId2, mappingId3, mappingId4, mappingId5, mappingId6],
      saveSnapshots: false,
    },
  });
  assert.equal(tooLargeSelected.statusCode, 400);
  assert.equal(tooLargeSelected.json().error.code, "manual_batch_too_large");

  const otherSupplierSelected = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/run-selected`,
    headers: sessionHeaders,
    payload: { supplierMappingIds: [otherSupplierMappingId], saveSnapshots: false },
  });
  assert.equal(otherSupplierSelected.statusCode, 403);
  assert.equal(otherSupplierSelected.json().error.code, "mapping_supplier_mismatch");

  runtime.html = sampleDetailHtml("CS-A2200247", true);
  const dryRunSelected = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/run-selected`,
    headers: sessionHeaders,
    payload: { supplierMappingIds: [mappingId2, mappingId3], saveSnapshots: false },
  });
  assert.equal(dryRunSelected.statusCode, 200);
  assert.equal(dryRunSelected.json().status, "completed");
  assert.equal(dryRunSelected.json().processed, 2);
  assert.equal(dryRunSelected.json().savedCount, 0);
  assert.equal(repository.snapshots.length, 1);
  assert.equal(runtime.maxConcurrentReadOnlyUrlCalls, 1);
  assert.equal(
    /cookie|storageState|password|credential|rawHtml|screenshot|authorization|setCookie|profilePath/i.test(
      JSON.stringify(dryRunSelected.json())
    ),
    false
  );

  const savedSelected = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/run-selected`,
    headers: sessionHeaders,
    payload: { supplierMappingIds: [mappingId2, mappingId3], saveSnapshots: true },
  });
  assert.equal(savedSelected.statusCode, 200);
  assert.equal(savedSelected.json().status, "completed");
  assert.equal(typeof savedSelected.json().runId, "string");
  assert.equal(savedSelected.json().startedAt, now.toISOString());
  assert.equal(savedSelected.json().processed, 2);
  assert.equal(savedSelected.json().savedCount, 2);
  assert.equal(repository.snapshots.length, 3);
  assert.equal(manualRunRepository.runs[0]?.mode, "selected_micro_batch");
  assert.equal(manualRunRepository.runs[0]?.savedCount, 2);

  runtime.html = sampleCartHtml("CS-A2200247");
  const cartCompletedSelected = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/run-selected`,
    headers: sessionHeaders,
    payload: { supplierMappingIds: [mappingId4, mappingId5], saveSnapshots: true },
  });
  assert.equal(cartCompletedSelected.statusCode, 200);
  assert.equal(cartCompletedSelected.json().status, "completed");
  assert.equal(cartCompletedSelected.json().processed, 2);
  assert.equal(cartCompletedSelected.json().savedCount, 2);
  assert.equal(repository.snapshots.length, 5);

  const completedRunId = cartCompletedSelected.json().runId as string;
  const historyList = await server.inject({
    method: "GET",
    url: `/supplier-sessions/${supplierId}/manual-runs?limit=5`,
    headers: sessionHeaders,
  });
  assert.equal(historyList.statusCode, 200);
  assert.equal(historyList.json().runs.length > 0, true);
  assert.equal(historyList.json().runs[0].supplierId, supplierId);

  const completedRun = await server.inject({
    method: "GET",
    url: `/supplier-sessions/${supplierId}/manual-runs/${completedRunId}`,
    headers: sessionHeaders,
  });
  assert.equal(completedRun.statusCode, 200);
  assert.equal(completedRun.json().itemSummaries[0].status, "saved");
  assert.equal(JSON.stringify(completedRun.json()).includes("C:\\Users"), false);

  const csvExport = await server.inject({
    method: "GET",
    url: `/supplier-sessions/${supplierId}/manual-runs/${completedRunId}/export?format=csv`,
    headers: sessionHeaders,
  });
  assert.equal(csvExport.statusCode, 200);
  assert.match(csvExport.body, /runId,supplierId,mode/);
  assert.match(csvExport.body, /saved/);

  const badExport = await server.inject({
    method: "GET",
    url: `/supplier-sessions/${supplierId}/manual-runs/${completedRunId}/export?format=zip`,
    headers: sessionHeaders,
  });
  assert.equal(badExport.statusCode, 400);
  assert.equal(badExport.json().error.code, "manual_run_export_format_invalid");

  const retryNotAllowed = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/retry-one`,
    headers: sessionHeaders,
    payload: { sourceRunId: savedSelected.json().runId, supplierMappingId: mappingId2 },
  });
  assert.equal(retryNotAllowed.statusCode, 400);
  assert.equal(retryNotAllowed.json().error.code, "retry_item_not_failed_or_blocked");

  runtime.html = sampleDetailHtml("CS-A2200247", false);
  const blockedSave = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/read-one`,
    headers: sessionHeaders,
    payload: { supplierMappingId: mappingId, dryRun: false, saveSnapshot: true },
  });
  assert.equal(blockedSave.statusCode, 200);
  assert.equal(blockedSave.json().persistence.saved, false);
  assert.equal(blockedSave.json().snapshotGate.allowed, false);
  assert.equal(repository.snapshots.length, 5);

  const closed = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/close`,
    headers: sessionHeaders,
    payload: {},
  });
  assert.equal(closed.statusCode, 200);
  assert.equal(closed.json().state, "closed");

  const reset = await server.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/reset-profile`,
    headers: sessionHeaders,
    payload: {},
  });
  assert.equal(reset.statusCode, 200);
  assert.equal(reset.json().reset, true);
  assert.equal(runtime.resetCalled, true);
} finally {
  await server.close();
}

const prodServer = Fastify({ logger: false });
await registerSupplierSessionRoutes(prodServer, {
  env: { NODE_ENV: "production" },
  snapshotRepository: repository,
  runtimeFactory: () => new StubRuntime(),
});

try {
  const disabled = await prodServer.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/open`,
    headers: sessionHeaders,
    payload: { connectorId: DVG_CONNECTOR_ID, loginUrl: DVG_LOGIN_URL },
  });
  assert.equal(disabled.statusCode, 403);
  assert.equal(disabled.json().error.code, "supplier_session_disabled");
} finally {
  await prodServer.close();
}

const prodEnabledServer = Fastify({ logger: false });
await registerSupplierSessionRoutes(prodEnabledServer, {
  env: { NODE_ENV: "production", ENABLE_SUPPLIER_SESSION_LAB: "true" },
  snapshotRepository: repository,
  runtimeFactory: () => new StubRuntime(),
});

try {
  const missingHeaderStillBlocked = await prodEnabledServer.inject({
    method: "POST",
    url: `/supplier-sessions/${supplierId}/open`,
    payload: { connectorId: DVG_CONNECTOR_ID, loginUrl: DVG_LOGIN_URL },
  });
  assert.equal(missingHeaderStillBlocked.statusCode, 403);
  assert.equal(missingHeaderStillBlocked.json().error.code, "supplier_session_header_missing");
} finally {
  await prodEnabledServer.close();
}

console.log("Supplier session route tests passed");

function createSessionState(
  authenticated: boolean,
  reused: boolean,
  safetyEventCodes: string[] = [],
  blockingReasons: string[] = []
): SupplierSessionState {
  const safetyEvents = safetyEventCodes.map((code) => ({
    timestamp: now.toISOString(),
    severity: "critical" as const,
    code,
    message: code,
    phase: "network" as const,
  }));
  const safetyFlags = readSupplierSessionSafetyFlagsFromContent({
    currentUrl: authenticated
      ? "https://devecchigiuseppesrl.com/e-commerce/cerca.asp"
      : DVG_LOGIN_URL,
    html: authenticated ? "<main>Authenticated page</main>" : '<form id="formLogin"></form>',
    visibleText: authenticated ? "Authenticated page" : "Login",
    formState: null,
    safetyEvents,
  });
  return {
    mode: "manual_host_browser_profile",
    supplierId,
    connectorId: DVG_CONNECTOR_ID,
    connectorName: DVG_DISPLAY_NAME,
    status: authenticated ? "authenticated" : "open",
    authenticated,
    finalPath: authenticated ? "/e-commerce/cerca.asp" : "/e-commerce/account/login.asp",
    profilePolicy,
    reused,
    safetyFlags,
    blockingReasons,
    warnings: blockingReasons,
  };
}

function createMapping(id: string, mappingSupplierId: string, enabled: boolean): SupplierMapping {
  return {
    id,
    catalogProductId,
    supplierId: mappingSupplierId,
    supplierArticleNumber: "CS-A2200247",
    supplierProductNameOverride: null,
    lookupStrategy: "direct_url",
    directUrl: null,
    priority: 100,
    enabled,
    isPrimary: true,
    matchValidationMode: "exact_article_number",
    notes: null,
    createdBy: null,
    updatedBy: null,
    createdAt: now,
    updatedAt: now,
  };
}

function sampleDetailHtml(article: string, withPrice: boolean): string {
  return `
    <main>
      <strong>${article}</strong>
      <h1>TAP VALVE PIAZZA SAN MARCO GROUP</h1>
      <p>Original code A2200247</p>
      ${withPrice ? '<span class="price"><span class="amount">4,72</span> €/pc</span>' : ""}
    </main>
  `;
}

function sampleDangerHtml(article: string): string {
  return `
    <main>
      <strong>${article}</strong>
      <h1>TAP VALVE PIAZZA SAN MARCO GROUP</h1>
      <span class="price"><span class="amount">4,72</span> €/pc</span>
      <p>Payment address checkout request quote</p>
    </main>
  `;
}

function sampleCartHtml(article: string): string {
  return `
    <main>
      <strong>${article}</strong>
      <h1>TAP VALVE PIAZZA SAN MARCO GROUP</h1>
      <span class="price"><span class="amount">4,72</span> €/pc</span>
      <form id="FormAggiungi_Carrello"><input id="Qta" name="Qta" /></form>
    </main>
  `;
}
