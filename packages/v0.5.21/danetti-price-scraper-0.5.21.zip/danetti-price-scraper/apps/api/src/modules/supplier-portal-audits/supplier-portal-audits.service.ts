import type {
  NewSupplierPortalAudit,
  NewSupplierPortalAuditCheck,
  NewSupplierPortalAuditEvidenceNote,
  SupplierCheckSettings,
  SupplierPortalAudit,
  SupplierPortalAuditCheck,
  SupplierPortalAuditEvidenceNote,
} from "@danetti/db";
import {
  APPROVAL_PASSING_CHECK_STATUSES,
  DEFAULT_PORTAL_AUDIT_CHECKS,
} from "./supplier-portal-audits.checklist.js";
import {
  PortalAuditValidationError,
  type AuditCheckStatus,
  type PortalAuditConnectorPlanResponse,
  type PortalAuditConnectorReadiness,
  type PortalAuditDetail,
  type EvidenceNoteType,
  type PortalAuditSafeExport,
  type ResultPageType,
} from "./supplier-portal-audits.types.js";

const SENSITIVE_KEY_PATTERN = /(credential|password|secret|token|cookie|session|storageState)/i;
const SENSITIVE_CONTENT_PATTERN =
  /(password\s*[:=]|secret\s*[:=]|token\s*[:=]|cookie\s*[:=]|cookie\s*:|set-cookie\s*:|authorization\s*:|bearer\s+[a-z0-9._~+\/-]+=*|storageState|localStorage\s*(?:[:=]|dump|\{|\[)|session(?:id|_id|-id)?\s*[:=]|eyJ[a-z0-9_-]{10,}\.[a-z0-9_-]{10,}\.)/i;
const MAX_EVIDENCE_CONTENT_LENGTH = 4000;
const POST_METHOD = "POST";

const RESULT_PAGE_TYPES: ResultPageType[] = [
  "search_result",
  "search_then_detail",
  "direct_url",
  "export_file",
  "network_response",
  "unknown",
];
const CHECK_STATUSES: AuditCheckStatus[] = [
  "unknown",
  "pass",
  "fail",
  "not_applicable",
  "needs_review",
];
const EVIDENCE_TYPES: EvidenceNoteType[] = [
  "manual_note",
  "selector_note",
  "network_note",
  "screenshot_reference",
  "html_reference",
  "risk_note",
];

export function validateCreatePortalAuditInput(input: unknown): NewSupplierPortalAudit {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  return {
    supplierId: readUuid(record, "supplierId"),
    auditTitle: readRequiredString(record, "auditTitle"),
    status: "draft",
    ...readAuditOptionalFields(record),
  };
}

export function validateUpdatePortalAuditInput(input: unknown): Partial<NewSupplierPortalAudit> {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  if ("status" in record) {
    throw new PortalAuditValidationError(
      "status_endpoint_required",
      "Use review endpoints to change audit status"
    );
  }
  const update: Partial<NewSupplierPortalAudit> = { updatedAt: new Date() };
  if ("auditTitle" in record) update.auditTitle = readRequiredString(record, "auditTitle");
  return { ...update, ...readAuditOptionalFields(record) };
}

export function createDefaultChecklistRows(auditId: string): NewSupplierPortalAuditCheck[] {
  return DEFAULT_PORTAL_AUDIT_CHECKS.map((check) => ({
    auditId,
    checkKey: check.checkKey,
    label: check.label,
    status: "unknown",
  }));
}

export function validateCheckUpdateInput(
  input: unknown
): Pick<NewSupplierPortalAuditCheck, "status" | "notes"> {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  return {
    status: readCheckStatus(record, "status"),
    notes: readOptionalString(record, "notes"),
  };
}

export function validateEvidenceNoteInput(input: unknown): NewSupplierPortalAuditEvidenceNote {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  const content = readRequiredString(record, "content");
  if (content.length > MAX_EVIDENCE_CONTENT_LENGTH) {
    throw new PortalAuditValidationError(
      "content_too_large",
      "Evidence note content is too large",
      413
    );
  }
  if (SENSITIVE_CONTENT_PATTERN.test(content)) {
    throw new PortalAuditValidationError(
      "sensitive_content",
      "Evidence note appears to contain credentials/session/cookie content"
    );
  }
  return {
    auditId: "00000000-0000-4000-8000-000000000000",
    title: readRequiredString(record, "title"),
    evidenceType: readEvidenceType(record, "evidenceType"),
    content,
    containsSensitiveData: readOptionalBoolean(record, "containsSensitiveData") ?? false,
    createdBy: readOptionalString(record, "createdBy"),
  };
}

export function validateApproveInput(input: unknown): { approvedBy: string } {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  return { approvedBy: readRequiredString(record, "approvedBy") };
}

export function validateRejectInput(input: unknown): { reviewedBy: string; safetyNotes: string } {
  assertNoSensitiveFields(input);
  const record = asRecord(input);
  return {
    reviewedBy: readRequiredString(record, "reviewedBy"),
    safetyNotes: readRequiredString(record, "notes"),
  };
}

export function assertAuditCanBeApproved(
  audit: SupplierPortalAudit,
  checks: SupplierPortalAuditCheck[]
): void {
  if (audit.status !== "in_review") {
    throw new PortalAuditValidationError(
      "invalid_status",
      "Audit must be in_review before approval"
    );
  }
  if (!audit.allowedDomains?.length)
    throw new PortalAuditValidationError(
      "missing_allowed_domains",
      "allowedDomains is required before approval"
    );
  if (!audit.dangerousUrlPatterns?.length)
    throw new PortalAuditValidationError(
      "missing_dangerous_url_patterns",
      "dangerousUrlPatterns is required before approval"
    );
  if (!audit.allowedUrlPatterns?.length)
    throw new PortalAuditValidationError(
      "missing_allowed_url_patterns",
      "allowedUrlPatterns is required before approval"
    );
  if (!audit.allowedMethods?.length)
    throw new PortalAuditValidationError(
      "missing_allowed_methods",
      "allowedMethods is required before approval"
    );
  if (audit.has2fa === null || audit.hasCaptcha === null || audit.hasAccountLockRisk === null) {
    throw new PortalAuditValidationError(
      "missing_access_risk_documentation",
      "2FA, CAPTCHA and account lock risk must be documented before approval"
    );
  }
  if (!audit.safetyNotes?.trim())
    throw new PortalAuditValidationError(
      "missing_safety_notes",
      "safetyNotes is required before approval"
    );
  if (audit.resultPageType === "unknown")
    throw new PortalAuditValidationError(
      "missing_result_page_type",
      "resultPageType must be confirmed before approval"
    );
  if (
    !Number.isInteger(audit.suggestedRateLimitPerMinute) ||
    audit.suggestedRateLimitPerMinute <= 0
  ) {
    throw new PortalAuditValidationError(
      "missing_rate_limit",
      "suggestedRateLimitPerMinute must be positive"
    );
  }
  const byKey = new Map(checks.map((check) => [check.checkKey, check]));
  const missing = DEFAULT_PORTAL_AUDIT_CHECKS.filter((check) => check.requiredForApproval).filter(
    (check) =>
      !APPROVAL_PASSING_CHECK_STATUSES.has(byKey.get(check.checkKey)?.status as AuditCheckStatus)
  );
  if (missing.length > 0) {
    throw new PortalAuditValidationError(
      "checklist_incomplete",
      `Required checks incomplete: ${missing.map((check) => check.checkKey).join(", ")}`
    );
  }
}

export function evaluateSupplierPortalAuditReadiness(
  audit: SupplierPortalAudit,
  checks: SupplierPortalAuditCheck[]
): PortalAuditConnectorReadiness {
  const missingRequiredFields: string[] = [];
  const warnings: string[] = [];
  const noGoReasons: string[] = [];
  if (audit.status !== "approved") addMissing("status=approved", "Audit is not approved");
  if (!audit.allowedDomains?.length) addMissing("allowedDomains", "Allowed domains missing");
  if (!audit.dangerousUrlPatterns?.length)
    addMissing("dangerousUrlPatterns", "Dangerous URL patterns missing");
  if (!audit.allowedUrlPatterns?.length)
    addMissing("allowedUrlPatterns", "Allowed URL patterns missing");
  if (!audit.allowedMethods?.length) addMissing("allowedMethods", "Allowed methods missing");
  if (audit.resultPageType === "unknown") addMissing("resultPageType", "Result page type unknown");
  if (audit.has2fa === null) addMissing("has2fa", "2FA behavior not documented");
  if (audit.hasCaptcha === null) addMissing("hasCaptcha", "CAPTCHA behavior not documented");
  if (audit.hasAccountLockRisk === null)
    addMissing("hasAccountLockRisk", "Account lock risk not documented");
  if (!audit.safetyNotes?.trim()) addMissing("safetyNotes", "Safety notes missing");
  if (
    !Number.isInteger(audit.suggestedRateLimitPerMinute) ||
    audit.suggestedRateLimitPerMinute <= 0
  ) {
    addMissing("suggestedRateLimitPerMinute", "Rate limit missing or invalid");
  }

  const byKey = new Map(checks.map((check) => [check.checkKey, check]));
  const failingChecks = DEFAULT_PORTAL_AUDIT_CHECKS.filter((check) => check.requiredForApproval)
    .filter(
      (check) =>
        !APPROVAL_PASSING_CHECK_STATUSES.has(byKey.get(check.checkKey)?.status as AuditCheckStatus)
    )
    .map((check) => check.checkKey);

  for (const checkKey of failingChecks) {
    noGoReasons.push(`Required checklist item incomplete: ${checkKey}`);
  }

  if (usesPostSearch(audit) && !audit.allowedPostPatterns?.length) {
    warnings.push(
      "POST search is documented, but allowed POST patterns still need explicit review."
    );
  }
  if (audit.resultPageType === "direct_url" && !audit.searchUrl && !audit.auditNotes) {
    warnings.push(
      "Direct URL strategy selected, but stable read-only URL pattern is not documented."
    );
  }
  if (!audit.stockVisibleOn?.trim()) warnings.push("Stock field is not documented.");
  if (
    audit.resultPageType === "network_response" &&
    !isPassingCheck(byKey.get("terms_or_business_approval_reviewed"))
  ) {
    warnings.push("Network response strategy requires explicit ToS/business approval review.");
  }
  if (!audit.skuExactMatchRequired || !isPassingCheck(byKey.get("sku_exact_match_confirmed"))) {
    warnings.push("SKU exact-match behavior is not fully confirmed.");
  }

  const ready = missingRequiredFields.length === 0 && failingChecks.length === 0;
  const requiredBeforeConnector = [...missingRequiredFields, ...failingChecks].map((item) =>
    item.startsWith("status=") ? item : `Complete ${item}`
  );

  return {
    auditId: audit.id,
    status: audit.status,
    ready,
    missingRequiredFields,
    failingChecks,
    warnings,
    recommendedStrategy: audit.resultPageType === "unknown" ? null : audit.resultPageType,
    safetySummary: {
      allowedDomains: audit.allowedDomains ?? [],
      allowedUrlPatterns: audit.allowedUrlPatterns ?? [],
      dangerousUrlPatterns: audit.dangerousUrlPatterns ?? [],
      allowedMethods: audit.allowedMethods ?? [],
      allowedPostPatterns: audit.allowedPostPatterns ?? [],
      suggestedRateLimitPerMinute: audit.suggestedRateLimitPerMinute,
      resultPageType: audit.resultPageType,
      has2fa: audit.has2fa,
      hasCaptcha: audit.hasCaptcha,
      hasAccountLockRisk: audit.hasAccountLockRisk,
      skuExactMatchRequired: audit.skuExactMatchRequired,
      safetyNotesPresent: Boolean(audit.safetyNotes?.trim()),
    },
    requiredBeforeConnector,
    noGoReasons,
    nextAction: getReadinessNextAction(ready, missingRequiredFields, failingChecks),
  };

  function addMissing(field: string, reason: string): void {
    missingRequiredFields.push(field);
    noGoReasons.push(reason);
  }
}

export function buildSupplierPortalConnectorPlan(
  audit: PortalAuditDetail,
  checkSettings: SupplierCheckSettings | null
): PortalAuditConnectorPlanResponse {
  const readiness = evaluateSupplierPortalAuditReadiness(audit, audit.checks);
  const connectorPlan = {
    connectorIdSuggestion: slugify(
      `${audit.supplierCode}-${readiness.recommendedStrategy ?? "pending"}`
    ),
    displayNameSuggestion: `${audit.supplierName} connector terv`,
    allowedDomains: audit.allowedDomains ?? [],
    allowedUrlPatterns: audit.allowedUrlPatterns ?? [],
    deniedUrlPatterns: audit.dangerousUrlPatterns ?? [],
    allowedMethods: audit.allowedMethods ?? [],
    allowedPostPatterns: audit.allowedPostPatterns ?? [],
    lookupStrategy: readiness.recommendedStrategy,
    expectedPageKind: audit.resultPageType,
    priceExtractionNotes: safeText(audit.priceVisibleOn, "Ár helye nincs dokumentálva."),
    stockExtractionNotes: joinPlanNotes([
      audit.stockVisibleOn,
      audit.availabilityTextNotes,
      audit.productIdentityNotes,
    ]),
    matchValidationRules: [
      audit.skuExactMatchRequired
        ? "Exact supplier article/SKU match required before price is trusted."
        : "Exact supplier article/SKU match is not confirmed; connector must fail closed.",
      "Multiple matches -> needs_manual_check.",
      "Missing price or currency -> needs_manual_check.",
      "Unclear product identity -> needs_manual_check.",
      safeText(audit.productIdentityNotes, "Product name/article visibility notes missing."),
    ],
    rateLimitSettings: {
      auditSuggestedRateLimitPerMinute: audit.suggestedRateLimitPerMinute,
      productsPerMinute: checkSettings?.productsPerMinute ?? null,
      delayBetweenProductsSeconds: checkSettings?.delayBetweenProductsSeconds ?? null,
      jitterMinSeconds: checkSettings?.jitterMinSeconds ?? null,
      jitterMaxSeconds: checkSettings?.jitterMaxSeconds ?? null,
      maxRetriesPerItem: checkSettings?.maxRetriesPerItem ?? null,
      navigationTimeoutSeconds: checkSettings?.navigationTimeoutSeconds ?? null,
      itemTimeoutSeconds: checkSettings?.itemTimeoutSeconds ?? null,
    },
    safetyStopRules: buildSafetyStopRules(audit, checkSettings),
    evidencePlan: [
      "Store text-only sanitized evidence notes.",
      "Do not store credentials, cookies, storageState, raw HTML or private screenshots.",
      safeText(audit.evidenceExpectations, "Evidence expectations not documented."),
    ],
    manualSessionPolicy: [
      "Manual login/session handling stays operator-owned.",
      safeText(audit.sessionLifetimeNotes, "Session lifetime notes missing."),
    ],
    openQuestions: splitPlanLines(audit.openQuestions).concat(readiness.noGoReasons),
    implementationSteps: [
      "Use SafeBrowserContext only; no raw Playwright page access in connector code.",
      "Build policy from allowedDomains, allowedUrlPatterns, deniedUrlPatterns and allowedMethods.",
      "Implement lookup using approved strategy only.",
      "Parse price/stock using documented notes and fail closed on ambiguity.",
      "Wire queue pacing from supplier check settings before any real run.",
    ],
    acceptanceCriteria: [
      "No connector starts unless readiness.ready is true.",
      "No WooCommerce writes, supplier cart actions, checkout, order or quote actions.",
      "Exact match required before price snapshot is trusted.",
      "Tests use local stubs only; no supplier portal access.",
    ],
    testPlan: [
      "Pure unit tests for strategy selection, parser notes and fail-closed classifications.",
      "SafeBrowserContext local stub tests for allowed/denied URL and method behavior.",
      "No external navigation, credentials, cookies or storageState in tests.",
    ],
  };

  return {
    auditId: audit.id,
    supplier: { id: audit.supplierId, code: audit.supplierCode, name: audit.supplierName },
    readiness,
    connectorPlan,
  };
}

export function buildSafePortalAuditExport(
  audit: PortalAuditDetail,
  checkSettings: SupplierCheckSettings | null
): PortalAuditSafeExport {
  const plan = buildSupplierPortalConnectorPlan(audit, checkSettings);
  const { checks: _checks, evidenceNotes: _evidenceNotes, ...safeAudit } = audit;

  return {
    auditId: audit.id,
    supplier: plan.supplier,
    audit: safeAudit,
    checks: audit.checks.map((check) => ({
      checkKey: check.checkKey,
      label: check.label,
      status: check.status,
      notes: check.notes,
    })),
    evidenceNotes: audit.evidenceNotes.map(safeEvidenceNote),
    readiness: plan.readiness,
    connectorPlanSummary: {
      connectorIdSuggestion: plan.connectorPlan.connectorIdSuggestion,
      displayNameSuggestion: plan.connectorPlan.displayNameSuggestion,
      lookupStrategy: plan.connectorPlan.lookupStrategy,
      expectedPageKind: plan.connectorPlan.expectedPageKind,
      rateLimitSettings: plan.connectorPlan.rateLimitSettings,
      safetyStopRules: plan.connectorPlan.safetyStopRules,
      openQuestions: plan.connectorPlan.openQuestions,
    },
  };
}

function isPassingCheck(check: SupplierPortalAuditCheck | undefined): boolean {
  return APPROVAL_PASSING_CHECK_STATUSES.has(check?.status as AuditCheckStatus);
}

function usesPostSearch(audit: SupplierPortalAudit): boolean {
  return audit.searchMethod?.trim().toUpperCase() === POST_METHOD;
}

function getReadinessNextAction(
  ready: boolean,
  missingRequiredFields: string[],
  failingChecks: string[]
): string {
  if (ready) return "Ready for connector implementation prompt";
  if (missingRequiredFields.length > 0)
    return `Complete missing field: ${missingRequiredFields[0]}`;
  return `Complete checklist item: ${failingChecks[0] ?? "unknown"}`;
}

function slugify(value: string): string {
  const slug = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug || "supplier-connector-plan";
}

function safeText(value: string | null, fallback: string): string {
  return value?.trim() || fallback;
}

function joinPlanNotes(values: Array<string | null>): string {
  const joined = values
    .map((value) => value?.trim())
    .filter(Boolean)
    .join("\n");
  return joined || "Készlet / elérhetőség mezők nincsenek dokumentálva.";
}

function splitPlanLines(value: string | null): string[] {
  return (
    value
      ?.split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean) ?? []
  );
}

function buildSafetyStopRules(
  audit: SupplierPortalAudit,
  checkSettings: SupplierCheckSettings | null
): string[] {
  return [
    "Stop on unsafe domain.",
    "Stop on denied URL pattern.",
    "Stop on unsafe method.",
    "Stop on CAPTCHA, 2FA challenge or account lock signal.",
    checkSettings?.stopOnSafetyEvent === false
      ? "Supplier setting currently does not stop on safety event; enable before connector run."
      : "Stop on safety event.",
    checkSettings?.stopOnCartChange === false
      ? "Supplier setting currently does not stop on cart change; enable before connector run."
      : "Stop on cart change.",
    `Cart indicator selector: ${safeText(audit.cartIndicatorSelector, "not documented")}`,
    `Stop after consecutive failures: ${checkSettings?.stopAfterConsecutiveFailures ?? "not configured"}`,
    `Safety notes: ${safeText(audit.safetyNotes, "missing")}`,
  ];
}

function safeEvidenceNote(note: SupplierPortalAuditEvidenceNote) {
  return {
    id: note.id,
    title: note.title,
    evidenceType: note.evidenceType,
    containsSensitiveData: note.containsSensitiveData,
    createdBy: note.createdBy,
    createdAt: note.createdAt,
  };
}

export function validateUuid(value: string, field: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new PortalAuditValidationError("invalid_uuid", `${field} must be a UUID`);
  }
}

function readAuditOptionalFields(record: Record<string, unknown>): Partial<NewSupplierPortalAudit> {
  const output: Partial<NewSupplierPortalAudit> = {};
  copyString(record, output, "portalBaseUrl");
  copyString(record, output, "loginUrl");
  copyBoolean(record, output, "has2fa");
  copyBoolean(record, output, "hasCaptcha");
  copyBoolean(record, output, "hasAccountLockRisk");
  copyString(record, output, "loginFlowNotes");
  copyString(record, output, "sessionLifetimeNotes");
  copyString(record, output, "searchUrl");
  copyString(record, output, "searchMethod");
  copyString(record, output, "searchInputNotes");
  copyBoolean(record, output, "skuExactMatchRequired");
  if ("resultPageType" in record)
    output.resultPageType = readResultPageType(record, "resultPageType");
  copyString(record, output, "priceVisibleOn");
  copyString(record, output, "stockVisibleOn");
  copyString(record, output, "availabilityTextNotes");
  copyString(record, output, "productIdentityNotes");
  copyString(record, output, "cartIndicatorSelector");
  copyStringArray(record, output, "dangerousUrlPatterns");
  copyStringArray(record, output, "allowedUrlPatterns");
  copyStringArray(record, output, "allowedDomains");
  copyStringArray(record, output, "allowedMethods");
  copyStringArray(record, output, "allowedPostPatterns");
  if ("suggestedRateLimitPerMinute" in record)
    output.suggestedRateLimitPerMinute = readPositiveInteger(record, "suggestedRateLimitPerMinute");
  copyString(record, output, "parserNotes");
  copyString(record, output, "evidenceExpectations");
  copyString(record, output, "knownBlockers");
  copyString(record, output, "goNoGoDecision");
  copyString(record, output, "openQuestions");
  copyString(record, output, "auditNotes");
  copyString(record, output, "safetyNotes");
  return output;
}

function assertNoSensitiveFields(input: unknown): void {
  if (input === null || typeof input !== "object") return;
  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (SENSITIVE_KEY_PATTERN.test(key))
      throw new PortalAuditValidationError(
        "sensitive_field",
        `Sensitive field is not allowed: ${key}`
      );
    assertNoSensitiveFields(value);
  }
}

function asRecord(input: unknown): Record<string, unknown> {
  if (input === null || typeof input !== "object" || Array.isArray(input))
    throw new PortalAuditValidationError("invalid_body", "Request body must be an object");
  return input as Record<string, unknown>;
}

function readRequiredString(record: Record<string, unknown>, key: string): string {
  const value = readOptionalString(record, key);
  if (value === null) throw new PortalAuditValidationError("missing_field", `${key} is required`);
  return value;
}

function readOptionalString(record: Record<string, unknown>, key: string): string | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "string")
    throw new PortalAuditValidationError("invalid_field", `${key} must be a string`);
  const trimmed = value.trim();
  return trimmed.length ? trimmed : null;
}

function readUuid(record: Record<string, unknown>, key: string): string {
  const value = readRequiredString(record, key);
  validateUuid(value, key);
  return value;
}

function readOptionalBoolean(record: Record<string, unknown>, key: string): boolean | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "boolean")
    throw new PortalAuditValidationError("invalid_field", `${key} must be a boolean`);
  return value;
}

function readStringArray(record: Record<string, unknown>, key: string): string[] | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (!Array.isArray(value))
    throw new PortalAuditValidationError("invalid_field", `${key} must be an array`);
  return value
    .map((item) => {
      if (typeof item !== "string")
        throw new PortalAuditValidationError("invalid_field", `${key} must contain strings`);
      return item.trim();
    })
    .filter(Boolean);
}

function readPositiveInteger(record: Record<string, unknown>, key: string): number {
  const value = record[key];
  if (typeof value !== "number" || !Number.isInteger(value) || value <= 0)
    throw new PortalAuditValidationError("invalid_field", `${key} must be a positive integer`);
  return value;
}

function readResultPageType(record: Record<string, unknown>, key: string): ResultPageType {
  const value = readRequiredString(record, key) as ResultPageType;
  if (!RESULT_PAGE_TYPES.includes(value))
    throw new PortalAuditValidationError("invalid_result_page_type", `${key} is invalid`);
  return value;
}

function readCheckStatus(record: Record<string, unknown>, key: string): AuditCheckStatus {
  const value = readRequiredString(record, key) as AuditCheckStatus;
  if (!CHECK_STATUSES.includes(value))
    throw new PortalAuditValidationError("invalid_check_status", `${key} is invalid`);
  return value;
}

function readEvidenceType(record: Record<string, unknown>, key: string): EvidenceNoteType {
  const value = readRequiredString(record, key) as EvidenceNoteType;
  if (!EVIDENCE_TYPES.includes(value))
    throw new PortalAuditValidationError("invalid_evidence_type", `${key} is invalid`);
  return value;
}

function copyString(
  record: Record<string, unknown>,
  output: Record<string, unknown>,
  key: string
): void {
  if (key in record) output[key] = readOptionalString(record, key);
}

function copyBoolean(
  record: Record<string, unknown>,
  output: Record<string, unknown>,
  key: string
): void {
  if (key in record) output[key] = readOptionalBoolean(record, key);
}

function copyStringArray(
  record: Record<string, unknown>,
  output: Record<string, unknown>,
  key: string
): void {
  if (key in record) output[key] = readStringArray(record, key);
}
