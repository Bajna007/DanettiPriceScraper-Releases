import { getRuntimeHealth } from "../health/runtime-health.service.js";
import type { RuntimeHealthResponse } from "../health/runtime-health.types.js";
import type { SetupStatusResponse, SetupStatusStep } from "./setup.types.js";

interface SetupStatusOptions {
  getHealth?: () => Promise<RuntimeHealthResponse>;
  now?: () => Date;
}

export async function getSetupStatus(
  options: SetupStatusOptions = {}
): Promise<SetupStatusResponse> {
  const health = await (options.getHealth ?? getRuntimeHealth)();
  const now = options.now ?? (() => new Date());

  return {
    status: health.status,
    generatedAt: now().toISOString(),
    steps: buildSetupSteps(health),
    commands: [
      "npm.cmd install",
      "npm.cmd run local:web:doctor",
      "npm.cmd run docker:up",
      "npm.cmd run db:migrate",
      "npm.cmd run local:web",
      "npm.cmd run docker:down",
    ],
    safetyNotes: [
      "A setup oldal és a local:web:doctor csak olvasó diagnosztika.",
      "WooCommerce az MVP-ben CSV import forrás marad. Nincs WooCommerce írás.",
      "Beszállítói portál belépési adatok, cookie-k és storageState fájlok nem kerülhetnek a repóba.",
    ],
  };
}

function buildSetupSteps(health: RuntimeHealthResponse): SetupStatusStep[] {
  return [
    {
      key: "api",
      label: "API",
      status: health.api.status,
      message: "API folyamat válaszol.",
      action: null,
    },
    {
      key: "database",
      label: "Adatbázis",
      status: health.database.status,
      message: health.database.message,
      action:
        health.database.status === "ok"
          ? null
          : "Indítsd a Postgres konténert és futtasd a migrációt.",
    },
    {
      key: "redis",
      label: "Redis",
      status: health.redis.status,
      message: health.redis.message,
      action: health.redis.status === "ok" ? null : "Indítsd a Redis konténert.",
    },
    {
      key: "worker",
      label: "Worker",
      status: health.worker.status,
      message: health.worker.message,
      action: "Worker státusz külön folyamatból ellenőrizhető későbbi fázisban.",
    },
  ];
}
