import {
  buildDvgDetailUrl,
  createDvgEnvCredentialProvider,
  DVG_ALLOWED_DOMAIN,
  DVG_CONNECTOR_ID,
  type DvgCredentials,
} from "@danetti/connectors";
import type { Supplier } from "@danetti/db";
import type { SupplierCredentialStore } from "./supplier-credentials.store.js";
import {
  type ResolvedSupplierCredential,
  type SupplierCredentialSaveInput,
  type SupplierCredentialSecret,
  type SupplierCredentialStatus,
  type SupplierCredentialTestInput,
  SupplierCredentialError,
  type SupplierCredentialTestResult,
} from "./supplier-credentials.types.js";

const USERNAME_MAX_LENGTH = 128;
const PASSWORD_MAX_LENGTH = 512;
const SENSITIVE_KEY_PATTERN =
  /(credential|username|password|secret|token|cookie|session|storageState)/i;
const SUPPORTED_CREDENTIAL_CONNECTORS = [DVG_CONNECTOR_ID];
const SAFE_TEST_ERROR_CODES = new Set([
  "success",
  "dvg_login_ok_price_ok",
  "dvg_login_landing_detected",
  "dvg_login_rejected",
  "dvg_login_click_event_missing",
  "dvg_login_submit_event_missing",
  "dvg_login_submit_prevented",
  "dvg_login_prevented_by_client_validation",
  "dvg_login_prevented_by_captcha_or_security",
  "dvg_login_prevented_by_cookie_consent",
  "dvg_login_prevented_by_missing_required_field",
  "dvg_login_prevented_by_unknown_handler",
  "dvg_login_post_not_sent",
  "dvg_login_post_blocked_by_safety",
  "dvg_login_script_dependency_blocked",
  "dvg_login_server_rejected",
  "dvg_login_failed",
  "dvg_credentials_missing",
  "dvg_login_check_failed",
  "dvg_login_form_not_found",
  "dvg_username_field_not_found",
  "dvg_password_field_not_found",
  "dvg_login_submit_not_found",
  "dvg_login_submit_disabled_after_fill",
  "dvg_login_submit_no_effect",
  "dvg_login_account_security_risk",
  "dvg_login_timeout",
  "credential_test_failed",
  "supplier_credential_missing",
  "credential_store_unavailable",
  "dvg_article_invalid",
  "dvg_detail_fetch_failed",
  "dvg_detail_redirected_to_login",
  "dvg_article_not_found_or_access_denied",
  "dvg_price_not_found",
  "dvg_test_article_missing",
]);

export type CredentialSupplier = Pick<
  Supplier,
  "id" | "code" | "name" | "baseUrl" | "allowedDomains"
>;

export function validateSupplierCredentialSaveInput(input: unknown): SupplierCredentialSaveInput {
  const record = asRecord(input);
  assertAllowedKeys(record, ["connectorId", "kind", "username", "password"]);
  const connectorId = readRequiredString(record, "connectorId");
  const kind = readOptionalString(record, "kind") ?? "username_password";
  const username = readRequiredString(record, "username");
  const password = readRequiredSecretString(record, "password");

  if (kind !== "username_password") {
    throw new SupplierCredentialError("unsupported_credential_kind", "Unsupported credential kind");
  }
  if (username.length > USERNAME_MAX_LENGTH) {
    throw new SupplierCredentialError("invalid_username", "Username is too long");
  }
  if (password.length > PASSWORD_MAX_LENGTH) {
    throw new SupplierCredentialError("invalid_password", "Password is too long");
  }

  return { connectorId, kind, username, password };
}

export function validateSupplierCredentialTestInput(input: unknown): SupplierCredentialTestInput {
  if (input === undefined || input === null) return {};
  const record = asRecord(input);
  assertNoSensitiveFields(record);
  assertAllowedKeys(record, ["testArticle", "forensicMode"]);
  const testArticle = readOptionalString(record, "testArticle");
  const forensicMode = readOptionalString(record, "forensicMode");
  if (forensicMode !== null && forensicMode !== "prevent_default_v3") {
    throw new SupplierCredentialError("invalid_forensic_mode", "Invalid forensic mode");
  }
  if (testArticle === null) return { forensicMode: forensicMode ?? undefined };

  try {
    buildDvgDetailUrl(testArticle);
  } catch {
    throw new SupplierCredentialError("dvg_article_invalid", "DVG test article is invalid");
  }

  return { testArticle, forensicMode: forensicMode ?? undefined };
}

export function inferCredentialConnectorId(supplier: CredentialSupplier): string | null {
  const allowedDomains = supplier.allowedDomains.map((domain) => domain.toLowerCase());
  const baseHost = getHostname(supplier.baseUrl);
  const matchesDvg =
    supplier.code === DVG_CONNECTOR_ID ||
    allowedDomains.includes(DVG_ALLOWED_DOMAIN) ||
    baseHost === DVG_ALLOWED_DOMAIN;

  return matchesDvg ? DVG_CONNECTOR_ID : null;
}

export function assertCredentialConnectorSupported(
  supplier: CredentialSupplier,
  connectorId: string | null | undefined
): string {
  const inferredConnectorId = inferCredentialConnectorId(supplier);
  const requestedConnectorId = connectorId?.trim() || inferredConnectorId;
  if (
    !requestedConnectorId ||
    !SUPPORTED_CREDENTIAL_CONNECTORS.includes(requestedConnectorId) ||
    !inferredConnectorId
  ) {
    throw new SupplierCredentialError(
      "unsupported_credential_connector",
      "Supplier does not support saved credentials"
    );
  }

  if (requestedConnectorId !== inferredConnectorId) {
    throw new SupplierCredentialError(
      "connector_supplier_mismatch",
      "Credential connector does not match supplier metadata"
    );
  }

  return requestedConnectorId;
}

export async function getSupplierCredentialStatus(input: {
  supplier: CredentialSupplier;
  store: SupplierCredentialStore;
  env?: Record<string, string | undefined>;
}): Promise<SupplierCredentialStatus> {
  const connectorId = assertCredentialConnectorSupported(input.supplier, undefined);
  const stored = await input.store.get(input.supplier.id, connectorId);
  if (stored) return statusFromSecret(stored, "stored");

  const envCredentials = await createDvgEnvCredentialProvider(input.env).getCredentials();
  if (envCredentials?.username && envCredentials.password) {
    return emptyStatus(input.supplier.id, connectorId, {
      configured: true,
      source: "env",
      usernameDisplay: maskUsername(envCredentials.username),
    });
  }

  return emptyStatus(input.supplier.id, connectorId);
}

export function createSupplierCredentialSecret(input: {
  supplierId: string;
  connectorId: string;
  username: string;
  password: string;
  now?: Date;
}): SupplierCredentialSecret {
  return {
    supplierId: input.supplierId,
    connectorId: input.connectorId,
    kind: "username_password",
    username: input.username,
    password: input.password,
    updatedAt: (input.now ?? new Date()).toISOString(),
    lastTestedAt: null,
    lastTestStatus: "not_tested",
    lastErrorCode: null,
  };
}

export async function resolveSupplierCredentialForDvg(input: {
  supplier: CredentialSupplier;
  store: SupplierCredentialStore;
  env?: Record<string, string | undefined>;
}): Promise<ResolvedSupplierCredential> {
  const connectorId = assertCredentialConnectorSupported(input.supplier, DVG_CONNECTOR_ID);
  const stored = await input.store.get(input.supplier.id, connectorId);
  if (stored?.username && stored.password) {
    return {
      credentials: { username: stored.username, password: stored.password },
      source: "stored",
      storedSecret: stored,
    };
  }

  const envCredentials = await createDvgEnvCredentialProvider(input.env).getCredentials();
  if (envCredentials?.username && envCredentials.password) {
    return { credentials: envCredentials, source: "env", storedSecret: null };
  }

  throw new SupplierCredentialError(
    "supplier_credential_missing",
    "Supplier credentials are not configured"
  );
}

export function applyCredentialTestResult(
  secret: SupplierCredentialSecret,
  result: SupplierCredentialTestResult,
  now = new Date()
): SupplierCredentialSecret {
  return {
    ...secret,
    lastTestedAt: now.toISOString(),
    lastTestStatus: result.status,
    lastErrorCode: result.status === "success" ? null : sanitizeCredentialTestCode(result.code),
  };
}

export function statusFromSecret(
  secret: SupplierCredentialSecret,
  source: "stored"
): SupplierCredentialStatus {
  return {
    supplierId: secret.supplierId,
    connectorId: secret.connectorId,
    kind: secret.kind,
    configured: true,
    source,
    usernameDisplay: maskUsername(secret.username),
    lastTestedAt: secret.lastTestedAt,
    lastTestStatus: secret.lastTestStatus,
    lastErrorCode: secret.lastErrorCode,
  };
}

export function maskUsername(username: string): string {
  const trimmed = username.trim();
  if (!trimmed) return "";
  const atIndex = trimmed.indexOf("@");
  if (atIndex > 0) return `${trimmed.slice(0, 1)}***${trimmed.slice(atIndex)}`;
  if (trimmed.length <= 2) return "**";
  if (trimmed.length <= 4) return `${trimmed.slice(0, 1)}***`;
  return `${trimmed.slice(0, 2)}***${trimmed.slice(-1)}`;
}

export function sanitizeCredentialTestCode(code: string): string {
  return SAFE_TEST_ERROR_CODES.has(code) ? code : "credential_test_failed";
}

export function credentialsToDvgProvider(credentials: DvgCredentials) {
  return { getCredentials: () => credentials };
}

function emptyStatus(
  supplierId: string,
  connectorId: string,
  override: Partial<SupplierCredentialStatus> = {}
): SupplierCredentialStatus {
  return {
    supplierId,
    connectorId,
    kind: "username_password",
    configured: false,
    source: "missing",
    usernameDisplay: null,
    lastTestedAt: null,
    lastTestStatus: "not_tested",
    lastErrorCode: null,
    ...override,
  };
}

function asRecord(input: unknown): Record<string, unknown> {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    throw new SupplierCredentialError("invalid_body", "Request body must be an object");
  }
  return input as Record<string, unknown>;
}

function assertAllowedKeys(record: Record<string, unknown>, allowedKeys: string[]): void {
  for (const key of Object.keys(record)) {
    if (!allowedKeys.includes(key)) {
      throw new SupplierCredentialError("unknown_field", `Unknown credential field: ${key}`);
    }
  }
}

function assertNoSensitiveFields(input: unknown): void {
  if (input === null || typeof input !== "object") return;

  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (SENSITIVE_KEY_PATTERN.test(key)) {
      throw new SupplierCredentialError(
        "sensitive_field",
        `Sensitive field is not allowed: ${key}`
      );
    }
    assertNoSensitiveFields(value);
  }
}

function readRequiredString(record: Record<string, unknown>, key: string): string {
  const value = readOptionalString(record, key);
  if (value === null) throw new SupplierCredentialError("missing_field", `${key} is required`);
  return value;
}

function readRequiredSecretString(record: Record<string, unknown>, key: string): string {
  const value = record[key];
  if (typeof value !== "string" || value.length === 0) {
    throw new SupplierCredentialError("missing_field", `${key} is required`);
  }
  return value;
}

function readOptionalString(record: Record<string, unknown>, key: string): string | null {
  const value = record[key];
  if (value === undefined || value === null) return null;
  if (typeof value !== "string") {
    throw new SupplierCredentialError("invalid_field", `${key} must be a string`);
  }
  const trimmed = value.trim();
  return trimmed.length ? trimmed : null;
}

function getHostname(value: string | null | undefined): string | null {
  if (!value) return null;
  try {
    return new URL(value).hostname.toLowerCase();
  } catch {
    return null;
  }
}
