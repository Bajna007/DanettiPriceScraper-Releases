import assert from "node:assert/strict";
import {
  assertValidSupplierCheckSettingsMerge,
  validateCreateSupplierInput,
  validateUpdateSupplierCheckSettingsInput,
} from "./suppliers.service.js";
import { SupplierValidationError } from "./suppliers.types.js";

const supplier = validateCreateSupplierInput({ code: "italian_b2b-1", name: "Italian B2B" });
assert.equal(supplier.code, "italian_b2b-1");
assert.equal(supplier.name, "Italian B2B");
assert.equal(supplier.enabled, true);
assert.deepEqual(supplier.supportedLookupStrategies, ["search_result"]);
assert.equal(supplier.defaultRateLimitPerMinute, 6);

const dvgSupplier = validateCreateSupplierInput({
  code: "dvg-devecchi",
  name: "DVG De Vecchi",
  baseUrl: "https://devecchigiuseppesrl.com",
  allowedDomains: ["devecchigiuseppesrl.com"],
  supportedLookupStrategies: ["direct_url"],
  defaultRateLimitPerMinute: 6,
});
assert.equal(dvgSupplier.code, "dvg-devecchi");
assert.equal(dvgSupplier.baseUrl, "https://devecchigiuseppesrl.com");
assert.deepEqual(dvgSupplier.allowedDomains, ["devecchigiuseppesrl.com"]);
assert.deepEqual(dvgSupplier.supportedLookupStrategies, ["direct_url"]);

assert.throws(
  () => validateCreateSupplierInput({ code: "Bad Code", name: "Supplier" }),
  SupplierValidationError
);

assert.throws(
  () => validateCreateSupplierInput({ code: "supplier", name: "Supplier", password: "secret" }),
  SupplierValidationError
);

assert.throws(
  () =>
    validateCreateSupplierInput({
      code: "supplier",
      name: "Supplier",
      supportedLookupStrategies: ["unsafe_click"],
    }),
  SupplierValidationError
);

assert.throws(
  () =>
    validateCreateSupplierInput({
      code: "bad-domain",
      name: "Bad Domain",
      allowedDomains: ["https://bad.example"],
    }),
  /allowedDomains contains invalid domain/
);

const checkSettingsUpdate = validateUpdateSupplierCheckSettingsInput({
  productsPerMinute: 6,
  delayBetweenProductsSeconds: 10,
  jitterMinSeconds: 1,
  jitterMaxSeconds: 5,
  maxRetriesPerItem: 1,
  navigationTimeoutSeconds: 30,
  itemTimeoutSeconds: 60,
  stopAfterConsecutiveFailures: 5,
  stopOnSafetyEvent: true,
  stopOnCartChange: true,
  enabled: true,
});
assert.equal(checkSettingsUpdate.productsPerMinute, 6);
assert.equal(checkSettingsUpdate.stopOnSafetyEvent, true);

assert.throws(
  () => validateUpdateSupplierCheckSettingsInput({ productsPerMinute: 0 }),
  SupplierValidationError
);

assert.throws(
  () => validateUpdateSupplierCheckSettingsInput({ jitterMinSeconds: 10, jitterMaxSeconds: 5 }),
  SupplierValidationError
);

assert.throws(
  () =>
    assertValidSupplierCheckSettingsMerge(
      {
        id: "settings-id",
        supplierId: "supplier-id",
        productsPerMinute: 6,
        delayBetweenProductsSeconds: 10,
        jitterMinSeconds: 1,
        jitterMaxSeconds: 5,
        maxRetriesPerItem: 1,
        navigationTimeoutSeconds: 30,
        itemTimeoutSeconds: 60,
        stopAfterConsecutiveFailures: 5,
        stopOnSafetyEvent: true,
        stopOnCartChange: true,
        enabled: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      { jitterMinSeconds: 6 }
    ),
  SupplierValidationError
);

console.log("Supplier validation tests passed");
