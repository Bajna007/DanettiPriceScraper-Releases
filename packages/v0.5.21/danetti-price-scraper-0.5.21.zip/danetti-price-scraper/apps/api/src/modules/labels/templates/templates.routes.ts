import type { FastifyInstance } from "fastify";
import {
  bodyRecord,
  handleLabelError,
  paramsRecord,
  queryRecord,
  type LabelRouteContext,
} from "../route-utils.js";

export async function registerLabelTemplateRoutes(
  server: FastifyInstance,
  context: LabelRouteContext
): Promise<void> {
  server.get("/label-templates", async (request, reply) => {
    try {
      const query = queryRecord(request.query);
      return { items: await context.getService().listTemplates(query.brand as never) };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/label-templates", async (request, reply) => {
    try {
      return reply
        .code(201)
        .send({ item: await context.getService().createTemplate(bodyRecord(request.body)) });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.patch("/label-templates/:id", async (request, reply) => {
    try {
      return {
        item: await context
          .getService()
          .patchTemplate(paramsRecord(request.params).id!, bodyRecord(request.body)),
      };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
}
