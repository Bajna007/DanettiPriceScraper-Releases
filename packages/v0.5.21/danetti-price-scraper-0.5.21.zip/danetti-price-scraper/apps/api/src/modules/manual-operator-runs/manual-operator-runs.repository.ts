import {
  manualOperatorRuns,
  type DanettiDatabase,
  type ManualOperatorRun,
  type ManualOperatorRunItemSummary,
  type ManualOperatorRunMode,
  type NewManualOperatorRun,
} from "@danetti/db";
import { and, desc, eq, type SQL } from "drizzle-orm";

export interface ManualOperatorRunSummary {
  runId: string;
  supplierId: string;
  startedAt: string;
  finishedAt: string;
  mode: ManualOperatorRunMode;
  requestedCount: number;
  processedCount: number;
  savedCount: number;
  blockedCount: number;
  failedCount: number;
  stoppedReason: string | null;
  itemSummaries: ManualOperatorRunItemSummary[];
}

export interface ManualOperatorRunListFilters {
  supplierId?: string;
  mode?: ManualOperatorRunMode;
  limit: number;
  offset: number;
}

export interface ManualOperatorRunsRepositoryLike {
  insertRun(input: NewManualOperatorRun): Promise<ManualOperatorRun>;
  listRuns(input: ManualOperatorRunListFilters): Promise<ManualOperatorRun[]>;
  getRun(runId: string): Promise<ManualOperatorRun | null>;
}

export class ManualOperatorRunsRepository implements ManualOperatorRunsRepositoryLike {
  constructor(private readonly db: DanettiDatabase) {}

  async insertRun(input: NewManualOperatorRun): Promise<ManualOperatorRun> {
    const [run] = await this.db.insert(manualOperatorRuns).values(input).returning();
    if (!run) throw new Error("Failed to insert manual operator run");
    return run;
  }

  async listRuns(input: ManualOperatorRunListFilters): Promise<ManualOperatorRun[]> {
    const conditions: SQL[] = [];
    if (input.supplierId) conditions.push(eq(manualOperatorRuns.supplierId, input.supplierId));
    if (input.mode) conditions.push(eq(manualOperatorRuns.mode, input.mode));
    return this.db
      .select()
      .from(manualOperatorRuns)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(manualOperatorRuns.startedAt), desc(manualOperatorRuns.createdAt))
      .limit(input.limit)
      .offset(input.offset);
  }

  async getRun(runId: string): Promise<ManualOperatorRun | null> {
    const [run] = await this.db
      .select()
      .from(manualOperatorRuns)
      .where(eq(manualOperatorRuns.runId, runId))
      .limit(1);
    return run ?? null;
  }
}

export function summarizeManualOperatorRun(run: ManualOperatorRun): ManualOperatorRunSummary {
  return {
    runId: run.runId,
    supplierId: run.supplierId,
    startedAt: run.startedAt.toISOString(),
    finishedAt: run.finishedAt.toISOString(),
    mode: run.mode,
    requestedCount: run.requestedCount,
    processedCount: run.processedCount,
    savedCount: run.savedCount,
    blockedCount: run.blockedCount,
    failedCount: run.failedCount,
    stoppedReason: run.stoppedReason,
    itemSummaries: run.itemSummaries,
  };
}

export function sanitizeManualOperatorRunItems(
  items: ManualOperatorRunItemSummary[]
): ManualOperatorRunItemSummary[] {
  return items.map((item) => ({
    mappingId: item.mappingId ?? null,
    supplierArticleNumber: item.supplierArticleNumber,
    status: item.status,
    price: typeof item.price === "number" && Number.isFinite(item.price) ? item.price : null,
    currency: item.currency ?? null,
    snapshotId: item.snapshotId ?? null,
    safetyFlags: Array.from(new Set(item.safetyFlags.filter(Boolean))).sort(),
    reason: item.reason,
  }));
}
