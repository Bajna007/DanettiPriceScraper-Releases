import { Decimal } from "decimal.js";
import { z } from "zod";
import { EprError } from "./epr.errors.js";

Decimal.set({ precision: 60, rounding: Decimal.ROUND_HALF_UP });
export const decimalString = z.string().regex(/^-?\d{1,20}(\.\d{1,10})?$/);
export const dateString = z.iso.date();
export const invoiceSchema = z
  .object({
    documentType: z.enum([
      "invoice",
      "credit_note",
      "corrective_invoice",
      "cancellation",
      "proforma",
      "delivery_note",
      "other",
    ]),
    supplier: z.object({
      name: z.string().max(300).nullable(),
      taxId: z.string().max(100).nullable(),
    }),
    customerIdentity: z.string().max(300).nullable(),
    invoiceNumber: z.string().max(150).nullable(),
    orderReferences: z.array(z.string().max(150)).max(30),
    issueDate: dateString.nullable(),
    performanceDate: dateString.nullable(),
    dueDate: dateString.nullable(),
    currency: z.string().max(10).nullable(),
    reasonCodes: z.array(z.string().max(100)).max(30),
    lines: z
      .array(
        z.object({
          sourceLineId: z.string().max(100),
          supplierSku: z.string().max(200).nullable(),
          description: z.string().max(2000),
          quantity: decimalString.nullable(),
          unit: z.string().max(50).nullable(),
          unitPrice: decimalString.nullable(),
          lineNet: decimalString.nullable(),
          provenance: z.object({
            page: z.number().int().min(1).max(1000).nullable(),
            sourceText: z.string().max(4000).nullable(),
          }),
        })
      )
      .max(2000),
  })
  .strict();
export type Invoice = z.infer<typeof invoiceSchema>;
export const ruleSchema = z
  .object({
    key: z.string().min(1).max(200),
    name: z.string().min(1).max(300),
    supplierIdentity: z.string().min(1).max(300),
    supplierSku: z.string().min(1).max(200),
    validFrom: dateString,
    validTo: dateString.nullable().default(null),
    applicability: z.enum([
      "PER_ITEM",
      "PER_PACKAGE",
      "PER_CASE",
      "PER_SHIPMENT",
      "MANUAL_QUANTITY",
    ]),
    unit: z.string().min(1).max(50),
    source: z.string().min(1).max(2000),
    notes: z.string().max(4000).nullable().default(null),
    operator: z.string().min(1).max(100),
    components: z
      .array(
        z.object({
          name: z.string().min(1).max(200),
          material: z.string().min(1).max(100),
          grams: decimalString.refine((s) => new Decimal(s).gt(0)),
          classification: z.string().max(100).nullable(),
        })
      )
      .min(1)
      .max(50),
  })
  .strict()
  .refine((r) => !r.validTo || r.validTo >= r.validFrom);
export type MaterialRule = z.infer<typeof ruleSchema> & { id: string; version: number };
export type CalculationTrace = {
  ruleVersionId: string;
  ruleVersion: number;
  applicability: string;
  invoiceQuantity: string;
  invoiceUnit: string;
  factor: string;
  normalizedQuantity: string;
  components: {
    name: string;
    material: string;
    classification: string | null;
    gramsPerUnit: string;
    grams: string;
  }[];
  totalGrams: string;
};
export function calculateMaterial(input: {
  quantity: string | null;
  unit: string | null;
  rule: MaterialRule;
  conversionFactor?: string;
  basisQuantity?: string;
  creditApproved?: boolean;
}): CalculationTrace {
  const { rule, quantity, unit } = input;
  if (quantity === null || unit === null) throw new EprError("quantity_missing");
  if (!decimalString.safeParse(quantity).success) throw new EprError("quantity_invalid");
  if (new Decimal(quantity).isNegative() && !input.creditApproved)
    throw new EprError("credit_material_review_required");
  let factor = "1",
    normalized = new Decimal(quantity);
  if (rule.applicability !== "PER_ITEM") {
    if (!input.basisQuantity || !decimalString.safeParse(input.basisQuantity).success)
      throw new EprError("packaging_quantity_missing");
    normalized = new Decimal(input.basisQuantity);
    if (normalized.isNegative() && !input.creditApproved)
      throw new EprError("credit_material_review_required");
  } else if (unit !== rule.unit) {
    if (
      !input.conversionFactor ||
      !decimalString.safeParse(input.conversionFactor).success ||
      new Decimal(input.conversionFactor).lte(0)
    )
      throw new EprError("unit_conversion_missing");
    factor = input.conversionFactor;
    normalized = normalized.mul(factor);
  }
  const components = rule.components.map((c) => ({
    name: c.name,
    material: c.material,
    classification: c.classification,
    gramsPerUnit: c.grams,
    grams: normalized.mul(c.grams).toFixed(),
  }));
  return {
    ruleVersionId: rule.id,
    ruleVersion: rule.version,
    applicability: rule.applicability,
    invoiceQuantity: quantity,
    invoiceUnit: unit,
    factor,
    normalizedQuantity: normalized.toFixed(),
    components,
    totalGrams: components.reduce((sum, c) => sum.plus(c.grams), new Decimal(0)).toFixed(),
  };
}
export function totalsFromTraces(traces: CalculationTrace[]): Record<string, string> {
  const totals: Record<string, Decimal> = {};
  for (const trace of traces)
    for (const c of trace.components)
      totals[c.material] = (totals[c.material] ?? new Decimal(0)).plus(c.grams);
  return Object.fromEntries(
    Object.entries(totals).map(([material, grams]) => [material, grams.div(1000).toFixed()])
  );
}
export function quarter(code: string) {
  const match = /^(20\d{2})-Q([1-4])$/.exec(code);
  if (!match) throw new EprError("period_invalid");
  const year = Number(match[1]),
    q = Number(match[2]),
    month = (q - 1) * 3;
  return {
    code,
    startsAt: `${year}-${String(month + 1).padStart(2, "0")}-01`,
    endsAt: new Date(Date.UTC(year, month + 3, 0)).toISOString().slice(0, 10),
  };
}
export function discoverySignals(subject: string, filenames: string[], text = ""): string[] {
  const signals: string[] = [];
  if (filenames.some((f) => /\.(pdf|xml)$/i.test(f)))
    signals.push("commercial_attachment_candidate");
  if (
    /invoice|rechnung|számla|fattura|credit.?note|delivery.?note|rendelés|order|beszerz|purchase/i.test(
      subject
    )
  )
    signals.push("commercial_subject");
  if (/invoice\s*(no|number|#)|számlaszám|rechnungsnummer|<Invoice\b/i.test(text))
    signals.push("invoice_number_detected");
  return signals;
}
