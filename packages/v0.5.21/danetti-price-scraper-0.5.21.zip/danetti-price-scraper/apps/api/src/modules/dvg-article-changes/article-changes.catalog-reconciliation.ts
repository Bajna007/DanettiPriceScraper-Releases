import { readWooSkuArticleCandidates, type SupplierArticleChangeItem } from "@danetti/shared";
export interface CatalogImportProof {
  currentSku: string | null;
  currentWooId: string | null;
  catalogProductId: string;
  wooId: string;
  sku: string;
  importRunId: string;
  finishedAt: string;
}
export interface ArticleCatalogCorrection {
  catalogProductId: string;
  newSku: string;
  importRunId: string;
}

/** A completed CSV import and a unique stable Woo identity must prove the correction. */
export function findArticleCatalogCorrections(
  items: SupplierArticleChangeItem[],
  identities: Map<string, string>,
  proofs: CatalogImportProof[]
): ArticleCatalogCorrection[] {
  const latest = new Map<string, CatalogImportProof[]>();
  for (const proof of proofs) {
    const existing = latest.get(proof.wooId);
    if (!existing || proof.finishedAt > existing[0]!.finishedAt) latest.set(proof.wooId, [proof]);
    else if (proof.finishedAt === existing[0]!.finishedAt) existing.push(proof);
  }
  const corrections: ArticleCatalogCorrection[] = [];
  for (const item of items) {
    if (
      !item.newArticle ||
      !(item.newArticleVerified ?? ["priced", "unpriced"].includes(item.status))
    )
      continue;
    const wooId = identities.get(item.catalogProductId);
    if (!wooId) continue;
    const rows = latest.get(wooId);
    if (!rows || rows.length !== 1) continue;
    const proof = rows[0]!;
    if (item.reviewOpenedAt && Date.parse(proof.finishedAt) <= Date.parse(item.reviewOpenedAt))
      continue;
    if (proof.currentSku !== proof.sku || proof.currentWooId !== proof.wooId) continue;
    const articles = readWooSkuArticleCandidates(proof.sku).map((a) => a.toUpperCase());
    if (
      articles.includes(item.newArticle.toUpperCase()) &&
      !articles.includes(item.originalArticle.toUpperCase())
    )
      corrections.push({
        catalogProductId: item.catalogProductId,
        newSku: proof.sku,
        importRunId: proof.importRunId,
      });
  }
  return corrections;
}
