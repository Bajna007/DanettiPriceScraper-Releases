import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { detectWooCsvColumnMapping } from "@danetti/db";
import { buildCatalogProductsSummary } from "./catalog-import.repository.js";
import { parseCatalogProductUpdateInput } from "./catalog-import.routes.js";
import { parseWooCsv } from "./catalog-import.service.js";
import { CatalogImportValidationError } from "./catalog-import.types.js";

const repositorySource = readFileSync(
  new URL("./catalog-import.repository.ts", import.meta.url),
  "utf8"
);

assert.equal(typeof detectWooCsvColumnMapping, "function");

const parsed = parseWooCsv(Buffer.from("SKU,Name\n421944065151_SAE125,Test product\n", "utf8"));
assert.equal(parsed.columnMapping.effectiveMapping.sku, "SKU");
assert.equal(parsed.rows.length, 1);

assert.deepEqual(
  parseCatalogProductUpdateInput({
    sku: " NEW_SKU ",
    name: " Updated product ",
    suggestedSupplierArticle: " ",
    dvgPurchasePriceEur: "12.5",
  }),
  {
    sku: "NEW_SKU",
    name: "Updated product",
    suggestedSupplierArticle: null,
    dvgPurchasePriceEur: "12.5",
  }
);
assert.throws(
  () => parseCatalogProductUpdateInput({ sku: " ", name: "Product" }),
  CatalogImportValidationError
);

const summary = buildCatalogProductsSummary([
  {
    regularPrice: "10000",
    salePrice: null,
    currentPrice: "9000",
    dvgPurchasePriceHuf: "5000",
    dvgPurchasePriceEur: null,
    dvgProfitNetHuf: "4000",
    dvgProfitPercent: "80",
    dvgLastRunStatus: "ok",
    dvgLastRunMessage: null,
    dvgPricingUpdatedAt: new Date("2026-06-01T10:00:00.000Z"),
    lfPurchasePriceHuf: "5200",
    lfPurchasePriceEur: null,
    lfProfitNetHuf: "3800",
    lfProfitPercent: "73.08",
    lfLastRunStatus: "ok",
    lfLastRunMessage: null,
    lfPricingUpdatedAt: new Date("2026-06-01T12:00:00.000Z"),
  },
  {
    regularPrice: "20000",
    salePrice: null,
    currentPrice: "20000",
    dvgPurchasePriceHuf: "18000",
    dvgPurchasePriceEur: null,
    dvgProfitNetHuf: "-500",
    dvgProfitPercent: "-2.5",
    dvgLastRunStatus: "price_missing",
    dvgLastRunMessage: null,
    dvgPricingUpdatedAt: new Date("2026-06-02T10:00:00.000Z"),
    lfPurchasePriceHuf: null,
    lfPurchasePriceEur: null,
    lfProfitNetHuf: null,
    lfProfitPercent: null,
    lfLastRunStatus: "cross_reference_only",
    lfLastRunMessage: null,
    lfPricingUpdatedAt: null,
  },
  {
    regularPrice: "30000",
    salePrice: null,
    currentPrice: null,
    dvgPurchasePriceHuf: null,
    dvgPurchasePriceEur: null,
    dvgProfitNetHuf: null,
    dvgProfitPercent: null,
    dvgLastRunStatus: null,
    dvgLastRunMessage: null,
    dvgPricingUpdatedAt: null,
    lfPurchasePriceHuf: null,
    lfPurchasePriceEur: null,
    lfProfitNetHuf: null,
    lfProfitPercent: null,
    lfLastRunStatus: "item_not_available",
    lfLastRunMessage: null,
    lfPricingUpdatedAt: null,
  },
]);

assert.equal(summary.totalProducts, 3);
assert.equal(summary.dvg.productsWithPrice, 2);
assert.equal(summary.dvg.missingPrice, 1);
assert.equal(summary.dvg.lowProfitCount, 1);
assert.equal(summary.dvg.negativeProfitCount, 1);
assert.equal(summary.dvg.needsAttentionCount, 2);
assert.equal(summary.lf.productsWithPrice, 1);
assert.equal(summary.lf.missingPrice, 2);
assert.equal(summary.lf.needsAttentionCount, 2);
assert.equal(summary.lf.latestPricingAt?.toISOString(), "2026-06-01T12:00:00.000Z");
assert.equal(summary.wooPriceHuf.median, 20000);
assert.equal(summary.dvg.profitPercent.average, 38.75);
assert.equal(summary.dvg.profitPercent.modeBucket?.label, "veszteséges");
assert.equal(summary.dvg.statusCounts.ok, 1);
assert.equal(summary.dvg.statusCounts.priceMissing, 1);
assert.equal(summary.dvg.statusCounts.noRun, 1);
assert.equal(summary.lf.statusCounts.ok, 1);
assert.equal(summary.lf.statusCounts.crossReferenceOnly, 1);
assert.equal(summary.lf.statusCounts.notSupplierOwnArticle, 1);
assert.equal(summary.lf.statusCounts.unavailable, 1);
assert.equal(summary.lf.statusCounts.failedOrTimeout, 0);
assert.equal(summary.lf.statusCounts.noRun, 0);

assert.match(repositorySource, /LF_SUPPLIER_CODE = "lf-spare-parts-724"/);
assert.match(repositorySource, /readSupplierPricingScope/);
assert.match(repositorySource, /supplier\?\.code === LF_SUPPLIER_CODE \? "lf" : "dvg"/);
assert.match(repositorySource, /catalogPricingColumns\(pricingScope\)/);
assert.match(repositorySource, /catalogProducts\.lfPurchasePriceEur/);
assert.match(repositorySource, /catalogProducts\.lfLastRunStatus/);
assert.match(repositorySource, /productOrderBy\(input, pricingScope\)/);
assert.match(repositorySource, /liveProfitPercentExpression\([\s\S]*pricingScope/);

console.log("Catalog import runtime import tests passed");
