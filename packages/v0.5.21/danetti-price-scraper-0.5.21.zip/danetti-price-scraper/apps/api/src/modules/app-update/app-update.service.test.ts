import assert from "node:assert/strict";
import { createPublicKey, generateKeyPairSync, sign } from "node:crypto";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  AppUpdateService,
  DEFAULT_APP_UPDATE_CONFIG,
  resolveAppRootDirectory,
  type AppUpdateConfig,
  validateManifest,
} from "./app-update.service.js";

const appRoot = resolveAppRootDirectory();
const packageJson = JSON.parse(await readFile(join(appRoot, "package.json"), "utf8")) as {
  name: string;
  version: string;
};
assert.equal(packageJson.name, "danetti-price-scraper");
const pair = generateKeyPairSync("ed25519");
const publicKey = createPublicKey(pair.privateKey)
  .export({ type: "spki", format: "der" })
  .subarray(-32)
  .toString("base64");
const config: AppUpdateConfig = {
  product: "danetti-price-scraper",
  channel: "stable",
  manifestUrl:
    "https://api.github.com/repos/Bajna007/DanettiPriceScraper-Releases/contents/stable/manifest.json?ref=main",
  releaseRepository: "Bajna007/DanettiPriceScraper-Releases",
  publicKeys: [publicKey],
};
const unsigned = {
  schema_version: "1.0.0" as const,
  product: config.product,
  version: "9.0.0",
  channel: "stable" as const,
  changelog: "Tesztelt aláírt frissítés.",
  asset: {
    name: "danetti-price-scraper-9.0.0.zip",
    size: 1234,
    sha256: "a".repeat(64),
  },
  package_url:
    "https://github.com/Bajna007/DanettiPriceScraper-Releases/releases/download/v9.0.0/danetti-price-scraper-9.0.0.zip",
  release_commit: "b".repeat(40),
  published_at: "2026-08-17T12:00:00.000Z",
};
const manifest = {
  ...unsigned,
  signature: sign(
    null,
    Buffer.from(JSON.stringify(canonicalize(unsigned))),
    pair.privateKey
  ).toString("base64"),
};
assert.equal(validateManifest(manifest, config).version, "9.0.0");

const gitConfig = { ...config, allowGitDistribution: true };
const gitManifest = {
  ...unsigned,
  schema_version: "2.0.0",
  distribution: "github_git",
  artifact_commit: "c".repeat(40),
  package_url: `https://raw.githubusercontent.com/Bajna007/DanettiPriceScraper-Releases/${"c".repeat(40)}/packages/v9.0.0/danetti-price-scraper-9.0.0.zip`,
};
assert.equal(validateManifest(gitManifest, gitConfig).version, "9.0.0");
assert.throws(() => validateManifest(gitManifest, config));
let gitLaunch = false;
const gitUpdate = await new AppUpdateService({
  config: gitConfig,
  fetcher: async () => new Response(JSON.stringify(gitManifest)),
  launcher: async (request) => {
    gitLaunch = request.expectedVersion === "9.0.0";
  },
}).queueInstall("9.0.0");
assert.equal(gitUpdate.status, "available");
assert.equal(gitLaunch, true);
const rejectedGitUpdate = await new AppUpdateService({
  config: gitConfig,
  fetcher: async () =>
    new Response(
      JSON.stringify({ ...gitManifest, package_url: "https://example.test/payload.zip" })
    ),
}).check();
assert.equal(rejectedGitUpdate.status, "unavailable");

const directUrls: URL[] = [];
let directInstallUrl = "";
const directService = new AppUpdateService({
  fetcher: async (input) => {
    const url = new URL(String(input));
    directUrls.push(url);
    assert.equal(url.origin, "https://raw.githubusercontent.com");
    assert.equal(
      url.pathname,
      "/Bajna007/DanettiPriceScraper-Releases/main/stable/manifest-git.json"
    );
    return new Response(JSON.stringify(gitManifest));
  },
  launcher: async (request) => {
    directInstallUrl = request.manifestUrl;
  },
});
assert.equal((await directService.check(true)).status, "available");
assert(directUrls[0]!.searchParams.has("check"));
await directService.queueInstall("9.0.0");
assert.equal(directInstallUrl, DEFAULT_APP_UPDATE_CONFIG.manifestUrl);

const service = new AppUpdateService({
  config,
  fetcher: async () => new Response(JSON.stringify(manifest), { status: 200 }),
});
const available = await service.check();
assert.equal(available.status, "available");
assert.equal(available.currentVersion, packageJson.version);
assert.equal(available.availableVersion, "9.0.0");

let launchedVersion = "";
const queued = await new AppUpdateService({
  config,
  fetcher: async () => new Response(JSON.stringify(manifest), { status: 200 }),
  launcher: async (request) => {
    launchedVersion = request.expectedVersion;
  },
}).queueInstall("9.0.0");
assert.equal(queued.status, "available");
assert.equal(launchedVersion, "9.0.0");

await assert.rejects(
  () =>
    new AppUpdateService({
      config,
      fetcher: async () => new Response(JSON.stringify(manifest), { status: 200 }),
      launcher: async () => {
        throw new Error("launcher probe failed");
      },
    }).queueInstall("9.0.0"),
  (error: unknown) =>
    error instanceof Error &&
    "code" in error &&
    error.code === "update_launch_failed" &&
    error.message.includes("launcher probe failed")
);

const invalidPackage = { ...manifest, package_url: "https://example.test/package.zip" };
assert.throws(() => validateManifest(invalidPackage, config));
const unavailable = await new AppUpdateService({
  config,
  fetcher: async () => new Response("not found", { status: 404 }),
}).check();
assert.equal(unavailable.status, "unavailable");

const stateRoot = await mkdtemp(join(tmpdir(), "danetti-update-state-test-"));
try {
  await mkdir(join(stateRoot, "logs"), { recursive: true });
  await writeFile(
    join(stateRoot, "package.json"),
    JSON.stringify({ name: "danetti-price-scraper", version: "9.0.0" })
  );
  await writeFile(
    join(stateRoot, "logs", "danetti-update-state.json"),
    `\uFEFF${JSON.stringify({
      state: "complete",
      version: "9.0.0",
      message: "A frissítés elkészült.",
      updated_at: "2026-08-18T10:00:00.000Z",
    })}`
  );
  const installStatus = await new AppUpdateService({ rootDirectory: stateRoot }).installStatus();
  assert.equal(installStatus.state, "complete");
  assert.equal(installStatus.version, "9.0.0");
} finally {
  await rm(stateRoot, { recursive: true, force: true });
}

function canonicalize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (value && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return Object.fromEntries(
      Object.keys(record)
        .sort()
        .map((key) => [key, canonicalize(record[key])])
    );
  }
  return value;
}

console.log("Signed app-update manifest tests passed");
