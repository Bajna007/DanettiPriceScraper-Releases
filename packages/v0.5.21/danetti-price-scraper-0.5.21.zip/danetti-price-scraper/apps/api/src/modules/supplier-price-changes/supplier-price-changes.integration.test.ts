import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import Fastify from "fastify";
import postgres from "postgres";
import { drizzle } from "drizzle-orm/postgres-js";
import { sql } from "drizzle-orm";
import { schema } from "@danetti/db";
import { DVG_CONNECTOR_ID, LF_CONNECTOR_ID } from "@danetti/connectors";
import { SupplierPriceChangesRepository } from "./supplier-price-changes.repository.js";
import { registerSupplierPriceChangeRoutes } from "./supplier-price-changes.routes.js";

const databaseUrl = process.env.SUPPLIER_PRICE_CHANGES_TEST_DATABASE_URL;
if (!databaseUrl) throw new Error("SUPPLIER_PRICE_CHANGES_TEST_DATABASE_URL is required");
const client = postgres(databaseUrl, { max: 1, onnotice: () => undefined });

try {
  await drizzle(client, { schema }).transaction(async (testDb) => {
    const transaction = Object.assign(
      (strings: TemplateStringsArray, ...parameters: unknown[]) =>
        testDb.execute(sql(strings, ...parameters)),
      { unsafe: (query: string) => testDb.execute(sql.raw(query)) }
    );
    // Only transaction-owned temporary tables are visible. Existing application
    // data is neither read nor written, and PostgreSQL drops fixtures on teardown.
    await transaction`SET LOCAL search_path TO pg_temp`;
    await transaction.unsafe(`CREATE TEMP TABLE suppliers (
      id uuid PRIMARY KEY, code text, name text
    ) ON COMMIT DROP`);
    await transaction.unsafe(`CREATE TEMP TABLE catalog_products (
      id uuid PRIMARY KEY, sku text, name text, current_price numeric,
      sale_price numeric, regular_price numeric
      ,source_product_id text,source_variation_id text
    ) ON COMMIT DROP`);
    await transaction.unsafe(`CREATE TEMP TABLE supplier_price_snapshots (
      id uuid PRIMARY KEY, supplier_id uuid, supplier_mapping_id uuid,
      catalog_product_id uuid, supplier_article_number text, price_net_eur numeric(12, 2),
      currency text, observed_at timestamptz, created_at timestamptz
    ) ON COMMIT DROP`);
    await transaction.unsafe(`CREATE TEMP TABLE supplier_mappings (
      id uuid PRIMARY KEY, catalog_product_id uuid, supplier_id uuid,
      supplier_article_number text
    ) ON COMMIT DROP`);
    for (const table of ["dvg_operator_runs", "lf_operator_runs"]) {
      await transaction.unsafe(`CREATE TEMP TABLE ${table} (
        run_id text PRIMARY KEY, started_at timestamptz, rows jsonb,
        completed_at timestamptz, updated_at timestamptz
      ) ON COMMIT DROP`);
    }
    await transaction.unsafe(`CREATE TEMP TABLE price_change_reviews (
      event_id text PRIMARY KEY, baseline_woo_gross_huf numeric(14,2), baseline_source text NOT NULL,
      decision text NOT NULL DEFAULT 'auto', decided_at timestamptz, created_at timestamptz DEFAULT now()
    ) ON COMMIT DROP`);

    const dvgId = randomUUID();
    const lfId = randomUUID();
    const changedId = randomUUID();
    const unchangedId = randomUUID();
    const baselineId = randomUUID();
    const decreaseId = randomUUID();
    const separateMappingId = randomUUID();
    const returnedPriceId = randomUUID();
    await transaction`INSERT INTO suppliers (id, code, name) VALUES
      (${dvgId}, ${DVG_CONNECTOR_ID}, 'DVG'), (${lfId}, ${LF_CONNECTOR_ID}, 'LF')`;
    for (const [id, sku] of [
      [changedId, "changed"],
      [unchangedId, "unchanged"],
      [baselineId, "baseline"],
      [decreaseId, "decrease"],
      [separateMappingId, "separate-mappings"],
      [returnedPriceId, "returned-price"],
    ]) {
      await transaction`INSERT INTO catalog_products (id, sku, name, current_price)
        VALUES (${id!}, ${sku!}, 'Synthetic test product', 7620)`;
    }

    async function observe(
      productId: string,
      supplierId: string,
      price: number | null,
      day: number,
      mappingId: string | null = null,
      currency = "EUR"
    ) {
      const id = randomUUID();
      await transaction`INSERT INTO supplier_price_snapshots
        (id, supplier_id, supplier_mapping_id, catalog_product_id,
         supplier_article_number, price_net_eur, currency, observed_at, created_at)
        VALUES (${id}, ${supplierId}, ${mappingId}, ${productId}, 'TEST-ARTICLE',
          ${price}, ${currency}, '2026-01-01'::timestamptz + ${day} * interval '1 day',
          '2026-01-01'::timestamptz + ${day} * interval '1 day')`;
      return id;
    }

    const oldId = await observe(changedId, dvgId, 4, 0);
    // More unchanged observations than the old default raw-snapshot scan limit.
    await transaction`INSERT INTO supplier_price_snapshots
      (id, supplier_id, catalog_product_id, supplier_article_number, price_net_eur,
       currency, observed_at, created_at)
      SELECT gen_random_uuid(), ${dvgId}, ${changedId}, 'TEST-ARTICLE', 5, 'EUR',
        '2026-01-02'::timestamptz + n * interval '1 minute',
        '2026-01-02'::timestamptz + n * interval '1 minute'
      FROM generate_series(1, 50001) AS n`;
    const newestId = await observe(changedId, dvgId, 5, 40);
    await observe(changedId, dvgId, 999, 41, null, "USD");
    await observe(changedId, dvgId, null, 42);
    await observe(unchangedId, dvgId, 4, 0);
    await observe(unchangedId, dvgId, 4, 1);
    await observe(baselineId, dvgId, 4, 0);
    await observe(decreaseId, lfId, 10, 0);
    await observe(decreaseId, lfId, 8, 1);
    await observe(decreaseId, lfId, 8, 2);
    await observe(separateMappingId, dvgId, 4, 0, randomUUID());
    await observe(separateMappingId, dvgId, 5, 1, randomUUID());
    await observe(returnedPriceId, dvgId, 4, 0);
    const reversalOldId = await observe(returnedPriceId, dvgId, 5, 1);
    await observe(returnedPriceId, dvgId, 4, 2);
    const reversalNewestId = await observe(returnedPriceId, dvgId, 4, 3);

    const repository = new SupplierPriceChangesRepository(testDb);
    const compactHistory = await repository.listRecentCatalogSnapshots(100, "all");
    assert.ok(compactHistory.length <= 3 * 7);
    assert.equal(compactHistory.filter((row) => row.catalogProductId === changedId).length, 4);
    const server = Fastify({ logger: false });
    await registerSupplierPriceChangeRoutes(server, { repository });
    try {
      const response = await server.inject("/supplier-price-changes?eurHufRate=400");
      assert.equal(response.statusCode, 200);
      const body = response.json();
      assert.equal(body.total, 3);
      assert.equal(body.summary.increaseCount, 1);
      assert.equal(body.summary.decreaseCount, 2);
      assert.equal(body.summary.noPreviousPriceCount, 3);
      const changed = body.items.find((row: { sku: string }) => row.sku === "changed");
      assert.equal(changed.oldSnapshotId, oldId);
      assert.equal(changed.newSnapshotId, newestId);
      assert.equal(changed.oldSupplierNetEur, 4);
      assert.equal(changed.newSupplierNetEur, 5);
      const reversed = body.items.find((row: { sku: string }) => row.sku === "returned-price");
      assert.equal(reversed.oldSnapshotId, reversalOldId);
      assert.equal(reversed.newSnapshotId, reversalNewestId);
      assert.equal(reversed.oldSupplierNetEur, 5);
      assert.equal(reversed.newSupplierNetEur, 4);

      const limited = await server.inject(
        "/supplier-price-changes?eurHufRate=400&maxSnapshotScan=100&limit=1&offset=1"
      );
      assert.equal(limited.statusCode, 200);
      assert.equal(limited.json().total, 3);
      assert.equal(limited.json().items.length, 1);
      assert.equal(limited.json().items[0].sku, "returned-price");
      const lf = await server.inject("/supplier-price-changes?eurHufRate=400&supplierScope=lf");
      assert.equal(lf.statusCode, 200);
      assert.equal(lf.json().total, 1);
      assert.equal(lf.json().items[0].sku, "decrease");
      const dvg = await server.inject("/supplier-price-changes?eurHufRate=400&supplierScope=dvg");
      assert.equal(dvg.statusCode, 200);
      assert.equal(dvg.json().total, 2);
      const filtered = await server.inject(
        "/supplier-price-changes?eurHufRate=400&direction=increase&minChangePercent=26"
      );
      assert.equal(filtered.statusCode, 200);
      assert.equal(filtered.json().total, 0);
      const allHistory = (
        await server.inject("/supplier-price-changes?eurHufRate=400&view=all")
      ).json();
      assert.equal(allHistory.total, 4, "A -> B -> A retains both transitions");
      assert.equal(
        (await server.inject("/supplier-price-changes?eurHufRate=400&view=latest")).json().total,
        0
      );
      // Reading historical changes does not backfill or duplicate snapshots.
      const [count] =
        await transaction`SELECT count(*)::int AS count FROM supplier_price_snapshots`;
      assert.equal(count?.count, 50017);

      // Real dry-run observations were archived but never written as snapshots.
      // They must still participate in historical comparisons, without backfill.
      const dvgMapping = randomUUID();
      const lfMapping = randomUUID();
      for (const [mapping, product, supplier] of [
        [dvgMapping, baselineId, dvgId],
        [lfMapping, decreaseId, lfId],
      ]) {
        await transaction`INSERT INTO supplier_mappings VALUES
          (${mapping!}, ${product!}, ${supplier!}, 'TEST-ARTICLE')`;
      }
      const dvgRow = {
        catalogProductId: baselineId,
        supplierId: dvgId,
        supplierMappingId: dvgMapping,
        supplierArticleNumber: "TEST-ARTICLE",
        status: "ok",
        currency: "EUR",
        candidateSource: "saved_mapping",
        matchConfidence: "exact_dvg_article",
        dvgArticle: "TEST-ARTICLE",
        supplierNetEur: 6,
      };
      await observe(baselineId, dvgId, 4, 0, dvgMapping);
      await transaction`INSERT INTO dvg_operator_runs (run_id, started_at, rows) VALUES
        ('archive-old', '2026-04-01', ${JSON.stringify([dvgRow])}::jsonb),
        ('archive-new', '2026-05-01', ${JSON.stringify([dvgRow])}::jsonb)`;
      const lfRow = {
        ...dvgRow,
        catalogProductId: decreaseId,
        supplierId: lfId,
        supplierMappingId: lfMapping,
        matchConfidence: "trusted_lf_item",
        lfAutocompleteId: "C:TEST-ARTICLE",
        supplierNetEur: 7,
      };
      await transaction`INSERT INTO lf_operator_runs (run_id, started_at, rows) VALUES
        ('lf-old', '2026-04-01', ${JSON.stringify([lfRow])}::jsonb),
        ('lf-new', '2026-05-01', ${JSON.stringify([{ ...lfRow, supplierNetEur: 9 }])}::jsonb)`;
      const invalidRows = [
        { ...dvgRow, status: "failed" },
        { ...dvgRow, candidateSource: "sku_prefix_candidate" },
        { ...dvgRow, supplierMappingId: null },
        { ...dvgRow, catalogProductId: changedId },
        { ...dvgRow, supplierId: lfId },
        { ...dvgRow, matchConfidence: "original_code_only" },
        { ...dvgRow, dvgArticle: "OTHER" },
        { ...dvgRow, currency: "USD" },
        { ...dvgRow, supplierNetEur: "invalid" },
        { ...dvgRow, supplierNetEur: null },
        { ...dvgRow, supplierNetEur: 0 },
      ];
      await transaction`INSERT INTO dvg_operator_runs (run_id, started_at, rows) VALUES
        ('invalid', '2026-06-01', ${JSON.stringify(invalidRows)}::jsonb)`;
      await transaction`INSERT INTO lf_operator_runs (run_id, started_at, rows) VALUES
        ('lf-invalid', '2026-06-01', ${JSON.stringify([{ ...lfRow, lfAutocompleteId: "C:OTHER" }])}::jsonb)`;
      const archived = (await server.inject("/supplier-price-changes?eurHufRate=400")).json();
      assert.equal(archived.total, 5);
      const recovered = archived.items.find(
        (row: { supplierMappingId: string }) => row.supplierMappingId === dvgMapping
      );
      assert.equal(recovered.oldSupplierNetEur, 4);
      assert.equal(recovered.newSupplierNetEur, 6);
      assert.equal(recovered.newObservedAt, "2026-05-01T00:00:00.000Z");
      assert.match(recovered.newSnapshotId, /^operator:/);
      const recoveredLf = archived.items.find(
        (row: { supplierMappingId: string }) => row.supplierMappingId === lfMapping
      );
      assert.equal(recoveredLf.oldSupplierNetEur, 7);
      assert.equal(recoveredLf.newSupplierNetEur, 9);
      assert.equal(
        (await server.inject("/supplier-price-changes?eurHufRate=400&supplierScope=lf")).json()
          .total,
        2
      );
      const [afterRead] =
        await transaction`SELECT count(*)::int AS count FROM supplier_price_snapshots`;
      assert.equal(afterRead?.count, 50018);

      // Snapshot writes from a trusted operator run are the same measurement,
      // not a second successful check which would hide the latest price change.
      await transaction`UPDATE lf_operator_runs SET completed_at=started_at + interval '1 hour', updated_at=started_at + interval '1 hour'`;
      await transaction`INSERT INTO supplier_price_snapshots
        (id,supplier_id,supplier_mapping_id,catalog_product_id,supplier_article_number,price_net_eur,currency,observed_at,created_at)
        VALUES (${randomUUID()},${lfId},${lfMapping},${decreaseId},'TEST-ARTICLE',9,'EUR','2026-05-01T00:01:00Z','2026-05-01T00:01:00Z')`;
      const latest = (
        await server.inject("/supplier-price-changes?eurHufRate=400&view=latest")
      ).json();
      assert.equal(
        latest.items.filter(
          (row: { supplierMappingId: string }) => row.supplierMappingId === lfMapping
        ).length,
        1
      );

      const eventId = changed.eventId;
      const decision = await server.inject({
        method: "POST",
        url: "/supplier-price-changes/review",
        headers: { "x-danetti-local-lab": "true" },
        payload: { eventId, decision: "resolved" },
      });
      assert.equal(decision.statusCode, 200);
      const resolved = (await server.inject("/supplier-price-changes?eurHufRate=400&view=all"))
        .json()
        .items.find((row: { eventId: string }) => row.eventId === eventId);
      assert.equal(resolved.reviewStatus, "resolved");
      await server.inject({
        method: "POST",
        url: "/supplier-price-changes/review",
        headers: { "x-danetti-local-lab": "true" },
        payload: { eventId, decision: "open" },
      });
      await transaction`UPDATE catalog_products SET current_price=9600 WHERE id=${changedId}`;
      const corrected = (await server.inject("/supplier-price-changes?eurHufRate=400"))
        .json()
        .items.find((row: { eventId: string }) => row.eventId === eventId);
      assert.equal(
        corrected.reviewStatus,
        "pending",
        "manual reopen remains actionable after an import"
      );
      assert.equal(corrected.currentWooPriceHuf, 9600);
      assert.equal(corrected.baselineWooGrossHuf, 7620);
      assert.equal(corrected.suggestedGrossPriceRoundedHuf, changed.suggestedGrossPriceRoundedHuf);
    } finally {
      await server.close();
    }
  });
  const [remaining] = await client`SELECT
    to_regclass('pg_temp.suppliers')::text AS suppliers,
    to_regclass('pg_temp.catalog_products')::text AS products,
    to_regclass('pg_temp.supplier_price_snapshots')::text AS snapshots`;
  assert.equal(remaining?.suppliers, null);
  assert.equal(remaining?.products, null);
  assert.equal(remaining?.snapshots, null);
} finally {
  await client.end({ timeout: 5 });
}

console.log("Supplier price changes PostgreSQL integration tests passed");
