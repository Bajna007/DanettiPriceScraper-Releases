import assert from "node:assert/strict";
import { DVG_ALLOWED_DOMAIN, DVG_CONNECTOR_ID, type DvgCredentials } from "@danetti/connectors";
import Fastify from "fastify";
import { registerSupplierCredentialRoutes } from "./supplier-credentials.routes.js";
import { InMemorySupplierCredentialStore } from "./supplier-credentials.store.js";
import type { SupplierCredentialStore } from "./supplier-credentials.store.js";
import type { CredentialSupplier } from "./supplier-credentials.service.js";
import { SupplierCredentialError } from "./supplier-credentials.types.js";
import type { SupplierCredentialSecret } from "./supplier-credentials.types.js";

const dvgSupplierId = "11111111-1111-4111-8111-111111111111";
const unsupportedSupplierId = "22222222-2222-4222-8222-222222222222";
const missingSupplierId = "33333333-3333-4333-8333-333333333333";
const hiddenStoredPassword = ["stored", "password", "secret"].join("-");
const hiddenEnvPassword = ["env", "password", "secret"].join("-");
const hiddenStoredUser = ["stored", "user", "secret"].join("-");
const hiddenEnvUser = ["env", "user", "secret"].join("-");
const dvgDiagnosticDetails = {
  loginPageMessage: null,
  finalPath: "/e-commerce/cerca.asp",
  loginLandingDetected: true,
  fillStrategy: "press_sequentially_tab_blur" as const,
  usernameFilled: true,
  passwordFilled: true,
  formActionHost: "devecchigiuseppesrl.com",
  formMethod: "POST",
  submitEnabled: true,
  submitEnabledAfterFill: true,
  submitEnabledBeforeSubmit: true,
  submitStrategy: "click" as const,
  submitCandidateSummary: [
    {
      index: 0,
      selector: 'form#formLogin button[type="submit"]',
      tagName: "button",
      type: "submit",
      visible: true,
      disabled: false,
      ariaDisabled: false,
      classHasDisabled: false,
      textLabel: "Login",
      namePresent: false,
      valuePresent: false,
      onclickPresent: false,
      insideForm: true,
    },
  ],
  attemptedStrategies: [],
  winningStrategy: "press_sequentially_tab_blur" as const,
  activeElementSummary: {
    tagName: "body",
    id: null,
    name: null,
    type: null,
    formId: null,
  },
  forensic: {
    clickEventFired: true,
    submitEventFired: true,
    defaultPrevented: false,
    postRequestHappened: true,
    postRequestBlocked: false,
    loginPostPath: "/e-commerce/account/login.asp",
    loginPostStatus: 200,
    navigationStarted: true,
    blockedRequestCount: 0,
    blockedScriptCount: 0,
    externalScriptHosts: [],
    consoleErrorCount: 0,
    pageErrorCount: 0,
    runtimePath: "/e-commerce/cerca.asp",
    preventDefaultCalled: false,
    preventDefaultCallCount: 0,
    preventDefaultEventType: null,
    preventDefaultTargetTag: null,
    preventDefaultTargetId: null,
    preventDefaultStackSummary: [],
    submitHandlerCount: 0,
    clickHandlerCount: 0,
    requestSubmitCalled: false,
    nativeSubmitCalled: false,
    formOnSubmitPresent: false,
    buttonOnClickPresent: false,
    buttonType: "submit",
    hiddenFieldCount: 0,
    requiredFieldCount: 0,
    emptyRequiredFieldNamesSanitized: [],
    captchaLikeElementPresent: false,
    recaptchaLikeElementPresent: false,
    cookieConsentVisible: false,
    loginFormVisible: false,
    submitButtonVisible: false,
    submitButtonEnabled: false,
  },
};

const suppliers: CredentialSupplier[] = [
  {
    id: dvgSupplierId,
    code: DVG_CONNECTOR_ID,
    name: "DVG De Vecchi",
    baseUrl: "https://devecchigiuseppesrl.com",
    allowedDomains: [DVG_ALLOWED_DOMAIN],
  },
  {
    id: unsupportedSupplierId,
    code: "other-supplier",
    name: "Other Supplier",
    baseUrl: "https://other.example",
    allowedDomains: ["other.example"],
  },
];
const store = new InMemorySupplierCredentialStore();
const capturedCredentials: DvgCredentials[] = [];
const capturedArticles: string[] = [];
const capturedForensicModes: Array<string | undefined> = [];
const server = Fastify({ logger: false });

await registerSupplierCredentialRoutes(server, {
  credentialStore: store,
  supplierSource: {
    async list() {
      return suppliers;
    },
    async getById(id) {
      return suppliers.find((supplier) => supplier.id === id) ?? null;
    },
  },
  mappingSource: {
    async getFirstSupplierArticle() {
      return "CS-A2200247";
    },
  },
  credentialTester: {
    async testDvgCredential(input) {
      capturedCredentials.push(input.credentials);
      capturedArticles.push(input.article);
      capturedForensicModes.push(input.forensicMode);
      return {
        status: "success",
        code: "dvg_login_ok_price_ok",
        loginOk: true,
        detailFetchOk: true,
        parsed: {
          dvgArticle: "CS-A2200247",
          originalCode: "A2200247",
          productName: "TAP VALVE PIAZZA SAN MARCO GROUP",
          currentPrice: 4.72,
          crossedPrice: 10.48,
          currency: "EUR",
          unit: "pc",
        },
        warnings: ["cart_form_present_do_not_interact"],
        stage: "price_parsed",
        safeMessage: "DVG login succeeded and detail price parse succeeded.",
        selectorHint: null,
        ...dvgDiagnosticDetails,
      };
    },
  },
  env: { DVG_USERNAME: hiddenEnvUser, DVG_PASSWORD: hiddenEnvPassword },
});

try {
  const listed = await server.inject({ method: "GET", url: "/supplier-credentials" });
  assert.equal(listed.statusCode, 200);
  assert.equal(listed.json().items.length, 1);
  assert.equal(listed.json().items[0].source, "env");
  assert.equal(JSON.stringify(listed.json()).includes(hiddenEnvPassword), false);
  assert.equal(JSON.stringify(listed.json()).includes(hiddenEnvUser), false);

  const saved = await server.inject({
    method: "PUT",
    url: `/supplier-credentials/${dvgSupplierId}`,
    payload: {
      connectorId: DVG_CONNECTOR_ID,
      username: hiddenStoredUser,
      password: hiddenStoredPassword,
    },
  });
  assert.equal(saved.statusCode, 200);
  assert.equal(saved.json().source, "stored");
  assert.equal(saved.json().configured, true);
  assert.equal(JSON.stringify(saved.json()).includes(hiddenStoredPassword), false);
  assert.equal(JSON.stringify(saved.json()).includes(hiddenStoredUser), false);

  const fetched = await server.inject({
    method: "GET",
    url: `/supplier-credentials/${dvgSupplierId}`,
  });
  assert.equal(fetched.statusCode, 200);
  assert.equal(fetched.json().source, "stored");
  assert.equal(JSON.stringify(fetched.json()).includes(hiddenStoredPassword), false);

  const testedStored = await server.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: {},
  });
  assert.equal(testedStored.statusCode, 200);
  assert.equal(testedStored.json().status, "success");
  assert.equal(testedStored.json().supplierId, dvgSupplierId);
  assert.equal(testedStored.json().connectorId, "dvg-devecchi");
  assert.equal(testedStored.json().credentialConfigured, true);
  assert.equal(testedStored.json().loginOk, true);
  assert.equal(testedStored.json().detailFetchOk, true);
  assert.equal(testedStored.json().parsed.currentPrice, 4.72);
  assert.equal(testedStored.json().errorCode, null);
  assert.equal(testedStored.json().stage, "price_parsed");
  assert.equal(
    testedStored.json().safeMessage,
    "DVG login succeeded and detail price parse succeeded."
  );
  assert.equal(testedStored.json().selectorHint, null);
  assert.equal(testedStored.json().errorCode, null);
  assert.equal(testedStored.json().finalPath, "/e-commerce/cerca.asp");
  assert.equal(testedStored.json().loginLandingDetected, true);
  assert.equal(testedStored.json().usernameFilled, true);
  assert.equal(testedStored.json().passwordFilled, true);
  assert.equal(testedStored.json().formActionHost, "devecchigiuseppesrl.com");
  assert.equal(testedStored.json().formMethod, "POST");
  assert.equal(testedStored.json().submitEnabled, true);
  assert.equal(testedStored.json().submitEnabledAfterFill, true);
  assert.equal(testedStored.json().submitEnabledBeforeSubmit, true);
  assert.equal(testedStored.json().submitStrategy, "click");
  assert.equal(testedStored.json().fillStrategy, "press_sequentially_tab_blur");
  assert.equal(testedStored.json().winningStrategy, "press_sequentially_tab_blur");
  assert.equal(testedStored.json().submitCandidateSummary[0].insideForm, true);
  assert.equal(testedStored.json().forensic.clickEventFired, true);
  assert.equal(testedStored.json().forensic.postRequestHappened, true);
  assert.deepEqual(capturedCredentials.at(-1), {
    username: hiddenStoredUser,
    password: hiddenStoredPassword,
  });
  assert.equal(capturedArticles.at(-1), "CS-A2200247");
  assert.equal(JSON.stringify(testedStored.json()).includes(hiddenStoredPassword), false);
  assert.equal(JSON.stringify(testedStored.json()).includes("cookie="), false);
  assert.equal(JSON.stringify(testedStored.json()).includes("session"), false);
  assert.equal(JSON.stringify(testedStored.json()).includes("storageState"), false);
  assert.equal(JSON.stringify(testedStored.json()).includes("rawHtml"), false);

  const deleted = await server.inject({
    method: "DELETE",
    url: `/supplier-credentials/${dvgSupplierId}`,
  });
  assert.equal(deleted.statusCode, 200);
  assert.equal(deleted.json().source, "env");

  const testedEnv = await server.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { testArticle: "CS-A2200247" },
  });
  assert.equal(testedEnv.statusCode, 200);
  assert.equal(testedEnv.json().status, "success");
  assert.deepEqual(capturedCredentials.at(-1), {
    username: hiddenEnvUser,
    password: hiddenEnvPassword,
  });
  assert.equal(capturedArticles.at(-1), "CS-A2200247");
  assert.equal(capturedForensicModes.at(-1), undefined);
  assert.equal(JSON.stringify(testedEnv.json()).includes(hiddenEnvPassword), false);

  const forensicV3 = await server.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { testArticle: "CS-A2200247", forensicMode: "prevent_default_v3" },
  });
  assert.equal(forensicV3.statusCode, 200);
  assert.equal(capturedForensicModes.at(-1), "prevent_default_v3");

  const invalidForensicMode = await server.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { testArticle: "CS-A2200247", forensicMode: "unsafe" },
  });
  assert.equal(invalidForensicMode.statusCode, 400);
  assert.equal(invalidForensicMode.json().error.code, "invalid_forensic_mode");

  const unsafeArticle = await server.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { testArticle: "https://unsafe.example/ARTICLE" },
  });
  assert.equal(unsafeArticle.statusCode, 400);
  assert.equal(unsafeArticle.json().error.code, "dvg_article_invalid");

  const rejectedTestPayload = await server.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { password: hiddenStoredPassword },
  });
  assert.equal(rejectedTestPayload.statusCode, 400);
  assert.equal(rejectedTestPayload.json().error.code, "sensitive_field");
  assert.equal(JSON.stringify(rejectedTestPayload.json()).includes(hiddenStoredPassword), false);

  const unsupportedSupplierTest = await server.inject({
    method: "POST",
    url: `/supplier-credentials/${unsupportedSupplierId}/test`,
    payload: { testArticle: "CS-A2200247" },
  });
  assert.equal(unsupportedSupplierTest.statusCode, 400);
  assert.equal(unsupportedSupplierTest.json().error.code, "unsupported_credential_connector");

  const unsupportedConnector = await server.inject({
    method: "PUT",
    url: `/supplier-credentials/${dvgSupplierId}`,
    payload: {
      connectorId: "dummy-supplier",
      username: hiddenStoredUser,
      password: hiddenStoredPassword,
    },
  });
  assert.equal(unsupportedConnector.statusCode, 400);
  assert.equal(unsupportedConnector.json().error.code, "unsupported_credential_connector");
  assert.equal(JSON.stringify(unsupportedConnector.json()).includes(hiddenStoredPassword), false);

  const unsupportedSupplier = await server.inject({
    method: "GET",
    url: `/supplier-credentials/${unsupportedSupplierId}`,
  });
  assert.equal(unsupportedSupplier.statusCode, 400);
  assert.equal(unsupportedSupplier.json().error.code, "unsupported_credential_connector");

  const missingSupplier = await server.inject({
    method: "GET",
    url: `/supplier-credentials/${missingSupplierId}`,
  });
  assert.equal(missingSupplier.statusCode, 404);
  assert.equal(missingSupplier.json().error.code, "not_found");
} finally {
  await server.close();
}

const missingCredentialServer = Fastify({ logger: false });
await registerSupplierCredentialRoutes(missingCredentialServer, {
  credentialStore: new InMemorySupplierCredentialStore(),
  supplierSource: {
    async list() {
      return [suppliers[0]];
    },
    async getById(id) {
      return suppliers.find((supplier) => supplier.id === id) ?? null;
    },
  },
  env: {},
});

try {
  const missingCredential = await missingCredentialServer.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { testArticle: "CS-A2200247" },
  });
  assert.equal(missingCredential.statusCode, 400);
  assert.equal(missingCredential.json().error.code, "supplier_credential_missing");
} finally {
  await missingCredentialServer.close();
}

const failedLoginServer = Fastify({ logger: false });
await registerSupplierCredentialRoutes(failedLoginServer, {
  credentialStore: store,
  supplierSource: {
    async list() {
      return [suppliers[0]];
    },
    async getById(id) {
      return suppliers.find((supplier) => supplier.id === id) ?? null;
    },
  },
  credentialTester: {
    async testDvgCredential() {
      return {
        status: "failed",
        code: "dvg_login_submit_no_effect",
        loginOk: false,
        detailFetchOk: false,
        parsed: null,
        warnings: ["dvg_login_submit_no_effect"],
        stage: "login_result_detected",
        safeMessage:
          "DVG login submit was enabled and clicked, but no useful login result was detected.",
        selectorHint: "form#formLogin",
        ...dvgDiagnosticDetails,
        finalPath: "/e-commerce/account/login.asp",
        loginLandingDetected: false,
        loginPageMessage: "No visible login error message detected.",
      };
    },
  },
  env: { DVG_USERNAME: hiddenEnvUser, DVG_PASSWORD: hiddenEnvPassword },
});

try {
  const failedLogin = await failedLoginServer.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { testArticle: "CS-A2200247" },
  });
  assert.equal(failedLogin.statusCode, 200);
  assert.equal(failedLogin.json().status, "failed");
  assert.equal(failedLogin.json().errorCode, "dvg_login_submit_no_effect");
  assert.equal(failedLogin.json().stage, "login_result_detected");
  assert.equal(failedLogin.json().selectorHint, "form#formLogin");
  assert.equal(failedLogin.json().loginPageMessage, "No visible login error message detected.");
  assert.equal(failedLogin.json().forensic.clickEventFired, true);
} finally {
  await failedLoginServer.close();
}

const accessDeniedServer = Fastify({ logger: false });
await registerSupplierCredentialRoutes(accessDeniedServer, {
  credentialStore: store,
  supplierSource: {
    async list() {
      return [suppliers[0]];
    },
    async getById(id) {
      return suppliers.find((supplier) => supplier.id === id) ?? null;
    },
  },
  credentialTester: {
    async testDvgCredential() {
      return {
        status: "failed",
        code: "dvg_article_not_found_or_access_denied",
        loginOk: true,
        detailFetchOk: false,
        parsed: null,
        warnings: ["dvg_article_not_found_or_access_denied"],
        stage: "detail_page_parsed",
        safeMessage: "DVG detail page was not reachable or article was not found.",
        selectorHint: null,
        ...dvgDiagnosticDetails,
      };
    },
  },
  env: { DVG_USERNAME: hiddenEnvUser, DVG_PASSWORD: hiddenEnvPassword },
});

try {
  const accessDenied = await accessDeniedServer.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { testArticle: "CS-A2200247" },
  });
  assert.equal(accessDenied.statusCode, 200);
  assert.equal(accessDenied.json().status, "failed");
  assert.equal(accessDenied.json().errorCode, "dvg_article_not_found_or_access_denied");
  assert.equal(accessDenied.json().stage, "detail_page_parsed");
} finally {
  await accessDeniedServer.close();
}

class UnavailableCredentialStore implements SupplierCredentialStore {
  async get(): Promise<SupplierCredentialSecret | null> {
    throw new SupplierCredentialError(
      "credential_store_unavailable",
      "Windows Credential Manager operation failed.",
      503
    );
  }

  async put(): Promise<void> {
    throw new SupplierCredentialError(
      "credential_store_unavailable",
      "Windows Credential Manager operation failed.",
      503
    );
  }

  async delete(): Promise<void> {
    throw new SupplierCredentialError(
      "credential_store_unavailable",
      "Windows Credential Manager operation failed.",
      503
    );
  }
}

const unavailableServer = Fastify({ logger: false });
await registerSupplierCredentialRoutes(unavailableServer, {
  credentialStore: new UnavailableCredentialStore(),
  supplierSource: {
    async list() {
      return [suppliers[0]];
    },
    async getById(id) {
      return suppliers.find((supplier) => supplier.id === id) ?? null;
    },
  },
  env: {},
});

try {
  const status = await unavailableServer.inject({ method: "GET", url: "/supplier-credentials" });
  assert.equal(status.statusCode, 503);
  assert.equal(status.json().error.code, "credential_store_unavailable");

  const test = await unavailableServer.inject({
    method: "POST",
    url: `/supplier-credentials/${dvgSupplierId}/test`,
    payload: { testArticle: "CS-A2200247" },
  });
  assert.equal(test.statusCode, 503);
  assert.equal(test.json().error.code, "credential_store_unavailable");
} finally {
  await unavailableServer.close();
}

console.log("Supplier credential route tests passed");
