import {
  LfManualSessionBatchRunner,
  LF_ORIGIN,
  isLfReviewDetailUrl,
  type LfManualBatchSettings,
  type LfManualBatchRow,
  type DvgManualBatchSettings,
} from "@danetti/connectors";
import type { DanettiDatabase } from "@danetti/db";
import { LfProductsRepository } from "../lf-products/lf-products.repository.js";
import {
  DvgArticleChangesRepository,
  type ArticleChangesSource,
  type ArticleReviewRow,
} from "./dvg-article-changes.repository.js";
import type { ArticleChangeAdapter, ReviewRunnerFactory } from "./dvg-article-changes.service.js";

export const lfArticleChangeAdapter: ArticleChangeAdapter = {
  supplier: "lf",
  originalUrl: (row) =>
    isLfReviewDetailUrl(row.dvgDetailUrl) ? row.dvgDetailUrl : `${LF_ORIGIN}/en/search`,
  validUrl: isLfReviewDetailUrl,
  priceBasis: "lf_net_unit_price_lowest_quantity",
};

export const lfReviewSettings = (settings: DvgManualBatchSettings): LfManualBatchSettings => ({
  speedMode: settings.speedMode,
  markupPercent: settings.markupPercent,
  vatPercent: settings.vatPercent,
  eurHufRate: settings.eurHufRate,
  wooPricesIncludeVat: settings.wooPricesIncludeVat,
  limit: settings.limit,
  offset: 0,
  onlyMappedLf: true,
  rerunPreviousNonOkOnly: false,
  allowSuggestedLfArticle: false,
  allowSkuPrefixCandidate: false,
  dryRun: true,
  allowSnapshotWrite: false,
  itemTimeoutMs: settings.itemTimeoutMs,
});

export function lfReviewRow(row: LfManualBatchRow): ArticleReviewRow {
  return {
    ...row,
    candidateSource: "saved_mapping",
    status:
      row.status === "ok" && !(row.supplierNetEur !== null && row.supplierNetEur > 0)
        ? "price_missing"
        : ["skipped_not_lf_candidate", "cross_reference_only"].includes(row.status)
          ? "needs_mapping_review"
          : (row.status as ArticleReviewRow["status"]),
    dvgDetailUrl: row.lfFinalUrl ?? `${LF_ORIGIN}/en/search`,
    dvgArticle: row.lfPartNumber,
    dvgProductName: row.lfProductName,
    dvgOriginalCode: null,
    supplierCrossedEur: row.supplierGrossEur,
    priceBasis: "lf_net_unit_price_lowest_quantity",
  };
}

export class LfArticleChangesRepository extends DvgArticleChangesRepository {
  constructor(db: DanettiDatabase) {
    super(db, "lf");
  }
  override async source(): Promise<ArticleChangesSource | null> {
    const source = await new LfProductsRepository(this.db).getLatestLfOperatorRunState();
    if (!source) return null;
    return {
      runId: source.runId,
      completedAt: source.completedAt,
      rows: source.rows.map(lfReviewRow),
      settings: {
        ...source.settings,
        shopMode: "new_shop",
        onlyMappedDvg: true,
        allowSuggestedDvgArticle: false,
        detailFetchTimeoutMs: 20000,
        fallbackNavigationTimeoutMs: 20000,
        recoverAfterConsecutiveTimeouts: 0,
      },
    };
  }
  override async candidates(settings: DvgManualBatchSettings) {
    const repository = new LfProductsRepository(this.db);
    const [candidates, source] = await Promise.all([
      repository.listCandidates(lfReviewSettings(settings)),
      repository.getLatestLfOperatorRunState(),
    ]);
    const urls = new Map(
      source?.rows
        .filter(
          (r) =>
            r.lfFinalUrl &&
            (r.lfPartNumber === r.supplierArticleNumber ||
              r.lfAutocompleteId === `C:${r.supplierArticleNumber}`)
        )
        .map((r) => [r.catalogProductId, r.lfFinalUrl!])
    );
    return candidates.map((candidate) => ({
      ...candidate,
      candidateSource: "saved_mapping" as const,
      reviewOriginalUrl: urls.get(candidate.catalogProductId),
    }));
  }
}

export const lfArticleReviewRunner: ReviewRunnerFactory = (callbacks) => {
  const runner = new LfManualSessionBatchRunner(
    {
      onStatus: (status) => callbacks.onStatus?.(status),
      onRow: (row) => callbacks.onRow?.(lfReviewRow(row)),
      onCurrentItem: (item) =>
        callbacks.onCurrentItem?.(
          item
            ? {
                ...item,
                status: "parsing_detail",
                parsed: { ...item.parsed, crossedPrice: item.parsed.grossPrice },
              }
            : null
        ),
    },
    { reuseAuthenticatedSession: true, closeVisibleBrowserAfterDetach: false }
  );
  return {
    openBrowser: () => runner.openBrowser(),
    waitForManualLogin: (timeout) => runner.waitForManualLogin(timeout),
    runCandidates: (work, settings) =>
      runner.runArticleChangeReview(
        work.map((candidate) => ({ ...candidate, candidateSource: "saved_mapping" })),
        lfReviewSettings(settings)
      ),
    cancel: () => runner.cancel(),
    close: () => runner.close(),
  };
};
