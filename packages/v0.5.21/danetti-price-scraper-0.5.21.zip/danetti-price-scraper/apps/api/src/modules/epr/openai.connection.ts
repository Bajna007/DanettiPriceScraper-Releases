import { createHash, randomBytes, randomUUID } from "node:crypto";
import { createRemoteJWKSet, jwtVerify, type JWTPayload } from "jose";
import { and, eq, gt, inArray } from "drizzle-orm";
import {
  eprAuthAttempts,
  eprInstallations,
  openaiProfiles,
  type DanettiDbClient,
} from "@danetti/db";
import type { SecretStore } from "../../security/secret-store.js";
import { EprError, safeCode } from "./epr.errors.js";

const issuer = "https://auth.openai.com";
const resource = "https://api.openai.com/v1";
export const requiredScopes = [
  "openid",
  "profile",
  "email",
  "offline_access",
  "resource.invoke",
  "chatgpt.tokens.use.direct",
];
const tokenKey = (id: string) => `DanettiPriceScraper:openai-oauth:${id}`;
const attemptKey = (id: string) => `DanettiPriceScraper:openai-auth:${id}`;
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
const random = () => randomBytes(32).toString("base64url");
type Profile = typeof openaiProfiles.$inferSelect;
type AuthSecret = {
  state: string;
  nonce: string;
  verifier: string;
  redirectUri: string;
  clientId: string;
  url: string;
  expectedSubject: string | null;
};
export type OAuthSecret = {
  issuedClientId: string;
  accessToken: string;
  refreshToken: string;
  retainedIdToken?: string;
  accessTokenExpiresAt: number;
  earliestRefreshAt: number;
  grantedScopes: string[];
};
type Discovery = {
  issuer: string;
  authorization_endpoint: string;
  token_endpoint: string;
  jwks_uri: string;
  revocation_endpoint?: string;
};
export interface AiConnectionProvider {
  getStatus(): Promise<Record<string, unknown>>;
  startAuthorization(): Promise<{ id: string; openUrl: string }>;
  disconnect(): Promise<{ remoteRevocationConfirmed: boolean }>;
  getValidAccessToken(): Promise<string>;
}

export class OpenAiChatGptPlanConnection implements AiConnectionProvider {
  private discoveryPromise?: Promise<Discovery>;
  constructor(
    private readonly client: DanettiDbClient,
    private readonly secrets: SecretStore,
    private readonly request: typeof fetch = fetch,
    private readonly verify?: (
      token: string,
      clientId: string,
      nonce: string
    ) => Promise<JWTPayload>,
    private readonly now = () => Date.now()
  ) {}

  private async profile(): Promise<Profile> {
    await this.client.db.insert(openaiProfiles).values({ slot: "active" }).onConflictDoNothing();
    const [profile] = await this.client.db
      .select()
      .from(openaiProfiles)
      .where(eq(openaiProfiles.slot, "active"));
    return profile;
  }
  private async discovery(): Promise<Discovery> {
    this.discoveryPromise ??= (async () => {
      const response = await this.request(`${issuer}/.well-known/openid-configuration`, {
        signal: AbortSignal.timeout(15_000),
      });
      if (!response.ok) throw new EprError("chatgpt_temporarily_unavailable", 503);
      const data = (await response.json()) as Discovery;
      if (data.issuer !== issuer) throw new EprError("chatgpt_discovery_invalid", 503);
      for (const endpoint of [
        data.authorization_endpoint,
        data.token_endpoint,
        data.jwks_uri,
        data.revocation_endpoint,
      ].filter(Boolean)) {
        const url = new URL(endpoint!);
        if (url.origin !== issuer || url.username || url.password)
          throw new EprError("chatgpt_discovery_invalid", 503);
      }
      return data;
    })().catch((error) => {
      this.discoveryPromise = undefined;
      throw error;
    });
    return this.discoveryPromise;
  }
  async getStatus() {
    const p = await this.profile();
    return {
      connected: p.connected,
      emailDisplay: p.maskedEmail,
      planUsageEnabled: p.planUsageEnabled,
      lastErrorCode: p.lastErrorCode,
      lastInferenceAt: p.lastInferenceAt,
      lastRefreshAt: p.lastRefreshAt,
      model: p.model,
    };
  }
  async startAuthorization() {
    return this.client.sql.begin(async (sql) => {
      await sql`select pg_advisory_xact_lock(72164001)`;
      await this.cancelPendingAuthorization();
      return this.startAuthorizationLocked();
    });
  }
  private async cancelPendingAuthorization() {
    const attempts = await this.client.db
      .update(eprAuthAttempts)
      .set({ status: "failed", errorCode: "chatgpt_auth_cancelled" })
      .where(inArray(eprAuthAttempts.status, ["pending", "processing"]))
      .returning();
    for (const attempt of attempts) await this.secrets.delete(attemptKey(attempt.id));
  }
  private async startAuthorizationLocked() {
    if (process.platform !== "win32" && this.secrets.constructor.name === "WindowsSecretStore")
      throw new EprError("credential_store_unavailable", 503);
    const discovery = await this.discovery();
    const profile = await this.profile();
    const saved = await this.loadSecret(profile);
    await this.client.db
      .insert(eprInstallations)
      .values({ name: "local", hostId: `urn:uuid:${randomUUID()}` })
      .onConflictDoNothing();
    const [host] = await this.client.db
      .select()
      .from(eprInstallations)
      .where(eq(eprInstallations.name, "local"));
    const port = Number(process.env.API_PORT ?? 4000);
    const state = random(),
      nonce = random(),
      verifier = randomBytes(64).toString("base64url"),
      id = randomUUID();
    const redirectUri = `http://127.0.0.1:${port}/auth/openai/callback`;
    const clientId = profile.issuedClientId ?? "dynamic_agent_client";
    const url = new URL(discovery.authorization_endpoint);
    url.search = new URLSearchParams({
      client_id: clientId,
      ext_agent_host_id: host.hostId,
      response_type: "code",
      redirect_uri: redirectUri,
      scope: requiredScopes.join(" "),
      resource,
      state,
      nonce,
      code_challenge_method: "S256",
      code_challenge: createHash("sha256").update(verifier).digest("base64url"),
    }).toString();
    if (clientId === "dynamic_agent_client")
      url.searchParams.set("agent_name_hint", "DanettiPriceScraper");
    else if (saved?.retainedIdToken) url.searchParams.set("id_token_hint", saved.retainedIdToken);
    // Hints and the PKCE verifier remain in the secure store; UI only sees the local launch route.
    await this.secrets.put(
      attemptKey(id),
      JSON.stringify({
        state,
        nonce,
        verifier,
        redirectUri,
        clientId,
        url: url.toString(),
        expectedSubject: profile.subject,
      } satisfies AuthSecret)
    );
    try {
      await this.client.db
        .insert(eprAuthAttempts)
        .values({ id, stateHash: hash(state), expiresAt: new Date(this.now() + 600_000) });
    } catch (error) {
      await this.secrets.delete(attemptKey(id));
      throw error;
    }
    return { id, openUrl: `http://127.0.0.1:${port}/epr/ai/auth/open/${id}` };
  }
  async authorizationUrl(id: string): Promise<string> {
    const [attempt] = await this.client.db
      .select()
      .from(eprAuthAttempts)
      .where(
        and(
          eq(eprAuthAttempts.id, id),
          eq(eprAuthAttempts.status, "pending"),
          gt(eprAuthAttempts.expiresAt, new Date(this.now()))
        )
      );
    if (!attempt) throw new EprError("chatgpt_auth_callback_expired");
    const secret = await this.secrets.get(attemptKey(id));
    if (!secret) throw new EprError("chatgpt_auth_callback_expired");
    return (JSON.parse(secret) as AuthSecret).url;
  }
  async attemptStatus(id: string) {
    const [attempt] = await this.client.db
      .select()
      .from(eprAuthAttempts)
      .where(eq(eprAuthAttempts.id, id));
    if (!attempt) throw new EprError("chatgpt_auth_attempt_not_found", 404);
    if (
      ["pending", "processing"].includes(attempt.status) &&
      attempt.expiresAt.getTime() <= this.now()
    ) {
      await this.client.db
        .update(eprAuthAttempts)
        .set({ status: "failed", errorCode: "chatgpt_auth_callback_expired" })
        .where(
          and(
            eq(eprAuthAttempts.id, id),
            inArray(eprAuthAttempts.status, ["pending", "processing"])
          )
        );
      await this.secrets.delete(attemptKey(id));
      return { id, status: "failed", errorCode: "chatgpt_auth_callback_expired" };
    }
    return { id, status: attempt.status, errorCode: attempt.errorCode };
  }
  async callback(query: Record<string, string | undefined>): Promise<void> {
    await this.client.sql.begin(async (sql) => {
      await sql`select pg_advisory_xact_lock(72164001)`;
      await this.callbackLocked(query);
    });
  }
  private async callbackLocked(query: Record<string, string | undefined>): Promise<void> {
    if (!query.state || query.state.length > 256) throw new EprError("chatgpt_auth_state_invalid");
    const [attempt] = await this.client.db
      .update(eprAuthAttempts)
      .set({ status: "processing" })
      .where(
        and(
          eq(eprAuthAttempts.stateHash, hash(query.state)),
          eq(eprAuthAttempts.status, "pending"),
          gt(eprAuthAttempts.expiresAt, new Date(this.now()))
        )
      )
      .returning();
    if (!attempt) throw new EprError("chatgpt_auth_state_invalid");
    try {
      const raw = await this.secrets.get(attemptKey(attempt.id));
      await this.secrets.delete(attemptKey(attempt.id));
      if (!raw) throw new EprError("chatgpt_auth_callback_expired");
      const txn = JSON.parse(raw) as AuthSecret;
      if (txn.state !== query.state) throw new EprError("chatgpt_auth_state_invalid");
      if (query.error)
        throw new EprError(
          query.error === "access_denied"
            ? "chatgpt_auth_cancelled"
            : "chatgpt_oauth_client_not_eligible"
        );
      if (!query.code) throw new EprError("chatgpt_auth_code_missing");
      const issued = txn.clientId === "dynamic_agent_client" ? query.client_id : txn.clientId;
      if (
        !issued ||
        issued === "dynamic_agent_client" ||
        !/^oaiapp_[A-Za-z0-9_-]+$/.test(issued) ||
        (txn.clientId !== "dynamic_agent_client" && query.client_id && query.client_id !== issued)
      )
        throw new EprError("chatgpt_auth_client_invalid");
      const p = await this.profile();
      // Save registration before exchange so an expired code does not cause a new registration.
      await this.client.db
        .update(openaiProfiles)
        .set({ issuedClientId: issued })
        .where(eq(openaiProfiles.id, p.id));
      const data = await this.tokenRequest({
        grant_type: "authorization_code",
        client_id: issued,
        code: query.code,
        code_verifier: txn.verifier,
        redirect_uri: txn.redirectUri,
        resource,
      });
      if (typeof data.id_token !== "string") throw new EprError("chatgpt_id_token_invalid");
      let identity: JWTPayload;
      try {
        if (this.verify) identity = await this.verify(data.id_token, issued, txn.nonce);
        else {
          const discovery = await this.discovery();
          const result = await jwtVerify(
            data.id_token,
            createRemoteJWKSet(new URL(discovery.jwks_uri), { timeoutDuration: 15_000 }),
            {
              issuer: discovery.issuer,
              audience: issued,
              requiredClaims: ["sub", "exp", "iat"],
              clockTolerance: 5,
            }
          );
          identity = result.payload;
        }
        if (
          identity.nonce !== txn.nonce ||
          !identity.sub ||
          (txn.expectedSubject && identity.sub !== txn.expectedSubject)
        )
          throw new Error();
      } catch {
        throw new EprError("chatgpt_id_token_invalid");
      }
      const secret = this.parseTokens(data, issued);
      const email = typeof identity.email === "string" ? identity.email : "";
      await this.secrets.put(tokenKey(p.id), JSON.stringify(secret));
      await this.client.db
        .update(openaiProfiles)
        .set({
          subject: identity.sub,
          maskedEmail: email
            ? `${email[0]}***${email.includes("@") ? email.slice(email.indexOf("@")) : ""}`
            : null,
          connected: true,
          planUsageEnabled: true,
          lastErrorCode: null,
        })
        .where(eq(openaiProfiles.id, p.id));
      await this.client.db
        .update(eprAuthAttempts)
        .set({ status: "completed" })
        .where(eq(eprAuthAttempts.id, attempt.id));
    } catch (error) {
      await this.client.db
        .update(eprAuthAttempts)
        .set({ status: "failed", errorCode: safeCode(error, "chatgpt_temporarily_unavailable") })
        .where(eq(eprAuthAttempts.id, attempt.id));
      throw error instanceof EprError
        ? error
        : new EprError("chatgpt_temporarily_unavailable", 503);
    }
  }
  private async tokenRequest(params: Record<string, string>): Promise<Record<string, unknown>> {
    const discovery = await this.discovery();
    let response: Response;
    try {
      response = await this.request(discovery.token_endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams(params),
        signal: AbortSignal.timeout(20_000),
      });
    } catch {
      throw new EprError("chatgpt_temporarily_unavailable", 503);
    }
    const data = (await response.json().catch(() => ({}))) as Record<string, unknown>;
    if (!response.ok) {
      if (data.error === "invalid_grant")
        throw new EprError("chatgpt_reauthorization_required", 401);
      if (data.error === "invalid_client" || data.error === "unauthorized_client")
        throw new EprError("chatgpt_oauth_client_not_eligible", 403);
      throw new EprError("chatgpt_temporarily_unavailable", 503);
    }
    return data;
  }
  private parseTokens(
    data: Record<string, unknown>,
    clientId: string,
    previous?: OAuthSecret
  ): OAuthSecret {
    const scopes =
      typeof data.scope === "string" ? data.scope.split(/\s+/) : (previous?.grantedScopes ?? []);
    if (!requiredScopes.every((scope) => scopes.includes(scope)))
      throw new EprError("chatgpt_plan_permission_missing", 403);
    if (
      typeof data.access_token !== "string" ||
      !data.access_token ||
      typeof data.refresh_token !== "string" ||
      !data.refresh_token ||
      data.token_type !== "Bearer" ||
      typeof data.expires_in !== "number" ||
      data.expires_in <= 0
    )
      throw new EprError("chatgpt_token_response_invalid", 502);
    const earliest = data.earliest_refresh_at;
    const earliestRefreshAt =
      typeof earliest === "number"
        ? earliest * 1000
        : typeof earliest === "string"
          ? Date.parse(earliest)
          : 0;
    if (!Number.isFinite(earliestRefreshAt))
      throw new EprError("chatgpt_token_response_invalid", 502);
    return {
      issuedClientId: clientId,
      accessToken: data.access_token,
      refreshToken: data.refresh_token,
      retainedIdToken:
        typeof data.id_token === "string" ? data.id_token : previous?.retainedIdToken,
      grantedScopes: scopes,
      accessTokenExpiresAt: this.now() + data.expires_in * 1000,
      earliestRefreshAt,
    };
  }
  private async loadSecret(p: Profile): Promise<OAuthSecret | null> {
    const value = await this.secrets.get(tokenKey(p.id));
    return value ? (JSON.parse(value) as OAuthSecret) : null;
  }
  async getValidAccessToken(): Promise<string> {
    // PostgreSQL advisory transaction lock serializes rotation across API processes.
    return this.client.sql.begin(async (sql) => {
      await sql`select pg_advisory_xact_lock(72164001)`;
      const p = await this.profile(),
        secret = await this.loadSecret(p);
      if (!p.connected || !secret) throw new EprError("chatgpt_reauthorization_required", 401);
      if (secret.accessTokenExpiresAt > this.now() + 60_000) return secret.accessToken;
      if (secret.earliestRefreshAt > this.now()) {
        if (secret.accessTokenExpiresAt > this.now()) return secret.accessToken;
        throw new EprError("chatgpt_refresh_required", 503);
      }
      try {
        const data = await this.tokenRequest({
          grant_type: "refresh_token",
          client_id: secret.issuedClientId,
          refresh_token: secret.refreshToken,
          resource,
        });
        const replacement = this.parseTokens(data, secret.issuedClientId, secret);
        await this.secrets.put(tokenKey(p.id), JSON.stringify(replacement));
        await this.client.db
          .update(openaiProfiles)
          .set({ lastRefreshAt: new Date(this.now()), lastErrorCode: null })
          .where(eq(openaiProfiles.id, p.id));
        return replacement.accessToken;
      } catch (error) {
        if (error instanceof EprError && error.code === "chatgpt_reauthorization_required") {
          await this.secrets.delete(tokenKey(p.id));
          await this.client.db
            .update(openaiProfiles)
            .set({ connected: false, planUsageEnabled: false, lastErrorCode: error.code })
            .where(eq(openaiProfiles.id, p.id));
        }
        throw error;
      }
    });
  }
  async disconnect(): Promise<{ remoteRevocationConfirmed: boolean }> {
    return this.client.sql.begin(async (sql) => {
      await sql`select pg_advisory_xact_lock(72164001)`;
      await this.cancelPendingAuthorization();
      const p = await this.profile(),
        secret = await this.loadSecret(p);
      let remoteRevocationConfirmed = false;
      if (secret) {
        try {
          const discovery = await this.discovery();
          if (discovery.revocation_endpoint) {
            const response = await this.request(discovery.revocation_endpoint, {
              method: "POST",
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              body: new URLSearchParams({
                token: secret.refreshToken,
                token_type_hint: "refresh_token",
                client_id: secret.issuedClientId,
              }),
              signal: AbortSignal.timeout(15_000),
            });
            remoteRevocationConfirmed = response.status === 200;
          }
        } catch {
          /* Local disconnect must complete even when the provider is unavailable. */
        }
      }
      await this.secrets.delete(tokenKey(p.id));
      await this.client.db
        .update(openaiProfiles)
        .set({ connected: false, planUsageEnabled: false, lastErrorCode: null })
        .where(eq(openaiProfiles.id, p.id));
      return { remoteRevocationConfirmed };
    });
  }
  async models(): Promise<{ slug: string; display_name: string }[]> {
    const token = await this.getValidAccessToken();
    const response = await this.request(`${resource}/models`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(20_000),
    });
    if (!response.ok) throw new EprError("chatgpt_temporarily_unavailable", 503);
    const data = (await response.json()) as {
      models?: { slug: string; display_name: string; visibility: string }[];
    };
    return (data.models ?? [])
      .filter(
        (m) =>
          m.visibility === "list" &&
          typeof m.slug === "string" &&
          typeof m.display_name === "string"
      )
      .map(({ slug, display_name }) => ({ slug, display_name }));
  }
  async selectModel(slug: string) {
    if (!(await this.models()).some((m) => m.slug === slug))
      throw new EprError("chatgpt_model_unavailable");
    const p = await this.profile();
    await this.client.db
      .update(openaiProfiles)
      .set({ model: slug })
      .where(eq(openaiProfiles.id, p.id));
  }
  async infer(
    input: unknown[],
    instructions: string,
    onModel?: (model: string) => void
  ): Promise<string> {
    const p = await this.profile();
    if (!p.model) throw new EprError("chatgpt_model_selection_required", 409);
    onModel?.(p.model);
    const token = await this.getValidAccessToken();
    let response: Response;
    try {
      response = await this.request(`${resource}/responses`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: p.model, input, instructions, store: false, stream: true }),
        signal: AbortSignal.timeout(120_000),
      });
    } catch {
      throw new EprError("chatgpt_temporarily_unavailable", 503);
    }
    if (!response.ok || !response.body) throw new EprError("chatgpt_temporarily_unavailable", 503);
    let buffer = "",
      output = "",
      completed = false;
    const decoder = new TextDecoder();
    for await (const chunk of response.body as unknown as AsyncIterable<Uint8Array>) {
      buffer += decoder.decode(chunk, { stream: true }).replace(/\r\n/g, "\n");
      if (buffer.length > 1_000_000 || output.length > 500_000)
        throw new EprError("chatgpt_response_too_large", 502);
      let boundary: number;
      while ((boundary = buffer.indexOf("\n\n")) >= 0) {
        const frame = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);
        const payload = frame
          .split("\n")
          .filter((line) => line.startsWith("data:"))
          .map((line) => line.slice(5).trim())
          .join("\n");
        if (!payload || payload === "[DONE]") continue;
        const event = JSON.parse(payload) as { type: string; delta?: string };
        if (event.type === "response.output_text.delta") output += event.delta ?? "";
        if (event.type === "response.completed") completed = true;
        if (["response.failed", "response.incomplete", "error"].includes(event.type))
          throw new EprError("chatgpt_inference_failed", 502);
      }
    }
    if (!completed) throw new EprError("chatgpt_stream_interrupted", 502);
    await this.client.db
      .update(openaiProfiles)
      .set({ lastInferenceAt: new Date(this.now()) })
      .where(eq(openaiProfiles.id, p.id));
    return output;
  }
}
