import assert from "node:assert/strict";
import { buildLfRunMessage, readLfExactAutoPairCandidates } from "./lf-products.repository.js";
import type { LfManualBatchRow } from "@danetti/connectors";

const enabledSources = { allowSuggestedLfArticle: true, allowSkuPrefixCandidate: true };

assert.deepEqual(readCandidateArticles("5067364_UN303", "5067364"), [
  { article: "5067364", source: "suggested_supplier_article" },
]);

assert.deepEqual(readCandidateArticles("421944040781_1186848_SAE046", "421944040781"), [
  { article: "1186848", source: "sku_segment_candidate" },
]);

assert.deepEqual(readCandidateArticles("Cikksz\u00e1m: 1017002_UN691", "Cikksz\u00e1m: 1017002"), [
  { article: "1017002", source: "suggested_supplier_article" },
]);
assert.deepEqual(readCandidateArticles("Cikksz\u00e1m: 1394009_UN715", null), [
  { article: "1394009", source: "sku_prefix_candidate" },
]);

assert.deepEqual(
  readCandidateArticles("Cikksz\u00e1m:5513227981_5062941_DEL44", "Cikksz\u00e1m:5513227981"),
  [
    { article: "5513227981", source: "suggested_supplier_article" },
    { article: "5062941", source: "sku_segment_candidate" },
  ]
);

assert.deepEqual(readCandidateArticles("421944065151_SAE125", "421944065151"), []);
assert.deepEqual(
  readCandidateArticles("421944040781_1186848_SAE046", "421944040781", {
    allowSuggestedLfArticle: true,
    allowSkuPrefixCandidate: false,
  }),
  []
);

const lfRow = {
  status: "ok",
  catalogProductId: "product-1",
  wooSku: "5067364_UN303",
  wooName: "Teszt termek",
  supplierId: "supplier-1",
  supplierMappingId: "mapping-1",
  supplierArticleNumber: "5067364",
  candidateSource: "saved_mapping",
  lfAutocompleteId: "C:5067364",
  lfAutocompleteValue: "5067364 RUBINETTO VALVOLA GRUPPO",
  lfManufacturerCode: null,
  lfManufacturerName: null,
  lfFinalUrl: "https://b2bnet.lfspareparts724.com/en/product/test/RisultatoRicercaRapida",
  lfProductName: "RUBINETTO VALVOLA GRUPPO",
  lfProductId: "5067364",
  lfPartNumber: "5067364",
  supplierNetEur: 30.31,
  supplierGrossEur: 60.62,
  currency: "EUR",
  unit: "N",
  eurHufRate: 400,
  markupPercent: 0,
  vatPercent: 27,
  matchConfidence: "trusted_lf_item",
  warnings: [],
  wooPriceHuf: 20000,
  wooPriceSource: "currentPrice",
  wooGrossHuf: 20000,
  wooNetHuf: 15748.03,
  supplierNetHuf: 12124,
  targetNetHuf: 12124,
  targetGrossHuf: 15397.48,
  targetGrossHufRounded: 15400,
  actualProfitNetHuf: 3624.03,
  actualProfitPercentOnCost: 29.89,
  actualGrossDeltaToTargetHuf: 4600,
} satisfies LfManualBatchRow;

assert.equal(buildLfRunMessage(lfRow), "LF ár beolvasva.");
assert.equal(
  buildLfRunMessage({
    ...lfRow,
    status: "article_changed",
    supplierArticleNumber: "5067364",
    lfPartNumber: "5067365",
    warnings: ["lf_supplier_article_changed"],
  }),
  "LF cikkszám megváltozott: új cikkszám 5067365; mapping ellenőrzés kell."
);
assert.equal(
  buildLfRunMessage({
    ...lfRow,
    status: "price_missing",
    supplierNetEur: null,
    warnings: ["lf_item_no_longer_in_production", "lf_net_unit_price_missing"],
  }),
  "LF szerint a termék már nem gyártott."
);
assert.equal(
  buildLfRunMessage({
    ...lfRow,
    status: "article_not_found",
    supplierNetEur: null,
    lfProductId: null,
    lfPartNumber: null,
    warnings: ["lf_empty_detail_or_search_redirect", "lf_article_not_found"],
  }),
  "LF nem találta a cikkszámot, vagy üres/keresési oldalra irányított."
);
assert.equal(
  buildLfRunMessage({
    ...lfRow,
    status: "item_not_available",
    supplierNetEur: null,
    warnings: ["lf_item_not_available", "lf_net_unit_price_missing"],
  }),
  "LF szerint a cikk jelenleg nem rendelhető / item not available."
);
assert.equal(
  buildLfRunMessage({
    ...lfRow,
    status: "cross_reference_only",
    lfAutocompleteId: "A:4SC000190:004591",
    lfManufacturerName: "DE VECCHI GIUSEPPE",
    warnings: ["lf_supplier_cross_reference_not_lf_own_article"],
  }),
  "LF kereszthivatkozás: DE VECCHI GIUSEPPE · A:4SC000190:004591. Fő forrás: DVG-jelölt; LF mapping nem készült."
);
assert.equal(
  buildLfRunMessage({
    ...lfRow,
    status: "cross_reference_only",
    lfAutocompleteId: "A:00311864:001234",
    lfManufacturerName: "BOSCH - SIEMENS - BALAY",
    warnings: ["lf_supplier_cross_reference_not_lf_own_article"],
  }),
  "LF kereszthivatkozás: BOSCH - SIEMENS - BALAY · A:00311864:001234. Fő forrás: külső forrás-jelölt; LF mapping nem készült."
);

assert.deepEqual(
  readLfExactAutoPairCandidates(
    { sku: "8W17201__1755603_9999999", suggestedSupplierArticle: null },
    { limit: 10, offset: 0, allowSuggestedLfArticle: false, allowSkuPrefixCandidate: true }
  ).map((row) => row.supplierArticleNumber),
  ["1755603"]
);
console.log("LF products repository tests passed");

function readCandidateArticles(
  sku: string,
  suggestedSupplierArticle: string | null,
  input = enabledSources
): Array<{ article: string; source: string }> {
  return readLfExactAutoPairCandidates(
    { sku, suggestedSupplierArticle },
    { ...input, limit: 10, offset: 0 }
  ).map((candidate) => ({ article: candidate.supplierArticleNumber, source: candidate.source }));
}
