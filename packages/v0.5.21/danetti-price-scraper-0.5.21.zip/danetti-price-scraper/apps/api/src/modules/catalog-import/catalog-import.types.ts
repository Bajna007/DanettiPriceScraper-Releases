import type {
  CsvColumnMappingAnalysis,
  CsvColumnMappingOverride,
  NormalizedWooCsvRow,
  NewCatalogProduct,
  ParsedWooSku,
} from "@danetti/db";

export type CatalogImportMode = "preview_only" | "add_only" | "update_existing";

export type CatalogImportRowStatus =
  | "inserted"
  | "updated"
  | "skipped_existing"
  | "skipped_duplicate"
  | "skipped_missing_sku"
  | "invalid"
  | "failed";

export interface UploadedCatalogCsv {
  filename: string | null;
  mimetype: string | null;
  buffer: Buffer;
  fileSha256: string;
  fileSizeBytes: number;
}

export interface ParsedCatalogCsvRow {
  rowNumber: number;
  rawRow: Record<string, unknown>;
}

export interface ParsedCatalogCsv {
  rows: ParsedCatalogCsvRow[];
  headers: string[];
  columnMapping: CsvColumnMappingAnalysis;
}

export interface CatalogImportSummary {
  totalRows: number;
  insertedCount: number;
  updatedCount: number;
  deletedCount: number;
  skippedExistingCount: number;
  skippedDuplicateCount: number;
  skippedMissingSkuCount: number;
  invalidCount: number;
  failedCount: number;
}

export interface ExistingCatalogProductMatch {
  id: string;
  sku: string;
}

export interface ClassifiedCatalogImportRow {
  rowNumber: number;
  status: CatalogImportRowStatus;
  wouldInsert: boolean;
  sku: string | null;
  normalized: NormalizedWooCsvRow;
  parsedSku: ParsedWooSku | null;
  suggestedSupplierArticle: string | null;
  internalSkuSuffix: string | null;
  productInput: NewCatalogProduct | null;
  catalogProductId: string | null;
  errorCode: string | null;
  errorMessage: string | null;
  warningCode: string | null;
  warningMessage: string | null;
  warnings: CatalogImportValidationIssue[];
  rawRow: Record<string, unknown> | null;
}

export interface CatalogImportResult extends CatalogImportSummary {
  importRunId: string | null;
  mode: CatalogImportMode;
  sampleRows: CatalogImportSampleRow[];
  validation: CatalogImportValidationReport;
}

export interface CatalogImportValidationReport {
  requiredColumns: string[];
  missingRequiredColumns: string[];
  headers: string[];
  columnMapping: CsvColumnMappingAnalysis;
  recognizedColumns: string[];
  unknownColumns: string[];
  unknownColumnCount: number;
  ambiguousColumns: CsvColumnMappingAnalysis["ambiguousColumns"];
  warnings: CatalogImportValidationIssue[];
  errorRows: CatalogImportValidationIssue[];
}

export interface CatalogImportValidationIssue {
  rowNumber: number | null;
  sku: string | null;
  name: string | null;
  sourceProductId: string | null;
  status: CatalogImportRowStatus | null;
  code: string;
  message: string;
}

export interface CatalogImportSampleRow {
  rowNumber: number;
  status: CatalogImportRowStatus;
  wouldInsert: boolean;
  sku: string | null;
  name: string | null;
  barcodeOrGlobalId: string | null;
  suggestedSupplierArticle: string | null;
  internalSkuSuffix: string | null;
  regularPrice: string | null;
  salePrice: string | null;
  catalogProductId: string | null;
  errorCode: string | null;
  errorMessage: string | null;
  warningCode: string | null;
  warningMessage: string | null;
}

export type CatalogImportColumnMappingInput = CsvColumnMappingOverride;

export class CatalogImportValidationError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus = 400
  ) {
    super(message);
    this.name = "CatalogImportValidationError";
  }
}

export class CatalogImportDatabaseError extends Error {
  constructor(message = "Database unavailable") {
    super(message);
    this.name = "CatalogImportDatabaseError";
  }
}
