import {
  supplierMappings,
  supplierPriceSnapshots,
  type DanettiDatabase,
  type NewSupplierPriceSnapshot,
  type SupplierMapping,
  type SupplierPriceSnapshot,
} from "@danetti/db";
import { and, desc, eq, type SQL } from "drizzle-orm";

export interface SupplierSnapshotListFilters {
  supplierId?: string;
  supplierMappingId?: string;
  catalogProductId?: string;
  supplierArticleNumber?: string;
  limit: number;
  offset: number;
}

export interface SupplierSnapshotsRepositoryLike {
  getMappingById(id: string): Promise<SupplierMapping | null>;
  insertSnapshot(input: NewSupplierPriceSnapshot): Promise<SupplierPriceSnapshot>;
  listSnapshots(input: SupplierSnapshotListFilters): Promise<SupplierPriceSnapshot[]>;
  getSnapshotById(id: string): Promise<SupplierPriceSnapshot | null>;
}

export class SupplierSnapshotsRepository implements SupplierSnapshotsRepositoryLike {
  constructor(private readonly db: DanettiDatabase) {}

  async getMappingById(id: string): Promise<SupplierMapping | null> {
    const [mapping] = await this.db
      .select()
      .from(supplierMappings)
      .where(eq(supplierMappings.id, id))
      .limit(1);
    return mapping ?? null;
  }

  async insertSnapshot(input: NewSupplierPriceSnapshot): Promise<SupplierPriceSnapshot> {
    const [snapshot] = await this.db.insert(supplierPriceSnapshots).values(input).returning();
    if (!snapshot) throw new Error("Failed to insert supplier price snapshot");
    return snapshot;
  }

  async listSnapshots(input: SupplierSnapshotListFilters): Promise<SupplierPriceSnapshot[]> {
    const conditions: SQL[] = [];
    if (input.supplierId) conditions.push(eq(supplierPriceSnapshots.supplierId, input.supplierId));
    if (input.supplierMappingId) {
      conditions.push(eq(supplierPriceSnapshots.supplierMappingId, input.supplierMappingId));
    }
    if (input.catalogProductId) {
      conditions.push(eq(supplierPriceSnapshots.catalogProductId, input.catalogProductId));
    }
    if (input.supplierArticleNumber) {
      conditions.push(
        eq(supplierPriceSnapshots.supplierArticleNumber, input.supplierArticleNumber)
      );
    }

    return this.db
      .select()
      .from(supplierPriceSnapshots)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(supplierPriceSnapshots.observedAt), desc(supplierPriceSnapshots.createdAt))
      .limit(input.limit)
      .offset(input.offset);
  }

  async getSnapshotById(id: string): Promise<SupplierPriceSnapshot | null> {
    const [snapshot] = await this.db
      .select()
      .from(supplierPriceSnapshots)
      .where(eq(supplierPriceSnapshots.id, id))
      .limit(1);
    return snapshot ?? null;
  }
}
