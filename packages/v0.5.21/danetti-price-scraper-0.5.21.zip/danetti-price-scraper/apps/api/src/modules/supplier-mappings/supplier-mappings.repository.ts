import {
  catalogProducts,
  supplierMappings,
  suppliers,
  type CatalogProduct,
  type DanettiDatabase,
  type NewSupplierMapping,
  type Supplier,
  type SupplierMapping,
} from "@danetti/db";
import { and, desc, eq, type SQL } from "drizzle-orm";
import { getOrCreateDvgSupplier } from "../suppliers/dvg-supplier.js";
import { getOrCreateLfSupplier } from "../suppliers/lf-supplier.js";
import {
  buildDvgAutoPairDirectUrl,
  readDvgAutoPairCandidate,
} from "./supplier-mappings.service.js";
import type {
  DvgAutoPairResult,
  DvgAutoPairRow,
  SupplierMappingListFilters,
} from "./supplier-mappings.types.js";

export interface SupplierMappingListItem extends SupplierMapping {
  catalogProductSku: string;
  catalogProductName: string;
  supplierCode: string;
  supplierName: string;
}

export class SupplierMappingsRepository {
  constructor(private readonly db: DanettiDatabase) {}

  async list(input: SupplierMappingListFilters): Promise<SupplierMappingListItem[]> {
    const conditions: SQL[] = [];
    if (input.catalogProductId)
      conditions.push(eq(supplierMappings.catalogProductId, input.catalogProductId));
    if (input.supplierId) conditions.push(eq(supplierMappings.supplierId, input.supplierId));
    if (input.enabled !== undefined) conditions.push(eq(supplierMappings.enabled, input.enabled));

    const rows = await this.db
      .select({
        mapping: supplierMappings,
        catalogProductSku: catalogProducts.sku,
        catalogProductName: catalogProducts.name,
        supplierCode: suppliers.code,
        supplierName: suppliers.name,
      })
      .from(supplierMappings)
      .innerJoin(catalogProducts, eq(supplierMappings.catalogProductId, catalogProducts.id))
      .innerJoin(suppliers, eq(supplierMappings.supplierId, suppliers.id))
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(supplierMappings.createdAt))
      .limit(input.limit)
      .offset(input.offset);

    return rows.map((row) => ({
      ...row.mapping,
      catalogProductSku: row.catalogProductSku,
      catalogProductName: row.catalogProductName,
      supplierCode: row.supplierCode,
      supplierName: row.supplierName,
    }));
  }

  async getById(id: string): Promise<SupplierMappingListItem | null> {
    const [row] = await this.db
      .select({
        mapping: supplierMappings,
        catalogProductSku: catalogProducts.sku,
        catalogProductName: catalogProducts.name,
        supplierCode: suppliers.code,
        supplierName: suppliers.name,
      })
      .from(supplierMappings)
      .innerJoin(catalogProducts, eq(supplierMappings.catalogProductId, catalogProducts.id))
      .innerJoin(suppliers, eq(supplierMappings.supplierId, suppliers.id))
      .where(eq(supplierMappings.id, id))
      .limit(1);

    if (row === undefined) return null;
    return {
      ...row.mapping,
      catalogProductSku: row.catalogProductSku,
      catalogProductName: row.catalogProductName,
      supplierCode: row.supplierCode,
      supplierName: row.supplierName,
    };
  }

  async getCatalogProductById(id: string): Promise<CatalogProduct | null> {
    const [product] = await this.db
      .select()
      .from(catalogProducts)
      .where(eq(catalogProducts.id, id))
      .limit(1);
    return product ?? null;
  }

  async getSupplierById(id: string): Promise<Supplier | null> {
    const [supplier] = await this.db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1);
    return supplier ?? null;
  }

  async listActiveSuppliers(): Promise<Array<Pick<Supplier, "id" | "code" | "name">>> {
    await Promise.all([getOrCreateDvgSupplier(this.db), getOrCreateLfSupplier(this.db)]);

    return this.db
      .select({ id: suppliers.id, code: suppliers.code, name: suppliers.name })
      .from(suppliers)
      .where(eq(suppliers.enabled, true))
      .orderBy(suppliers.name);
  }

  async autoPairDvgProducts(observedAt = new Date()): Promise<DvgAutoPairResult> {
    const supplier = await getOrCreateDvgSupplier(this.db);
    const products = await this.db
      .select({
        id: catalogProducts.id,
        sku: catalogProducts.sku,
        name: catalogProducts.name,
        suggestedSupplierArticle: catalogProducts.suggestedSupplierArticle,
      })
      .from(catalogProducts)
      .orderBy(catalogProducts.sku);
    const mappings = await this.db
      .select()
      .from(supplierMappings)
      .where(eq(supplierMappings.supplierId, supplier.id))
      .orderBy(desc(supplierMappings.isPrimary), desc(supplierMappings.enabled));
    const mappingsByProductId = groupMappingsByCatalogProductId(mappings);
    const rows: DvgAutoPairRow[] = [];
    let createdCount = 0;
    let updatedCount = 0;
    let verifiedCount = 0;
    let conflictCount = 0;
    let skippedNotDvgCandidateCount = 0;

    for (const product of products) {
      const candidate = readDvgAutoPairCandidate(product);
      if (candidate === null) {
        skippedNotDvgCandidateCount += 1;
        rows.push(autoPairRow(product, null, null, "skipped_not_dvg_candidate", null, null));
        continue;
      }

      const article = candidate.supplierArticleNumber;
      const directUrl = buildDvgAutoPairDirectUrl(article);
      const existingMappings = mappingsByProductId.get(product.id) ?? [];
      const activePrimary = existingMappings.find(
        (mapping) => mapping.enabled && mapping.isPrimary
      );
      const sameArticleMapping = findSameArticleMapping(existingMappings, article);

      if (activePrimary && !sameArticle(activePrimary, article)) {
        conflictCount += 1;
        rows.push(
          autoPairRow(
            product,
            article,
            directUrl,
            "conflict",
            candidate.source,
            activePrimary.supplierArticleNumber
          )
        );
        continue;
      }

      if (sameArticleMapping) {
        const update = buildDvgAutoPairMappingUpdate(
          sameArticleMapping,
          article,
          directUrl,
          observedAt
        );
        if (Object.keys(update).length > 0) {
          await this.update(sameArticleMapping.id, update);
          updatedCount += 1;
          rows.push(autoPairRow(product, article, directUrl, "updated", candidate.source, null));
        } else {
          verifiedCount += 1;
          rows.push(autoPairRow(product, article, directUrl, "verified", candidate.source, null));
        }
        continue;
      }

      await this.create({
        catalogProductId: product.id,
        supplierId: supplier.id,
        supplierArticleNumber: article,
        lookupStrategy: "direct_url",
        directUrl,
        priority: 10,
        enabled: true,
        isPrimary: true,
        notes: "DVG auto-pair: catalog article matched digit-letter-number DVG pattern.",
        createdBy: "dvg_auto_pair",
        updatedBy: "dvg_auto_pair",
      });
      createdCount += 1;
      rows.push(autoPairRow(product, article, directUrl, "created", candidate.source, null));
    }

    return {
      supplierId: supplier.id,
      totalProducts: products.length,
      dvgCandidateCount: products.length - skippedNotDvgCandidateCount,
      createdCount,
      updatedCount,
      verifiedCount,
      conflictCount,
      skippedNotDvgCandidateCount,
      rows,
    };
  }

  async findActiveDuplicate(input: {
    catalogProductId: string;
    supplierId: string;
    supplierArticleNumber: string;
    excludeId?: string;
  }): Promise<SupplierMapping | null> {
    const [mapping] = await this.db
      .select()
      .from(supplierMappings)
      .where(
        and(
          eq(supplierMappings.catalogProductId, input.catalogProductId),
          eq(supplierMappings.supplierId, input.supplierId),
          eq(supplierMappings.supplierArticleNumber, input.supplierArticleNumber),
          eq(supplierMappings.enabled, true)
        )
      )
      .limit(1);

    if (mapping === undefined) return null;
    if (input.excludeId && mapping.id === input.excludeId) return null;
    return mapping;
  }

  async findActivePrimary(input: {
    catalogProductId: string;
    supplierId: string;
    excludeId?: string;
  }): Promise<SupplierMapping | null> {
    const [mapping] = await this.db
      .select()
      .from(supplierMappings)
      .where(
        and(
          eq(supplierMappings.catalogProductId, input.catalogProductId),
          eq(supplierMappings.supplierId, input.supplierId),
          eq(supplierMappings.enabled, true),
          eq(supplierMappings.isPrimary, true)
        )
      )
      .limit(1);

    if (mapping === undefined) return null;
    if (input.excludeId && mapping.id === input.excludeId) return null;
    return mapping;
  }

  async create(input: NewSupplierMapping): Promise<SupplierMapping> {
    const [mapping] = await this.db.insert(supplierMappings).values(input).returning();
    if (mapping === undefined) throw new Error("Failed to create supplier mapping");
    return mapping;
  }

  async update(id: string, input: Partial<NewSupplierMapping>): Promise<SupplierMapping | null> {
    const [mapping] = await this.db
      .update(supplierMappings)
      .set(input)
      .where(eq(supplierMappings.id, id))
      .returning();
    return mapping ?? null;
  }
}

function groupMappingsByCatalogProductId(
  mappings: SupplierMapping[]
): Map<string, SupplierMapping[]> {
  const grouped = new Map<string, SupplierMapping[]>();
  for (const mapping of mappings) {
    const current = grouped.get(mapping.catalogProductId) ?? [];
    current.push(mapping);
    grouped.set(mapping.catalogProductId, current);
  }
  return grouped;
}

function findSameArticleMapping(
  mappings: SupplierMapping[],
  supplierArticleNumber: string
): SupplierMapping | null {
  return mappings.find((mapping) => sameArticle(mapping, supplierArticleNumber)) ?? null;
}

function sameArticle(mapping: SupplierMapping, supplierArticleNumber: string): boolean {
  return mapping.supplierArticleNumber.trim().toUpperCase() === supplierArticleNumber;
}

function buildDvgAutoPairMappingUpdate(
  mapping: SupplierMapping,
  supplierArticleNumber: string,
  directUrl: string,
  observedAt: Date
): Partial<NewSupplierMapping> {
  const update: Partial<NewSupplierMapping> = {};
  if (mapping.supplierArticleNumber !== supplierArticleNumber) {
    update.supplierArticleNumber = supplierArticleNumber;
  }
  if (mapping.lookupStrategy !== "direct_url") update.lookupStrategy = "direct_url";
  if (mapping.directUrl !== directUrl) update.directUrl = directUrl;
  if (!mapping.enabled) update.enabled = true;
  if (!mapping.isPrimary) update.isPrimary = true;
  if (Object.keys(update).length > 0) {
    update.updatedAt = observedAt;
    update.updatedBy = "dvg_auto_pair";
  }
  return update;
}

function autoPairRow(
  product: Pick<CatalogProduct, "id" | "sku" | "name">,
  supplierArticleNumber: string | null,
  directUrl: string | null,
  status: DvgAutoPairRow["status"],
  source: DvgAutoPairRow["source"],
  existingSupplierArticleNumber: string | null
): DvgAutoPairRow {
  return {
    catalogProductId: product.id,
    sku: product.sku,
    name: product.name,
    supplierArticleNumber,
    directUrl,
    status,
    source,
    existingSupplierArticleNumber,
    message: dvgAutoPairMessage(status),
  };
}

function dvgAutoPairMessage(status: DvgAutoPairRow["status"]): string {
  switch (status) {
    case "created":
      return "DVG mapping created with direct detail URL.";
    case "updated":
      return "Existing DVG mapping updated to direct detail URL.";
    case "verified":
      return "Existing DVG mapping is already valid.";
    case "conflict":
      return "Existing active DVG mapping uses a different article; manual review required.";
    case "skipped_not_dvg_candidate":
      return "SKU/suggested article is not a digit-letter-number DVG article.";
  }
}
