import { createDbClient } from "@danetti/db";
import { Redis } from "ioredis";
import type { RuntimeDependencyHealth, RuntimeHealthResponse } from "./runtime-health.types.js";

interface RuntimeHealthOptions {
  env?: NodeJS.ProcessEnv;
  timeoutMs?: number;
  checkDatabase?: (databaseUrl: string, timeoutMs: number) => Promise<void>;
  checkRedis?: (redisUrl: string, timeoutMs: number) => Promise<void>;
}

const defaultTimeoutMs = 2_000;

export async function getRuntimeHealth(
  options: RuntimeHealthOptions = {}
): Promise<RuntimeHealthResponse> {
  const env = options.env ?? process.env;
  const timeoutMs = options.timeoutMs ?? defaultTimeoutMs;
  const checkDatabase = options.checkDatabase ?? checkDatabaseConnection;
  const checkRedis = options.checkRedis ?? checkRedisConnection;

  const [database, redis] = await Promise.all([
    getDatabaseHealth(env.DATABASE_URL, timeoutMs, checkDatabase),
    getRedisHealth(env.REDIS_URL, timeoutMs, checkRedis),
  ]);

  return {
    status: getOverallStatus(database, redis),
    api: { status: "ok" },
    launcher: {
      runId: env.DANETTI_LAUNCHER_RUN_ID?.trim() || null,
    },
    database,
    redis,
    worker: {
      status: "not_checked",
      message: "Worker folyamat állapota ebből az API végpontból nincs ellenőrizve.",
    },
  };
}

async function getDatabaseHealth(
  databaseUrl: string | undefined,
  timeoutMs: number,
  checkDatabase: (databaseUrl: string, timeoutMs: number) => Promise<void>
): Promise<RuntimeDependencyHealth> {
  const trimmed = databaseUrl?.trim();
  if (!trimmed) {
    return {
      status: "missing_config",
      message:
        "DATABASE_URL nincs beállítva. Add meg .env fájlban, vagy indítsd a helyi app scriptet.",
    };
  }

  try {
    await checkDatabase(trimmed, timeoutMs);
    return { status: "ok", message: "Adatbázis kapcsolat rendben." };
  } catch {
    return {
      status: "unavailable",
      message:
        "Adatbázis nem elérhető. Ellenőrizd, hogy fut-e a Docker Desktop és a Postgres konténer.",
    };
  }
}

async function getRedisHealth(
  redisUrl: string | undefined,
  timeoutMs: number,
  checkRedis: (redisUrl: string, timeoutMs: number) => Promise<void>
): Promise<RuntimeDependencyHealth> {
  const trimmed = redisUrl?.trim();
  if (!trimmed) {
    return {
      status: "missing_config",
      message:
        "REDIS_URL nincs beállítva. Add meg .env fájlban, vagy indítsd a helyi app scriptet.",
    };
  }

  try {
    await checkRedis(trimmed, timeoutMs);
    return { status: "ok", message: "Redis kapcsolat rendben." };
  } catch {
    return {
      status: "unavailable",
      message: "Redis nem elérhető. Ellenőrizd, hogy fut-e a Docker Desktop és a Redis konténer.",
    };
  }
}

async function checkDatabaseConnection(databaseUrl: string, timeoutMs: number): Promise<void> {
  const client = createDbClient(databaseUrl);
  try {
    await withTimeout(client.sql`select 1`, timeoutMs);
  } finally {
    await client.close();
  }
}

async function checkRedisConnection(redisUrl: string, timeoutMs: number): Promise<void> {
  const redis = new Redis(redisUrl, {
    connectTimeout: timeoutMs,
    enableReadyCheck: false,
    lazyConnect: true,
    maxRetriesPerRequest: 1,
  });
  redis.on("error", () => undefined);

  try {
    await withTimeout(redis.ping(), timeoutMs);
  } finally {
    redis.disconnect();
  }
}

function getOverallStatus(
  database: RuntimeDependencyHealth,
  redis: RuntimeDependencyHealth
): RuntimeHealthResponse["status"] {
  if (database.status !== "ok") {
    return "error";
  }

  if (redis.status !== "ok") {
    return "degraded";
  }

  return "ok";
}

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  let timeout: NodeJS.Timeout | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_, reject) => {
        timeout = setTimeout(() => reject(new Error("runtime_health_timeout")), timeoutMs);
      }),
    ]);
  } finally {
    if (timeout) {
      clearTimeout(timeout);
    }
  }
}
