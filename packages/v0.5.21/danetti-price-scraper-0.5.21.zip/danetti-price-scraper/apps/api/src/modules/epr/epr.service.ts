import { createHash } from "node:crypto";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { simpleParser } from "mailparser";
import ExcelJS from "exceljs";
import * as tables from "@danetti/db";
import type { DanettiDbClient, DanettiDatabase } from "@danetti/db";
import { z } from "zod";
import {
  calculateMaterial,
  dateString,
  decimalString,
  invoiceSchema,
  quarter,
  ruleSchema,
  totalsFromTraces,
  type CalculationTrace,
  type Invoice,
  type MaterialRule,
} from "./epr.domain.js";
import { DocumentArchive } from "./document.archive.js";
import {
  EXTRACTOR_VERSION,
  parseStructuredInvoice,
  type DocumentIntelligenceProvider,
} from "./document.provider.js";
import { EprError, safeCode } from "./epr.errors.js";

type Tx = Parameters<Parameters<DanettiDatabase["transaction"]>[0]>[0];
type Db = DanettiDatabase | Tx;
const {
  eprPeriods,
  purchases,
  purchaseLines,
  businessDocuments,
  businessDocumentLines,
  purchaseDocuments,
  sourceDocuments,
  sourceDocumentLinks,
  eprMaterialRules,
  eprUnitConversions,
  eprEntries,
  eprReviewDecisions,
  eprPeriodSnapshots,
  eprExports,
  eprRecognitionRules,
  mailboxMessages,
  eprScanRuns,
  eprScanRunEvents,
} = tables;
export class EprService {
  constructor(
    readonly client: DanettiDbClient,
    readonly archive: DocumentArchive,
    private readonly intelligence: DocumentIntelligenceProvider
  ) {}
  async periods() {
    return this.client.db.select().from(eprPeriods).orderBy(desc(eprPeriods.code));
  }
  async createPeriod(code: string) {
    const values = quarter(code);
    await this.client.db.insert(eprPeriods).values(values).onConflictDoNothing();
    const [period] = await this.client.db
      .select()
      .from(eprPeriods)
      .where(eq(eprPeriods.code, code));
    return period;
  }
  private async locked<T>(
    periodId: string,
    operation: (tx: Tx, period: typeof eprPeriods.$inferSelect) => Promise<T>,
    allowClosed = false
  ) {
    return this.client.db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(72164002)`);
      const [period] = await tx
        .select()
        .from(eprPeriods)
        .where(eq(eprPeriods.id, periodId))
        .for("update");
      if (!period) throw new EprError("period_not_found", 404);
      if (period.status === "CLOSED" && !allowClosed) throw new EprError("period_closed", 409);
      return operation(tx, period);
    });
  }
  async configurePeriod(id: string, input: unknown) {
    const parsed = z
      .object({
        accountingBasis: z.string().min(1).max(2000),
        accountingEventType: z.string().min(1).max(200),
        accountingDateField: z.enum(["manual", "issueDate", "performanceDate"]).default("manual"),
      })
      .strict()
      .safeParse(input);
    if (!parsed.success) throw new EprError("accounting_configuration_required");
    return this.locked(id, async (tx) => {
      const [previous] = await tx.select().from(eprPeriods).where(eq(eprPeriods.id, id));
      const [period] = await tx
        .update(eprPeriods)
        .set(parsed.data)
        .where(eq(eprPeriods.id, id))
        .returning();
      await tx.insert(eprReviewDecisions).values({
        periodId: id,
        action: "accounting_policy",
        reason: "Operátor által beállított elszámolási esemény és dátumforrás",
        operator: "local-operator",
        oldValue: {
          accountingBasis: previous.accountingBasis,
          accountingEventType: previous.accountingEventType,
          accountingDateField: previous.accountingDateField,
        },
        newValue: parsed.data,
      });
      return period;
    });
  }
  async listPurchases(periodId: string) {
    return this.client.db
      .select()
      .from(purchases)
      .where(eq(purchases.periodId, periodId))
      .orderBy(desc(purchases.accountingEventDate), desc(purchases.createdAt));
  }
  async detail(id: string, db: Db = this.client.db) {
    const [purchase] = await db.select().from(purchases).where(eq(purchases.id, id));
    if (!purchase) throw new EprError("purchase_not_found", 404);
    const lines = await db.select().from(purchaseLines).where(eq(purchaseLines.purchaseId, id));
    const documents = await db
      .select({ business: businessDocuments, source: sourceDocuments })
      .from(purchaseDocuments)
      .innerJoin(businessDocuments, eq(businessDocuments.id, purchaseDocuments.businessDocumentId))
      .innerJoin(sourceDocuments, eq(sourceDocuments.id, businessDocuments.sourceDocumentId))
      .where(eq(purchaseDocuments.purchaseId, id));
    const extractedLines = documents.length
      ? await db
          .select()
          .from(businessDocumentLines)
          .where(
            inArray(
              businessDocumentLines.businessDocumentId,
              documents.map((d) => d.business.id)
            )
          )
      : [];
    const entries = lines.length
      ? await db
          .select()
          .from(eprEntries)
          .where(
            inArray(
              eprEntries.purchaseLineId,
              lines.map((l) => l.id)
            )
          )
      : [];
    const decisions = await db
      .select()
      .from(eprReviewDecisions)
      .where(eq(eprReviewDecisions.purchaseId, id));
    const sources = documents.length
      ? await db
          .select({ message: mailboxMessages })
          .from(sourceDocumentLinks)
          .innerJoin(mailboxMessages, eq(mailboxMessages.id, sourceDocumentLinks.messageId))
          .where(
            inArray(
              sourceDocumentLinks.documentId,
              documents.map((d) => d.source.id)
            )
          )
      : [];
    return {
      purchase,
      lines,
      documents,
      extractedLines,
      entries,
      decisions,
      messages: sources.map((s) => s.message),
    };
  }
  async rules() {
    return this.client.db
      .select()
      .from(eprMaterialRules)
      .orderBy(eprMaterialRules.key, desc(eprMaterialRules.version));
  }
  async unresolvedProducts() {
    return this.client.db
      .select({
        id: purchaseLines.id,
        purchaseId: purchases.id,
        supplier: purchases.supplier,
        supplierSku: purchaseLines.supplierSku,
        description: purchaseLines.description,
      })
      .from(purchaseLines)
      .innerJoin(purchases, eq(purchases.id, purchaseLines.purchaseId))
      .innerJoin(eprPeriods, eq(eprPeriods.id, purchases.periodId))
      .where(
        and(
          eq(purchaseLines.safeErrorCode, "material_rule_missing"),
          sql`${eprPeriods.status} <> 'CLOSED'`,
          sql`${purchases.status} <> 'excluded'`
        )
      );
  }
  async archiveStatus() {
    const [counts] = await this.client.db
      .select({ count: sql<number>`count(*)::int` })
      .from(sourceDocuments);
    return { documentCount: counts.count, directory: this.archive.root };
  }
  async createRule(input: unknown) {
    const parsed = ruleSchema.safeParse(input);
    if (!parsed.success) throw new EprError("material_rule_invalid");
    return this.client.db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${parsed.data.key}))`);
      const [last] = await tx
        .select()
        .from(eprMaterialRules)
        .where(eq(eprMaterialRules.key, parsed.data.key))
        .orderBy(desc(eprMaterialRules.version))
        .limit(1);
      const [rule] = await tx
        .insert(eprMaterialRules)
        .values({ ...parsed.data, version: (last?.version ?? 0) + 1 })
        .returning();
      return rule;
    });
  }
  async recognitionRules() {
    return this.client.db.select().from(eprRecognitionRules);
  }
  async saveRecognition(input: unknown) {
    const parsed = z
      .object({
        kind: z.enum(["supplier_alias", "supplier_domain", "product_alias", "exclusion"]),
        match: z.string().min(1).max(500),
        value: z.string().min(1).max(500),
      })
      .strict()
      .safeParse(input);
    if (!parsed.success) throw new EprError("recognition_rule_invalid");
    const [item] = await this.client.db
      .insert(eprRecognitionRules)
      .values(parsed.data)
      .onConflictDoUpdate({
        target: [eprRecognitionRules.kind, eprRecognitionRules.match],
        set: { value: parsed.data.value },
      })
      .returning();
    return item;
  }
  async removeRecognition(id: string) {
    await this.client.db.delete(eprRecognitionRules).where(eq(eprRecognitionRules.id, id));
  }
  async saveConversion(input: unknown) {
    const parsed = z
      .object({
        supplierIdentity: z.string().min(1).max(300),
        supplierSku: z.string().min(1).max(200),
        fromUnit: z.string().min(1).max(50),
        toUnit: z.string().min(1).max(50),
        factor: decimalString,
        source: z.string().min(1).max(2000),
      })
      .strict()
      .safeParse(input);
    if (!parsed.success || Number(parsed.data.factor) <= 0)
      throw new EprError("unit_conversion_invalid");
    const [conversion] = await this.client.db
      .insert(eprUnitConversions)
      .values(parsed.data)
      .returning();
    return conversion;
  }
  async conversions() {
    return this.client.db.select().from(eprUnitConversions);
  }
  async document(id: string) {
    const [document] = await this.client.db
      .select()
      .from(sourceDocuments)
      .where(eq(sourceDocuments.id, id));
    if (!document) throw new EprError("document_not_found", 404);
    return document;
  }
  async importMessage(
    periodId: string,
    messageId: string,
    source: Buffer,
    metadata: Record<string, unknown>
  ) {
    const mail = await simpleParser(source, {
      skipHtmlToText: true,
      skipTextToHtml: true,
      maxHtmlLengthToParse: 0,
    });
    // Preserve the original relevant email separately from each attached business document.
    if (source.length <= 20_000_000) {
      const archived = await this.archive.put(source);
      const [email] = await this.client.db
        .insert(sourceDocuments)
        .values({
          ...archived,
          filename: "original-email.eml",
          mime: "message/rfc822",
          status: "archived",
        })
        .onConflictDoUpdate({ target: sourceDocuments.hash, set: { hash: archived.hash } })
        .returning();
      await this.client.db
        .insert(sourceDocumentLinks)
        .values({ documentId: email.id, messageId })
        .onConflictDoNothing();
      await this.client.db
        .update(mailboxMessages)
        .set({ metadata: { ...metadata, originalEmailDocumentId: email.id } })
        .where(eq(mailboxMessages.id, messageId));
    }
    const attachments = mail.attachments.filter(
      (a) =>
        /\.pdf$|\.json$|\.xml$/i.test(a.filename ?? "") ||
        ["application/pdf", "application/json", "application/xml", "text/xml"].includes(
          a.contentType
        )
    );
    for (const attachment of attachments) {
      if (attachment.content.length > 20_000_000) {
        await this.importOversizedMessage(periodId, messageId, {
          ...metadata,
          filename: attachment.filename,
          size: attachment.content.length,
        });
        continue;
      }
      await this.importDocument(periodId, {
        bytes: attachment.content,
        filename: attachment.filename ?? "document",
        mime: attachment.contentType,
        messageId,
        metadata,
      });
    }
    if (!attachments.length && mail.text?.trim())
      await this.importDocument(periodId, {
        bytes: Buffer.from(mail.text.slice(0, 120_000)),
        filename: "email-body.txt",
        mime: "text/plain",
        messageId,
        metadata,
      });
  }
  async importOversizedMessage(
    periodId: string,
    messageId: string,
    metadata: Record<string, unknown>
  ) {
    const archived = await this.archive.put(
      Buffer.from(
        JSON.stringify({
          messageId,
          metadata,
          originalNotDownloaded: true,
          reason: "document_size_invalid",
        })
      )
    );
    const [document] = await this.client.db
      .insert(sourceDocuments)
      .values({
        ...archived,
        filename: "size-limit-review.json",
        mime: "application/json",
        status: "review",
        provider: "metadata-only",
        safeErrorCode: "document_size_invalid",
      })
      .onConflictDoUpdate({ target: sourceDocuments.hash, set: { hash: archived.hash } })
      .returning();
    await this.client.db
      .insert(sourceDocumentLinks)
      .values({ documentId: document.id, messageId })
      .onConflictDoNothing();
    await this.persistInvoice(
      periodId,
      document.id,
      {
        documentType: "other",
        supplier: { name: null, taxId: null },
        customerIdentity: null,
        invoiceNumber: null,
        orderReferences: [],
        issueDate: null,
        performanceDate: null,
        dueDate: null,
        currency: null,
        lines: [],
        reasonCodes: ["document_size_invalid", "original_not_downloaded"],
      },
      true,
      metadata
    );
  }
  async importDocument(
    periodId: string,
    input: {
      bytes: Buffer;
      filename: string;
      mime: string;
      messageId?: string;
      metadata?: Record<string, unknown>;
    }
  ) {
    const archived = await this.archive.put(input.bytes);
    const isPdf = input.mime === "application/pdf" || /\.pdf$/i.test(input.filename);
    if (isPdf && !input.bytes.subarray(0, 1024).includes(Buffer.from("%PDF-")))
      throw new EprError("document_pdf_invalid");
    const [document] = await this.client.db
      .insert(sourceDocuments)
      .values({
        ...archived,
        filename: input.filename.slice(0, 500),
        mime: isPdf ? "application/pdf" : input.mime,
        status: "pending",
      })
      .onConflictDoUpdate({ target: sourceDocuments.hash, set: { hash: archived.hash } })
      .returning();
    if (input.messageId)
      await this.client.db
        .insert(sourceDocumentLinks)
        .values({ documentId: document.id, messageId: input.messageId })
        .onConflictDoNothing();
    if (document.status === "processed" || document.status === "review") return document;
    let text = "",
      invoice: Invoice | null = null,
      errorCode: string | null = null,
      provider = "deterministic";
    let model: string | null = null;
    try {
      text = isPdf
        ? await extractPdfText(input.bytes)
        : input.bytes.toString("utf8").slice(0, 120_000);
      invoice = parseStructuredInvoice(text);
      if (!invoice) {
        provider = "openai-chatgpt-plan";
        invoice = await this.intelligence.extractInvoice({
          documentId: document.id,
          filename: document.filename,
          text,
          pdf: isPdf ? input.bytes : undefined,
          onModel: (selected) => {
            model = selected;
          },
        });
      }
    } catch (error) {
      errorCode = safeCode(error, "document_parse_failed");
    }
    const fallback: Invoice = invoice ?? {
      documentType: "other",
      supplier: { name: null, taxId: null },
      customerIdentity: null,
      invoiceNumber: null,
      orderReferences: [],
      issueDate: null,
      performanceDate: null,
      dueDate: null,
      currency: null,
      lines: [],
      reasonCodes: [errorCode ?? "document_review_required"],
    };
    await this.persistInvoice(periodId, document.id, fallback, invoice === null, input.metadata);
    await this.client.db
      .update(sourceDocuments)
      .set({
        status: invoice ? "processed" : "review",
        extraction: invoice as unknown as Record<string, unknown> | null,
        extractionVersion: EXTRACTOR_VERSION,
        provider,
        model,
        safeErrorCode: errorCode,
      })
      .where(eq(sourceDocuments.id, document.id));
    return this.document(document.id);
  }
  private async persistInvoice(
    periodId: string,
    documentId: string,
    invoice: Invoice,
    unresolved: boolean,
    metadata?: Record<string, unknown>
  ) {
    return this.locked(
      periodId,
      async (tx, period) => {
        await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${documentId}))`);
        const [existing] = await tx
          .select()
          .from(businessDocuments)
          .where(eq(businessDocuments.sourceDocumentId, documentId));
        if (existing) return;
        const aliases = await tx.select().from(eprRecognitionRules);
        const alias = aliases.find(
          (a) => a.kind === "supplier_alias" && a.match === invoice.supplier.name
        );
        const from = (metadata?.from as { address?: string }[] | undefined)?.[0]?.address;
        const domain = from?.split("@")[1]?.toLowerCase();
        const domainAlias = domain
          ? aliases.find((a) => a.kind === "supplier_domain" && a.match.toLowerCase() === domain)
          : undefined;
        const supplierIdentity =
          invoice.supplier.taxId ?? alias?.value ?? domainAlias?.value ?? null;
        const identity =
          supplierIdentity && invoice.invoiceNumber && invoice.customerIdentity
            ? JSON.stringify([
                supplierIdentity,
                invoice.invoiceNumber,
                invoice.documentType,
                invoice.customerIdentity,
              ])
            : null;
        const conflicts = identity
          ? await tx
              .select()
              .from(businessDocuments)
              .where(eq(businessDocuments.identity, identity))
          : [];
        if (conflicts.length)
          await this.invalidateConflictingPurchases(
            tx,
            conflicts.map((d) => d.id)
          );
        if (conflicts.length)
          await tx
            .update(businessDocuments)
            .set({ conflict: true })
            .where(eq(businessDocuments.identity, identity!));
        const [business] = await tx
          .insert(businessDocuments)
          .values({
            sourceDocumentId: documentId,
            identity,
            supplierIdentity,
            invoiceNumber: invoice.invoiceNumber,
            documentType: invoice.documentType,
            data: invoice as unknown as Record<string, unknown>,
            conflict: conflicts.length > 0,
          })
          .returning();
        const groupingKey =
          supplierIdentity && invoice.customerIdentity && invoice.orderReferences.length === 1
            ? JSON.stringify([
                supplierIdentity,
                invoice.customerIdentity,
                invoice.orderReferences[0],
                periodId,
              ])
            : `document:${documentId}`;
        const excluded = aliases.some(
          (a) =>
            a.kind === "exclusion" &&
            (a.match === invoice.supplier.name || a.match === invoice.documentType)
        );
        let [purchase] = await tx
          .select()
          .from(purchases)
          .where(eq(purchases.groupingKey, groupingKey));
        const existingPurchase = purchase;
        if (!purchase)
          [purchase] = await tx
            .insert(purchases)
            .values({
              periodId,
              groupingKey,
              supplier:
                invoice.supplier.name ?? String(metadata?.subject ?? "Ismeretlen beszállító"),
              supplierIdentity,
              reference: invoice.orderReferences[0] ?? invoice.invoiceNumber,
              status: excluded ? "excluded" : "potential",
              reasonCodes: [
                ...invoice.reasonCodes,
                ...(unresolved ? ["extraction_review_required"] : []),
                ...(conflicts.length ? ["document_conflict"] : []),
              ],
              accountingEventDate: null,
            })
            .returning();
        await tx
          .insert(purchaseDocuments)
          .values({ purchaseId: purchase.id, businessDocumentId: business.id });
        for (const line of invoice.lines) {
          const [businessLine] = await tx
            .insert(businessDocumentLines)
            .values({
              businessDocumentId: business.id,
              sourceLineId: line.sourceLineId,
              data: { ...line, provenance: { ...line.provenance, documentId } },
            })
            .returning();
          await tx.insert(purchaseLines).values({
            purchaseId: purchase.id,
            businessDocumentLineId: businessLine.id,
            description: line.description,
            supplierSku: line.supplierSku,
            quantity: line.quantity,
            unit: line.unit,
            safeErrorCode: "operator_review_required",
          });
        }
        if (
          existingPurchase &&
          !["potential", "excluded"].includes(existingPurchase.status) &&
          period.status !== "CLOSED"
        ) {
          await tx
            .update(purchases)
            .set({ status: "potential", accountingEventDate: null })
            .where(eq(purchases.id, purchase.id));
          const priorLines = await tx
            .select({ id: purchaseLines.id })
            .from(purchaseLines)
            .where(eq(purchaseLines.purchaseId, purchase.id));
          if (priorLines.length)
            await tx.delete(eprEntries).where(
              inArray(
                eprEntries.purchaseLineId,
                priorLines.map((l) => l.id)
              )
            );
          await tx.insert(eprReviewDecisions).values({
            periodId,
            purchaseId: purchase.id,
            action: "additional_evidence",
            operator: "system",
            reason:
              "Új bizonylat miatt az elszámolási dátumot és a számítást újra ellenőrizni kell",
            oldValue: existingPurchase,
            newValue: { documentId },
          });
        }
        if (period.status === "CLOSED") {
          await tx.insert(eprReviewDecisions).values({
            periodId,
            purchaseId: purchase.id,
            action: "late_evidence",
            reason: "Új dokumentum érinti a lezárt időszakot.",
            newValue: { documentId },
            operator: "system",
          });
        } else if (!excluded) {
          await this.autoApproveKnownPurchase(tx, purchase.id, period);
          await tx
            .update(eprPeriods)
            .set({ status: "REVIEW_REQUIRED" })
            .where(eq(eprPeriods.id, periodId));
        }
      },
      true
    );
  }
  async reviewPurchase(id: string, input: unknown) {
    const parsed = z
      .object({
        action: z.enum(["accept", "reject"]),
        reason: z.string().min(1).max(2000),
        operator: z.string().min(1).max(100),
        accountingEventDate: dateString.nullable().default(null),
        supplierIdentity: z.string().min(1).max(300).nullable().default(null),
        supplier: z.string().min(1).max(300).nullable().default(null),
      })
      .strict()
      .safeParse(input);
    if (!parsed.success) throw new EprError("review_invalid");
    const detail = await this.detail(id);
    return this.locked(detail.purchase.periodId, async (tx, period) => {
      if (
        parsed.data.action === "accept" &&
        (!period.accountingBasis || !period.accountingEventType || !parsed.data.accountingEventDate)
      )
        throw new EprError("accounting_configuration_required");
      if (
        parsed.data.accountingEventDate &&
        (parsed.data.accountingEventDate < period.startsAt ||
          parsed.data.accountingEventDate > period.endsAt)
      )
        throw new EprError("accounting_date_outside_period");
      if (parsed.data.action === "accept" && detail.documents.some((d) => d.business.conflict))
        throw new EprError("document_conflict", 409);
      const next = {
        status: parsed.data.action === "reject" ? "excluded" : "review",
        accountingEventDate: parsed.data.accountingEventDate,
        accountingBasis: period.accountingBasis,
        accountingEventType: period.accountingEventType,
        supplierIdentity: parsed.data.supplierIdentity ?? detail.purchase.supplierIdentity,
        supplier: parsed.data.supplier ?? detail.purchase.supplier,
      };
      await tx.update(purchases).set(next).where(eq(purchases.id, id));
      await tx.insert(eprReviewDecisions).values({
        periodId: period.id,
        purchaseId: id,
        action: parsed.data.action,
        reason: parsed.data.reason,
        operator: parsed.data.operator,
        oldValue: detail.purchase,
        newValue: next,
      });
      await this.calculatePurchase(tx, id);
      return this.detail(id, tx);
    });
  }
  async editLine(id: string, input: unknown) {
    const parsed = z
      .object({
        quantity: decimalString.nullable(),
        unit: z.string().min(1).max(50).nullable(),
        supplierSku: z.string().max(200).nullable(),
        ruleVersionId: z.uuid().nullable(),
        basisQuantity: decimalString.nullable().default(null),
        creditApproved: z.boolean().default(false),
        reason: z.string().min(1).max(2000),
        operator: z.string().min(1).max(100),
        rememberMapping: z.boolean().default(false),
      })
      .strict()
      .safeParse(input);
    if (!parsed.success) throw new EprError("line_review_invalid");
    const [line] = await this.client.db
      .select()
      .from(purchaseLines)
      .where(eq(purchaseLines.id, id));
    if (!line) throw new EprError("line_not_found", 404);
    const detail = await this.detail(line.purchaseId);
    return this.locked(detail.purchase.periodId, async (tx) => {
      const next = {
        quantity: parsed.data.quantity,
        unit: parsed.data.unit,
        supplierSku: parsed.data.supplierSku,
        ruleVersionId: parsed.data.ruleVersionId,
        mappingApproved: !!parsed.data.ruleVersionId,
        factors: {
          basisQuantity: parsed.data.basisQuantity ?? "",
          creditApproved: String(parsed.data.creditApproved),
        },
      };
      await tx.update(purchaseLines).set(next).where(eq(purchaseLines.id, id));
      await tx.insert(eprReviewDecisions).values({
        periodId: detail.purchase.periodId,
        purchaseId: line.purchaseId,
        lineId: id,
        action: parsed.data.rememberMapping ? "remember_mapping" : "line_override",
        reason: parsed.data.reason,
        operator: parsed.data.operator,
        oldValue: line,
        newValue: next,
      });
      if (
        parsed.data.rememberMapping &&
        detail.purchase.supplierIdentity &&
        parsed.data.supplierSku &&
        parsed.data.ruleVersionId
      ) {
        const match = JSON.stringify([detail.purchase.supplierIdentity, parsed.data.supplierSku]);
        await tx
          .insert(eprRecognitionRules)
          .values({ kind: "product_alias", match, value: parsed.data.ruleVersionId })
          .onConflictDoUpdate({
            target: [eprRecognitionRules.kind, eprRecognitionRules.match],
            set: { value: parsed.data.ruleVersionId },
          });
      }
      await this.calculatePurchase(tx, line.purchaseId);
      return this.detail(line.purchaseId, tx);
    });
  }
  async excludeLine(id: string, reason: string) {
    if (!reason || reason.length > 2000) throw new EprError("review_reason_required");
    const [line] = await this.client.db
      .select()
      .from(purchaseLines)
      .where(eq(purchaseLines.id, id));
    if (!line) throw new EprError("line_not_found", 404);
    const detail = await this.detail(line.purchaseId);
    return this.locked(detail.purchase.periodId, async (tx) => {
      await tx
        .update(purchaseLines)
        .set({ factors: { ...line.factors, excluded: "true" }, safeErrorCode: null })
        .where(eq(purchaseLines.id, id));
      await tx.delete(eprEntries).where(eq(eprEntries.purchaseLineId, id));
      await tx.insert(eprReviewDecisions).values({
        periodId: detail.purchase.periodId,
        purchaseId: line.purchaseId,
        lineId: id,
        action: "line_excluded",
        reason,
        operator: "local-operator",
        oldValue: line,
        newValue: { excluded: true },
      });
      await this.calculatePurchase(tx, line.purchaseId);
      return this.detail(line.purchaseId, tx);
    });
  }
  async resolveDocumentConflict(documentId: string, reason: string) {
    if (!reason || reason.length > 2000) throw new EprError("review_reason_required");
    const [document] = await this.client.db
      .select()
      .from(businessDocuments)
      .where(eq(businessDocuments.sourceDocumentId, documentId));
    if (!document) throw new EprError("document_not_found", 404);
    const [link] = await this.client.db
      .select()
      .from(purchaseDocuments)
      .where(eq(purchaseDocuments.businessDocumentId, document.id));
    const detail = await this.detail(link.purchaseId);
    return this.locked(detail.purchase.periodId, async (tx) => {
      await tx
        .update(businessDocuments)
        .set({ conflict: false, data: { ...document.data, operatorExcluded: true } })
        .where(eq(businessDocuments.id, document.id));
      const lines = await tx
        .select()
        .from(businessDocumentLines)
        .where(eq(businessDocumentLines.businessDocumentId, document.id));
      for (const line of detail.lines.filter((l) =>
        lines.some((b) => b.id === l.businessDocumentLineId)
      )) {
        await tx
          .update(purchaseLines)
          .set({ factors: { ...line.factors, excluded: "true" }, safeErrorCode: null })
          .where(eq(purchaseLines.id, line.id));
        await tx.delete(eprEntries).where(eq(eprEntries.purchaseLineId, line.id));
      }
      if (document.identity) {
        const remaining = await tx
          .select()
          .from(businessDocuments)
          .where(eq(businessDocuments.identity, document.identity));
        const active = remaining.filter(
          (d) => d.id !== document.id && d.data.operatorExcluded !== true
        );
        if (active.length === 1) {
          await tx
            .update(businessDocuments)
            .set({ conflict: false })
            .where(eq(businessDocuments.id, active[0].id));
          const related = await tx
            .select({ purchase: purchases })
            .from(purchaseDocuments)
            .innerJoin(purchases, eq(purchases.id, purchaseDocuments.purchaseId))
            .where(eq(purchaseDocuments.businessDocumentId, active[0].id));
          for (const item of related) {
            const [period] = await tx
              .select()
              .from(eprPeriods)
              .where(eq(eprPeriods.id, item.purchase.periodId))
              .for("update");
            if (period.status !== "CLOSED") await this.calculatePurchase(tx, item.purchase.id);
          }
        }
      }
      const refreshed = await this.detail(link.purchaseId, tx);
      if (refreshed.documents.every((d) => d.business.data.operatorExcluded === true))
        await tx
          .update(purchases)
          .set({ status: "excluded" })
          .where(eq(purchases.id, link.purchaseId));
      await tx.insert(eprReviewDecisions).values({
        periodId: detail.purchase.periodId,
        purchaseId: link.purchaseId,
        action: "document_excluded",
        reason,
        operator: "local-operator",
        oldValue: { documentId, conflict: document.conflict },
        newValue: { operatorExcluded: true },
      });
      await this.calculatePurchase(tx, link.purchaseId);
      return this.detail(link.purchaseId, tx);
    });
  }
  async movePurchase(id: string, targetPeriodId: string, reason: string) {
    if (!reason || reason.length > 2000) throw new EprError("review_reason_required");
    const detail = await this.detail(id);
    return this.client.db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(72164002)`);
      const periods = await tx
        .select()
        .from(eprPeriods)
        .where(inArray(eprPeriods.id, [detail.purchase.periodId, targetPeriodId]))
        .orderBy(eprPeriods.id)
        .for("update");
      const target = periods.find((p) => p.id === targetPeriodId);
      if (!target || target.status === "CLOSED") throw new EprError("period_closed", 409);
      const [closedSnapshot] = await tx
        .select()
        .from(eprPeriodSnapshots)
        .where(eq(eprPeriodSnapshots.periodId, detail.purchase.periodId));
      if (
        closedSnapshot &&
        ((closedSnapshot.data.details as { purchase: { id: string } }[]) ?? []).some(
          (d) => d.purchase.id === id
        )
      )
        throw new EprError("period_closed", 409);
      for (const line of detail.lines)
        await tx.delete(eprEntries).where(eq(eprEntries.purchaseLineId, line.id));
      await tx
        .update(purchases)
        .set({
          periodId: targetPeriodId,
          accountingEventDate: null,
          accountingBasis: null,
          accountingEventType: null,
          status: "potential",
          groupingKey: `moved:${id}`,
        })
        .where(eq(purchases.id, id));
      await tx.insert(eprReviewDecisions).values({
        periodId: targetPeriodId,
        purchaseId: id,
        action: "period_reallocation",
        reason,
        operator: "local-operator",
        oldValue: { periodId: detail.purchase.periodId },
        newValue: { periodId: targetPeriodId },
      });
      await tx
        .update(eprPeriods)
        .set({ status: "REVIEW_REQUIRED" })
        .where(eq(eprPeriods.id, targetPeriodId));
      return this.detail(id, tx);
    });
  }
  private async invalidateConflictingPurchases(tx: Tx, documentIds: string[]) {
    const related = await tx
      .select({ purchase: purchases })
      .from(purchaseDocuments)
      .innerJoin(purchases, eq(purchases.id, purchaseDocuments.purchaseId))
      .where(inArray(purchaseDocuments.businessDocumentId, documentIds));
    for (const { purchase } of related) {
      const [period] = await tx
        .select()
        .from(eprPeriods)
        .where(eq(eprPeriods.id, purchase.periodId))
        .for("update");
      if (period.status === "CLOSED" || purchase.status === "excluded") continue;
      const lines = await tx
        .select()
        .from(purchaseLines)
        .where(eq(purchaseLines.purchaseId, purchase.id));
      for (const line of lines) {
        await tx.delete(eprEntries).where(eq(eprEntries.purchaseLineId, line.id));
        await tx
          .update(purchaseLines)
          .set({ safeErrorCode: "document_conflict" })
          .where(eq(purchaseLines.id, line.id));
      }
      if (purchase.status === "ok")
        await tx.update(purchases).set({ status: "review" }).where(eq(purchases.id, purchase.id));
      await tx
        .update(eprPeriods)
        .set({ status: "REVIEW_REQUIRED" })
        .where(eq(eprPeriods.id, period.id));
    }
  }
  private async calculatePurchase(tx: Tx, id: string) {
    const detail = await this.detail(id, tx),
      purchase = detail.purchase;
    if (purchase.status === "potential" || purchase.status === "excluded") {
      for (const line of detail.lines)
        await tx.delete(eprEntries).where(eq(eprEntries.purchaseLineId, line.id));
      return;
    }
    let unresolved = detail.lines.length === 0;
    const rules = await tx.select().from(eprMaterialRules).orderBy(desc(eprMaterialRules.version));
    const aliases = await tx
      .select()
      .from(eprRecognitionRules)
      .where(eq(eprRecognitionRules.kind, "product_alias"));
    const conversions = await tx
      .select()
      .from(eprUnitConversions)
      .orderBy(desc(eprUnitConversions.createdAt));
    const shipmentRules = new Set<string>();
    for (const line of detail.lines) {
      if (line.factors?.excluded === "true") {
        await tx.delete(eprEntries).where(eq(eprEntries.purchaseLineId, line.id));
        continue;
      }
      try {
        if (
          detail.documents.some(
            (d) => d.business.conflict && d.business.data.operatorExcluded !== true
          )
        )
          throw new EprError("document_conflict");
        if (!purchase.accountingEventDate) throw new EprError("accounting_date_missing");
        const ruleId =
          line.ruleVersionId ??
          aliases.find(
            (a) => a.match === JSON.stringify([purchase.supplierIdentity, line.supplierSku])
          )?.value;
        const applicable = (rule: typeof eprMaterialRules.$inferSelect) =>
          rule.validFrom <= purchase.accountingEventDate! &&
          (!rule.validTo || rule.validTo >= purchase.accountingEventDate!);
        const rule = ruleId
          ? rules.find((r) => r.id === ruleId && applicable(r))
          : rules.find(
              (r) =>
                r.supplierIdentity === purchase.supplierIdentity &&
                r.supplierSku === line.supplierSku &&
                applicable(r)
            );
        if (!rule) throw new EprError("material_rule_missing");
        if (rule.applicability === "PER_SHIPMENT" && shipmentRules.has(rule.key))
          throw new EprError("shipment_packaging_duplicate");
        const business = detail.extractedLines.find((l) => l.id === line.businessDocumentLineId);
        const document = detail.documents.find(
          (d) => d.business.id === business?.businessDocumentId
        );
        if (
          ["proforma", "delivery_note", "other"].includes(
            document?.business.documentType ?? "other"
          )
        )
          throw new EprError("document_accounting_review_required");
        if (
          ["credit_note", "corrective_invoice", "cancellation"].includes(
            document?.business.documentType ?? ""
          ) &&
          line.factors?.creditApproved !== "true"
        )
          throw new EprError("credit_material_review_required");
        const conversion = conversions.find(
          (c) =>
            c.supplierIdentity === purchase.supplierIdentity &&
            c.supplierSku === line.supplierSku &&
            c.fromUnit === line.unit &&
            c.toUnit === rule.unit
        );
        const trace = calculateMaterial({
          quantity: line.quantity,
          unit: line.unit,
          rule: rule as MaterialRule,
          conversionFactor: conversion?.factor,
          basisQuantity: line.factors?.basisQuantity,
          creditApproved: line.factors?.creditApproved === "true",
        });
        if (rule.applicability === "PER_SHIPMENT") shipmentRules.add(rule.key);
        await tx
          .insert(eprEntries)
          .values({
            periodId: purchase.periodId,
            purchaseLineId: line.id,
            ruleVersionId: rule.id,
            trace: trace as unknown as Record<string, unknown>,
            grams: trace.totalGrams,
          })
          .onConflictDoUpdate({
            target: eprEntries.purchaseLineId,
            set: {
              ruleVersionId: rule.id,
              trace: trace as unknown as Record<string, unknown>,
              grams: trace.totalGrams,
            },
          });
        await tx
          .update(purchaseLines)
          .set({ ruleVersionId: rule.id, mappingApproved: true, safeErrorCode: null })
          .where(eq(purchaseLines.id, line.id));
      } catch (error) {
        unresolved = true;
        await tx.delete(eprEntries).where(eq(eprEntries.purchaseLineId, line.id));
        await tx
          .update(purchaseLines)
          .set({ safeErrorCode: safeCode(error, "calculation_failed") })
          .where(eq(purchaseLines.id, line.id));
      }
    }
    await tx
      .update(purchases)
      .set({ status: unresolved ? "review" : "ok" })
      .where(eq(purchases.id, id));
  }
  private async autoApproveKnownPurchase(
    tx: Tx,
    id: string,
    period: typeof eprPeriods.$inferSelect
  ) {
    if (
      period.accountingDateField === "manual" ||
      !period.accountingBasis ||
      !period.accountingEventType ||
      period.status === "CLOSED"
    )
      return;
    const detail = await this.detail(id, tx),
      purchase = detail.purchase;
    if (
      purchase.status !== "potential" ||
      !purchase.supplierIdentity ||
      !detail.lines.length ||
      !detail.documents.length
    )
      return;
    const invoices = detail.documents.map((d) => invoiceSchema.safeParse(d.business.data));
    if (
      detail.documents.some((d) => d.business.conflict || d.source.safeErrorCode) ||
      invoices.some((i) => !i.success)
    )
      return;
    const data = invoices.map((i) => i.data!);
    if (
      data.some((i) => i.documentType !== "invoice" || !i.invoiceNumber || !i.customerIdentity) ||
      detail.documents.some((d) => d.business.supplierIdentity !== purchase.supplierIdentity) ||
      new Set(data.map((i) => i.customerIdentity)).size !== 1
    )
      return;
    const dates = data.map((i) =>
      period.accountingDateField === "issueDate" ? i.issueDate : i.performanceDate
    );
    const date = dates[0];
    if (!date || dates.some((d) => d !== date) || date < period.startsAt || date > period.endsAt)
      return;
    const known = await tx
      .select({ id: eprMaterialRules.id })
      .from(eprMaterialRules)
      .where(
        and(
          eq(eprMaterialRules.supplierIdentity, purchase.supplierIdentity),
          sql`${eprMaterialRules.validFrom} <= ${date}::date`,
          sql`(${eprMaterialRules.validTo} IS NULL OR ${eprMaterialRules.validTo} >= ${date}::date)`
        )
      )
      .limit(1);
    if (!known.length) return;
    const next = {
      status: "review",
      accountingEventDate: date,
      accountingBasis: period.accountingBasis,
      accountingEventType: period.accountingEventType,
    };
    await tx.update(purchases).set(next).where(eq(purchases.id, id));
    await tx.insert(eprReviewDecisions).values({
      periodId: period.id,
      purchaseId: id,
      action: "automatic_accept",
      operator: "system",
      reason: "Ismert beszállító számlája az operátor által választott elszámolási dátumforrással",
      oldValue: purchase,
      newValue: {
        ...next,
        accountingDateField: period.accountingDateField,
        documentIds: detail.documents.map((d) => d.source.id),
      },
    });
    await this.calculatePurchase(tx, id);
  }
  async recalculate(periodId: string) {
    return this.locked(periodId, async (tx, period) => {
      for (const purchase of await tx
        .select()
        .from(purchases)
        .where(eq(purchases.periodId, periodId))) {
        await this.autoApproveKnownPurchase(tx, purchase.id, period);
        await this.calculatePurchase(tx, purchase.id);
      }
      const items = await tx.select().from(purchases).where(eq(purchases.periodId, periodId));
      await tx
        .update(eprPeriods)
        .set({
          status: items.some((p) => p.status !== "ok" && p.status !== "excluded")
            ? "REVIEW_REQUIRED"
            : "READY",
        })
        .where(eq(eprPeriods.id, periodId));
    });
  }
  private async snapshotData(periodId: string, db: Db) {
    const [period] = await db.select().from(eprPeriods).where(eq(eprPeriods.id, periodId));
    if (!period) throw new EprError("period_not_found", 404);
    const items = await db.select().from(purchases).where(eq(purchases.periodId, periodId));
    const details = [];
    for (const purchase of items) details.push(await this.detail(purchase.id, db));
    const entries = await db.select().from(eprEntries).where(eq(eprEntries.periodId, periodId));
    const ruleIds = [...new Set(entries.map((e) => e.ruleVersionId))];
    const rules = ruleIds.length
      ? await db.select().from(eprMaterialRules).where(inArray(eprMaterialRules.id, ruleIds))
      : [];
    const decisions = await db
      .select()
      .from(eprReviewDecisions)
      .where(eq(eprReviewDecisions.periodId, periodId));
    return {
      period,
      details,
      entries,
      rules,
      decisions,
      totals: totalsFromTraces(entries.map((e) => e.trace as unknown as CalculationTrace)),
      unresolved: items.filter((p) => p.status !== "ok" && p.status !== "excluded").length,
    };
  }
  async summary(
    periodId: string
  ): Promise<
    Awaited<ReturnType<EprService["snapshotData"]>> & { closed?: boolean; digest?: string }
  > {
    const [snapshot] = await this.client.db
      .select()
      .from(eprPeriodSnapshots)
      .where(eq(eprPeriodSnapshots.periodId, periodId));
    if (snapshot)
      return { ...snapshot.data, closed: true, digest: snapshot.digest } as unknown as Awaited<
        ReturnType<EprService["snapshotData"]>
      > & { closed: boolean; digest: string };
    return this.snapshotData(periodId, this.client.db);
  }
  async close(periodId: string, operator: string) {
    return this.locked(periodId, async (tx, period) => {
      const runs = await tx
        .select()
        .from(eprScanRuns)
        .where(
          and(
            eq(eprScanRuns.periodId, periodId),
            inArray(eprScanRuns.status, ["QUEUED", "RUNNING", "PAUSED"])
          )
        );
      if (runs.length) throw new EprError("period_scan_in_progress", 409);
      if (!period.accountingBasis || !period.accountingEventType)
        throw new EprError("accounting_configuration_required");
      const data = await this.snapshotData(periodId, tx);
      if (data.unresolved) throw new EprError("period_review_required", 409);
      const [decision] = await tx
        .insert(eprReviewDecisions)
        .values({ periodId, action: "close", reason: "Időszak lezárása", operator })
        .returning();
      data.decisions.push(decision);
      const frozen = JSON.parse(
        JSON.stringify({ ...data, period: { ...data.period, status: "CLOSED" } })
      );
      const digest = createHash("sha256").update(JSON.stringify(frozen)).digest("hex");
      const [snapshot] = await tx
        .insert(eprPeriodSnapshots)
        .values({ periodId, data: frozen, digest })
        .returning();
      await tx.update(eprPeriods).set({ status: "CLOSED" }).where(eq(eprPeriods.id, periodId));
      return snapshot;
    });
  }
  async export(periodId: string) {
    const data = (await this.summary(periodId)) as Awaited<
      ReturnType<EprService["snapshotData"]>
    > & { digest?: string };
    const workbook = new ExcelJS.Workbook();
    workbook.creator = "DanettiPriceScraper";
    const add = (name: string, rows: unknown[]) => {
      const sheet = workbook.addWorksheet(name);
      const records = rows as Record<string, unknown>[];
      const keys = [...new Set(records.flatMap((row) => Object.keys(row)))];
      sheet.columns = keys.map((key) => ({ header: key, key, width: 28 }));
      for (const record of records)
        sheet.addRow(
          Object.fromEntries(
            keys.map((key) => {
              const value = record[key];
              return [
                key,
                value === null || value === undefined
                  ? ""
                  : typeof value === "object"
                    ? JSON.stringify(value)
                    : String(value),
              ];
            })
          )
        );
      sheet.views = [{ state: "frozen", ySplit: 1 }];
      if (keys.length)
        sheet.autoFilter = {
          from: { row: 1, column: 1 },
          to: { row: Math.max(1, records.length + 1), column: keys.length },
        };
      sheet.getRow(1).font = { bold: true };
    };
    const summary = workbook.addWorksheet("Summary");
    summary.addRow(["Időszak", data.period.code]);
    summary.addRow(["Állapot", data.period.status]);
    summary.addRow(["Pillanatkép SHA-256", data.digest ?? "Nyitott időszak"]);
    summary.addRow(["Elszámolási alap", data.period.accountingBasis]);
    summary.addRow(["Nem elszámolt beszerzések", data.unresolved]);
    summary.addRow(["Anyag", "kg"]);
    for (const [material, kg] of Object.entries(data.totals)) summary.addRow([material, kg]);
    add(
      "Purchases",
      data.details.map((d) => d.purchase)
    );
    add(
      "Documents",
      data.details.flatMap((d) =>
        d.documents.map((document) => ({
          ...document.business,
          purchaseId: d.purchase.id,
          source: document.source,
        }))
      )
    );
    add(
      "Invoice lines",
      data.details.flatMap((d) => d.extractedLines)
    );
    add("Material calculations", data.entries);
    add(
      "Manual overrides",
      data.decisions.filter((d) => d.action.includes("override") || d.action === "remember_mapping")
    );
    add("Review decisions", data.decisions);
    add(
      "Excluded candidates",
      data.details.filter((d) => d.purchase.status === "excluded").map((d) => d.purchase)
    );
    add("Rule versions", data.rules);
    const bytes = Buffer.from(await workbook.xlsx.writeBuffer());
    const hash = createHash("sha256").update(bytes).digest("hex");
    await this.client.db
      .insert(eprExports)
      .values({ periodId, snapshotDigest: data.digest ?? null, hash });
    return { bytes, filename: `EPR-${data.period.code}.xlsx` };
  }
  async reprocess(documentId: string, periodId: string) {
    const [period] = await this.client.db
      .select()
      .from(eprPeriods)
      .where(eq(eprPeriods.id, periodId));
    if (!period || period.status === "CLOSED") throw new EprError("period_closed", 409);
    const document = await this.document(documentId);
    const [business] = await this.client.db
      .select()
      .from(businessDocuments)
      .where(eq(businessDocuments.sourceDocumentId, documentId));
    if (business) {
      const [link] = await this.client.db
        .select()
        .from(purchaseDocuments)
        .where(eq(purchaseDocuments.businessDocumentId, business.id));
      const detail = await this.detail(link.purchaseId);
      if (
        detail.purchase.periodId !== periodId ||
        detail.purchase.status === "excluded" ||
        detail.lines.length
      )
        throw new EprError("document_already_reviewed", 409);
      const bytes = await this.archive.read(document.hash);
      const text =
        document.mime === "application/pdf"
          ? await extractPdfText(bytes)
          : bytes.toString("utf8").slice(0, 120_000);
      let model: string | null = null;
      const invoice = await this.intelligence.extractInvoice({
        documentId,
        filename: document.filename,
        text,
        pdf: document.mime === "application/pdf" ? bytes : undefined,
        onModel: (selected) => {
          model = selected;
        },
      });
      await this.manualExtraction(documentId, periodId, invoice, "openai-chatgpt-plan");
      await this.client.db
        .update(sourceDocuments)
        .set({ provider: "openai-chatgpt-plan", model, extractionVersion: EXTRACTOR_VERSION })
        .where(eq(sourceDocuments.id, documentId));
      return this.document(documentId);
    }
    await this.client.db
      .update(sourceDocuments)
      .set({ status: "pending" })
      .where(eq(sourceDocuments.id, documentId));
    return this.importDocument(periodId, {
      bytes: await this.archive.read(document.hash),
      filename: document.filename,
      mime: document.mime,
    });
  }
  async manualExtraction(
    documentId: string,
    periodId: string,
    input: unknown,
    extractor = "manual"
  ) {
    const invoice = invoiceSchema.safeParse(input);
    if (!invoice.success) throw new EprError("document_extraction_schema_invalid");
    const [old] = await this.client.db
      .select()
      .from(businessDocuments)
      .where(eq(businessDocuments.sourceDocumentId, documentId));
    if (!old) {
      await this.persistInvoice(periodId, documentId, invoice.data, false);
      return;
    }
    const [link] = await this.client.db
      .select()
      .from(purchaseDocuments)
      .where(eq(purchaseDocuments.businessDocumentId, old.id));
    if (!link) throw new EprError("purchase_not_found", 404);
    await this.locked(periodId, async (tx) => {
      const [purchase] = await tx.select().from(purchases).where(eq(purchases.id, link.purchaseId));
      if (purchase.periodId !== periodId || !["potential", "review"].includes(purchase.status))
        throw new EprError("document_already_accounted", 409);
      const lines = await tx
        .select()
        .from(businessDocumentLines)
        .where(eq(businessDocumentLines.businessDocumentId, old.id));
      if (lines.length) throw new EprError("document_lines_already_present", 409);
      const identity =
        invoice.data.supplier.taxId && invoice.data.invoiceNumber && invoice.data.customerIdentity
          ? JSON.stringify([
              invoice.data.supplier.taxId,
              invoice.data.invoiceNumber,
              invoice.data.documentType,
              invoice.data.customerIdentity,
            ])
          : null;
      const conflicts = identity
        ? (
            await tx
              .select()
              .from(businessDocuments)
              .where(eq(businessDocuments.identity, identity))
          ).filter((d) => d.id !== old.id && d.data.operatorExcluded !== true)
        : [];
      if (conflicts.length)
        await this.invalidateConflictingPurchases(
          tx,
          conflicts.map((d) => d.id)
        );
      if (conflicts.length)
        await tx
          .update(businessDocuments)
          .set({ conflict: true })
          .where(
            inArray(
              businessDocuments.id,
              conflicts.map((d) => d.id)
            )
          );
      await tx
        .update(businessDocuments)
        .set({
          identity,
          supplierIdentity: invoice.data.supplier.taxId,
          conflict: conflicts.length > 0,
          data: invoice.data as unknown as Record<string, unknown>,
          invoiceNumber: invoice.data.invoiceNumber,
          documentType: invoice.data.documentType,
        })
        .where(eq(businessDocuments.id, old.id));
      await tx
        .update(purchases)
        .set({
          supplier: invoice.data.supplier.name ?? purchase.supplier,
          supplierIdentity: invoice.data.supplier.taxId,
          reference: invoice.data.invoiceNumber,
        })
        .where(eq(purchases.id, purchase.id));
      for (const line of invoice.data.lines) {
        const [businessLine] = await tx
          .insert(businessDocumentLines)
          .values({
            businessDocumentId: old.id,
            sourceLineId: line.sourceLineId,
            data: { ...line, provenance: { ...line.provenance, documentId } },
          })
          .returning();
        await tx.insert(purchaseLines).values({
          purchaseId: purchase.id,
          businessDocumentLineId: businessLine.id,
          description: line.description,
          supplierSku: line.supplierSku,
          quantity: line.quantity,
          unit: line.unit,
          safeErrorCode: "operator_review_required",
        });
      }
      await tx.insert(eprReviewDecisions).values({
        periodId,
        purchaseId: purchase.id,
        action: extractor === "manual" ? "manual_extraction" : "ai_reprocess",
        reason:
          extractor === "manual"
            ? "Operátor által rögzített számlaadatok"
            : "AI-val újrafeldolgozott, operátori ellenőrzésre váró számlaadatok",
        oldValue: old.data,
        newValue: invoice.data,
        operator: extractor === "manual" ? "local-operator" : "system",
      });
      await tx
        .update(sourceDocuments)
        .set({
          extraction: invoice.data as unknown as Record<string, unknown>,
          status: "processed",
          provider: "manual",
          extractionVersion: EXTRACTOR_VERSION,
          safeErrorCode: null,
        })
        .where(eq(sourceDocuments.id, documentId));
    });
  }
  async scanEvent(runId: string, code: string, data: Record<string, unknown> = {}) {
    await this.client.db.insert(eprScanRunEvents).values({ runId, code, data });
  }
  async retryUnavailableDocuments(periodId: string) {
    const items = await this.listPurchases(periodId);
    for (const purchase of items.filter((p) => ["potential", "review"].includes(p.status))) {
      const detail = await this.detail(purchase.id);
      if (detail.lines.length) continue;
      for (const document of detail.documents) {
        if (
          ![
            "chatgpt_reauthorization_required",
            "chatgpt_model_selection_required",
            "chatgpt_temporarily_unavailable",
          ].includes(document.source.safeErrorCode ?? "")
        )
          continue;
        try {
          await this.reprocess(document.source.id, periodId);
        } catch (error) {
          if (safeCode(error).startsWith("chatgpt_")) return;
        }
      }
    }
  }
}

async function extractPdfText(bytes: Buffer) {
  const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const task = getDocument({ data: new Uint8Array(bytes), useSystemFonts: false });
  const timer = setTimeout(() => void task.destroy(), 30_000);
  try {
    const pdf = await task.promise;
    if (pdf.numPages > 300) throw new EprError("document_page_limit");
    let text = "";
    for (let page = 1; page <= pdf.numPages; page++) {
      const content = await (await pdf.getPage(page)).getTextContent();
      text +=
        `\n[page ${page}]\n` +
        content.items.map((item) => ("str" in item ? item.str : "")).join(" ");
      if (text.length > 120_000) break;
    }
    return text.slice(0, 120_000);
  } finally {
    clearTimeout(timer);
    await task.destroy();
  }
}
