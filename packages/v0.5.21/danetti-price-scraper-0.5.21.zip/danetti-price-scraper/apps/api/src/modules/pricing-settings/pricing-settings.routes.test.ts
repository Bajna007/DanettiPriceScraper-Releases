import assert from "node:assert/strict";
import type { ExchangeRate, NewExchangeRate } from "@danetti/db";
import Fastify from "fastify";
import { registerPricingSettingsRoutes } from "./pricing-settings.routes.js";

const rates: ExchangeRate[] = [];
const now = new Date("2026-06-11T12:00:00.000Z");
const server = Fastify({ logger: false });

await registerPricingSettingsRoutes(server, {
  now: () => now,
  repository: {
    async getLatestExchangeRate() {
      return rates.at(-1) ?? null;
    },
    async createExchangeRate(input: NewExchangeRate) {
      const rate: ExchangeRate = {
        id: `11111111-1111-4111-8111-${String(rates.length + 1).padStart(12, "0")}`,
        source: input.source,
        eurHufRate: input.eurHufRate,
        effectiveAt: input.effectiveAt,
        createdBy: input.createdBy ?? null,
        notes: input.notes ?? null,
        createdAt: now,
      };
      rates.push(rate);
      return rate;
    },
  },
});

try {
  const empty = await server.inject({ method: "GET", url: "/pricing-settings/current" });
  assert.equal(empty.statusCode, 200);
  assert.equal(empty.json().eurHufRate, null);

  const saved = await server.inject({
    method: "POST",
    url: "/pricing-settings/exchange-rate",
    payload: { eurHufRate: 405.25, notes: "manual rate" },
  });
  assert.equal(saved.statusCode, 201);
  assert.equal(saved.json().eurHufRate, 405.25);
  assert.equal(saved.json().source, "manual_operator");
  assert.equal(saved.json().effectiveAt, now.toISOString());

  const current = await server.inject({ method: "GET", url: "/pricing-settings/current" });
  assert.equal(current.statusCode, 200);
  assert.equal(current.json().eurHufRate, 405.25);
  assert.equal(current.json().notes, "manual rate");

  const missingRate = await server.inject({
    method: "POST",
    url: "/pricing-settings/exchange-rate",
    payload: {},
  });
  assert.equal(missingRate.statusCode, 400);
  assert.equal(missingRate.json().error.code, "pricing_exchange_rate_required");

  const sensitive = await server.inject({
    method: "POST",
    url: "/pricing-settings/exchange-rate",
    payload: { eurHufRate: 405.25, password: "do-not-return" },
  });
  assert.equal(sensitive.statusCode, 400);
  assert.equal(sensitive.json().error.code, "sensitive_field");
  assert.equal(JSON.stringify(sensitive.json()).includes("do-not-return"), false);
} finally {
  await server.close();
}

console.log("Pricing settings route tests passed");
