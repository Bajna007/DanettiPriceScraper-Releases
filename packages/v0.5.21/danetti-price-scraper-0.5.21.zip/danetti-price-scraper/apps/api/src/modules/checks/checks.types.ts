export class CheckValidationError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus = 400
  ) {
    super(message);
    this.name = "CheckValidationError";
  }
}

export class CheckQueueError extends Error {
  constructor(message = "Supplier check queue unavailable") {
    super(message);
    this.name = "CheckQueueError";
  }
}
