import type { SupplierCheckJobData } from "@danetti/shared";
import type { SupplierMappingListItem } from "../supplier-mappings/supplier-mappings.repository.js";
import { CheckValidationError } from "./checks.types.js";

const FORBIDDEN_DRY_RUN_BODY_KEYS =
  /(url|domain|credential|password|secret|token|cookie|session|storageState|connectorId)/i;
const DUMMY_CONNECTOR_ID = "dummy-supplier";

export function validateDryRunRequestBody(input: unknown): void {
  if (input === undefined || input === null) return;
  if (typeof input !== "object" || Array.isArray(input)) {
    throw new CheckValidationError(
      "invalid_body",
      "Dry-run request body must be an object if provided"
    );
  }
  for (const [key, value] of Object.entries(input as Record<string, unknown>)) {
    if (FORBIDDEN_DRY_RUN_BODY_KEYS.test(key)) {
      throw new CheckValidationError(
        "forbidden_field",
        `Field is not allowed for dry-run checks: ${key}`
      );
    }
    if (value !== null && typeof value === "object") validateDryRunRequestBody(value);
  }
}

export function buildDryRunSupplierJob(supplierId: string): SupplierCheckJobData {
  return {
    jobType: "dry_run_supplier_check",
    supplierId,
    supplierCode: supplierId === DUMMY_CONNECTOR_ID ? "dummy" : undefined,
    connectorId: DUMMY_CONNECTOR_ID,
    supplierArticleNumber: "DUMMY-ARTICLE",
    lookupStrategy: "search_result",
    dryRun: true,
    requestedAt: new Date().toISOString(),
  };
}

export function buildDryRunMappingJob(mapping: SupplierMappingListItem): SupplierCheckJobData {
  return {
    jobType: "dry_run_mapping_check",
    supplierId: mapping.supplierId,
    supplierCode: mapping.supplierCode,
    supplierMappingId: mapping.id,
    catalogProductId: mapping.catalogProductId,
    connectorId: DUMMY_CONNECTOR_ID,
    supplierArticleNumber: mapping.supplierArticleNumber,
    lookupStrategy: mapping.lookupStrategy,
    dryRun: true,
    requestedAt: new Date().toISOString(),
  };
}

export function validateUuid(value: string, field: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new CheckValidationError("invalid_uuid", `${field} must be a UUID`);
  }
}
