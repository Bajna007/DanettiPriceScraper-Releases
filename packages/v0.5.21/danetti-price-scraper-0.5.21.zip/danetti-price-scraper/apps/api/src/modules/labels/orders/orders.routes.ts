import type { FastifyInstance } from "fastify";
import {
  bodyRecord,
  handleLabelError,
  paramsRecord,
  queryRecord,
  type LabelRouteContext,
} from "../route-utils.js";

export async function registerLabelOrderRoutes(
  server: FastifyInstance,
  context: LabelRouteContext
): Promise<void> {
  server.get("/label-orders", async (request, reply) => {
    try {
      const q = queryRecord(request.query);
      return { items: await context.getService().listOrders(q.brand as never) };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.get("/label-orders/active", async (request, reply) => {
    try {
      const q = queryRecord(request.query);
      return { item: await context.getService().getActiveOrder(q.brand as never) };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/label-orders", async (request, reply) => {
    try {
      return reply
        .code(201)
        .send({ item: await context.getService().createOrder(bodyRecord(request.body)) });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.get("/label-orders/:id", async (request, reply) => {
    try {
      return { item: await context.getService().getOrder(paramsRecord(request.params).id!) };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.patch("/label-orders/:id", async (request, reply) => {
    try {
      return {
        item: await context
          .getService()
          .patchOrder(paramsRecord(request.params).id!, bodyRecord(request.body)),
      };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/label-orders/:id/items", async (request, reply) => {
    try {
      return reply.code(201).send({
        item: await context
          .getService()
          .addOrderItem(paramsRecord(request.params).id!, bodyRecord(request.body)),
      });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.patch("/label-orders/:id/items/:itemId", async (request, reply) => {
    try {
      const p = paramsRecord(request.params);
      return {
        item: await context.getService().patchOrderItem(p.id!, p.itemId!, bodyRecord(request.body)),
      };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.delete("/label-orders/:id/items/:itemId", async (request, reply) => {
    try {
      const p = paramsRecord(request.params);
      return { item: await context.getService().deleteOrderItem(p.id!, p.itemId!) };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/label-orders/:id/freeze", async (request, reply) => {
    try {
      return { item: await context.getService().freezeOrder(paramsRecord(request.params).id!) };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/label-orders/:id/export", async (request, reply) => {
    try {
      return reply.code(201).send({
        item: await context
          .getService()
          .exportOrder(paramsRecord(request.params).id!, bodyRecord(request.body)),
      });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
}
