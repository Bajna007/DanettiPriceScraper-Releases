import type { FastifyReply } from "fastify";
import { LabelStudioError, type LabelStudioService } from "./labels.service.js";

export interface LabelRouteContext {
  getService: () => LabelStudioService;
}

export function bodyRecord(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}
export function queryRecord(value: unknown): Record<string, unknown> {
  return bodyRecord(value);
}
export function paramsRecord(value: unknown): Record<string, string> {
  return bodyRecord(value) as Record<string, string>;
}

export function handleLabelError(reply: FastifyReply, error: unknown): FastifyReply {
  if (error instanceof LabelStudioError)
    return reply
      .code(error.statusCode)
      .send({ error: { code: error.code, message: error.message } });
  const message = error instanceof Error ? error.message : "A Címkestúdió művelete sikertelen.";
  return reply.code(500).send({ error: { code: "label_studio_failed", message } });
}
