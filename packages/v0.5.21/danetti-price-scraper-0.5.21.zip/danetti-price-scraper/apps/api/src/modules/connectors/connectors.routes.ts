import { getConnector, getConnectorMetadata, toConnectorMetadata } from "@danetti/connectors";
import type { FastifyInstance } from "fastify";

interface IdParams {
  id: string;
}

export async function registerConnectorRoutes(server: FastifyInstance): Promise<void> {
  server.get("/connectors", async () => ({
    items: getConnectorMetadata().map(withSafetyStatus),
  }));

  server.get("/connectors/:id", async (request, reply) => {
    const params = request.params as IdParams;
    const connector = getConnector(params.id);
    if (connector === undefined) {
      return reply.code(404).send({ error: { code: "not_found", message: "Connector not found" } });
    }

    return withSafetyStatus(toConnectorMetadata(connector));
  });
}

function withSafetyStatus<T extends object>(metadata: T): T & { safetyStatus: "scaffold_only" } {
  return { ...metadata, safetyStatus: "scaffold_only" };
}
