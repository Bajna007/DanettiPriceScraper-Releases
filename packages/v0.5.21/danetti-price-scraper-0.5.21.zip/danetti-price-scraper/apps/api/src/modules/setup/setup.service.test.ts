import assert from "node:assert/strict";
import { getSetupStatus } from "./setup.service.js";

const status = await getSetupStatus({
  now: () => new Date("2026-01-01T00:00:00.000Z"),
  getHealth: async () => ({
    status: "degraded",
    api: { status: "ok" },
    database: { status: "ok", message: "DB ok" },
    redis: { status: "unavailable", message: "Redis down" },
    worker: { status: "not_checked", message: "Worker not checked" },
    launcher: { runId: null },
  }),
});

assert.equal(status.status, "degraded");
assert.equal(status.generatedAt, "2026-01-01T00:00:00.000Z");
assert.equal(status.steps.length, 4);
assert.equal(status.steps[0]?.key, "api");
assert.equal(status.steps[2]?.status, "unavailable");
assert.ok(status.commands.includes("npm.cmd run local:web"));
assert.ok(status.safetyNotes.some((note) => note.includes("WooCommerce")));

console.log("Setup status tests passed");
