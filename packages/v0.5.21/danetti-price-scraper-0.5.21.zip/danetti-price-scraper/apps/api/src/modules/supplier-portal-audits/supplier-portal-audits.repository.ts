import {
  supplierCheckSettings,
  suppliers,
  supplierPortalAuditChecks,
  supplierPortalAuditEvidenceNotes,
  supplierPortalAudits,
  type DanettiDatabase,
  type NewSupplierPortalAudit,
  type NewSupplierPortalAuditCheck,
  type NewSupplierPortalAuditEvidenceNote,
  type Supplier,
  type SupplierCheckSettings,
  type SupplierPortalAudit,
  type SupplierPortalAuditCheck,
  type SupplierPortalAuditEvidenceNote,
} from "@danetti/db";
import { and, desc, eq, type SQL } from "drizzle-orm";
import type {
  PortalAuditDetail,
  PortalAuditListFilters,
  PortalAuditListItem,
} from "./supplier-portal-audits.types.js";

export class SupplierPortalAuditsRepository {
  constructor(private readonly db: DanettiDatabase) {}

  async transaction<T>(
    handler: (repository: SupplierPortalAuditsRepository) => Promise<T>
  ): Promise<T> {
    return this.db.transaction(async (tx) =>
      handler(new SupplierPortalAuditsRepository(tx as unknown as DanettiDatabase))
    );
  }

  async list(input: PortalAuditListFilters): Promise<PortalAuditListItem[]> {
    const conditions: SQL[] = [];
    if (input.supplierId) conditions.push(eq(supplierPortalAudits.supplierId, input.supplierId));
    if (input.status) conditions.push(eq(supplierPortalAudits.status, input.status));

    const rows = await this.db
      .select({
        audit: supplierPortalAudits,
        supplierCode: suppliers.code,
        supplierName: suppliers.name,
      })
      .from(supplierPortalAudits)
      .innerJoin(suppliers, eq(supplierPortalAudits.supplierId, suppliers.id))
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(desc(supplierPortalAudits.createdAt))
      .limit(input.limit)
      .offset(input.offset);

    return rows.map((row) => ({
      ...row.audit,
      supplierCode: row.supplierCode,
      supplierName: row.supplierName,
    }));
  }

  async getSupplierById(id: string): Promise<Supplier | null> {
    const [supplier] = await this.db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1);
    return supplier ?? null;
  }

  async getCheckSettingsBySupplierId(supplierId: string): Promise<SupplierCheckSettings | null> {
    const [settings] = await this.db
      .select()
      .from(supplierCheckSettings)
      .where(eq(supplierCheckSettings.supplierId, supplierId))
      .limit(1);
    return settings ?? null;
  }

  async getById(id: string): Promise<PortalAuditDetail | null> {
    const [row] = await this.db
      .select({
        audit: supplierPortalAudits,
        supplierCode: suppliers.code,
        supplierName: suppliers.name,
      })
      .from(supplierPortalAudits)
      .innerJoin(suppliers, eq(supplierPortalAudits.supplierId, suppliers.id))
      .where(eq(supplierPortalAudits.id, id))
      .limit(1);
    if (!row) return null;
    const [checks, evidenceNotes] = await Promise.all([
      this.listChecks(id),
      this.listEvidenceNotes(id),
    ]);
    return {
      ...row.audit,
      supplierCode: row.supplierCode,
      supplierName: row.supplierName,
      checks,
      evidenceNotes,
    };
  }

  async create(input: NewSupplierPortalAudit): Promise<SupplierPortalAudit> {
    const [audit] = await this.db.insert(supplierPortalAudits).values(input).returning();
    if (!audit) throw new Error("Failed to create supplier portal audit");
    return audit;
  }

  async update(
    id: string,
    input: Partial<NewSupplierPortalAudit>
  ): Promise<SupplierPortalAudit | null> {
    const [audit] = await this.db
      .update(supplierPortalAudits)
      .set(input)
      .where(eq(supplierPortalAudits.id, id))
      .returning();
    return audit ?? null;
  }

  async createChecks(rows: NewSupplierPortalAuditCheck[]): Promise<void> {
    if (rows.length) await this.db.insert(supplierPortalAuditChecks).values(rows);
  }

  async listChecks(auditId: string): Promise<SupplierPortalAuditCheck[]> {
    return this.db
      .select()
      .from(supplierPortalAuditChecks)
      .where(eq(supplierPortalAuditChecks.auditId, auditId));
  }

  async updateCheck(
    auditId: string,
    id: string,
    input: Partial<NewSupplierPortalAuditCheck>
  ): Promise<SupplierPortalAuditCheck | null> {
    const [check] = await this.db
      .update(supplierPortalAuditChecks)
      .set({ ...input, updatedAt: new Date() })
      .where(
        and(eq(supplierPortalAuditChecks.auditId, auditId), eq(supplierPortalAuditChecks.id, id))
      )
      .returning();
    return check ?? null;
  }

  async createEvidenceNote(
    input: NewSupplierPortalAuditEvidenceNote
  ): Promise<SupplierPortalAuditEvidenceNote> {
    const [note] = await this.db.insert(supplierPortalAuditEvidenceNotes).values(input).returning();
    if (!note) throw new Error("Failed to create supplier portal audit evidence note");
    return note;
  }

  async listEvidenceNotes(auditId: string): Promise<SupplierPortalAuditEvidenceNote[]> {
    return this.db
      .select()
      .from(supplierPortalAuditEvidenceNotes)
      .where(eq(supplierPortalAuditEvidenceNotes.auditId, auditId))
      .orderBy(desc(supplierPortalAuditEvidenceNotes.createdAt));
  }
}
