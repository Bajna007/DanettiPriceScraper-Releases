import type { FastifyInstance } from "fastify";
import {
  bodyRecord,
  handleLabelError,
  paramsRecord,
  queryRecord,
  type LabelRouteContext,
} from "../route-utils.js";

export async function registerLabelDesignRoutes(
  server: FastifyInstance,
  context: LabelRouteContext
): Promise<void> {
  server.get("/labels/overview", async (_request, reply) => {
    try {
      return { items: await context.getService().getOverview() };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.get("/labels", async (request, reply) => {
    try {
      return { items: await context.getService().listDesigns(queryRecord(request.query)) };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/labels", async (request, reply) => {
    try {
      return reply
        .code(201)
        .send({ item: await context.getService().createDesign(bodyRecord(request.body)) });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.patch("/labels", async (request, reply) => {
    try {
      const body = bodyRecord(request.body);
      const updates = Array.isArray(body.updates) ? body.updates : [];
      const items = [];
      for (const update of updates) {
        const item = bodyRecord(update);
        items.push(await context.getService().patchDesign(String(item.id ?? ""), item));
      }
      return { items };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.get("/labels/:id", async (request, reply) => {
    try {
      return { item: await context.getService().getDesign(paramsRecord(request.params).id!) };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.patch("/labels/:id", async (request, reply) => {
    try {
      return {
        item: await context
          .getService()
          .patchDesign(paramsRecord(request.params).id!, bodyRecord(request.body)),
      };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/labels/:id/duplicate", async (request, reply) => {
    try {
      return reply.code(201).send({
        item: await context
          .getService()
          .duplicateDesign(paramsRecord(request.params).id!, bodyRecord(request.body)),
      });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/labels/:id/versions", async (request, reply) => {
    try {
      return reply.code(201).send({
        item: await context
          .getService()
          .createDesignVersion(paramsRecord(request.params).id!, bodyRecord(request.body)),
      });
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.get("/labels/:id/versions", async (request, reply) => {
    try {
      return {
        items: await context.getService().listDesignVersions(paramsRecord(request.params).id!),
      };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/labels/:id/versions/:versionId/restore", async (request, reply) => {
    try {
      const params = paramsRecord(request.params);
      return {
        item: await context.getService().restoreDesignVersion(params.id!, params.versionId!),
      };
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.post("/labels/:id/validate", async (request, reply) => {
    try {
      return await context.getService().validateDesign(paramsRecord(request.params).id!);
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
  server.get("/labels/:id/preview.svg", async (request, reply) => {
    try {
      const query = queryRecord(request.query);
      const svg = await context
        .getService()
        .previewSvg(paramsRecord(request.params).id!, query.outlined === "true");
      return reply
        .header("content-type", "image/svg+xml; charset=utf-8")
        .header("cache-control", "no-store")
        .send(svg);
    } catch (error) {
      return handleLabelError(reply, error);
    }
  });
}
