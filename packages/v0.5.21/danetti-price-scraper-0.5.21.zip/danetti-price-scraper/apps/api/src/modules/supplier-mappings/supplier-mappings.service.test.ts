import assert from "node:assert/strict";

import {
  buildDvgAutoPairDirectUrl,
  buildDvgMappingReviewPreview,
  buildMappingSuggestions,
  readDvgAutoPairCandidate,
  validateDvgMappingReviewPreviewInput,
  validateCreateSupplierMappingInput,
} from "./supplier-mappings.service.js";
import { SupplierMappingValidationError } from "./supplier-mappings.types.js";

const productId = "11111111-1111-4111-8111-111111111111";
const supplierId = "22222222-2222-4222-8222-222222222222";

const mapping = validateCreateSupplierMappingInput({
  catalogProductId: productId,
  supplierId,
  supplierArticleNumber: "421944065151",
  lookupStrategy: "search_result",
});
assert.equal(mapping.catalogProductId, productId);
assert.equal(mapping.priority, 100);
assert.equal(mapping.enabled, true);
assert.equal(mapping.matchValidationMode, "exact_article_number");

assert.throws(
  () =>
    validateCreateSupplierMappingInput({
      catalogProductId: productId,
      supplierId,
      supplierArticleNumber: "421944065151",
      lookupStrategy: "search_result",
      directUrl: "https://example.test/product",
    }),
  SupplierMappingValidationError
);

const searchThenDetailMapping = validateCreateSupplierMappingInput({
  catalogProductId: productId,
  supplierId,
  supplierArticleNumber: "5067364",
  lookupStrategy: "search_then_detail",
  directUrl: "https://b2bnet.lfspareparts724.com/en/product/example/opaque/RisultatoRicercaRapida",
});
assert.equal(searchThenDetailMapping.directUrl?.includes("/en/product/"), true);

assert.throws(
  () =>
    validateCreateSupplierMappingInput({
      catalogProductId: productId,
      supplierId,
      supplierArticleNumber: "421944065151",
      lookupStrategy: "direct_url",
      sessionCookie: "secret",
    }),
  SupplierMappingValidationError
);

const suggestions = buildMappingSuggestions({
  product: {
    id: productId,
    sku: "421944065151_SAE125",
    suggestedSupplierArticle: "421944065151",
    internalSkuSuffix: "SAE125",
  },
  suppliers: [{ id: supplierId, code: "italian", name: "Italian B2B" }],
});
assert.equal(suggestions.suggestedMappings.length, 1);
assert.equal(suggestions.suggestedMappings[0]?.suggestedSupplierArticleNumber, "421944065151");
assert.equal(suggestions.suggestedMappings[0]?.defaultLookupStrategy, "search_result");

const emptySuggestions = buildMappingSuggestions({
  product: {
    id: productId,
    sku: "NO-SUGGESTION",
    suggestedSupplierArticle: null,
    internalSkuSuffix: null,
  },
  suppliers: [{ id: supplierId, code: "italian", name: "Italian B2B" }],
});
assert.equal(emptySuggestions.suggestedMappings.length, 0);
assert.equal(emptySuggestions.reason, "missing_suggested_supplier_article");

const dvgAutoPairFromSuggested = readDvgAutoPairCandidate({
  sku: "OTHER_INTERNAL",
  suggestedSupplierArticle: "8f11918",
});
assert.equal(dvgAutoPairFromSuggested?.supplierArticleNumber, "8F11918");
assert.equal(dvgAutoPairFromSuggested?.source, "suggested_supplier_article");

const dvgAutoPairFromSku = readDvgAutoPairCandidate({
  sku: "9V0_BI001",
  suggestedSupplierArticle: null,
});
assert.equal(dvgAutoPairFromSku?.supplierArticleNumber, "9V0");
assert.equal(dvgAutoPairFromSku?.source, "sku_prefix");
const dvgAutoPairFromSlashSku = readDvgAutoPairCandidate({
  sku: "8F705/A_F413",
  suggestedSupplierArticle: null,
});
assert.equal(dvgAutoPairFromSlashSku?.supplierArticleNumber, "8F705/A");
assert.equal(dvgAutoPairFromSlashSku?.source, "sku_prefix");
assert.equal(
  buildDvgAutoPairDirectUrl("8F11918"),
  "https://devecchigiuseppesrl.com/e-commerce/welcome/ordini/dettagli.asp?codice-articolo=8F11918"
);
assert.equal(buildDvgAutoPairDirectUrl("8F705/A").includes("8F705%2FA"), true);
assert.equal(
  readDvgAutoPairCandidate({ sku: "421944065151_SAE125", suggestedSupplierArticle: null }),
  null
);

const exactPreview = buildDvgMappingReviewPreview({
  preview: validateDvgMappingReviewPreviewInput({
    expectedArticle: "CS-A2200247",
    parsedDvgArticle: "CS-A2200247",
    parsedOriginalCode: "A2200247",
    currentPriceNetEur: 4.72,
    currency: "EUR",
  }),
});
assert.equal(exactPreview.outcome, "trusted_exact_mapping");
assert.equal(exactPreview.priceSnapshotAllowed, true);

const originalCodePreview = buildDvgMappingReviewPreview({
  preview: validateDvgMappingReviewPreviewInput({
    expectedArticle: "A2200247",
    parsedDvgArticle: "CS-A2200247",
    parsedOriginalCode: "A2200247",
    currentPriceNetEur: 4.72,
    currency: "EUR",
  }),
});
assert.equal(originalCodePreview.outcome, "needs_review_original_code_match");
assert.equal(originalCodePreview.priceSnapshotAllowed, false);
assert.equal(originalCodePreview.suggestedSupplierArticle, "CS-A2200247");

const missingPricePreview = buildDvgMappingReviewPreview({
  preview: validateDvgMappingReviewPreviewInput({
    expectedArticle: "CS-A2200247",
    parsedDvgArticle: "CS-A2200247",
    parsedOriginalCode: "A2200247",
    currency: "EUR",
  }),
});
assert.equal(missingPricePreview.outcome, "trusted_exact_mapping");
assert.equal(missingPricePreview.priceSnapshotAllowed, false);
assert.equal(missingPricePreview.snapshotGate.reason, "current_price_missing");

assert.throws(
  () =>
    validateDvgMappingReviewPreviewInput({
      expectedArticle: "CS-A2200247",
      parsedDvgArticle: "CS-A2200247",
      ["DVG_" + "PASSWORD"]: "x",
    }),
  SupplierMappingValidationError
);

assert.deepEqual(
  readDvgAutoPairCandidate({ sku: "1755603__8W17201_W051", suggestedSupplierArticle: "1755603" }),
  { supplierArticleNumber: "8W17201", source: "sku_article" }
);
assert.equal(
  readDvgAutoPairCandidate({ sku: "8W17201__8S29/1", suggestedSupplierArticle: null }),
  null
);
console.log("Supplier mapping validation tests passed");
