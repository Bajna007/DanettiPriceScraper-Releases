import type { FastifyInstance } from "fastify";
import { AppUpdateError, AppUpdateService } from "./app-update.service.js";

export async function registerAppUpdateRoutes(server: FastifyInstance): Promise<void> {
  const service = new AppUpdateService();
  server.get("/app-update", async (_request, reply) => {
    try {
      return { item: await service.check(false) };
    } catch (error) {
      return handleUpdateError(reply, error);
    }
  });
  server.post("/app-update/check", async (_request, reply) => {
    try {
      return { item: await service.check(true) };
    } catch (error) {
      return handleUpdateError(reply, error);
    }
  });
  server.get("/app-update/install-status", async (_request, reply) => {
    try {
      return { item: await service.installStatus() };
    } catch (error) {
      return handleUpdateError(reply, error);
    }
  });
  server.post("/app-update/install", async (request, reply) => {
    try {
      const body = request.body as { version?: unknown } | undefined;
      return reply.code(202).send({
        item: await service.queueInstall(
          typeof body?.version === "string" ? body.version : undefined
        ),
      });
    } catch (error) {
      return handleUpdateError(reply, error);
    }
  });
}

function handleUpdateError(
  reply: { code: (status: number) => { send: (body: unknown) => unknown } },
  error: unknown
) {
  if (error instanceof AppUpdateError)
    return reply
      .code(error.statusCode)
      .send({ error: { code: error.code, message: error.message } });
  const message = error instanceof Error ? error.message : "A frissítés ellenőrzése sikertelen.";
  return reply.code(500).send({ error: { code: "app_update_failed", message } });
}
