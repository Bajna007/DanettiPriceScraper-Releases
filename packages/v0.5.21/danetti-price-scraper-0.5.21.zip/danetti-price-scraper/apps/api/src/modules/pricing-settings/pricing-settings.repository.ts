import {
  exchangeRates,
  type DanettiDatabase,
  type ExchangeRate,
  type NewExchangeRate,
} from "@danetti/db";
import { desc } from "drizzle-orm";

export interface PricingSettingsRepositoryLike {
  getLatestExchangeRate(): Promise<ExchangeRate | null>;
  createExchangeRate(input: NewExchangeRate): Promise<ExchangeRate>;
}

export class PricingSettingsRepository implements PricingSettingsRepositoryLike {
  constructor(private readonly db: DanettiDatabase) {}

  async getLatestExchangeRate(): Promise<ExchangeRate | null> {
    const [rate] = await this.db
      .select()
      .from(exchangeRates)
      .orderBy(desc(exchangeRates.effectiveAt), desc(exchangeRates.createdAt))
      .limit(1);
    return rate ?? null;
  }

  async createExchangeRate(input: NewExchangeRate): Promise<ExchangeRate> {
    const [rate] = await this.db.insert(exchangeRates).values(input).returning();
    if (rate === undefined) throw new Error("Failed to create exchange rate");
    return rate;
  }
}
