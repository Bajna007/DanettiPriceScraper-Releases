import { Redis } from "ioredis";

export function getRedisUrl(): string {
  return process.env.REDIS_URL?.trim() || "redis://localhost:6379";
}

export function createRedisConnection() {
  return new Redis(getRedisUrl(), {
    connectTimeout: 2_000,
    enableReadyCheck: false,
    maxRetriesPerRequest: 1,
  });
}
