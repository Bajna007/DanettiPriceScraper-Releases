import { Queue } from "bullmq";
import {
  SUPPLIER_CHECK_QUEUE_NAME,
  type SupplierCheckJobData,
  type SupplierCheckJobResult,
} from "@danetti/shared";
import { createRedisConnection } from "./redis.js";

export function createSupplierCheckQueueClient() {
  const connection = createRedisConnection();
  const queue = new Queue<SupplierCheckJobData, SupplierCheckJobResult>(SUPPLIER_CHECK_QUEUE_NAME, {
    connection,
  });

  return {
    queue,
    async close() {
      await queue.close();
      await connection.quit();
    },
  };
}
