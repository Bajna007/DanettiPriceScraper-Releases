import { randomUUID } from "node:crypto";
import { invokeWindowsCredentialManager } from "./windows-credential-bridge.js";

export interface SecretStore {
  get(key: string): Promise<string | null>;
  put(key: string, secret: string): Promise<void>;
  delete(key: string): Promise<void>;
}

export class MemorySecretStore implements SecretStore {
  private readonly values = new Map<string, string>();
  async get(key: string) {
    return this.values.get(key) ?? null;
  }
  async put(key: string, secret: string) {
    this.values.set(key, secret);
  }
  async delete(key: string) {
    this.values.delete(key);
  }
}

type Manifest = { format: "danetti-chunks-v1"; generation: string; count: number };
const marker = "danetti-secret-manifest:";
// CredWrite permits 2560 bytes, and the bridge stores UTF-16. Leave room below 1280 code units.
const chunkLength = 1200;
export class WindowsSecretStore implements SecretStore {
  constructor(private readonly invoke = invokeWindowsCredentialManager) {}
  private async read(key: string) {
    if (process.platform !== "win32") throw new Error("credential_store_unavailable");
    const result = await this.invoke({ action: "read", target: key });
    return result.found ? (result.secret ?? null) : null;
  }
  private manifest(value: string | null): Manifest | null {
    if (!value?.startsWith(marker)) return null;
    const parsed = JSON.parse(value.slice(marker.length)) as Manifest;
    if (
      parsed.format !== "danetti-chunks-v1" ||
      !/^[a-f0-9-]{36}$/.test(parsed.generation) ||
      !Number.isInteger(parsed.count) ||
      parsed.count < 1 ||
      parsed.count > 128
    ) {
      throw new Error("credential_store_corrupt");
    }
    return parsed;
  }
  async get(key: string): Promise<string | null> {
    const value = await this.read(key);
    const manifest = this.manifest(value);
    if (!manifest) return value;
    let secret = "";
    for (let i = 0; i < manifest.count; i++) {
      const chunk = await this.read(`${key}:${manifest.generation}:${i}`);
      if (chunk === null) throw new Error("credential_store_corrupt");
      secret += chunk;
    }
    return secret;
  }
  async put(key: string, secret: string): Promise<void> {
    const old = this.manifest(await this.read(key));
    if (secret.length <= chunkLength && !secret.startsWith(marker)) {
      await this.invoke({ action: "write", target: key, secret });
    } else {
      const chunks: string[] = [];
      for (let start = 0; start < secret.length; ) {
        let end = Math.min(start + chunkLength, secret.length);
        const last = secret.charCodeAt(end - 1);
        if (end < secret.length && last >= 0xd800 && last <= 0xdbff) end--;
        chunks.push(secret.slice(start, end));
        start = end;
      }
      const manifest: Manifest = {
        format: "danetti-chunks-v1",
        generation: randomUUID(),
        count: chunks.length,
      };
      if (manifest.count > 128) throw new Error("credential_payload_too_large");
      const written: string[] = [];
      try {
        for (let i = 0; i < manifest.count; i++) {
          const target = `${key}:${manifest.generation}:${i}`;
          await this.invoke({
            action: "write",
            target,
            secret: chunks[i],
          });
          written.push(target);
        }
        await this.invoke({
          action: "write",
          target: key,
          secret: marker + JSON.stringify(manifest),
        });
      } catch (error) {
        for (const target of written)
          await this.invoke({ action: "delete", target }).catch(() => undefined);
        throw error;
      }
    }
    if (old) await this.removeChunks(key, old);
  }
  private async removeChunks(key: string, manifest: Manifest) {
    for (let i = 0; i < manifest.count; i++) {
      await this.invoke({ action: "delete", target: `${key}:${manifest.generation}:${i}` });
    }
  }
  async delete(key: string): Promise<void> {
    const manifest = this.manifest(await this.read(key));
    await this.invoke({ action: "delete", target: key });
    if (manifest) await this.removeChunks(key, manifest);
  }
}
