import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { WindowsSecretStore } from "./secret-store.js";

if (process.platform !== "win32")
  throw new Error("Actual Windows Credential Manager test requires Windows");
const key = `DanettiPriceScraper:epr-synthetic-proof:${randomUUID()}`;
const store = new WindowsSecretStore();
try {
  await store.put(key, "synthetic-only");
  assert.equal(await store.get(key), "synthetic-only");
  const large = "Árvíz😀".repeat(800);
  await store.put(key, large);
  assert.equal(await store.get(key), large);
} finally {
  await store.delete(key);
}
assert.equal(await store.get(key), null);
console.log(
  "Actual Windows Credential Manager persistence, Unicode, chunk replacement and cleanup passed with synthetic data."
);
