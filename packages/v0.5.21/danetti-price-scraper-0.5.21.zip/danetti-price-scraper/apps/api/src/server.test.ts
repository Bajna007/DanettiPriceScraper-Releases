import assert from "node:assert/strict";
import { buildServer } from "./server.js";

const server = buildServer({ logger: false });

try {
  const health = await server.inject({ method: "GET", url: "/health", remoteAddress: "127.0.0.1" });
  assert.equal(health.statusCode, 200);
  assert.deepEqual(health.json(), { status: "ok", service: "api" });

  const ipv6Health = await server.inject({ method: "GET", url: "/health", remoteAddress: "::1" });
  assert.equal(ipv6Health.statusCode, 200);

  const mappedHealth = await server.inject({
    method: "GET",
    url: "/health",
    remoteAddress: "::ffff:127.0.0.1",
  });
  assert.equal(mappedHealth.statusCode, 200);

  const blockedLan = await server.inject({
    method: "GET",
    url: "/health",
    remoteAddress: "192.168.1.20",
  });
  assert.equal(blockedLan.statusCode, 403);
  assert.equal(blockedLan.json().error.code, "api_local_only");
  const blockedEpr = await server.inject({
    method: "GET",
    url: "/epr/processing-policy",
    remoteAddress: "192.168.1.20",
  });
  assert.equal(blockedEpr.statusCode, 403);
  const noEprHeader = await server.inject({
    method: "POST",
    url: "/epr/ai/auth/start",
    remoteAddress: "127.0.0.1",
  });
  assert.equal(noEprHeader.statusCode, 403);
  const foreignEprOrigin = await server.inject({
    method: "POST",
    url: "/epr/ai/auth/start",
    remoteAddress: "127.0.0.1",
    headers: { origin: "https://untrusted.invalid", "x-danetti-epr": "1" },
  });
  assert.equal(foreignEprOrigin.statusCode, 403);
  const eprPreflight = await server.inject({
    method: "OPTIONS",
    url: "/epr/mailboxes",
    remoteAddress: "127.0.0.1",
    headers: {
      origin: "http://localhost:3000",
      "access-control-request-method": "POST",
      "access-control-request-headers": "content-type,x-danetti-epr",
    },
  });
  assert.equal(eprPreflight.statusCode, 204);
  assert.match(String(eprPreflight.headers["access-control-allow-headers"]), /x-danetti-epr/);

  for (const route of [
    { method: "PUT", url: "/supplier-credentials/00000000-0000-4000-8000-000000000001" },
    { method: "PATCH", url: "/suppliers/00000000-0000-4000-8000-000000000001" },
    { method: "DELETE", url: "/supplier-credentials/00000000-0000-4000-8000-000000000001" },
    { method: "POST", url: "/supplier-credentials/00000000-0000-4000-8000-000000000001/test" },
  ]) {
    const response = await server.inject({
      method: "OPTIONS",
      url: route.url,
      remoteAddress: "127.0.0.1",
      headers: {
        origin: "http://localhost:3000",
        "access-control-request-method": route.method,
        "access-control-request-headers": "content-type",
      },
    });
    assert.equal(response.statusCode, 204);
    assert.equal(response.headers["access-control-allow-origin"], "http://localhost:3000");
    assert.match(
      String(response.headers["access-control-allow-methods"]),
      new RegExp(route.method)
    );
  }
} finally {
  await server.close();
}

console.log("API server route and CORS tests passed");
