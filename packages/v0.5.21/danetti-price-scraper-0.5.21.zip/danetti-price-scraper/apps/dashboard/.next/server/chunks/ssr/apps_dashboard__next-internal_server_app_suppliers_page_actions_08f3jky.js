module.exports=[11468,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_suppliers_page_actions_08f3jky.js.map