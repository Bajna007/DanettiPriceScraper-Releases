module.exports=[19974,a=>{"use strict";a.s([])}];

//# sourceMappingURL=1vk4__next-internal_server_app_labels_%5Bbrand%5D_orders_%5BorderId%5D_page_actions_10pwv6a.js.map