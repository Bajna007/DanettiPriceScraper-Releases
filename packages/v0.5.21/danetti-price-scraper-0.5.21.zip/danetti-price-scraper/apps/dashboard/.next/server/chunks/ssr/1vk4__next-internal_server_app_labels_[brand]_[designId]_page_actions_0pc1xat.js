module.exports=[9860,a=>{"use strict";a.s([])}];

//# sourceMappingURL=1vk4__next-internal_server_app_labels_%5Bbrand%5D_%5BdesignId%5D_page_actions_0pc1xat.js.map