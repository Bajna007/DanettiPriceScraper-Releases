module.exports=[65715,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_connector-lab_page_actions_15o4t-g.js.map