module.exports=[72909,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_article-changes_page_actions_1_rwtps.js.map