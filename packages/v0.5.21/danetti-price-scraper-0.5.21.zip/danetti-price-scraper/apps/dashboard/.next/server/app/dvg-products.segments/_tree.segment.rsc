:HL["/_next/static/chunks/0bb2k-q9sk5ld.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"dvg-products","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"FNiOYAC5Zp09xRzCrHBeg"}
