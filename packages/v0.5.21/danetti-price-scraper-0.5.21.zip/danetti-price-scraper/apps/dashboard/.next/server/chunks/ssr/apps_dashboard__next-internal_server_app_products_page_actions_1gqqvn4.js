module.exports=[34353,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_products_page_actions_1gqqvn4.js.map