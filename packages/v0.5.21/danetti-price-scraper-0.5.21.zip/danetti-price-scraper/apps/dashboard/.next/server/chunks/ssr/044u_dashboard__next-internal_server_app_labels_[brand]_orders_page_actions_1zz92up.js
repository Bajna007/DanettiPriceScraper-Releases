module.exports=[20513,a=>{"use strict";a.s([])}];

//# sourceMappingURL=044u_dashboard__next-internal_server_app_labels_%5Bbrand%5D_orders_page_actions_1zz92up.js.map