module.exports=[63449,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_dashboard__next-internal_server_app_labels_custom_page_actions_0f-r5j5.js.map