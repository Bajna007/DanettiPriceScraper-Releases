module.exports=[17271,a=>{"use strict";a.s([])}];

//# sourceMappingURL=044u_dashboard__next-internal_server_app_supplier-price-changes_page_actions_1nnnuw8.js.map