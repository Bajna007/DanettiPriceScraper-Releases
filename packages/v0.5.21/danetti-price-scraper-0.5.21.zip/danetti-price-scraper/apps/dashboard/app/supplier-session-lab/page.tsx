"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import {
  checkSupplierSession,
  closeSupplierSession,
  exportSupplierSessionManualRun,
  formatApiErrorMessage,
  getSupplierSessionOperatorReadiness,
  getSupplierSessionStatus,
  listSupplierSessionManualRuns,
  listSupplierMappings,
  listSupplierSnapshots,
  listSuppliers,
  openSupplierSession,
  readOneSupplierSession,
  resetSupplierSessionProfile,
  retrySupplierSessionItem,
  runSelectedSupplierSession,
  type DvgSupplierSessionReadOneResult,
  type ManualOperatorRunItemSummary,
  type ManualOperatorRunSummary,
  type Supplier,
  type SupplierMapping,
  type SupplierProfileResetResult,
  type SupplierSessionOperatorReadinessResponse,
  type SupplierSessionRunSelectedResult,
  type SupplierSessionStatusResponse,
  type SupplierSnapshotSummary,
} from "../../src/lib/api";

const DVG_LOGIN_URL = "https://devecchigiuseppesrl.com/e-commerce/account/login.asp?";
const DEFAULT_TEST_ARTICLE = "CS-A2200247";
const MAX_MANUAL_BATCH_SIZE = 5;
const fallbackDvgSupplier: Supplier = {
  id: "dvg-devecchi",
  code: "DVG",
  name: "DVG De Vecchi",
  baseUrl: "https://devecchigiuseppesrl.com",
  enabled: true,
  allowedDomains: ["devecchigiuseppesrl.com"],
  supportedLookupStrategies: ["direct_url_authenticated"],
  defaultRateLimitPerMinute: 6,
  healthStatus: "unknown",
  lastSuccessAt: null,
  lastFailureAt: null,
  createdAt: "",
  updatedAt: "",
};

type ReadMode = "manual" | "mapping";

export default function DvgOperatorPage() {
  return (
    <Suspense fallback={<LoadingState message="DVG operátor betöltése..." />}>
      <DvgOperatorContent />
    </Suspense>
  );
}

function DvgOperatorContent() {
  const searchParams = useSearchParams();
  const requestedMappingId = searchParams.get("supplierMappingId") ?? "";
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [mappings, setMappings] = useState<SupplierMapping[]>([]);
  const [snapshots, setSnapshots] = useState<SupplierSnapshotSummary[]>([]);
  const [mappingSnapshots, setMappingSnapshots] = useState<SupplierSnapshotSummary[]>([]);
  const [manualRuns, setManualRuns] = useState<ManualOperatorRunSummary[]>([]);
  const [selectedSupplierId, setSelectedSupplierId] = useState(fallbackDvgSupplier.id);
  const [readMode, setReadMode] = useState<ReadMode>(requestedMappingId ? "mapping" : "manual");
  const [manualArticle, setManualArticle] = useState(DEFAULT_TEST_ARTICLE);
  const [supplierMappingId, setSupplierMappingId] = useState(requestedMappingId);
  const [selectedBatchIds, setSelectedBatchIds] = useState<string[]>([]);
  const [mappingFilter, setMappingFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [mappingsLoading, setMappingsLoading] = useState(false);
  const [snapshotsLoading, setSnapshotsLoading] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [readinessLoading, setReadinessLoading] = useState(false);
  const [action, setAction] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [readiness, setReadiness] = useState<SupplierSessionOperatorReadinessResponse | null>(null);
  const [exportChecks, setExportChecks] = useState({ json: false, csv: false });
  const [retryOneChecked, setRetryOneChecked] = useState(false);
  const [selectedRetryItem, setSelectedRetryItem] = useState<{
    runId: string;
    mappingId: string;
  } | null>(null);
  const [session, setSession] = useState<SupplierSessionStatusResponse | null>(null);
  const [readResult, setReadResult] = useState<DvgSupplierSessionReadOneResult | null>(null);
  const [batchResult, setBatchResult] = useState<SupplierSessionRunSelectedResult | null>(null);
  const [resetResult, setResetResult] = useState<SupplierProfileResetResult | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    listSuppliers({ limit: 100 })
      .then((response) => {
        if (!active) return;
        const dvgSuppliers = response.items.filter(isDvgSupplier);
        const nextSuppliers = dvgSuppliers.length > 0 ? dvgSuppliers : [fallbackDvgSupplier];
        setSuppliers(nextSuppliers);
        setSelectedSupplierId(nextSuppliers[0]?.id ?? fallbackDvgSupplier.id);
      })
      .catch((err) => {
        if (!active) return;
        setSuppliers([fallbackDvgSupplier]);
        setSelectedSupplierId(fallbackDvgSupplier.id);
        setError(formatApiErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!requestedMappingId) return;
    setReadMode("mapping");
    setSupplierMappingId(requestedMappingId);
    setSelectedBatchIds([requestedMappingId]);
  }, [requestedMappingId]);

  useEffect(() => {
    let active = true;
    setMappings([]);
    if (!isUuid(selectedSupplierId)) return;
    setMappingsLoading(true);
    listSupplierMappings({ supplierId: selectedSupplierId, limit: 200 })
      .then((response) => {
        if (!active) return;
        setMappings(response.items);
        if (!supplierMappingId && response.items[0]) setSupplierMappingId(response.items[0].id);
      })
      .catch((err) => {
        if (active) setError(formatApiErrorMessage(err));
      })
      .finally(() => {
        if (active) setMappingsLoading(false);
      });
    return () => {
      active = false;
    };
  }, [selectedSupplierId]);

  useEffect(() => {
    void refreshSnapshots();
  }, [selectedSupplierId, supplierMappingId, manualArticle, readMode]);

  useEffect(() => {
    void refreshMappingSnapshots();
    void refreshManualRuns();
    void refreshOperatorReadiness();
  }, [selectedSupplierId]);

  const selectedSupplier =
    suppliers.find((supplier) => supplier.id === selectedSupplierId) ?? fallbackDvgSupplier;
  const selectedMapping = mappings.find((mapping) => mapping.id === supplierMappingId) ?? null;
  const filteredMappings = filterMappings(mappings, mappingFilter).slice(0, 50);
  const latestSnapshotByMapping = latestSnapshotsByMappingId(mappingSnapshots);
  const selectedBatchMappings = selectedBatchIds
    .map((id) => mappings.find((mapping) => mapping.id === id))
    .filter((mapping): mapping is SupplierMapping => Boolean(mapping));
  const latestResult = batchResult ?? readResult ?? session ?? resetResult;
  const sessionReady = Boolean(
    session?.browserOpen && session.authenticatedLikely && session.blockingSafetyFlags.length === 0
  );
  const selectedMappingEnabled = selectedMapping?.enabled ?? true;
  const canRead =
    sessionReady &&
    (readMode === "mapping"
      ? Boolean(supplierMappingId.trim()) && selectedMappingEnabled
      : Boolean(manualArticle.trim()));
  const canSaveSnapshot =
    sessionReady &&
    readMode === "mapping" &&
    Boolean(supplierMappingId.trim()) &&
    selectedMappingEnabled;
  const canRunBatch =
    sessionReady &&
    selectedBatchIds.length > 0 &&
    selectedBatchIds.length <= MAX_MANUAL_BATCH_SIZE &&
    selectedBatchMappings.length === selectedBatchIds.length &&
    selectedBatchMappings.every((mapping) => mapping.enabled);
  const canRetryOne = sessionReady && selectedRetryItem !== null;
  const blockingSafetyFlags =
    batchResult?.items.find((item) => item.safety.blockingSafetyFlags.length > 0)?.safety
      .blockingSafetyFlags ??
    readResult?.safety.blockingSafetyFlags ??
    session?.blockingSafetyFlags ??
    [];
  const safetyEventCodes =
    batchResult?.items.flatMap((item) => item.safety.safetyEventCodes) ??
    readResult?.safety.safetyEventCodes ??
    session?.safetyEventCodes ??
    [];
  const readOnlyRiskCodes =
    batchResult?.items.flatMap((item) => item.safety.readOnlyRiskCodes) ??
    readResult?.safety.readOnlyRiskCodes ??
    [];
  const profilePath =
    session?.maskedProfilePath ?? resetResult?.profilePolicy.maskedProfilePath ?? "-";
  const operatorState = getOperatorState({
    error,
    session,
    selectedMapping,
    readResult,
    batchResult,
    blockingSafetyFlags,
  });
  const acceptanceItems = buildAcceptanceChecklist({
    session,
    readResult,
    batchResult,
    manualRuns,
    exportChecks,
    retryOneChecked,
    resetResult,
    latestResult,
    error,
  });
  const manualAcceptanceStatus = acceptanceItems.every((item) => item.done)
    ? "complete"
    : acceptanceItems.some((item) => item.done)
      ? "in_progress"
      : "not_started";

  async function refreshSnapshots() {
    const params: Parameters<typeof listSupplierSnapshots>[0] = { limit: 20 };
    if (isUuid(selectedSupplierId)) params.supplierId = selectedSupplierId;
    if (readMode === "mapping" && supplierMappingId.trim()) {
      params.supplierMappingId = supplierMappingId.trim();
    } else if (manualArticle.trim()) {
      params.supplierArticleNumber = manualArticle.trim();
    }
    setSnapshotsLoading(true);
    try {
      const response = await listSupplierSnapshots(params);
      setSnapshots(response.items);
    } catch {
      setSnapshots([]);
    } finally {
      setSnapshotsLoading(false);
    }
  }

  async function refreshMappingSnapshots() {
    if (!isUuid(selectedSupplierId)) {
      setMappingSnapshots([]);
      return;
    }
    try {
      const response = await listSupplierSnapshots({ supplierId: selectedSupplierId, limit: 200 });
      setMappingSnapshots(response.items);
    } catch {
      setMappingSnapshots([]);
    }
  }

  async function refreshManualRuns() {
    if (!isUuid(selectedSupplierId)) {
      setManualRuns([]);
      return;
    }
    setHistoryLoading(true);
    try {
      const response = await listSupplierSessionManualRuns(selectedSupplierId, { limit: 20 });
      setManualRuns(response.runs);
    } catch {
      setManualRuns([]);
    } finally {
      setHistoryLoading(false);
    }
  }

  async function refreshOperatorReadiness() {
    if (!isUuid(selectedSupplierId)) {
      setReadiness(null);
      return;
    }
    setReadinessLoading(true);
    try {
      const response = await getSupplierSessionOperatorReadiness(selectedSupplierId);
      setReadiness(response);
    } catch (err) {
      setReadiness({
        supplierId: selectedSupplierId,
        status: "degraded",
        apiReachable: false,
        databaseReachable: false,
        sessionLabEnabled: false,
        browserRuntimeAvailable: false,
        currentLocalGuardMode: "loopback_header_localhost_origin_production_opt_in",
        manualAcceptanceStatus: "needs_operator_action",
        normalizedErrorCodes: ["api_unavailable"],
        warnings: [formatApiErrorMessage(err)],
      });
    } finally {
      setReadinessLoading(false);
    }
  }

  async function runAction<T>(
    name: string,
    task: () => Promise<T>,
    onSuccess: (result: T) => void
  ) {
    setAction(name);
    setError(null);
    setResetResult(null);
    try {
      const result = await task();
      onSuccess(result);
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setAction(null);
    }
  }

  function refreshAfterSupplierRead() {
    void refreshSnapshots();
    void refreshMappingSnapshots();
    void refreshManualRuns();
    void refreshOperatorReadiness();
  }

  function openSession() {
    setReadResult(null);
    setBatchResult(null);
    void runAction(
      "open",
      () => openSupplierSession(selectedSupplierId, { loginUrl: DVG_LOGIN_URL }),
      (result) => {
        setSession(result);
        void refreshOperatorReadiness();
      }
    );
  }

  function checkSession() {
    void runAction(
      "check",
      () => checkSupplierSession(selectedSupplierId),
      (result) => {
        setSession(result);
        void refreshOperatorReadiness();
      }
    );
  }

  function pollStatus() {
    void runAction(
      "status",
      () => getSupplierSessionStatus(selectedSupplierId),
      (result) => {
        setSession(result);
        void refreshOperatorReadiness();
      }
    );
  }

  function closeSession() {
    void runAction(
      "close",
      () => closeSupplierSession(selectedSupplierId),
      (result) => {
        setSession(result);
        void refreshOperatorReadiness();
      }
    );
  }

  function readOne(dryRun: boolean, saveSnapshot: boolean) {
    setReadResult(null);
    setBatchResult(null);
    const input =
      readMode === "mapping"
        ? { supplierMappingId: supplierMappingId.trim(), dryRun, saveSnapshot }
        : { supplierArticleNumber: manualArticle.trim(), dryRun, saveSnapshot };
    void runAction(
      "read-one",
      () => readOneSupplierSession(selectedSupplierId, input),
      (result) => {
        setReadResult(result);
        refreshAfterSupplierRead();
      }
    );
  }

  function runSelected(saveSnapshots: boolean) {
    setReadResult(null);
    setBatchResult(null);
    void runAction(
      "run-selected",
      () =>
        runSelectedSupplierSession(selectedSupplierId, {
          supplierMappingIds: selectedBatchIds,
          saveSnapshots,
          maxItems: MAX_MANUAL_BATCH_SIZE,
        }),
      (result) => {
        setBatchResult(result);
        refreshAfterSupplierRead();
      }
    );
  }

  function retryOne(saveSnapshot: boolean) {
    if (!selectedRetryItem) return;
    setReadResult(null);
    setBatchResult(null);
    void runAction(
      "retry-one",
      () =>
        retrySupplierSessionItem(selectedSupplierId, {
          sourceRunId: selectedRetryItem.runId,
          supplierMappingId: selectedRetryItem.mappingId,
          saveSnapshot,
        }),
      (result) => {
        setBatchResult(result);
        setSelectedRetryItem(null);
        setRetryOneChecked(true);
        refreshAfterSupplierRead();
      }
    );
  }

  function exportManualRun(runId: string, format: "json" | "csv") {
    void runAction(
      `export-${format}`,
      () => exportSupplierSessionManualRun(selectedSupplierId, runId, format),
      (result) => {
        downloadTextFile(result.filename, result.content, result.contentType);
        setExportChecks((current) => ({ ...current, [format]: true }));
      }
    );
  }

  function resetProfile() {
    setSession(null);
    setReadResult(null);
    setBatchResult(null);
    void runAction(
      "reset-profile",
      () => resetSupplierSessionProfile(selectedSupplierId),
      (result) => {
        setResetResult(result);
        void refreshOperatorReadiness();
      }
    );
  }

  function selectMapping(mapping: SupplierMapping) {
    setReadMode("mapping");
    setSupplierMappingId(mapping.id);
    setReadResult(null);
  }

  function toggleBatchMapping(mappingId: string) {
    setSelectedBatchIds((current) => {
      if (current.includes(mappingId)) return current.filter((id) => id !== mappingId);
      if (current.length >= MAX_MANUAL_BATCH_SIZE) return current;
      return [...current, mappingId];
    });
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1 className="page-title">DVG operator runtime</h1>
        </div>
        <span className="badge warning">Nincs Woo írás</span>
      </div>

      <section className="notice warning">
        <p className="card-title">Persistent profile warning</p>
        <p className="helper-text">
          DVG belépés a CloakBrowser Managerben történik: http://127.0.0.1:18080. A supplier
          cookie/session a dedikált Docker profilban marad. Frontend nem olvas cookie-t,
          storageState-et, raw HTML-t, headert vagy credentialt. Reset gomb zárja a sessiont; Docker
          profil törlése a Managerben külön művelet.
        </p>
      </section>

      <section className="card-grid">
        <div className="card summary-metric">
          <p className="card-title">Állapot</p>
          <p className="card-value">{operatorState}</p>
          <p className="helper-text">Gombok csak érvényes session + mapping állapotban aktívak.</p>
        </div>
        <div className="card summary-metric">
          <p className="card-title">Session</p>
          <p className="card-value">{session?.state ?? "closed"}</p>
          <p className="helper-text">Auth likely: {yesNo(session?.authenticatedLikely)}</p>
        </div>
        <div className="card summary-metric">
          <p className="card-title">Batch</p>
          <p className="card-value">
            {selectedBatchIds.length}/{MAX_MANUAL_BATCH_SIZE}
          </p>
          <p className="helper-text">Nincs select all. Max 5 mapping.</p>
        </div>
        <div className="card summary-metric">
          <p className="card-title">Safety stop</p>
          <p className="card-value">{blockingSafetyFlags.length ? "blocked" : "clear"}</p>
          <p className="helper-text">{joinCodes(blockingSafetyFlags)}</p>
        </div>
      </section>

      <section className="card">
        <h2 className="section-title">Session vezérlés</h2>
        {loading ? <LoadingState message="Beszállítók betöltése..." /> : null}
        {!loading && suppliers.length === 0 ? (
          <EmptyState title="Nincs DVG supplier">
            Fallback DVG session opció használható.
          </EmptyState>
        ) : null}
        <div className="form-grid">
          <label className="field-label">
            Beszállító
            <select
              className="input"
              value={selectedSupplierId}
              onChange={(event) => {
                setSelectedSupplierId(event.target.value);
                setSelectedBatchIds([]);
                setReadResult(null);
                setBatchResult(null);
                setSession(null);
                setManualRuns([]);
                setMappingSnapshots([]);
                setSelectedRetryItem(null);
              }}
            >
              {suppliers.map((supplier) => (
                <option key={supplier.id} value={supplier.id}>
                  {supplier.code} - {supplier.name}
                </option>
              ))}
            </select>
          </label>
          <label className="field-label">
            Olvasási mód
            <select
              className="input"
              value={readMode}
              onChange={(event) => {
                setReadMode(event.target.value as ReadMode);
                setReadResult(null);
              }}
            >
              <option value="mapping">Mentett mapping snapshot gate</option>
              <option value="manual">Manual cikkszám preview</option>
            </select>
          </label>
        </div>
        <p className="helper-text">
          Kiválasztott: {selectedSupplier.code} - {selectedSupplier.name}. Session route csak
          loopbackről, local operator headerrel működik.
        </p>
        <div className="action-row">
          <button className="button" onClick={openSession} disabled={action !== null}>
            {action === "open" ? "Böngésző nyitása..." : "DVG böngésző nyitása"}
          </button>
          <button className="button secondary" onClick={checkSession} disabled={action !== null}>
            {action === "check" ? "Session ellenőrzése..." : "Session ellenőrzése"}
          </button>
          <button className="button secondary" onClick={pollStatus} disabled={action !== null}>
            {action === "status" ? "Status frissítése..." : "Status frissítése"}
          </button>
          <button className="button secondary" onClick={closeSession} disabled={action !== null}>
            {action === "close" ? "Session zárása..." : "Session zárása"}
          </button>
          <button className="button danger" onClick={resetProfile} disabled={action !== null}>
            {action === "reset-profile" ? "Profil törlése..." : "DVG profil reset"}
          </button>
        </div>
      </section>

      {error ? <ErrorState message={error} /> : null}

      <RuntimeReadinessPanel
        readiness={readiness}
        readinessLoading={readinessLoading}
        manualAcceptanceStatus={manualAcceptanceStatus}
        onRefresh={() => void refreshOperatorReadiness()}
      />

      <AcceptanceChecklistPanel items={acceptanceItems} status={manualAcceptanceStatus} />

      <SessionStatusTable session={session} profilePath={profilePath} />

      <section className="card table-card">
        <div className="table-toolbar">
          <div>
            <h2 className="section-title">DVG mapping választás</h2>
            <p className="helper-text">
              Enabled DVG mappingek. Szűrés cikkszámra, SKU-ra vagy terméknévre. Batch max 5.
            </p>
          </div>
          <button className="button secondary small" onClick={() => setSelectedBatchIds([])}>
            Batch törlés
          </button>
        </div>
        <label className="field-label">
          Mapping szűrő
          <input
            className="input"
            value={mappingFilter}
            onChange={(event) => setMappingFilter(event.target.value)}
            placeholder="Cikkszám, SKU, terméknév"
          />
        </label>
        {mappingsLoading ? <LoadingState message="Mappingek betöltése..." /> : null}
        <div className="table-scroll">
          <table className="table data-table data-table--wide">
            <colgroup>
              <col className="col-short" />
              <col className="col-action" />
              <col className="col-sku" />
              <col className="col-sku" />
              <col className="col-name" />
              <col className="col-status" />
              <col className="col-status" />
              <col className="col-price" />
              <col className="col-id" />
            </colgroup>
            <thead>
              <tr>
                <th>Batch</th>
                <th>Egy</th>
                <th>Article</th>
                <th>SKU</th>
                <th>Termék</th>
                <th>Enabled</th>
                <th>Trust</th>
                <th>Last snapshot</th>
                <th>Mapping ID</th>
              </tr>
            </thead>
            <tbody>
              {filteredMappings.length === 0 ? (
                <tr>
                  <td className="table-empty" colSpan={9}>
                    Nincs mapping találat.
                  </td>
                </tr>
              ) : (
                filteredMappings.map((mapping) => {
                  const checked = selectedBatchIds.includes(mapping.id);
                  const latestSnapshot = latestSnapshotByMapping.get(mapping.id) ?? null;
                  return (
                    <tr key={mapping.id}>
                      <td>
                        <input
                          aria-label={`Batch mapping ${mapping.supplierArticleNumber}`}
                          type="checkbox"
                          checked={checked}
                          disabled={
                            action !== null ||
                            !mapping.enabled ||
                            (!checked && selectedBatchIds.length >= MAX_MANUAL_BATCH_SIZE)
                          }
                          onChange={() => toggleBatchMapping(mapping.id)}
                        />
                      </td>
                      <td>
                        <button
                          className="button small secondary"
                          onClick={() => selectMapping(mapping)}
                          disabled={action !== null || !mapping.enabled}
                        >
                          Választ
                        </button>
                      </td>
                      <td className="cell-mono">{mapping.supplierArticleNumber}</td>
                      <td className="cell-mono cell-truncate">
                        {mapping.catalogProductSku ?? "-"}
                      </td>
                      <td className="cell-truncate">{mapping.catalogProductName ?? "-"}</td>
                      <td>{mapping.enabled ? "igen" : "nem"}</td>
                      <td>{mappingTrustBadge(mapping)}</td>
                      <td className="cell-nowrap">
                        {latestSnapshot
                          ? `${formatMoney(
                              latestSnapshot.priceNetEur,
                              latestSnapshot.currency
                            )} / ${formatDate(latestSnapshot.observedAt)}`
                          : "-"}
                      </td>
                      <td className="cell-mono cell-truncate">{mapping.id}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="card">
        <h2 className="section-title">Egy mapping olvasása</h2>
        <div className="form-grid">
          {readMode === "manual" ? (
            <label className="field-label">
              DVG cikkszám
              <input
                className="input"
                value={manualArticle}
                onChange={(event) => setManualArticle(event.target.value)}
                placeholder={DEFAULT_TEST_ARTICLE}
              />
              <span className="field-help">
                Preview only. Snapshot mentéshez mentett mapping kell.
              </span>
            </label>
          ) : (
            <label className="field-label">
              Mapping ID
              <input
                className="input"
                value={supplierMappingId}
                onChange={(event) => setSupplierMappingId(event.target.value)}
                placeholder="UUID"
              />
              <span className="field-help">Query param is használható: supplierMappingId.</span>
            </label>
          )}
        </div>
        {readMode === "mapping" && selectedMapping ? (
          <SelectedMappingCard
            mapping={selectedMapping}
            latestSnapshot={latestSnapshotByMapping.get(selectedMapping.id) ?? null}
          />
        ) : null}
        <div className="action-row">
          <button
            className="button secondary"
            onClick={() => readOne(true, false)}
            disabled={action !== null || !canRead}
          >
            {action === "read-one" ? "Olvasás..." : "Dry-run detail olvasás"}
          </button>
          <button
            className="button"
            onClick={() => readOne(false, true)}
            disabled={action !== null || !canSaveSnapshot}
          >
            {action === "read-one" ? "Gate + mentés..." : "Snapshot gate + mentés"}
          </button>
        </div>
      </section>

      <section className="card table-card">
        <div className="table-toolbar">
          <div>
            <h2 className="section-title">Selected micro-batch preview</h2>
            <p className="helper-text">Kézi, sequential futás. Nincs worker, nincs scheduler.</p>
          </div>
          <span className="badge muted">
            {selectedBatchIds.length}/{MAX_MANUAL_BATCH_SIZE}
          </span>
        </div>
        <SelectedBatchTable mappings={selectedBatchMappings} onRemove={toggleBatchMapping} />
        <div className="action-row">
          <button
            className="button secondary"
            onClick={() => runSelected(false)}
            disabled={action !== null || !canRunBatch}
          >
            {action === "run-selected" ? "Batch fut..." : "Micro-batch dry-run"}
          </button>
          <button
            className="button"
            onClick={() => runSelected(true)}
            disabled={action !== null || !canRunBatch}
          >
            {action === "run-selected" ? "Batch ment..." : "Micro-batch snapshot mentés"}
          </button>
        </div>
      </section>

      {readResult ? <ReadResultSummary result={readResult} /> : null}
      {batchResult ? <BatchResultSummary result={batchResult} /> : null}

      <SnapshotHistoryTable
        snapshots={snapshots}
        snapshotsLoading={snapshotsLoading}
        onRefresh={() => void refreshSnapshots()}
      />

      <ManualRunHistoryTable
        runs={manualRuns}
        historyLoading={historyLoading}
        selectedRetryItem={selectedRetryItem}
        canRetryOne={canRetryOne}
        action={action}
        onRefresh={() => void refreshManualRuns()}
        onSelectRetry={(runId, mappingId) =>
          setSelectedRetryItem((current) =>
            current?.runId === runId && current.mappingId === mappingId
              ? null
              : { runId, mappingId }
          )
        }
        onRetryDryRun={() => retryOne(false)}
        onRetrySave={() => retryOne(true)}
        onExport={exportManualRun}
      />

      <section className={`notice ${blockingSafetyFlags.length ? "error" : "info"}`}>
        <p className="card-title">Safety stop panel</p>
        <p className="helper-text">
          Blocking flags: {joinCodes(blockingSafetyFlags)}. Safety events:{" "}
          {joinCodes(safetyEventCodes)}. Read-only risks: {joinCodes(readOnlyRiskCodes)}. Batch
          stopped reason: {batchResult?.stoppedReason ?? "-"}.
        </p>
      </section>

      <section className="card">
        <details>
          <summary className="section-title">Sanitized debug JSON</summary>
          <p className="helper-text">
            Csak tisztított mezők. Cookie, storageState, raw HTML, screenshot, header, credential és
            full profile path nincs.
          </p>
          <pre className="json-preview">
            {latestResult ? JSON.stringify(latestResult, null, 2) : "Nincs eredmény."}
          </pre>
        </details>
      </section>
    </div>
  );
}

interface AcceptanceItem {
  key: string;
  label: string;
  done: boolean;
  detail: string;
}

function RuntimeReadinessPanel({
  readiness,
  readinessLoading,
  manualAcceptanceStatus,
  onRefresh,
}: {
  readiness: SupplierSessionOperatorReadinessResponse | null;
  readinessLoading: boolean;
  manualAcceptanceStatus: "not_started" | "in_progress" | "complete";
  onRefresh: () => void;
}) {
  return (
    <section className="card table-card">
      <div className="table-toolbar">
        <div>
          <h2 className="section-title">Runtime readiness</h2>
          <p className="helper-text">
            Localhost operator gate. Supplier portal nem nyílik ebből az ellenőrzésből.
          </p>
        </div>
        <button className="button secondary small" onClick={onRefresh}>
          Frissítés
        </button>
      </div>
      {readinessLoading ? <LoadingState message="Runtime readiness ellenőrzése..." /> : null}
      <div className="table-scroll">
        <table className="table data-table data-table--compact">
          <colgroup>
            <col className="col-key" />
            <col className="col-message" />
          </colgroup>
          <tbody>
            <FlagRow label="API reachable" value={yesNo(readiness?.apiReachable)} />
            <FlagRow label="DB reachable" value={yesNo(readiness?.databaseReachable)} />
            <FlagRow label="Session lab enabled" value={yesNo(readiness?.sessionLabEnabled)} />
            <FlagRow
              label="Browser runtime available"
              value={yesNo(readiness?.browserRuntimeAvailable)}
            />
            <FlagRow label="Local guard mode" value={readiness?.currentLocalGuardMode ?? "-"} />
            <FlagRow label="API readiness" value={readiness?.status ?? "unknown"} />
            <FlagRow label="Manual acceptance" value={manualAcceptanceStatus} />
            <FlagRow
              label="Server acceptance marker"
              value={readiness?.manualAcceptanceStatus ?? "-"}
            />
            <FlagRow label="Normalized errors" value={joinCodes(readiness?.normalizedErrorCodes)} />
            <FlagRow label="Warnings" value={joinCodes(readiness?.warnings)} />
          </tbody>
        </table>
      </div>
    </section>
  );
}

function AcceptanceChecklistPanel({
  items,
  status,
}: {
  items: AcceptanceItem[];
  status: "not_started" | "in_progress" | "complete";
}) {
  return (
    <section className="card table-card">
      <div className="table-toolbar">
        <div>
          <h2 className="section-title">Local acceptance checklist</h2>
          <p className="helper-text">
            Status: {status}. Checklist only mirrors local operator evidence; it does not automate
            supplier actions.
          </p>
        </div>
        <span className={status === "complete" ? "badge success" : "badge muted"}>{status}</span>
      </div>
      <div className="table-scroll">
        <table className="table data-table data-table--wide">
          <colgroup>
            <col className="col-status" />
            <col className="col-name" />
            <col className="col-message" />
          </colgroup>
          <thead>
            <tr>
              <th>Done</th>
              <th>Step</th>
              <th>Evidence</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.key}>
                <td>{checkBadge(item.done)}</td>
                <td>{item.label}</td>
                <td className="cell-wrap">{item.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function SessionStatusTable({
  session,
  profilePath,
}: {
  session: SupplierSessionStatusResponse | null;
  profilePath: string;
}) {
  return (
    <section className="card table-card">
      <h2 className="section-title">Session állapot</h2>
      <div className="table-scroll">
        <table className="table data-table data-table--compact">
          <colgroup>
            <col className="col-key" />
            <col className="col-message" />
          </colgroup>
          <tbody>
            <FlagRow label="State" value={session?.state ?? "closed"} />
            <FlagRow label="Browser open" value={yesNo(session?.browserOpen)} />
            <FlagRow label="Authenticated likely" value={yesNo(session?.authenticatedLikely)} />
            <FlagRow label="Last known URL" value={session?.lastKnownUrl ?? "-"} />
            <FlagRow label="Masked profile" value={profilePath} />
            <FlagRow label="Last error" value={formatError(session?.lastError)} />
            <FlagRow label="Warnings" value={joinCodes(session?.warnings)} />
          </tbody>
        </table>
      </div>
    </section>
  );
}

function SelectedBatchTable({
  mappings,
  onRemove,
}: {
  mappings: SupplierMapping[];
  onRemove: (id: string) => void;
}) {
  return (
    <div className="table-scroll">
      <table className="table data-table data-table--wide">
        <colgroup>
          <col className="col-sku" />
          <col className="col-sku" />
          <col className="col-name" />
          <col className="col-action" />
        </colgroup>
        <thead>
          <tr>
            <th>Article</th>
            <th>SKU</th>
            <th>Termék</th>
            <th>Művelet</th>
          </tr>
        </thead>
        <tbody>
          {mappings.length === 0 ? (
            <tr>
              <td className="table-empty" colSpan={4}>
                Nincs kiválasztott mapping.
              </td>
            </tr>
          ) : (
            mappings.map((mapping) => (
              <tr key={mapping.id}>
                <td className="cell-mono">{mapping.supplierArticleNumber}</td>
                <td className="cell-mono cell-truncate">{mapping.catalogProductSku ?? "-"}</td>
                <td className="cell-truncate">{mapping.catalogProductName ?? "-"}</td>
                <td>
                  <button className="button small secondary" onClick={() => onRemove(mapping.id)}>
                    Kivesz
                  </button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

function SelectedMappingCard({
  mapping,
  latestSnapshot,
}: {
  mapping: SupplierMapping;
  latestSnapshot: SupplierSnapshotSummary | null;
}) {
  return (
    <div className="notice info">
      <p className="card-title">Kiválasztott mapping</p>
      <p className="helper-text">
        {mapping.catalogProductSku ?? mapping.catalogProductId} -{" "}
        {mapping.catalogProductName ?? "név nélkül"}
      </p>
      <p className="helper-text">
        DVG article: <code>{mapping.supplierArticleNumber}</code>. Enabled:{" "}
        {mapping.enabled ? "igen" : "nem"}. Match mode: {mapping.matchValidationMode}.
      </p>
      <p className="helper-text">
        Trust: {mappingTrustText(mapping)}. Last snapshot: {formatSnapshotSummary(latestSnapshot)}.
      </p>
    </div>
  );
}

function ReadResultSummary({ result }: { result: DvgSupplierSessionReadOneResult }) {
  return (
    <div className="grid-2">
      <section className="card table-card">
        <h2 className="section-title">Parser eredmény</h2>
        <div className="table-scroll">
          <table className="table data-table data-table--compact">
            <colgroup>
              <col className="col-key" />
              <col className="col-message" />
            </colgroup>
            <tbody>
              <FlagRow label="Status" value={result.status} />
              <FlagRow label="Requested article" value={result.requestedArticle} />
              <FlagRow label="Final URL" value={result.finalUrl ?? "-"} />
              <FlagRow label="DVG article" value={result.parsed?.dvgArticle ?? "-"} />
              <FlagRow label="Original code" value={result.parsed?.originalCode ?? "-"} />
              <FlagRow label="Product" value={result.parsed?.productName ?? "-"} />
              <FlagRow
                label="Current price"
                value={formatMoney(
                  result.parsed?.currentPrice ?? null,
                  result.parsed?.currency ?? null
                )}
              />
              <FlagRow label="Unit" value={result.parsed?.unit ?? "-"} />
              <FlagRow label="Stock" value={result.parsed?.stockStatus ?? "-"} />
            </tbody>
          </table>
        </div>
      </section>
      <section className="card table-card">
        <h2 className="section-title">Mapping és snapshot gate</h2>
        <div className="table-scroll">
          <table className="table data-table data-table--compact">
            <colgroup>
              <col className="col-key" />
              <col className="col-message" />
            </colgroup>
            <tbody>
              <FlagRow label="Mapping outcome" value={result.mappingReview.outcome} />
              <FlagRow label="Mapping reason" value={result.mappingReview.reason} />
              <FlagRow
                label="Snapshot allowed"
                value={result.snapshotGate.allowed ? "igen" : "nem"}
              />
              <FlagRow label="Snapshot reason" value={result.snapshotGate.reason} />
              <FlagRow label="Persistence attempted" value={yesNo(result.persistence.attempted)} />
              <FlagRow label="Persistence saved" value={yesNo(result.persistence.saved)} />
              <FlagRow label="Persistence reason" value={result.persistence.reason} />
              <FlagRow label="Snapshot id" value={result.persistence.snapshotId ?? "-"} />
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function BatchResultSummary({ result }: { result: SupplierSessionRunSelectedResult }) {
  return (
    <section className="card table-card">
      <h2 className="section-title">Micro-batch eredmény</h2>
      <p className="helper-text">
        Run: {result.runId}. Status: {result.status}. Processed: {result.processed}/
        {result.totalRequested}. Saved: {result.savedCount}. Blocked: {result.blockedCount}. Failed:{" "}
        {result.failedCount}.
      </p>
      <div className="table-scroll">
        <table className="table data-table data-table--wide">
          <colgroup>
            <col className="col-status" />
            <col className="col-sku" />
            <col className="col-price" />
            <col className="col-status" />
            <col className="col-id" />
            <col className="col-message" />
          </colgroup>
          <thead>
            <tr>
              <th>Status</th>
              <th>Article</th>
              <th>Net EUR</th>
              <th>Gate</th>
              <th>Snapshot</th>
              <th>Reason</th>
            </tr>
          </thead>
          <tbody>
            {result.items.map((item) => (
              <tr key={item.mappingId}>
                <td>{statusBadge(item.status)}</td>
                <td className="cell-mono">{item.supplierArticleNumber}</td>
                <td className="cell-number">
                  {formatMoney(item.parsed?.currentPrice ?? null, item.parsed?.currency ?? null)}
                </td>
                <td>{item.snapshotGate.allowed ? "allowed" : item.snapshotGate.reason}</td>
                <td className="cell-mono cell-truncate">{item.snapshotId ?? "-"}</td>
                <td className="cell-wrap">{item.reason}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function SnapshotHistoryTable({
  snapshots,
  snapshotsLoading,
  onRefresh,
}: {
  snapshots: SupplierSnapshotSummary[];
  snapshotsLoading: boolean;
  onRefresh: () => void;
}) {
  return (
    <section className="card table-card">
      <div className="table-toolbar">
        <div>
          <h2 className="section-title">Snapshot history</h2>
          <p className="helper-text">Utolsó 20 lokális supplier snapshot az aktuális szűrőhöz.</p>
        </div>
        <button className="button secondary small" onClick={onRefresh}>
          Frissítés
        </button>
      </div>
      {snapshotsLoading ? <LoadingState message="Snapshotok betöltése..." /> : null}
      <div className="table-scroll">
        <table className="table data-table data-table--wide">
          <colgroup>
            <col className="col-date" />
            <col className="col-sku" />
            <col className="col-price" />
            <col className="col-status" />
            <col className="col-id" />
            <col className="col-id" />
          </colgroup>
          <thead>
            <tr>
              <th>Observed</th>
              <th>Article</th>
              <th>Net EUR</th>
              <th>Stock</th>
              <th>Snapshot</th>
              <th>Mapping</th>
            </tr>
          </thead>
          <tbody>
            {snapshots.length === 0 ? (
              <tr>
                <td className="table-empty" colSpan={6}>
                  Nincs snapshot.
                </td>
              </tr>
            ) : (
              snapshots.map((snapshot) => (
                <tr key={snapshot.id}>
                  <td className="cell-nowrap">{formatDate(snapshot.observedAt)}</td>
                  <td className="cell-mono">{snapshot.supplierArticleNumber}</td>
                  <td className="cell-number">
                    {formatMoney(snapshot.priceNetEur, snapshot.currency)}
                  </td>
                  <td>
                    <span className="badge muted">{snapshot.stockStatus}</span>
                  </td>
                  <td className="cell-mono cell-truncate">{snapshot.id}</td>
                  <td className="cell-mono cell-truncate">{snapshot.supplierMappingId ?? "-"}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function ManualRunHistoryTable({
  runs,
  historyLoading,
  selectedRetryItem,
  canRetryOne,
  action,
  onRefresh,
  onSelectRetry,
  onRetryDryRun,
  onRetrySave,
  onExport,
}: {
  runs: ManualOperatorRunSummary[];
  historyLoading: boolean;
  selectedRetryItem: { runId: string; mappingId: string } | null;
  canRetryOne: boolean;
  action: string | null;
  onRefresh: () => void;
  onSelectRetry: (runId: string, mappingId: string) => void;
  onRetryDryRun: () => void;
  onRetrySave: () => void;
  onExport: (runId: string, format: "json" | "csv") => void;
}) {
  const rows: Array<{
    run: ManualOperatorRunSummary;
    item: ManualOperatorRunItemSummary | null;
    index: number;
  }> = runs.flatMap(
    (
      run
    ): Array<{
      run: ManualOperatorRunSummary;
      item: ManualOperatorRunItemSummary | null;
      index: number;
    }> =>
      run.itemSummaries.length > 0
        ? run.itemSummaries.map((item, index) => ({ run, item, index }))
        : [{ run, item: null, index: 0 }]
  );
  return (
    <section className="card table-card">
      <div className="table-toolbar">
        <div>
          <h2 className="section-title">Manual run history</h2>
          <p className="helper-text">
            Sanitized local operator history only. Retry-one engedélyezett failed/blocked itemre,
            egy kiválasztás egyszerre.
          </p>
        </div>
        <div className="action-row compact">
          <button className="button secondary small" onClick={onRefresh} disabled={action !== null}>
            Frissítés
          </button>
          <button
            className="button secondary small"
            onClick={onRetryDryRun}
            disabled={action !== null || !canRetryOne}
          >
            Retry-one dry-run
          </button>
          <button
            className="button small"
            onClick={onRetrySave}
            disabled={action !== null || !canRetryOne}
          >
            Retry-one snapshot mentés
          </button>
        </div>
      </div>
      <p className="helper-text">
        Kijelölt retry: {selectedRetryItem?.mappingId ?? "-"}. Export JSON/CSV csak tisztított
        futásösszegzést ad.
      </p>
      {historyLoading ? <LoadingState message="Manual run history betöltése..." /> : null}
      <div className="table-scroll">
        <table className="table data-table data-table--wide">
          <colgroup>
            <col className="col-short" />
            <col className="col-date" />
            <col className="col-status" />
            <col className="col-sku" />
            <col className="col-price" />
            <col className="col-status" />
            <col className="col-message" />
            <col className="col-action" />
          </colgroup>
          <thead>
            <tr>
              <th>Retry</th>
              <th>Run</th>
              <th>Status</th>
              <th>Article</th>
              <th>Price</th>
              <th>Safety</th>
              <th>Reason</th>
              <th>Export</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td className="table-empty" colSpan={8}>
                  Nincs manual run history.
                </td>
              </tr>
            ) : (
              rows.map(({ run, item, index }) => {
                const mappingId = item?.mappingId ?? null;
                const retryable = Boolean(
                  mappingId && (item?.status === "blocked" || item?.status === "failed")
                );
                const checked = Boolean(
                  selectedRetryItem &&
                  selectedRetryItem.runId === run.runId &&
                  selectedRetryItem.mappingId === mappingId
                );
                return (
                  <tr key={`${run.runId}-${mappingId ?? "empty"}-${index}`}>
                    <td>
                      <input
                        aria-label={`Retry item ${mappingId ?? run.runId}`}
                        type="radio"
                        checked={checked}
                        disabled={!retryable || action !== null}
                        onChange={() => {
                          if (mappingId) onSelectRetry(run.runId, mappingId);
                        }}
                      />
                    </td>
                    <td className="cell-mono cell-wrap">
                      {formatDate(run.startedAt)}
                      <br />
                      {run.mode} {run.processedCount}/{run.requestedCount}
                    </td>
                    <td>{item ? statusBadge(item.status) : (run.stoppedReason ?? "stopped")}</td>
                    <td className="cell-mono">{item?.supplierArticleNumber ?? "-"}</td>
                    <td className="cell-number">
                      {item ? formatMoney(item.price, item.currency) : "-"}
                    </td>
                    <td className="cell-wrap">{joinCodes(item?.safetyFlags)}</td>
                    <td className="cell-wrap">{item?.reason ?? run.stoppedReason ?? "-"}</td>
                    <td>
                      {index === 0 ? (
                        <div className="action-row compact">
                          <button
                            className="button small secondary"
                            onClick={() => onExport(run.runId, "json")}
                            disabled={action !== null}
                          >
                            JSON
                          </button>
                          <button
                            className="button small secondary"
                            onClick={() => onExport(run.runId, "csv")}
                            disabled={action !== null}
                          >
                            CSV
                          </button>
                        </div>
                      ) : null}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function FlagRow({ label, value }: { label: string; value: string }) {
  return (
    <tr>
      <th className="cell-nowrap">{label}</th>
      <td className="cell-mono cell-wrap">{value}</td>
    </tr>
  );
}

function statusBadge(status: SupplierSessionRunSelectedResult["items"][number]["status"]) {
  const className =
    status === "saved" || status === "parsed"
      ? "badge success"
      : status === "blocked"
        ? "badge danger"
        : "badge warning";
  return <span className={className}>{status}</span>;
}

function filterMappings(mappings: SupplierMapping[], filter: string): SupplierMapping[] {
  const query = filter.trim().toLowerCase();
  if (!query) return mappings;
  return mappings.filter((mapping) =>
    [
      mapping.supplierArticleNumber,
      mapping.catalogProductSku,
      mapping.catalogProductName,
      mapping.supplierProductNameOverride,
      mapping.id,
    ]
      .filter(Boolean)
      .some((value) => String(value).toLowerCase().includes(query))
  );
}

function latestSnapshotsByMappingId(
  snapshots: SupplierSnapshotSummary[]
): Map<string, SupplierSnapshotSummary> {
  const map = new Map<string, SupplierSnapshotSummary>();
  for (const snapshot of snapshots) {
    if (!snapshot.supplierMappingId || map.has(snapshot.supplierMappingId)) continue;
    map.set(snapshot.supplierMappingId, snapshot);
  }
  return map;
}

function mappingTrustText(mapping: SupplierMapping): string {
  if (!mapping.enabled) return "disabled";
  return "saved mapping; exact DVG gate required; nincs approval mező";
}

function mappingTrustBadge(mapping: SupplierMapping) {
  return <span className="badge muted">{mappingTrustText(mapping)}</span>;
}

function buildAcceptanceChecklist(input: {
  session: SupplierSessionStatusResponse | null;
  readResult: DvgSupplierSessionReadOneResult | null;
  batchResult: SupplierSessionRunSelectedResult | null;
  manualRuns: ManualOperatorRunSummary[];
  exportChecks: { json: boolean; csv: boolean };
  retryOneChecked: boolean;
  resetResult: SupplierProfileResetResult | null;
  latestResult: unknown;
  error: string | null;
}): AcceptanceItem[] {
  const dryRunPassed = Boolean(
    input.readResult?.status === "parsed" && !input.readResult.persistence.saved
  );
  const snapshotSaved = Boolean(
    input.readResult?.persistence.saved ||
    input.batchResult?.savedCount ||
    input.manualRuns.some((run) => run.savedCount > 0)
  );
  const historyUpdated = input.manualRuns.length > 0;
  const microBatchChecked = Boolean(
    input.batchResult &&
    input.batchResult.totalRequested > 0 &&
    input.batchResult.totalRequested <= MAX_MANUAL_BATCH_SIZE
  );
  return [
    {
      key: "browser-opened",
      label: "DVG browser opened",
      done: Boolean(input.session?.browserOpen),
      detail: input.session?.state ?? "session closed",
    },
    {
      key: "manual-login-completed",
      label: "Manual login completed",
      done: Boolean(input.session?.authenticatedLikely),
      detail: `Auth likely: ${yesNo(input.session?.authenticatedLikely)}`,
    },
    {
      key: "session-check-passed",
      label: "Session check passed",
      done: Boolean(
        input.session?.authenticatedLikely && input.session.blockingSafetyFlags.length === 0
      ),
      detail: `Blocking flags: ${joinCodes(input.session?.blockingSafetyFlags)}`,
    },
    {
      key: "one-mapping-dry-run",
      label: "One mapping dry-run passed",
      done: dryRunPassed,
      detail: input.readResult?.requestedArticle ?? "no dry-run result",
    },
    {
      key: "snapshot-saved",
      label: "Snapshot saved",
      done: snapshotSaved,
      detail: input.readResult?.persistence.snapshotId ?? `Saved in history: ${snapshotSaved}`,
    },
    {
      key: "history-updated",
      label: "Run history updated",
      done: historyUpdated,
      detail: `${input.manualRuns.length} manual run rows loaded`,
    },
    {
      key: "export-checked",
      label: "JSON/CSV export checked",
      done: input.exportChecks.json && input.exportChecks.csv,
      detail: `JSON: ${yesNo(input.exportChecks.json)}, CSV: ${yesNo(input.exportChecks.csv)}`,
    },
    {
      key: "micro-batch-max-five",
      label: "Micro-batch max 5 checked",
      done: microBatchChecked,
      detail: input.batchResult
        ? `${input.batchResult.totalRequested}/${MAX_MANUAL_BATCH_SIZE} requested`
        : "no micro-batch result",
    },
    {
      key: "retry-one",
      label: "Retry-one checked",
      done: input.retryOneChecked,
      detail: input.retryOneChecked ? "retry-one completed" : "no retry-one result",
    },
    {
      key: "reset-profile",
      label: "Reset profile checked",
      done: Boolean(input.resetResult?.reset),
      detail: input.resetResult?.reset ? "managed DVG profile reset" : "not reset",
    },
    {
      key: "no-sensitive-data-visible",
      label: "No sensitive data visible",
      done: isSanitizedResultVisible({ latestResult: input.latestResult, error: input.error }),
      detail: "debug/result JSON checked for sensitive keys and full paths",
    },
  ];
}

function checkBadge(done: boolean) {
  return <span className={done ? "badge success" : "badge muted"}>{done ? "ok" : "pending"}</span>;
}

function isSanitizedResultVisible(value: unknown): boolean {
  if (!value) return false;
  const text = JSON.stringify(value);
  return !/(cookie|set-cookie|authorization|bearer|password|credential|token|storageState|localStorage|sessionStorage|rawHtml|screenshot|\bHAR\b|trace|MHTML|[A-Za-z]:[\\/]|\\\\|\/(Users|home|root|tmp|var|private|opt|mnt|Volumes)\/)/i.test(
    text
  );
}

function formatSnapshotSummary(snapshot: SupplierSnapshotSummary | null): string {
  if (!snapshot) return "-";
  return `${formatMoney(snapshot.priceNetEur, snapshot.currency)} / ${formatDate(
    snapshot.observedAt
  )}`;
}

function downloadTextFile(filename: string, content: string, contentType: string): void {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}

function getOperatorState(input: {
  error: string | null;
  session: SupplierSessionStatusResponse | null;
  selectedMapping: SupplierMapping | null;
  readResult: DvgSupplierSessionReadOneResult | null;
  batchResult: SupplierSessionRunSelectedResult | null;
  blockingSafetyFlags: string[];
}): string {
  if (input.error?.includes("Helyi API")) return "API offline";
  if (input.blockingSafetyFlags.length > 0) return "safety stopped";
  if (input.batchResult?.status === "stopped") return "micro-batch stopped";
  if (input.batchResult?.status === "completed") return "micro-batch completed";
  if (input.readResult?.persistence.saved) return "snapshot saved";
  if (input.readResult?.snapshotGate.allowed) return "snapshot allowed";
  if (input.readResult && !input.readResult.snapshotGate.allowed) return "snapshot blocked";
  if (input.session?.authenticatedLikely && input.selectedMapping) return "mapping selected";
  if (input.session?.authenticatedLikely) return "authenticated likely";
  if (input.session?.browserOpen) return "login needed";
  return "session closed";
}

function isDvgSupplier(supplier: Supplier): boolean {
  return /dvg|de\s*vecchi/i.test(`${supplier.code} ${supplier.name}`);
}

function isUuid(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function yesNo(value: boolean | null | undefined): string {
  if (value === undefined || value === null) return "-";
  return value ? "igen" : "nem";
}

function joinCodes(values: string[] | null | undefined): string {
  return values && values.length > 0 ? Array.from(new Set(values)).join(", ") : "-";
}

function formatError(error: { code: string; message: string } | null | undefined): string {
  if (!error) return "-";
  return `${error.code}: ${error.message}`;
}

function formatMoney(value: number | null, currency: string | null): string {
  if (value === null || !Number.isFinite(value)) return "-";
  return `${value.toFixed(2)} ${currency ?? ""}`.trim();
}

function formatDate(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString("hu-HU");
}
