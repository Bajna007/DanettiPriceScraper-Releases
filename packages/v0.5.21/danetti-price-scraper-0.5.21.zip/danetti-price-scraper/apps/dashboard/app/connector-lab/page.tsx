"use client";

import { useEffect, useState } from "react";
import {
  getCheckJob,
  listConnectors,
  queueDummySupplierDryRun,
  type CheckJobResponse,
  type ConnectorMetadata,
} from "../../src/lib/api";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import { labelConnectorSafetyStatus, labelLookupStrategy } from "../../src/lib/labels";

export default function ConnectorLabPage() {
  const [connectors, setConnectors] = useState<ConnectorMetadata[]>([]);
  const [loading, setLoading] = useState(false);
  const [queueLoading, setQueueLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [queuedJobId, setQueuedJobId] = useState<string | null>(null);
  const [jobResult, setJobResult] = useState<CheckJobResponse | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);

    listConnectors()
      .then((response) => {
        if (active) setConnectors(response.items ?? []);
      })
      .catch((err) => {
        if (active)
          setError(err instanceof Error ? err.message : "Nem sikerült betölteni a connectorokat.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  async function queueDryRun() {
    setQueueLoading(true);
    setError(null);
    setJobResult(null);
    try {
      const response = await queueDummySupplierDryRun();
      setQueuedJobId(response.jobId ?? null);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Nem sikerült sorba állítani a próbaellenőrzést."
      );
    } finally {
      setQueueLoading(false);
    }
  }

  async function refreshJob() {
    if (!queuedJobId) return;
    setQueueLoading(true);
    setError(null);
    try {
      setJobResult(await getCheckJob(queuedJobId));
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Nem sikerült betölteni a sorba állított feladatot."
      );
    } finally {
      setQueueLoading(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Connector teszt</h1>
      </div>

      <section className="card">
        <h2 className="section-title">Biztonsági összefoglaló</h2>
        <p>
          Biztonságos Playwright audit alap csak helyi stub oldalakhoz készült. Valódi scraping
          nincs engedélyezve. Valódi connector munkához előbb jóváhagyott beszállítói portál audit
          kell.
        </p>
        <ul className="helper-text">
          <li>Ebben a fázisban nincs B2B portálhozzáférés.</li>
          <li>Nincs belépési adat, cookie vagy storageState fájl.</li>
          <li>
            DVG belépési adat csak runtime környezeti változó lehet, repositoryba nem kerülhet.
          </li>
          <li>
            Jövőbeli connector csak SafeBrowserContext és safety policy guard használatával
            készülhet.
          </li>
          <li>Valódi connector implementációt beszállítói portál audit jóváhagyás kapuz.</li>
          <li>Első valódi connector jóváhagyott audit metaadatból készüljön.</li>
          <li>Tetszőleges URL tesztelés nem engedélyezett.</li>
          <li>
            Tiltott műveletek: kosárba rakás, checkout, rendelés, ajánlatkérés,
            mentés/törlés/módosítás.
          </li>
          <li>Itt nincs futtatási, belépési vagy teszt portál vezérlő.</li>
          <li>DVG élő smoke teszt csak explicit operátori gate után futhat.</li>
        </ul>
      </section>

      <section className="card table-card">
        <h2 className="section-title">Connector stratégia mátrix</h2>
        <p className="helper-text">
          Audit után itt látszik, melyik megközelítés biztonságos. Jelenleg csak döntési segédlet,
          nem indít valódi connectort.
        </p>
        <div className="table-scroll">
          <table className="table data-table data-table--compact">
            <colgroup>
              <col className="col-strategy" />
              <col className="col-message" />
              <col className="col-warning" />
            </colgroup>
            <thead>
              <tr>
                <th className="cell-nowrap">Stratégia</th>
                <th>Mikor használható</th>
                <th>Fő kockázat</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="cell-nowrap">Találati lista</td>
                <td className="cell-wrap">Pontos SKU találat, ár és készlet listában látszik.</td>
                <td className="cell-wrap">Több találat esetén kézi ellenőrzés kell.</td>
              </tr>
              <tr>
                <td className="cell-nowrap">Találatból termékoldal</td>
                <td className="cell-wrap">
                  Lista csak linket ad, részletoldal olvasható veszélyes művelet nélkül.
                </td>
                <td className="cell-wrap">
                  Kosár vagy ajánlat gomb közelében nincs engedélyezett kattintás.
                </td>
              </tr>
              <tr>
                <td className="cell-nowrap">Direkt URL belépéssel</td>
                <td className="cell-wrap">
                  DVG jellegű, auditált részletoldal csak belépés után mutat nettó árat.
                </td>
                <td className="cell-wrap">
                  Credential nem tárolható; kosár form jelenléte miatt kattintás tiltott.
                </td>
              </tr>
              <tr>
                <td className="cell-nowrap">Export fájl</td>
                <td className="cell-wrap">Portál jóváhagyott, kézi exportot ad árlistára.</td>
                <td className="cell-wrap">Fájl formátum és frissesség külön ellenőrzendő.</td>
              </tr>
              <tr>
                <td className="cell-nowrap">Hálózati válasz</td>
                <td className="cell-wrap">
                  Auditált, olvasó GET válasz stabil és nem állapotmódosító.
                </td>
                <td className="cell-wrap">Ismeretlen endpoint probing tiltott.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section className="card">
        <h2 className="section-title">Próbafuttatás sor</h2>
        <p className="helper-text">
          Csak dummy / helyi sor ellenőrzés. Nem ér el beszállítói portált, és nem indít böngésző
          automatizálást. A jelenlegi sor/futtatás képesség csak dummy / helyi.
        </p>
        <div className="action-row">
          <button className="button" onClick={queueDryRun} disabled={queueLoading}>
            {queueLoading ? "Sorba állítás..." : "Dummy próbafuttatás sorba állítása"}
          </button>
          <button
            className="button secondary"
            onClick={refreshJob}
            disabled={!queuedJobId || queueLoading}
          >
            Feladat frissítése
          </button>
          {queuedJobId ? <span className="status">Feladat ID: {queuedJobId}</span> : null}
        </div>
        {jobResult ? (
          <p className="helper-text">
            Feladat állapot: {jobResult.state}. Eredmény:{" "}
            {jobResult.returnvalue ? JSON.stringify(jobResult.returnvalue) : "még nem készült el"}
          </p>
        ) : null}
      </section>

      {loading ? <LoadingState message="Connector metaadat betöltése..." /> : null}
      {error ? <ErrorState message={error} /> : null}

      {!loading && !error && connectors.length === 0 ? (
        <EmptyState title="Nincs elérhető connector">
          API elérhető, de a connector registry nem adott vissza metaadatot.
        </EmptyState>
      ) : null}

      {connectors.length ? (
        <section className="card table-card">
          <h2 className="section-title">Elérhető connectorok</h2>
          <div className="table-scroll">
            <table className="table data-table data-table--wide">
              <colgroup>
                <col className="col-id" />
                <col className="col-name" />
                <col className="col-strategy" />
                <col className="col-domains" />
                <col className="col-status" />
                <col className="col-action" />
              </colgroup>
              <thead>
                <tr>
                  <th className="cell-nowrap">ID</th>
                  <th>Név</th>
                  <th>Stratégiák</th>
                  <th>Engedélyezett domainek</th>
                  <th className="cell-nowrap">Biztonsági állapot</th>
                  <th className="cell-nowrap">Live smoke</th>
                </tr>
              </thead>
              <tbody>
                {connectors.map((connector) => (
                  <tr key={connector.id}>
                    <td className="cell-mono cell-truncate" title={connector.id}>
                      {connector.id}
                    </td>
                    <td className="cell-truncate" title={connector.displayName}>
                      {connector.displayName}
                    </td>
                    <td
                      className="cell-truncate"
                      title={connector.supportedStrategies.map(labelLookupStrategy).join(", ")}
                    >
                      {connector.supportedStrategies.map(labelLookupStrategy).join(", ")}
                    </td>
                    <td
                      className="cell-mono cell-truncate"
                      title={connector.allowedDomains.join(", ")}
                    >
                      {connector.allowedDomains.join(", ")}
                    </td>
                    <td className="cell-nowrap">
                      <span className="badge">
                        {labelConnectorSafetyStatus(connector.safetyStatus)}
                      </span>
                    </td>
                    <td className="cell-nowrap">
                      {connector.manualLiveSmokeCommand ? (
                        <code>{connector.manualLiveSmokeCommand}</code>
                      ) : (
                        "-"
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}
    </div>
  );
}
