"use client";

import { useState } from "react";
import {
  fullSyncCatalogCsv,
  previewCatalogCsv,
  type CatalogImportValidationIssue,
  type ImportDetailResponse,
} from "../../src/lib/api";
import { ErrorState, LoadingState } from "../../src/components/States";
import { labelImportStatus } from "../../src/lib/labels";

type DisplayImportIssue = CatalogImportValidationIssue & {
  kind: "error" | "warning";
};

export default function CsvImportPage() {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewResult, setPreviewResult] = useState<ImportDetailResponse | null>(null);
  const [importResult, setImportResult] = useState<ImportDetailResponse | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  const handlePreview = async () => {
    setError(null);
    setImportResult(null);

    if (!file) {
      setError("Előbb válassz CSV fájlt.");
      return;
    }

    setIsPreviewing(true);
    try {
      const result = await previewCatalogCsv(file);
      setPreviewResult(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Az előnézet nem sikerült.");
    } finally {
      setIsPreviewing(false);
    }
  };

  const handleImport = async () => {
    setError(null);

    if (!file) {
      setError("Előbb válassz CSV fájlt.");
      return;
    }
    if (!previewResult) {
      setError("Előbb készíts előnézetet.");
      return;
    }

    setIsImporting(true);
    try {
      const result = await fullSyncCatalogCsv(file);
      setImportResult(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Az import nem sikerült.");
    } finally {
      setIsImporting(false);
    }
  };

  const handleCopyField = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedField(value);
      window.setTimeout(
        () => setCopiedField((current) => (current === value ? null : current)),
        1400
      );
    } catch {
      setError("A vágólapra másolás nem sikerült. Jelöld ki és másold kézzel a mező nevét.");
    }
  };

  return (
    <div className="page csv-import-page">
      <div className="page-header">
        <h1 className="page-title">CSV import</h1>
      </div>

      <section className="card csv-upload-card">
        <div className="csv-section-heading">
          <div>
            <h2 className="section-title">WooCommerce CSV feltöltése</h2>
            <p className="helper-text">
              Először előnézet készül. Véglegesítéskor csak a helyi Danetti katalógus frissül.
            </p>
          </div>
          <span className="csv-safety-pill">WooCommerce írás nélkül</span>
        </div>

        <div className="csv-upload-row">
          <input
            className="input"
            type="file"
            accept=".csv"
            aria-label="WooCommerce CSV fájl kiválasztása"
            onChange={(event) => {
              setFile(event.target.files?.[0] ?? null);
              setPreviewResult(null);
              setImportResult(null);
              setError(null);
            }}
          />
          <button className="button" type="button" onClick={handlePreview} disabled={isPreviewing}>
            {isPreviewing ? "Előnézet készül..." : "Előnézet készítése"}
          </button>
        </div>

        {file ? (
          <p className="csv-file-feedback">
            Kiválasztva: <strong>{file.name}</strong>
          </p>
        ) : null}

        <div className="csv-rule-strip" aria-label="Import működés">
          <span>Új cikkszám bekerül.</span>
          <span>Meglévő cikkszám frissül.</span>
          <span>DVG ár és haszon megmarad.</span>
          <span>CSV-ből hiányzó termék nem törlődik.</span>
        </div>
      </section>

      {error ? <ErrorState message={error} /> : null}
      {isPreviewing ? <LoadingState message="CSV előnézet készül..." /> : null}

      {previewResult ? (
        <PreviewPanel result={previewResult} isImporting={isImporting} onImport={handleImport} />
      ) : (
        <section className="notice info csv-empty-preview">
          <strong>Nincs előnézet.</strong> Válassz CSV fájlt, majd kattints az előnézetre.
        </section>
      )}

      {isImporting ? <LoadingState message="Helyi katalógus frissítése..." /> : null}
      {importResult ? <ImportFinishedPanel result={importResult} /> : null}

      <section className="card csv-help-details" aria-labelledby="csv-help-title">
        <div className="csv-help-summary">
          <span className="csv-help-summary-copy">
            <strong id="csv-help-title">CSV fejléc segítség</strong>
            <small>Másolható WooCommerce és magyar oszlopnevek a biztos felismeréshez.</small>
          </span>
        </div>
        <CsvFieldList fields={csvFieldGuide} copiedField={copiedField} onCopy={handleCopyField} />
      </section>
    </div>
  );
}

function PreviewPanel({
  result,
  isImporting,
  onImport,
}: {
  result: ImportDetailResponse;
  isImporting: boolean;
  onImport: () => void;
}) {
  const issues = getImportIssues(result);
  const missingNameCount = issues.filter((issue) => issue.code === "missing_name").length;
  const previewState = getPreviewState(result, issues);

  return (
    <section className="card csv-result-panel">
      <div className={`csv-result-banner ${previewState.tone}`}>
        <div>
          <h2>{previewState.title}</h2>
          <p>{previewState.description}</p>
        </div>
        <span>{result.totalRows ?? 0} sor</span>
      </div>

      <div className="csv-metric-strip" aria-label="Előnézet számok">
        <CsvMetric label="Frissül" value={result.updatedCount ?? 0} />
        <CsvMetric label="Új" value={result.insertedCount ?? 0} />
        <CsvMetric label="SKU nélkül kimarad" value={result.skippedMissingSkuCount ?? 0} />
        <CsvMetric label="Korábbi duplikált sor" value={result.skippedDuplicateCount ?? 0} />
        <CsvMetric label="Név nélkül, importálva" value={missingNameCount} />
      </div>

      {issues.length > 0 ? (
        <div className="csv-issues-block">
          <div className="csv-block-heading">
            <h3 className="section-title">Figyelmeztetések teljes listája</h3>
            <span>{issues.length} jelzés</span>
          </div>
          <div className="table-scroll csv-issues-scroll">
            <table className="table data-table data-table--wide csv-issues-table">
              <colgroup>
                <col className="col-number" />
                <col className="col-name-wide" />
                <col className="col-sku" />
                <col className="col-warning" />
                <col className="col-warning" />
              </colgroup>
              <thead>
                <tr>
                  <th className="numeric cell-nowrap">Sor</th>
                  <th>Termék</th>
                  <th className="cell-nowrap">Cikkszám</th>
                  <th>Probléma</th>
                  <th>Mi történik?</th>
                </tr>
              </thead>
              <tbody>
                {issues.map((issue, index) => (
                  <tr key={`${issue.kind}-${issue.rowNumber ?? "file"}-${issue.code}-${index}`}>
                    <td className="numeric cell-nowrap">{issue.rowNumber ?? "-"}</td>
                    <td className="cell-truncate" title={labelIssueProduct(issue)}>
                      {labelIssueProduct(issue)}
                    </td>
                    <td className="cell-mono cell-truncate" title={issue.sku ?? ""}>
                      {issue.sku ?? "-"}
                    </td>
                    <td className="cell-wrap">
                      <span className="csv-issue-pill warning">{labelIssue(issue)}</span>
                    </td>
                    <td className="cell-wrap">{labelIssueAction(issue)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="notice success csv-inline-notice">
          <strong>Nincs javítandó sor.</strong> A helyi katalógus frissíthető.
        </div>
      )}

      <div className="csv-import-action">
        <button className="button" type="button" onClick={onImport} disabled={isImporting}>
          {isImporting ? "Teljes lista importálása..." : "Teljes lista importálása"}
        </button>
        <span>
          Minden SKU-val rendelkező sor frissül vagy bekerül. A jelzések csak figyelmeztetések; SKU
          nélküli sor nem azonosítható, ezért kimarad. Nincs WooCommerce írás.
        </span>
      </div>
    </section>
  );
}

function ImportFinishedPanel({ result }: { result: ImportDetailResponse }) {
  const failed = result.status === "failed" || (result.failedCount ?? 0) > 0;

  return (
    <section className={`notice ${failed ? "error" : "success"} csv-finished-panel`}>
      <h2>{failed ? "Az import nem futott le" : "Kész: helyi katalógus frissítve"}</h2>
      <p>
        Új: <strong>{result.insertedCount ?? 0}</strong>, frissült:{" "}
        <strong>{result.updatedCount ?? 0}</strong>, SKU nélkül kimaradt:{" "}
        <strong>{result.skippedMissingSkuCount ?? 0}</strong>, korábbi duplikált sor:{" "}
        <strong>{result.skippedDuplicateCount ?? 0}</strong>.
      </p>
    </section>
  );
}

function CsvMetric({ label, value }: { label: string; value: number }) {
  return (
    <div className="csv-metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

type CsvFieldGuideItem = {
  id: string;
  label: string;
  hungarianHeader: string;
  wooHeader: string;
  note: string;
};

const csvFieldGuide: CsvFieldGuideItem[] = [
  {
    id: "id",
    label: "Azonosító",
    hungarianHeader: "Azonosító",
    wooHeader: "ID",
    note: "WooCommerce termékazonosító. Hibakereséshez hasznos.",
  },
  {
    id: "sku",
    label: "Cikkszám",
    hungarianHeader: "Cikkszám",
    wooHeader: "SKU",
    note: "Ez alapján frissül a helyi termék. SKU nélkül a sor kimarad.",
  },
  {
    id: "name",
    label: "Név",
    hungarianHeader: "Név",
    wooHeader: "Name",
    note: "Ha üres, a sor SKU-alapú helyettesítő névvel importálódik.",
  },
  {
    id: "type",
    label: "Típus",
    hungarianHeader: "Típus",
    wooHeader: "Type",
    note: "Például simple, variable vagy variation.",
  },
  {
    id: "regularPrice",
    label: "Normál ár / listaár",
    hungarianHeader: "Normál ár",
    wooHeader: "Regular price",
    note: "Hibás szám esetén a termék importálódik, az ár üres marad.",
  },
  {
    id: "salePrice",
    label: "Akciós ár",
    hungarianHeader: "Akciós ár",
    wooHeader: "Sale price",
    note: "Akciós/kedvezményes ár, ha van.",
  },
  {
    id: "parent",
    label: "Szülő termék",
    hungarianHeader: "Szülő",
    wooHeader: "Parent",
    note: "Variációknál hasznos szülő termék ID vagy SKU hivatkozás.",
  },
];

function CsvFieldList({
  fields,
  copiedField,
  onCopy,
}: {
  fields: CsvFieldGuideItem[];
  copiedField: string | null;
  onCopy: (value: string) => void;
}) {
  return (
    <div className="csv-field-section">
      <div className="csv-field-intro">
        <strong>Ajánlott fejlécnevek</strong>
        <span>Kattints a másolás ikonra, ha egységes CSV sablont készítesz.</span>
      </div>
      <div className="csv-field-list">
        {fields.map((field) => (
          <div className="csv-field-row" key={field.id}>
            <div className="csv-field-copy">
              <strong>{field.label}</strong>
              <span>{field.note}</span>
            </div>
            <CopyableHeader
              label="Magyar fejléc"
              value={field.hungarianHeader}
              copied={copiedField === field.hungarianHeader}
              onCopy={onCopy}
            />
            <CopyableHeader
              label="Woo fejléc"
              value={field.wooHeader}
              copied={copiedField === field.wooHeader}
              onCopy={onCopy}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

function CopyableHeader({
  label,
  value,
  copied,
  onCopy,
}: {
  label: string;
  value: string;
  copied: boolean;
  onCopy: (value: string) => void;
}) {
  return (
    <div className="csv-copy-token">
      <span>{label}</span>
      <div className="csv-copy-value">
        <code>{value}</code>
        <button
          className={`button secondary small csv-copy-button${copied ? " is-copied" : ""}`}
          type="button"
          onClick={() => onCopy(value)}
          title={`${value} vágólapra másolása`}
          aria-label={`${value} vágólapra másolása`}
        >
          <svg aria-hidden="true" viewBox="0 0 16 16" width="14" height="14">
            <path d="M5 2.5A1.5 1.5 0 0 1 6.5 1h3A1.5 1.5 0 0 1 11 2.5V3h1.5A1.5 1.5 0 0 1 14 4.5v8A1.5 1.5 0 0 1 12.5 14h-9A1.5 1.5 0 0 1 2 12.5v-8A1.5 1.5 0 0 1 3.5 3H5v-.5Zm1 0V4h4V2.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM3.5 4a.5.5 0 0 0-.5.5v8a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5v-8a.5.5 0 0 0-.5-.5H11v.5A.5.5 0 0 1 10.5 5h-5A.5.5 0 0 1 5 4.5V4H3.5Z" />
          </svg>
          <span className="csv-copy-feedback">{copied ? "Másolva" : "Másolás"}</span>
        </button>
      </div>
    </div>
  );
}

function getImportIssues(result: ImportDetailResponse): DisplayImportIssue[] {
  const errors = (result.validation?.errorRows ?? []).map((issue) => ({
    ...issue,
    kind: "warning" as const,
  }));
  const warnings = (result.validation?.warnings ?? []).map((issue) => ({
    ...issue,
    kind: "warning" as const,
  }));
  return [...errors, ...warnings].sort(compareIssues);
}

function compareIssues(a: DisplayImportIssue, b: DisplayImportIssue): number {
  const rowA = a.rowNumber ?? Number.MAX_SAFE_INTEGER;
  const rowB = b.rowNumber ?? Number.MAX_SAFE_INTEGER;
  if (rowA !== rowB) return rowA - rowB;
  return a.code.localeCompare(b.code);
}

function getPreviewState(
  result: ImportDetailResponse,
  issues: DisplayImportIssue[]
): {
  tone: "success" | "warning" | "error";
  title: string;
  description: string;
} {
  if (issues.length > 0 || (result.skippedMissingSkuCount ?? 0) > 0) {
    return {
      tone: "warning",
      title: "CSV ellenőrzése kész, importálható figyelmeztetésekkel",
      description:
        "Minden SKU-val rendelkező sor megy tovább. A jelzések warningok, nem állítják meg az importot.",
    };
  }

  return {
    tone: "success",
    title: "CSV ellenőrzése kész",
    description: "Az előnézet alapján a helyi katalógus frissíthető.",
  };
}

function labelIssueProduct(issue: CatalogImportValidationIssue): string {
  if (issue.name) return issue.name;
  if (issue.sku) return `SKU: ${issue.sku}`;
  if (issue.sourceProductId) return `ID: ${issue.sourceProductId}`;
  if (issue.code === "column_mapping_warning") return "CSV fejléc";
  return "Név nélkül";
}

function labelIssue(issue: CatalogImportValidationIssue): string {
  switch (issue.code) {
    case "missing_name":
      return "Hiányzik a terméknév";
    case "missing_sku":
      return "Hiányzik a cikkszám";
    case "duplicate_sku":
      return "Duplikált cikkszám";
    case "sku_format_warning":
      return "Szokatlan cikkszám formátum";
    case "invalid_regular_price":
      return "Hibás normál ár";
    case "invalid_sale_price":
      return "Hibás akciós ár";
    case "invalid_current_price":
      return "Hibás aktuális ár";
    case "invalid_stock_quantity":
      return "Hibás készlet mennyiség";
    case "unsupported_type":
      return "Ismeretlen terméktípus";
    case "missing_variation_parent":
      return "Hiányzó szülő termék";
    case "column_mapping_warning":
      return "CSV fejléc ellenőrzendő";
    default:
      return issue.message;
  }
}

function labelIssueAction(issue: CatalogImportValidationIssue): string {
  switch (issue.code) {
    case "missing_name":
      return "Importálódik SKU-alapú helyettesítő névvel.";
    case "missing_sku":
      return "Ez a sor kimarad.";
    case "duplicate_sku":
      return issue.status === "skipped_duplicate"
        ? "Kimarad, az utolsó ilyen cikkszámú sor számít."
        : "Ez az utolsó előfordulás importálódik.";
    case "sku_format_warning":
      return "Importálódik, de a DVG javasolt cikkszám ellenőrizendő.";
    case "invalid_regular_price":
    case "invalid_sale_price":
    case "invalid_current_price":
    case "invalid_stock_quantity":
      return "Importálódik, az adott érték üres marad.";
    case "unsupported_type":
      return "Importálódik ezzel a típussal.";
    case "missing_variation_parent":
      return "Importálódik, de szülő nélkül.";
    case "column_mapping_warning":
      return "Részletek lent, a felismert CSV oszlopoknál.";
    default:
      return issue.status ? labelImportStatus(issue.status) : "Importálódik figyelmeztetéssel.";
  }
}
