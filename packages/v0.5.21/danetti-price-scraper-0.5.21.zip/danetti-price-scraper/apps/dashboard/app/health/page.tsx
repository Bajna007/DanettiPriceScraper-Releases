"use client";

import { useEffect, useMemo, useState } from "react";
import { ErrorState, LoadingState } from "../../src/components/States";
import { getRuntimeHealth, type RuntimeHealthResponse } from "../../src/lib/api";
import { labelRuntimeStatus } from "../../src/lib/labels";

export default function HealthPage() {
  const [health, setHealth] = useState<RuntimeHealthResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    setLoading(true);
    setError(null);

    try {
      setHealth(await getRuntimeHealth());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Nem sikerült betölteni a rendszerállapotot.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void refresh();
  }, []);

  const rows = useMemo(() => {
    if (!health) return [];

    return [
      { service: "API", status: health.api.status, message: "API folyamat válaszol." },
      { service: "Adatbázis", ...health.database },
      { service: "Redis", ...health.redis },
      { service: "Worker", ...health.worker },
    ];
  }, [health]);

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Rendszerállapot</h1>
      </div>

      <section className="card">
        <h2 className="section-title">Általános állapot</h2>
        <p className="card-value">{health ? labelRuntimeStatus(health.status) : "Betöltés..."}</p>
        <div className="action-row">
          <button className="button secondary" onClick={refresh} disabled={loading}>
            Frissítés
          </button>
          <span className="status">A nézet csak olvas, nem indít szolgáltatást.</span>
        </div>
      </section>

      {loading ? <LoadingState message="Rendszerállapot betöltése..." /> : null}
      {error ? <ErrorState message={error} /> : null}

      {health ? (
        <section className="card table-card">
          <div className="table-scroll">
            <table className="table data-table data-table--status">
              <colgroup>
                <col className="col-medium" />
                <col className="col-status" />
                <col className="col-message" />
              </colgroup>
              <thead>
                <tr>
                  <th className="cell-nowrap">Szolgáltatás</th>
                  <th className="cell-nowrap">Állapot</th>
                  <th>Üzenet</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.service}>
                    <td className="cell-nowrap">{row.service}</td>
                    <td className="cell-nowrap">
                      <span className="badge">{labelRuntimeStatus(row.status)}</span>
                    </td>
                    <td className="cell-wrap">{row.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}

      <section className="card">
        <h2 className="section-title">Hibaelhárítás</h2>
        <p className="helper-text">
          Ha adatbázis vagy Redis nem elérhető, indítsd a helyi infrastruktúrát, majd futtasd a
          migrációt. Docker nélküli PC-n ez a rész várhatóan hibát jelezhet.
        </p>
        <pre className="command-block">
          <code>npm.cmd run docker:up{"\n"}npm.cmd run db:migrate</code>
        </pre>
        <p className="helper-text">Teljes web-only indítás:</p>
        <pre className="command-block">
          <code>npm.cmd run local:web</code>
        </pre>
      </section>
    </div>
  );
}
