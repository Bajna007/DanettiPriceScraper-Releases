import { redirect } from "next/navigation";

export default function DvgProductsPage() {
  redirect("/operator/dvg");
}
