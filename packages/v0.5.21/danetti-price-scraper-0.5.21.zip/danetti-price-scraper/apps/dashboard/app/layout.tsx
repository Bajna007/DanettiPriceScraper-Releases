import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { DashboardShell } from "../src/components/DashboardShell";
import { Navigation } from "../src/components/Navigation";

export const metadata: Metadata = {
  title: "Danetti Árfigyelő",
  description: "Helyi, read-only B2B beszállítói árfigyelő dashboard",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="hu">
      <body>
        <DashboardShell title="Danetti Árfigyelő" nav={<Navigation />}>
          {children}
        </DashboardShell>
      </body>
    </html>
  );
}
