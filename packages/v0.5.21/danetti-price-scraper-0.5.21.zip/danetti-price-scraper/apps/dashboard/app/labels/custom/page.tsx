import { Suspense } from "react";
import { CustomLabelWorkspace } from "../../../src/labels/CustomLabelWorkspace";
export default function CustomLabelsPage() {
  return (
    <Suspense>
      <CustomLabelWorkspace />
    </Suspense>
  );
}
