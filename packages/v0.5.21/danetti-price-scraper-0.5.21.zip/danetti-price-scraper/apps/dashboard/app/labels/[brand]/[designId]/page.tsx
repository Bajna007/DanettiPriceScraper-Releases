import { notFound } from "next/navigation";
import { LabelEditor } from "../../../../src/labels/LabelEditor";
export default async function LabelEditorPage({
  params,
}: {
  params: Promise<{ brand: string; designId: string }>;
}) {
  const { brand, designId } = await params;
  if (brand !== "utopia" && brand !== "bean-on" && brand !== "custom") notFound();
  return <LabelEditor designId={designId} />;
}
