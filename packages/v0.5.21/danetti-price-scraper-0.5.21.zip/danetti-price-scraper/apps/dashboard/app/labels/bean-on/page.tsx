import { Suspense } from "react";
import { LabelWorkspace } from "../../../src/labels/LabelWorkspace";
export default function BeanOnLabelsPage() {
  return (
    <Suspense fallback={<p>Címketár betöltése…</p>}>
      <LabelWorkspace brand="bean_on" />
    </Suspense>
  );
}
