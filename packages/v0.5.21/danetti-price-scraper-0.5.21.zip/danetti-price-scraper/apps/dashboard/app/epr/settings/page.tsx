import { AiConnection } from "../../../src/epr/AiConnection";
import { Mailboxes } from "../../../src/epr/Mailboxes";
import { ProcessingSettings } from "../../../src/epr/ProcessingSettings";
export default function EprSettingsPage() {
  return (
    <>
      <h1>EPR beállítások</h1>
      <AiConnection />
      <Mailboxes />
      <ProcessingSettings />
    </>
  );
}
