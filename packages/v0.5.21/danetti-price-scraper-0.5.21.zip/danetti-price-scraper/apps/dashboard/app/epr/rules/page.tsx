"use client";
import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { eprError, eprRequest } from "../../../src/epr/api";
import type { Rule } from "../../../src/epr/types";
type Component = { name: string; material: string; grams: string; classification: string };
export default function RulesPage() {
  const [unresolved, setUnresolved] = useState<
    {
      id: string;
      purchaseId: string;
      supplier: string;
      supplierSku: string | null;
      description: string;
    }[]
  >([]);
  const [rules, setRules] = useState<Rule[]>([]),
    [search, setSearch] = useState(""),
    [editing, setEditing] = useState<Rule | "new" | null>(null),
    [components, setComponents] = useState<Component[]>([]),
    [busy, setBusy] = useState(true),
    [error, setError] = useState("");
  const [recognition, setRecognition] = useState<
      { id: string; kind: string; match: string; value: string }[]
    >([]),
    [conversions, setConversions] = useState<
      {
        id: string;
        supplierIdentity: string;
        supplierSku: string;
        fromUnit: string;
        toUnit: string;
        factor: string;
        source: string;
      }[]
    >([]);
  async function load() {
    const [r, a, c, u] = await Promise.all([
      eprRequest<{ items: Rule[] }>("/epr/rules"),
      eprRequest<{ items: typeof recognition }>("/epr/recognition-rules"),
      eprRequest<{ items: typeof conversions }>("/epr/conversions"),
      eprRequest<{ items: typeof unresolved }>("/epr/unresolved-products"),
    ]);
    setRules(r.items);
    setRecognition(a.items);
    setConversions(c.items);
    setUnresolved(u.items);
  }
  useEffect(() => {
    load()
      .catch((e) => setError(eprError(e)))
      .finally(() => setBusy(false));
  }, []);
  function edit(rule: Rule | "new") {
    setEditing(rule);
    setComponents(
      rule === "new"
        ? [{ name: "", material: "", grams: "", classification: "" }]
        : rule.components.map((c) => ({ ...c, classification: c.classification ?? "" }))
    );
  }
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const d = new FormData(event.currentTarget);
    setBusy(true);
    setError("");
    try {
      await eprRequest("/epr/rules", "POST", {
        key: d.get("key"),
        name: d.get("name"),
        supplierIdentity: d.get("supplier"),
        supplierSku: d.get("sku"),
        validFrom: d.get("from"),
        validTo: d.get("to") || null,
        applicability: d.get("applicability"),
        unit: d.get("unit"),
        source: d.get("source"),
        notes: d.get("notes") || null,
        operator: "local-operator",
        components: components.map((c) => ({ ...c, classification: c.classification || null })),
      });
      setEditing(null);
      await load();
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  const value = editing && editing !== "new" ? editing : null;
  return (
    <>
      <div className="epr-heading">
        <h1>Anyagszabályok</h1>
        <button className="button" disabled={busy} onClick={() => edit("new")}>
          Új szabály
        </button>
      </div>
      {error ? (
        <p className="epr-error" role="alert">
          {error}
        </p>
      ) : null}
      {unresolved.length ? (
        <section className="epr-section">
          <h2>{unresolved.length} termék vár hozzárendelésre</h2>
          {unresolved.map((line) => (
            <p key={line.id}>
              <Link href={`/epr/purchases/${line.purchaseId}`}>
                {line.supplier} · {line.supplierSku ?? line.description}
              </Link>
            </p>
          ))}
        </section>
      ) : null}
      <section className="epr-section">
        <p>
          A szabályok mért anyagsúlyokat és jóváhagyott besorolásokat tartalmaznak. Minden módosítás
          új, megőrzött verziót hoz létre.
        </p>
        <label className="epr-field">
          Keresés
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Beszállító, cikkszám vagy termék"
          />
        </label>
        <div className="table-scroll">
          <table className="table data-table data-table--wide">
            <colgroup>
              <col style={{ width: "20%" }} />
              <col style={{ width: "16%" }} />
              <col style={{ width: "24%" }} />
              <col style={{ width: "8%" }} />
              <col style={{ width: "18%" }} />
              <col style={{ width: "14%" }} />
            </colgroup>
            <thead>
              <tr>
                <th>Beszállító-azonosító</th>
                <th>Cikkszám</th>
                <th>Termék</th>
                <th>Verzió</th>
                <th>Érvényesség</th>
                <th>Művelet</th>
              </tr>
            </thead>
            <tbody>
              {rules
                .filter((r) =>
                  `${r.name} ${r.supplierIdentity} ${r.supplierSku}`
                    .toLocaleLowerCase("hu")
                    .includes(search.toLocaleLowerCase("hu"))
                )
                .map((r) => (
                  <tr key={r.id}>
                    <td>{r.supplierIdentity}</td>
                    <td>{r.supplierSku}</td>
                    <td>{r.name}</td>
                    <td>v{r.version}</td>
                    <td>
                      {r.validFrom} – {r.validTo ?? "folyamatos"}
                    </td>
                    <td>
                      <button className="button secondary" onClick={() => edit(r)}>
                        Új verzió
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
        {!rules.length ? (
          <p>
            Még nincs anyagszabály. Először rögzíts egy terméket és annak igazolt anyagösszetételét.
          </p>
        ) : null}
      </section>
      {editing ? (
        <section className="epr-section">
          <h2>{value ? `${value.name} · új verzió` : "Új anyagszabály"}</h2>
          <form onSubmit={save} key={value?.id ?? "new"} className="epr-form-grid">
            <label className="epr-field">
              Szabály azonosító
              <input
                name="key"
                defaultValue={value?.key ?? ""}
                readOnly={!!value}
                required
                maxLength={200}
              />
            </label>
            <label className="epr-field">
              Termék neve
              <input name="name" defaultValue={value?.name ?? ""} required maxLength={300} />
            </label>
            <label className="epr-field">
              Beszállító jóváhagyott azonosítója
              <input
                name="supplier"
                defaultValue={value?.supplierIdentity ?? ""}
                required
                maxLength={300}
              />
            </label>
            <label className="epr-field">
              Beszállítói cikkszám
              <input name="sku" defaultValue={value?.supplierSku ?? ""} required maxLength={200} />
            </label>
            <label className="epr-field">
              Érvényes ettől
              <input name="from" type="date" defaultValue={value?.validFrom ?? ""} required />
            </label>
            <label className="epr-field">
              Érvényes eddig
              <input name="to" type="date" defaultValue={value?.validTo ?? ""} />
            </label>
            <label className="epr-field">
              Alkalmazás
              <select name="applicability" defaultValue={value?.applicability ?? "PER_ITEM"}>
                <option value="PER_ITEM">Tételenként</option>
                <option value="PER_PACKAGE">Csomagonként, jóváhagyott darabszámmal</option>
                <option value="PER_CASE">Gyűjtőnként, jóváhagyott darabszámmal</option>
                <option value="PER_SHIPMENT">Szállítmányonként, jóváhagyott darabszámmal</option>
                <option value="MANUAL_QUANTITY">Kézi mennyiség</option>
              </select>
            </label>
            <label className="epr-field">
              Számítási egység
              <input name="unit" defaultValue={value?.unit ?? "db"} required maxLength={50} />
            </label>
            <label className="epr-field">
              Mérés / besorolás forrása
              <textarea
                name="source"
                defaultValue={value?.source ?? ""}
                required
                maxLength={2000}
              />
            </label>
            <label className="epr-field">
              Megjegyzés
              <textarea name="notes" maxLength={4000} />
            </label>
            <div className="epr-wide">
              <h3>Anyagösszetevők</h3>
              {components.map((c, index) => (
                <fieldset className="epr-component" key={index}>
                  <legend>{index + 1}. összetevő</legend>
                  {(
                    [
                      ["name", "Név"],
                      ["material", "Anyag"],
                      ["grams", "g / számítási egység"],
                      ["classification", "Jóváhagyott EPR-besorolás (opcionális)"],
                    ] as const
                  ).map(([key, text]) => (
                    <label className="epr-field" key={key}>
                      {text}
                      <input
                        value={c[key]}
                        required={key !== "classification"}
                        onChange={(e) =>
                          setComponents((old) =>
                            old.map((v, i) => (i === index ? { ...v, [key]: e.target.value } : v))
                          )
                        }
                      />
                    </label>
                  ))}
                  <button
                    className="button secondary"
                    type="button"
                    disabled={components.length === 1}
                    onClick={() => setComponents((old) => old.filter((_, i) => i !== index))}
                  >
                    Összetevő eltávolítása
                  </button>
                </fieldset>
              ))}
              <button
                className="button secondary"
                type="button"
                onClick={() =>
                  setComponents((old) => [
                    ...old,
                    { name: "", material: "", grams: "", classification: "" },
                  ])
                }
              >
                Összetevő hozzáadása
              </button>
            </div>
            <div className="epr-actions epr-wide">
              <button className="button" disabled={busy} type="submit">
                Szabályverzió mentése
              </button>
              <button className="button secondary" type="button" onClick={() => setEditing(null)}>
                Mégse
              </button>
            </div>
          </form>
        </section>
      ) : null}
      <section className="epr-section">
        <h2>Jóváhagyott egységátváltások</h2>
        {conversions.map((c) => (
          <p key={c.id}>
            {c.supplierIdentity} / {c.supplierSku}: 1 {c.fromUnit} = {c.factor} {c.toUnit} ·{" "}
            {c.source}
          </p>
        ))}
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            const form = e.currentTarget,
              d = new FormData(form);
            setBusy(true);
            try {
              await eprRequest("/epr/conversions", "POST", {
                supplierIdentity: d.get("supplier"),
                supplierSku: d.get("sku"),
                fromUnit: d.get("from"),
                toUnit: d.get("to"),
                factor: d.get("factor"),
                source: d.get("source"),
              });
              form.reset();
              await load();
            } catch (err) {
              setError(eprError(err));
            } finally {
              setBusy(false);
            }
          }}
          className="epr-form-grid"
        >
          {[
            ["supplier", "Beszállító-azonosító"],
            ["sku", "Cikkszám"],
            ["from", "Számlaegység"],
            ["to", "Számítási egység"],
            ["factor", "Átváltási szorzó"],
            ["source", "Jóváhagyott forrás"],
          ].map(([key, text]) => (
            <label className="epr-field" key={key}>
              {text}
              <input name={key} required />
            </label>
          ))}
          <button className="button" disabled={busy}>
            Átváltás mentése
          </button>
        </form>
      </section>
      <section className="epr-section">
        <h2>Felismerési és kizárási szabályok</h2>
        <p>
          Csak kifejezetten jóváhagyott, pontos egyezések kerülnek megjegyzésre. A kizárások
          láthatók és eltávolíthatók.
        </p>
        {recognition.map((r) => (
          <div key={r.id} className="epr-actions">
            <p>
              {r.kind}: {r.match} → {r.value}
            </p>
            <button
              className="button secondary"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  await eprRequest(`/epr/recognition-rules/${r.id}`, "DELETE");
                  await load();
                } catch (e) {
                  setError(eprError(e));
                } finally {
                  setBusy(false);
                }
              }}
            >
              Eltávolítás
            </button>
          </div>
        ))}
        <form
          className="epr-form-grid"
          onSubmit={async (e) => {
            e.preventDefault();
            const form = e.currentTarget,
              d = new FormData(form);
            setBusy(true);
            try {
              await eprRequest("/epr/recognition-rules", "POST", {
                kind: d.get("kind"),
                match: d.get("match"),
                value: d.get("value"),
              });
              form.reset();
              await load();
            } catch (err) {
              setError(eprError(err));
            } finally {
              setBusy(false);
            }
          }}
        >
          <label className="epr-field">
            Típus
            <select name="kind">
              <option value="supplier_alias">Beszállítónév → jóváhagyott azonosító</option>
              <option value="supplier_domain">Email domain → jóváhagyott azonosító</option>
              <option value="exclusion">Beszállító / dokumentumtípus kizárása</option>
            </select>
          </label>
          <label className="epr-field">
            Pontos egyezés
            <input name="match" required maxLength={500} />
          </label>
          <label className="epr-field">
            Érték / kizárás indoka
            <input name="value" required maxLength={500} />
          </label>
          <button className="button" disabled={busy}>
            Szabály mentése
          </button>
        </form>
      </section>
    </>
  );
}
