import Link from "next/link";
import type { ReactNode } from "react";
import "./epr.css";
export default function EprLayout({ children }: { children: ReactNode }) {
  return (
    <div className="epr">
      <nav className="epr-nav" aria-label="EPR nézetek">
        <Link href="/epr">Időszak</Link>
        <Link href="/epr/rules">Anyagszabályok</Link>
        <Link href="/epr/settings">Beállítások</Link>
      </nav>
      {children}
    </div>
  );
}
