"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  createSupplier,
  deleteSupplierCredential,
  formatApiErrorMessage,
  formatCredentialApiErrorMessage,
  getSupplierCheckSettings,
  listSupplierCredentials,
  listSuppliers,
  lookupStrategies,
  patchSupplierCheckSettings,
  patchSupplier,
  putSupplierCredential,
  testSupplierCredential,
  type LookupStrategy,
  type Supplier,
  type SupplierCheckSettings,
  type SupplierCredentialStatus,
  type SupplierCredentialTestResponse,
} from "../../src/lib/api";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import { TablePagination } from "../../src/components/TablePagination";
import { labelEnabled, labelHealthStatus, labelLookupStrategy } from "../../src/lib/labels";

const DEFAULT_SUPPLIER_LIMIT = 50;

const defaultForm = {
  code: "",
  name: "",
  baseUrl: "",
  allowedDomains: "",
  supportedLookupStrategies: ["search_result"] as LookupStrategy[],
  defaultRateLimitPerMinute: 6,
};

const defaultCredentialForm = {
  username: "",
  password: "",
};

export default function SuppliersPage() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [checkSettingsBySupplierId, setCheckSettingsBySupplierId] = useState<
    Record<string, SupplierCheckSettings>
  >({});
  const [credentialsBySupplierId, setCredentialsBySupplierId] = useState<
    Record<string, SupplierCredentialStatus>
  >({});
  const [credentialForms, setCredentialForms] = useState<
    Record<string, typeof defaultCredentialForm>
  >({});
  const [credentialTestArticles, setCredentialTestArticles] = useState<Record<string, string>>({});
  const [credentialTestResults, setCredentialTestResults] = useState<
    Record<string, SupplierCredentialTestResponse>
  >({});
  const [form, setForm] = useState(defaultForm);
  const [showAddSupplierForm, setShowAddSupplierForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savingSettingsId, setSavingSettingsId] = useState<string | null>(null);
  const [savingCredentialId, setSavingCredentialId] = useState<string | null>(null);
  const [testingCredentialId, setTestingCredentialId] = useState<string | null>(null);
  const [deletingCredentialId, setDeletingCredentialId] = useState<string | null>(null);
  const [credentialMessage, setCredentialMessage] = useState<string | null>(null);
  const [credentialLoadError, setCredentialLoadError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const [total, setTotal] = useState(0);
  const canGoBack = offset > 0;
  const canGoNext = offset + suppliers.length < total;
  const paginationLabel = useMemo(() => {
    const start = total === 0 ? 0 : offset + 1;
    const end = Math.min(offset + DEFAULT_SUPPLIER_LIMIT, total);
    return `Megjelenítve: ${start}-${end} / ${total}`;
  }, [offset, total]);

  async function refresh() {
    setLoading(true);
    setError(null);
    try {
      const response = await listSuppliers({ limit: DEFAULT_SUPPLIER_LIMIT, offset });
      const items = response.items ?? [];
      const settings = await Promise.all(
        items.map(
          async (supplier) => [supplier.id, await getSupplierCheckSettings(supplier.id)] as const
        )
      );
      const credentials = await listSupplierCredentials().catch((err) => {
        setCredentialLoadError(formatCredentialApiErrorMessage(err));
        return { items: [] as SupplierCredentialStatus[] };
      });
      if ((credentials.items ?? []).length > 0) setCredentialLoadError(null);
      setSuppliers(items);
      setTotal(response.total ?? items.length);
      setCheckSettingsBySupplierId(Object.fromEntries(settings));
      setCredentialsBySupplierId(
        Object.fromEntries((credentials.items ?? []).map((item) => [item.supplierId, item]))
      );
      setCredentialForms((current) => {
        const next: Record<string, typeof defaultCredentialForm> = {};
        for (const item of credentials.items ?? []) {
          next[item.supplierId] = current[item.supplierId] ?? defaultCredentialForm;
        }
        return next;
      });
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void refresh();
  }, [offset]);

  useEffect(() => {
    if (total === 0 && offset !== 0) {
      setOffset(0);
      return;
    }
    if (total > 0 && offset >= total) {
      setOffset(Math.floor((total - 1) / DEFAULT_SUPPLIER_LIMIT) * DEFAULT_SUPPLIER_LIMIT);
    }
  }, [offset, total]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError(null);
    try {
      await createSupplier({
        code: form.code,
        name: form.name,
        baseUrl: emptyToNull(form.baseUrl),
        allowedDomains: splitCsv(form.allowedDomains),
        supportedLookupStrategies: form.supportedLookupStrategies,
        defaultRateLimitPerMinute: form.defaultRateLimitPerMinute,
      });
      setForm(defaultForm);
      setShowAddSupplierForm(false);
      await refresh();
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  }

  async function toggleSupplier(supplier: Supplier) {
    setError(null);
    try {
      await patchSupplier(supplier.id, { enabled: !supplier.enabled });
      await refresh();
    } catch (err) {
      setError(formatApiErrorMessage(err));
    }
  }

  async function saveCheckSettings(supplierId: string) {
    const settings = checkSettingsBySupplierId[supplierId];
    if (!settings) return;

    setSavingSettingsId(supplierId);
    setError(null);
    try {
      const saved = await patchSupplierCheckSettings(supplierId, {
        productsPerMinute: settings.productsPerMinute,
        delayBetweenProductsSeconds: settings.delayBetweenProductsSeconds,
        jitterMinSeconds: settings.jitterMinSeconds,
        jitterMaxSeconds: settings.jitterMaxSeconds,
        maxRetriesPerItem: settings.maxRetriesPerItem,
        navigationTimeoutSeconds: settings.navigationTimeoutSeconds,
        itemTimeoutSeconds: settings.itemTimeoutSeconds,
        stopAfterConsecutiveFailures: settings.stopAfterConsecutiveFailures,
        stopOnSafetyEvent: settings.stopOnSafetyEvent,
        stopOnCartChange: settings.stopOnCartChange,
        enabled: settings.enabled,
      });
      setCheckSettingsBySupplierId((current) => ({ ...current, [supplierId]: saved }));
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setSavingSettingsId(null);
    }
  }

  function updateCheckSetting<Key extends keyof SupplierCheckSettings>(
    supplierId: string,
    key: Key,
    value: SupplierCheckSettings[Key]
  ) {
    setCheckSettingsBySupplierId((current) => {
      const settings = current[supplierId];
      if (!settings) return current;
      return { ...current, [supplierId]: { ...settings, [key]: value } };
    });
  }

  function updateCredentialForm(
    supplierId: string,
    key: keyof typeof defaultCredentialForm,
    value: string
  ) {
    setCredentialForms((current) => ({
      ...current,
      [supplierId]: { ...(current[supplierId] ?? defaultCredentialForm), [key]: value },
    }));
  }

  function updateCredentialTestArticle(supplierId: string, value: string) {
    setCredentialTestArticles((current) => ({ ...current, [supplierId]: value }));
  }

  async function saveSupplierCredential(supplier: Supplier) {
    const status = credentialsBySupplierId[supplier.id];
    const credentialForm = credentialForms[supplier.id] ?? defaultCredentialForm;
    if (!status) return;
    setSavingCredentialId(supplier.id);
    setError(null);
    setCredentialMessage(null);
    try {
      const saved = await putSupplierCredential(supplier.id, {
        connectorId: status.connectorId,
        username: credentialForm.username,
        password: credentialForm.password,
      });
      setCredentialsBySupplierId((current) => ({ ...current, [supplier.id]: saved }));
      setCredentialForms((current) => ({
        ...current,
        [supplier.id]: { username: "", password: "" },
      }));
      setCredentialMessage(
        `${supplier.code}: mentett adat újramentve a helyi Credential Managerben.`
      );
    } catch (err) {
      setError(formatCredentialApiErrorMessage(err));
    } finally {
      setSavingCredentialId(null);
    }
  }

  async function testCredential(supplier: Supplier) {
    setTestingCredentialId(supplier.id);
    setError(null);
    setCredentialMessage(null);
    try {
      const testArticle = credentialTestArticles[supplier.id]?.trim();
      const response = await testSupplierCredential(
        supplier.id,
        testArticle ? { testArticle } : undefined
      );
      setCredentialTestResults((current) => ({ ...current, [supplier.id]: response }));
      setCredentialsBySupplierId((current) => {
        const existing = current[supplier.id];
        if (!existing) return current;
        return {
          ...current,
          [supplier.id]: {
            ...existing,
            lastTestStatus: response.status === "success" ? "success" : "failed",
            lastErrorCode: response.errorCode,
          },
        };
      });
      setCredentialMessage(
        response.status === "success"
          ? `${supplier.code}: belépési teszt sikeres.`
          : `${supplier.code}: belépési teszt sikertelen (${labelCredentialError(response.errorCode ?? "credential_test_failed")}).`
      );
    } catch (err) {
      setError(formatCredentialApiErrorMessage(err));
    } finally {
      setTestingCredentialId(null);
    }
  }

  async function deleteCredential(supplier: Supplier) {
    if (
      !window.confirm(
        `${supplier.code}: törlöd a mentett belépési adatot? A következő DVG munkához újra meg kell adni.`
      )
    ) {
      return;
    }
    setDeletingCredentialId(supplier.id);
    setError(null);
    setCredentialMessage(null);
    try {
      const deleted = await deleteSupplierCredential(supplier.id);
      setCredentialsBySupplierId((current) => ({ ...current, [supplier.id]: deleted }));
      setCredentialMessage(`${supplier.code}: mentett belépési adat törölve.`);
    } catch (err) {
      setError(formatCredentialApiErrorMessage(err));
    } finally {
      setDeletingCredentialId(null);
    }
  }

  function toggleStrategy(strategy: LookupStrategy, enabled: boolean) {
    setForm((current) => {
      const next = enabled
        ? Array.from(new Set([...current.supportedLookupStrategies, strategy]))
        : current.supportedLookupStrategies.filter((item) => item !== strategy);

      return { ...current, supportedLookupStrategies: next.length ? next : ["search_result"] };
    });
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Beszállítók</h1>
      </div>

      <section className="card">
        <h2 className="section-title">Beszállító hozzáadása</h2>
        {suppliers.length > 0 && !showAddSupplierForm ? (
          <div className="action-row">
            <p className="helper-text">
              Beszállító már létezik. Új beszállítóhoz nyisd meg az űrlapot.
            </p>
            <button className="button secondary" onClick={() => setShowAddSupplierForm(true)}>
              Új beszállító hozzáadása
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <p className="helper-text">
              Itt csak biztonsági metaadat kerül mentésre: engedélyezett domainek, keresési
              stratégia és sebességkorlát.
            </p>
            <div className="form-grid">
              <label className="field-label">
                Kód
                <input
                  className="input"
                  value={form.code}
                  onChange={(event) => setForm({ ...form, code: event.target.value })}
                  placeholder="supplier_code"
                  required
                />
              </label>
              <label className="field-label">
                Név
                <input
                  className="input"
                  value={form.name}
                  onChange={(event) => setForm({ ...form, name: event.target.value })}
                  placeholder="Beszállító neve"
                  required
                />
              </label>
              <label className="field-label">
                Alap URL
                <input
                  className="input"
                  value={form.baseUrl}
                  onChange={(event) => setForm({ ...form, baseUrl: event.target.value })}
                  placeholder="https://supplier.example"
                />
              </label>
              <label className="field-label">
                Engedélyezett domainek
                <input
                  className="input"
                  value={form.allowedDomains}
                  onChange={(event) => setForm({ ...form, allowedDomains: event.target.value })}
                  placeholder="supplier.example, cdn.supplier.example"
                />
              </label>
              <label className="field-label">
                Sebességkorlát / perc
                <input
                  className="input"
                  type="number"
                  min="1"
                  value={form.defaultRateLimitPerMinute}
                  onChange={(event) =>
                    setForm({ ...form, defaultRateLimitPerMinute: Number(event.target.value) })
                  }
                />
              </label>
            </div>

            <div className="section-title">Támogatott keresési stratégiák</div>
            <div className="checkbox-grid">
              {lookupStrategies.map((strategy) => (
                <label key={strategy} className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={form.supportedLookupStrategies.includes(strategy)}
                    onChange={(event) => toggleStrategy(strategy, event.target.checked)}
                  />
                  {labelLookupStrategy(strategy)}
                </label>
              ))}
            </div>

            <div className="action-row">
              <button className="button" type="submit" disabled={saving}>
                {saving ? "Mentés..." : "Beszállító létrehozása"}
              </button>
              {suppliers.length > 0 ? (
                <button
                  className="button secondary"
                  type="button"
                  onClick={() => setShowAddSupplierForm(false)}
                >
                  Űrlap bezárása
                </button>
              ) : null}
              <span className="status">
                Belépési adat külön, helyi Credential Managerben kezelhető.
              </span>
            </div>
          </form>
        )}
      </section>

      {loading ? <LoadingState /> : null}
      {error ? <ErrorState message={error} /> : null}
      {credentialMessage ? <p className="status">{credentialMessage}</p> : null}
      {credentialLoadError ? (
        <p className="status">Belépési adat státusz: {credentialLoadError}</p>
      ) : null}

      {!loading && !error && suppliers.length === 0 ? (
        <EmptyState title="Még nincs beszállító">
          Párosítás előtt hozz létre beszállítói törzsadatot.
        </EmptyState>
      ) : null}

      {Object.keys(credentialsBySupplierId).length ? (
        <section className="card">
          <h2 className="section-title">Belépési adatok</h2>
          <p className="helper-text">
            Mentés csak a helyi Windows Credential Managerbe történik. A jelszó nem kerül vissza az
            API-válaszba vagy a felületre. A teszt csak biztonságos DVG bejelentkezés-ellenőrzés.
          </p>
          <p className="helper-text">
            A tesztet a helyi backend végzi bejelentkezett böngészős sessionben. A frontend nem
            kapcsolódik közvetlenül a DVG oldalhoz. A session nem kerül mentésre; csak a Windows
            Credential Managerben tárolt felhasználónév/jelszó marad meg.
          </p>
          {suppliers
            .filter((supplier) => credentialsBySupplierId[supplier.id])
            .map((supplier) => {
              const status = credentialsBySupplierId[supplier.id];
              const credentialForm = credentialForms[supplier.id] ?? defaultCredentialForm;
              const testResult = credentialTestResults[supplier.id];
              const testArticle = credentialTestArticles[supplier.id]?.trim() ?? "";
              return (
                <div key={supplier.id} className="card" style={{ marginTop: 16 }}>
                  <h3 className="section-title">
                    {supplier.code} - {supplier.name}
                  </h3>
                  <p className="status">
                    {status.configured
                      ? "Mentett belépési adat aktív"
                      : "Nincs mentett belépési adat"}
                  </p>
                  <div className="card-grid">
                    <div className="card">
                      <p className="card-title">Állapot</p>
                      <p className="card-value">{status.configured ? "Aktív" : "Hiányzik"}</p>
                    </div>
                    <div className="card">
                      <p className="card-title">Forrás</p>
                      <p className="card-value">{labelCredentialSource(status.source)}</p>
                    </div>
                    <div className="card">
                      <p className="card-title">Felhasználó</p>
                      <p className="card-value">{status.usernameDisplay ?? "-"}</p>
                    </div>
                    <div className="card">
                      <p className="card-title">Utolsó teszt</p>
                      <p className="card-value">
                        {labelCredentialTestStatus(status.lastTestStatus)}
                      </p>
                    </div>
                    <div className="card">
                      <p className="card-title">Teszt időpont</p>
                      <p className="card-value">
                        {status.lastTestedAt ? formatDate(status.lastTestedAt) : "nincs"}
                      </p>
                    </div>
                    <div className="card">
                      <p className="card-title">Hibakód</p>
                      <p className="card-value">
                        {status.lastErrorCode ? labelCredentialError(status.lastErrorCode) : "-"}
                      </p>
                    </div>
                  </div>
                  <div className="form-grid" style={{ marginTop: 16 }}>
                    <label className="field-label">
                      Felhasználónév
                      <input
                        className="input"
                        value={credentialForm.username}
                        onChange={(event) =>
                          updateCredentialForm(supplier.id, "username", event.target.value)
                        }
                        placeholder="Új mentéshez add meg"
                        autoComplete="off"
                      />
                    </label>
                    <label className="field-label">
                      Jelszó
                      <input
                        className="input"
                        type="password"
                        value={credentialForm.password}
                        onChange={(event) =>
                          updateCredentialForm(supplier.id, "password", event.target.value)
                        }
                        placeholder="Mindig üresen jelenik meg"
                        autoComplete="new-password"
                      />
                    </label>
                    <label className="field-label">
                      Teszt cikkszám
                      <input
                        className="input"
                        value={credentialTestArticles[supplier.id] ?? ""}
                        onChange={(event) =>
                          updateCredentialTestArticle(supplier.id, event.target.value)
                        }
                        placeholder="CS-A2200247"
                        autoComplete="off"
                      />
                    </label>
                  </div>
                  <p className="helper-text">
                    Ha jelszót módosítasz, mentsd újra itt. A teszt mindig az utoljára mentett helyi
                    adatot használja, nem az űrlap pillanatnyi értékét.
                  </p>
                  <div className="action-row">
                    <button
                      className="button secondary"
                      onClick={() => saveSupplierCredential(supplier)}
                      disabled={savingCredentialId === supplier.id}
                    >
                      {savingCredentialId === supplier.id ? "Mentés..." : "Belépési adat mentése"}
                    </button>
                    <button
                      className="button secondary"
                      onClick={() => testCredential(supplier)}
                      disabled={
                        !status.configured || !testArticle || testingCredentialId === supplier.id
                      }
                    >
                      {testingCredentialId === supplier.id ? "Teszt..." : "Belépés tesztelése"}
                    </button>
                    <button
                      className="button secondary"
                      onClick={() => deleteCredential(supplier)}
                      disabled={status.source !== "stored" || deletingCredentialId === supplier.id}
                    >
                      {deletingCredentialId === supplier.id ? "Törlés..." : "Mentett adat törlése"}
                    </button>
                    <span className="status">
                      {status.configured && !testArticle
                        ? "Teszteléshez adj meg DVG cikkszámot."
                        : "A teszt egyetlen DVG termékoldalt nyit meg backend sessionben."}
                    </span>
                  </div>
                  {testResult ? (
                    <div className="notice info" style={{ marginTop: 12 }}>
                      <p className="card-title">
                        DVG teszt: {labelCredentialTestResponse(testResult)}
                      </p>
                      {testResult.loginLandingDetected ? (
                        <p className="helper-text">
                          DVG login landing felismerve: kereső/katalógus oldal.
                        </p>
                      ) : null}
                      {testResult.status === "success" && testResult.detailFetchOk ? (
                        <p className="helper-text">Belépés sikeres, termékoldal betöltve.</p>
                      ) : null}
                      {testResult.loginOk && !testResult.detailFetchOk ? (
                        <p className="helper-text">
                          Belépés sikeres, de a termékoldal ellenőrzése sikertelen.
                        </p>
                      ) : null}
                      <p className="helper-text">Elakadt lépés: {testResult.stage}</p>
                      {testResult.safeMessage ? (
                        <p className="helper-text">{testResult.safeMessage}</p>
                      ) : null}
                      {testResult.selectorHint ? (
                        <p className="helper-text">Selector hint: {testResult.selectorHint}</p>
                      ) : null}
                      {testResult.loginPageMessage ? (
                        <p className="helper-text">
                          DVG oldalüzenet: {testResult.loginPageMessage}
                        </p>
                      ) : null}
                      <p className="helper-text">
                        Submit stratégia: {testResult.submitStrategy ?? "-"}
                      </p>
                      <p className="helper-text">
                        Kitöltési stratégia: {testResult.fillStrategy ?? "-"}, nyertes:{" "}
                        {testResult.winningStrategy ?? "-"}
                      </p>
                      <p className="helper-text">Végső útvonal: {testResult.finalPath ?? "-"}</p>
                      <p className="helper-text">
                        Kitöltés: felhasználó {labelBoolean(testResult.usernameFilled)}, jelszó{" "}
                        {labelBoolean(testResult.passwordFilled)}
                      </p>
                      <p className="helper-text">
                        Űrlap: {testResult.formMethod ?? "-"} {testResult.formActionHost ?? "-"},
                        submit aktív {labelBoolean(testResult.submitEnabled)}
                      </p>
                      <p className="helper-text">
                        Submit aktív kitöltés után {labelBoolean(testResult.submitEnabledAfterFill)}
                        , submit előtt {labelBoolean(testResult.submitEnabledBeforeSubmit)};
                        forenzikus próbák: {testResult.attemptedStrategies?.length ?? 0}
                      </p>
                      {testResult.forensic ? (
                        <div className="card-grid" style={{ marginTop: 12 }}>
                          <div className="card">
                            <p className="card-title">Kattintás / submit</p>
                            <p className="helper-text">
                              click {labelBoolean(testResult.forensic.clickEventFired)}, submit{" "}
                              {labelBoolean(testResult.forensic.submitEventFired)}, preventDefault{" "}
                              {labelBoolean(testResult.forensic.defaultPrevented)}
                            </p>
                            <p className="helper-text">
                              preventDefault hívás{" "}
                              {labelBoolean(testResult.forensic.preventDefaultCalled)}, esemény{" "}
                              {testResult.forensic.preventDefaultEventType ?? "-"}
                            </p>
                            <p className="helper-text">
                              submit handler {testResult.forensic.submitHandlerCount}, click handler{" "}
                              {testResult.forensic.clickHandlerCount}
                            </p>
                          </div>
                          <div className="card">
                            <p className="card-title">Login POST</p>
                            <p className="helper-text">
                              POST {labelBoolean(testResult.forensic.postRequestHappened)}, blokkolt{" "}
                              {labelBoolean(testResult.forensic.postRequestBlocked)}, státusz{" "}
                              {testResult.forensic.loginPostStatus ?? "-"}
                            </p>
                          </div>
                          <div className="card">
                            <p className="card-title">Script / konzol</p>
                            <p className="helper-text">
                              blokkolt script {testResult.forensic.blockedScriptCount}, külső host{" "}
                              {testResult.forensic.externalScriptHosts.length}, console error{" "}
                              {testResult.forensic.consoleErrorCount}, page error{" "}
                              {testResult.forensic.pageErrorCount}
                            </p>
                          </div>
                          <div className="card">
                            <p className="card-title">Űrlap állapot</p>
                            <p className="helper-text">
                              hidden {testResult.forensic.hiddenFieldCount}, required{" "}
                              {testResult.forensic.requiredFieldCount}, üres required{" "}
                              {testResult.forensic.emptyRequiredFieldNamesSanitized.length}
                            </p>
                            <p className="helper-text">
                              reCAPTCHA{" "}
                              {labelBoolean(testResult.forensic.recaptchaLikeElementPresent)},
                              cookie {labelBoolean(testResult.forensic.cookieConsentVisible)}
                            </p>
                          </div>
                        </div>
                      ) : null}
                      {testResult.parsed ? (
                        <div className="card-grid" style={{ marginTop: 12 }}>
                          <div className="card">
                            <p className="card-title">DVG cikkszám</p>
                            <p className="card-value">{testResult.parsed.dvgArticle ?? "-"}</p>
                          </div>
                          <div className="card">
                            <p className="card-title">Original code</p>
                            <p className="card-value">{testResult.parsed.originalCode ?? "-"}</p>
                          </div>
                          <div className="card">
                            <p className="card-title">Terméknév</p>
                            <p className="card-value">{testResult.parsed.productName ?? "-"}</p>
                          </div>
                          <div className="card">
                            <p className="card-title">Fizetendő ár</p>
                            <p className="card-value">{testResult.parsed.currentPrice ?? "-"}</p>
                          </div>
                          <div className="card">
                            <p className="card-title">Áthúzott/lista ár</p>
                            <p className="card-value">{testResult.parsed.crossedPrice ?? "-"}</p>
                          </div>
                          <div className="card">
                            <p className="card-title">Pénznem</p>
                            <p className="card-value">{testResult.parsed.currency ?? "-"}</p>
                          </div>
                          <div className="card">
                            <p className="card-title">Unit</p>
                            <p className="card-value">{testResult.parsed.unit ?? "-"}</p>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              );
            })}
        </section>
      ) : null}

      {suppliers.length ? (
        <section className="card table-card">
          <div className="table-toolbar product-table-toolbar">
            <TablePagination
              canGoBack={canGoBack}
              canGoNext={canGoNext}
              label={paginationLabel}
              onBack={() => setOffset(Math.max(0, offset - DEFAULT_SUPPLIER_LIMIT))}
              onNext={() => setOffset(offset + DEFAULT_SUPPLIER_LIMIT)}
              compact
            />
            <div className="product-view-controls" role="group" aria-label="Beszállító lista nézet">
              <span className="table-toolbar-status">Beszállítók és biztonsági állapotok</span>
            </div>
          </div>
          <div className="table-scroll">
            <table className="table data-table data-table--wide">
              <colgroup>
                <col className="col-id" />
                <col className="col-name" />
                <col className="col-url" />
                <col className="col-domains" />
                <col className="col-strategy" />
                <col className="col-number" />
                <col className="col-status" />
                <col className="col-status" />
                <col className="col-action" />
              </colgroup>
              <thead>
                <tr>
                  <th className="cell-nowrap">Kód</th>
                  <th>Név</th>
                  <th>Alap URL</th>
                  <th>Domainek</th>
                  <th>Stratégiák</th>
                  <th className="numeric cell-nowrap">Korlát</th>
                  <th className="cell-nowrap">Állapot</th>
                  <th className="cell-nowrap">Egészség</th>
                  <th className="actions">Művelet</th>
                </tr>
              </thead>
              <tbody>
                {suppliers.map((supplier) => (
                  <tr key={supplier.id}>
                    <td className="cell-mono cell-truncate" title={supplier.code}>
                      {supplier.code}
                    </td>
                    <td className="cell-truncate" title={supplier.name}>
                      {supplier.name}
                    </td>
                    <td className="cell-mono cell-truncate" title={supplier.baseUrl ?? ""}>
                      {supplier.baseUrl ?? "-"}
                    </td>
                    <td
                      className="cell-mono cell-truncate"
                      title={supplier.allowedDomains.join(", ")}
                    >
                      {supplier.allowedDomains.join(", ") || "-"}
                    </td>
                    <td
                      className="cell-truncate"
                      title={supplier.supportedLookupStrategies.map(labelLookupStrategy).join(", ")}
                    >
                      {supplier.supportedLookupStrategies.map(labelLookupStrategy).join(", ")}
                    </td>
                    <td className="numeric cell-nowrap">
                      {supplier.defaultRateLimitPerMinute}/min
                    </td>
                    <td className="actions">
                      <span className="badge">{labelEnabled(supplier.enabled)}</span>
                    </td>
                    <td className="cell-nowrap">{labelHealthStatus(supplier.healthStatus)}</td>
                    <td className="actions">
                      <button className="button secondary" onClick={() => toggleSupplier(supplier)}>
                        {supplier.enabled ? "Letiltás" : "Aktiválás"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}

      {suppliers.length ? (
        <TablePagination
          canGoBack={canGoBack}
          canGoNext={canGoNext}
          label={paginationLabel}
          onBack={() => setOffset(Math.max(0, offset - DEFAULT_SUPPLIER_LIMIT))}
          onNext={() => setOffset(offset + DEFAULT_SUPPLIER_LIMIT)}
        />
      ) : null}

      {suppliers.length ? (
        <section className="card">
          <h2 className="section-title">Ellenőrzési beállítások</h2>
          <p className="helper-text">
            Egy beszállítóra vonatkozó ütemezési és leállítási szabályok. Valódi portált nem ér el.
          </p>
          {suppliers.map((supplier) => {
            const settings = checkSettingsBySupplierId[supplier.id];
            if (!settings) {
              return (
                <p key={supplier.id} className="helper-text">
                  {supplier.code}: beállítások betöltése...
                </p>
              );
            }

            return (
              <div key={supplier.id} className="card" style={{ marginTop: 16 }}>
                <h3 className="section-title">
                  {supplier.code} - {supplier.name}
                </h3>
                <div className="form-grid">
                  <label className="field-label">
                    Termék / perc
                    <input
                      className="input"
                      type="number"
                      min="1"
                      max="60"
                      value={settings.productsPerMinute}
                      onChange={(event) =>
                        updateCheckSetting(
                          supplier.id,
                          "productsPerMinute",
                          Number(event.target.value)
                        )
                      }
                    />
                  </label>
                  <label className="field-label">
                    Várakozás termékek között
                    <input
                      className="input"
                      type="number"
                      min="0"
                      max="3600"
                      value={settings.delayBetweenProductsSeconds}
                      onChange={(event) =>
                        updateCheckSetting(
                          supplier.id,
                          "delayBetweenProductsSeconds",
                          Number(event.target.value)
                        )
                      }
                    />
                  </label>
                  <label className="field-label">
                    Véletlen késleltetés min.
                    <input
                      className="input"
                      type="number"
                      min="0"
                      max="3600"
                      value={settings.jitterMinSeconds}
                      onChange={(event) =>
                        updateCheckSetting(
                          supplier.id,
                          "jitterMinSeconds",
                          Number(event.target.value)
                        )
                      }
                    />
                  </label>
                  <label className="field-label">
                    Véletlen késleltetés max.
                    <input
                      className="input"
                      type="number"
                      min="0"
                      max="3600"
                      value={settings.jitterMaxSeconds}
                      onChange={(event) =>
                        updateCheckSetting(
                          supplier.id,
                          "jitterMaxSeconds",
                          Number(event.target.value)
                        )
                      }
                    />
                  </label>
                  <label className="field-label">
                    Újrapróbálkozások
                    <input
                      className="input"
                      type="number"
                      min="0"
                      max="10"
                      value={settings.maxRetriesPerItem}
                      onChange={(event) =>
                        updateCheckSetting(
                          supplier.id,
                          "maxRetriesPerItem",
                          Number(event.target.value)
                        )
                      }
                    />
                  </label>
                  <label className="field-label">
                    Navigáció timeout
                    <input
                      className="input"
                      type="number"
                      min="1"
                      max="600"
                      value={settings.navigationTimeoutSeconds}
                      onChange={(event) =>
                        updateCheckSetting(
                          supplier.id,
                          "navigationTimeoutSeconds",
                          Number(event.target.value)
                        )
                      }
                    />
                  </label>
                  <label className="field-label">
                    Elem timeout
                    <input
                      className="input"
                      type="number"
                      min="1"
                      max="600"
                      value={settings.itemTimeoutSeconds}
                      onChange={(event) =>
                        updateCheckSetting(
                          supplier.id,
                          "itemTimeoutSeconds",
                          Number(event.target.value)
                        )
                      }
                    />
                  </label>
                  <label className="field-label">
                    Leállítás egymás utáni hibák után
                    <input
                      className="input"
                      type="number"
                      min="1"
                      max="100"
                      value={settings.stopAfterConsecutiveFailures}
                      onChange={(event) =>
                        updateCheckSetting(
                          supplier.id,
                          "stopAfterConsecutiveFailures",
                          Number(event.target.value)
                        )
                      }
                    />
                  </label>
                </div>
                <div className="checkbox-grid" style={{ marginTop: 12 }}>
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={settings.enabled}
                      onChange={(event) =>
                        updateCheckSetting(supplier.id, "enabled", event.target.checked)
                      }
                    />
                    Ellenőrzés engedélyezve
                  </label>
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={settings.stopOnSafetyEvent}
                      onChange={(event) =>
                        updateCheckSetting(supplier.id, "stopOnSafetyEvent", event.target.checked)
                      }
                    />
                    Biztonsági eseménynél leállítás
                  </label>
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={settings.stopOnCartChange}
                      onChange={(event) =>
                        updateCheckSetting(supplier.id, "stopOnCartChange", event.target.checked)
                      }
                    />
                    Kosárváltozásnál leállítás
                  </label>
                </div>
                <div className="action-row">
                  <button
                    className="button secondary"
                    onClick={() => saveCheckSettings(supplier.id)}
                    disabled={savingSettingsId === supplier.id}
                  >
                    {savingSettingsId === supplier.id ? "Mentés..." : "Beállítások mentése"}
                  </button>
                  <span className="status">Mentés csak helyi futtatási szabályt módosít.</span>
                </div>
              </div>
            );
          })}
        </section>
      ) : null}
    </div>
  );
}

function splitCsv(value: string): string[] {
  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function emptyToNull(value: string): string | null {
  const trimmed = value.trim();
  return trimmed.length ? trimmed : null;
}

function labelCredentialSource(source: SupplierCredentialStatus["source"]): string {
  if (source === "stored") return "Helyi mentett";
  if (source === "env") return "Runtime env";
  return "Hiányzik";
}

function labelCredentialTestStatus(status: SupplierCredentialStatus["lastTestStatus"]): string {
  if (status === "success") return "Sikeres";
  if (status === "failed") return "Sikertelen";
  return "Nincs teszt";
}

function labelCredentialError(code: string): string {
  const labels: Record<string, string> = {
    dvg_login_failed: "DVG belépés sikertelen",
    dvg_login_rejected: "DVG belépés elutasítva",
    dvg_login_click_event_missing: "DVG belépés kattintás esemény hiányzik",
    dvg_login_submit_event_missing: "DVG belépés submit esemény hiányzik",
    dvg_login_submit_prevented: "DVG belépés submit eseményt oldal script megállította",
    dvg_login_post_not_sent: "DVG belépés POST nem indult el",
    dvg_login_post_blocked_by_safety: "DVG belépés POST biztonsági guard által blokkolva",
    dvg_login_script_dependency_blocked: "DVG belépés külső script függőség blokkolva",
    dvg_login_server_rejected: "DVG belépés POST után szerver elutasította",
    dvg_login_submit_disabled_after_fill: "DVG belépés gomb inaktív maradt kitöltés után",
    dvg_login_submit_no_effect: "DVG belépés kattintás hatástalan",
    dvg_login_account_security_risk: "DVG biztonsági/CAPTCHA/account lock kockázat",
    dvg_detail_redirected_to_login: "DVG termékoldal visszairányított a belépéshez",
    dvg_credentials_missing: "Hiányzó belépési adat",
    dvg_login_check_failed: "DVG teszt hiba",
    dvg_login_form_not_found: "DVG belépési űrlap nem található",
    dvg_username_field_not_found: "DVG felhasználónév mező nem található",
    dvg_password_field_not_found: "DVG jelszó mező nem található",
    dvg_login_submit_not_found: "DVG belépés gomb nem található",
    dvg_login_timeout: "DVG belépés időtúllépés",
    credential_test_failed: "Teszt hiba",
    supplier_credential_missing: "Nincs mentett belépési adat",
    credential_store_unavailable: "Credential Manager nem elérhető",
    dvg_article_invalid: "Érvénytelen DVG cikkszám",
    dvg_test_article_missing: "Hiányzó DVG teszt cikkszám",
    dvg_detail_fetch_failed: "DVG termékoldal nem érhető el belépés után",
    dvg_article_not_found_or_access_denied: "DVG cikkszám nem található vagy hozzáférés megtagadva",
    dvg_price_not_found: "DVG ár nem található",
  };
  return labels[code] ?? code;
}

function labelCredentialTestResponse(response: SupplierCredentialTestResponse): string {
  if (response.status !== "success") {
    if (response.loginLandingDetected || response.loginOk) {
      return `belépés sikeres, termékoldal hiba - ${labelCredentialError(response.errorCode ?? "credential_test_failed")}`;
    }
    return labelCredentialError(response.errorCode ?? "credential_test_failed");
  }

  const price =
    typeof response.parsed?.currentPrice === "number"
      ? `${response.parsed.currentPrice} ${response.parsed.currency ?? ""}`.trim()
      : "ár nélkül";
  return ["sikeres", response.parsed?.dvgArticle, price].filter(Boolean).join(" - ");
}

function labelBoolean(value: boolean | null | undefined): string {
  if (value === true) return "igen";
  if (value === false) return "nem";
  return "-";
}

function formatDate(value: string): string {
  return new Intl.DateTimeFormat("hu-HU", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(new Date(value));
}
