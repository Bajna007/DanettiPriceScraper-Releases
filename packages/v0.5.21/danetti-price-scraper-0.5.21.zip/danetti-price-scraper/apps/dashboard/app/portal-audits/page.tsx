"use client";

import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import {
  approvePortalAudit,
  createPortalAudit,
  createPortalAuditEvidenceNote,
  getPortalAudit,
  getPortalAuditConnectorPlan,
  getPortalAuditSafeExport,
  getSupplierCheckSettings,
  listPortalAudits,
  listSuppliers,
  patchPortalAudit,
  patchPortalAuditCheck,
  portalAuditCheckStatuses,
  portalAuditEvidenceTypes,
  portalAuditResultPageTypes,
  rejectPortalAudit,
  submitPortalAuditForReview,
  type PortalAudit,
  type PortalAuditCheck,
  type PortalAuditCheckStatus,
  type PortalAuditConnectorPlanResponse,
  type PortalAuditDetail,
  type PortalAuditEvidenceType,
  type PortalAuditSafeExport,
  type Supplier,
  type SupplierCheckSettings,
} from "../../src/lib/api";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import {
  labelNullableBoolean,
  labelPortalAuditCheckLabel,
  labelPortalAuditCheckStatus,
  labelPortalAuditEvidenceType,
  labelPortalAuditResultPageType,
  labelPortalAuditStatus,
} from "../../src/lib/labels";

const defaultCreateForm = {
  supplierId: "",
  auditTitle: "",
  portalBaseUrl: "",
  loginUrl: "",
};

const defaultEditForm = {
  portalBaseUrl: "",
  loginUrl: "",
  has2fa: "unknown",
  hasCaptcha: "unknown",
  hasAccountLockRisk: "unknown",
  loginFlowNotes: "",
  sessionLifetimeNotes: "",
  searchUrl: "",
  searchMethod: "",
  searchInputNotes: "",
  skuExactMatchRequired: "true",
  resultPageType: "unknown",
  priceVisibleOn: "",
  stockVisibleOn: "",
  availabilityTextNotes: "",
  productIdentityNotes: "",
  cartIndicatorSelector: "",
  dangerousUrlPatterns: "",
  allowedUrlPatterns: "",
  allowedDomains: "",
  allowedMethods: "GET",
  allowedPostPatterns: "",
  suggestedRateLimitPerMinute: 6,
  parserNotes: "",
  evidenceExpectations: "",
  knownBlockers: "",
  goNoGoDecision: "",
  openQuestions: "",
  auditNotes: "",
  safetyNotes: "",
};

const defaultEvidenceForm = {
  title: "",
  evidenceType: "manual_note" as PortalAuditEvidenceType,
  content: "",
  createdBy: "",
};

const fieldLabels: Record<string, string> = {
  "status=approved": "Audit jóváhagyása",
  allowedDomains: "Engedélyezett domainek",
  dangerousUrlPatterns: "Veszélyes URL minták",
  allowedUrlPatterns: "Engedélyezett URL minták",
  allowedMethods: "Engedélyezett metódusok",
  resultPageType: "Találati oldal típusa",
  has2fa: "2FA dokumentálás",
  hasCaptcha: "CAPTCHA dokumentálás",
  hasAccountLockRisk: "Fiókzárolási kockázat",
  safetyNotes: "Biztonsági megjegyzés",
  suggestedRateLimitPerMinute: "Sebességkorlát",
};

export default function PortalAuditsPage() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [audits, setAudits] = useState<PortalAudit[]>([]);
  const [selectedSupplierId, setSelectedSupplierId] = useState("");
  const [selectedAudit, setSelectedAudit] = useState<PortalAuditDetail | null>(null);
  const [connectorPlan, setConnectorPlan] = useState<PortalAuditConnectorPlanResponse | null>(null);
  const [safeExport, setSafeExport] = useState<PortalAuditSafeExport | null>(null);
  const [checkSettings, setCheckSettings] = useState<SupplierCheckSettings | null>(null);
  const [createForm, setCreateForm] = useState(defaultCreateForm);
  const [editForm, setEditForm] = useState(defaultEditForm);
  const [evidenceForm, setEvidenceForm] = useState(defaultEvidenceForm);
  const [reviewerName, setReviewerName] = useState("");
  const [rejectNotes, setRejectNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function refresh(selectedId = selectedAudit?.id) {
    setLoading(true);
    setError(null);
    try {
      const [supplierResponse, auditResponse] = await Promise.all([
        listSuppliers({ limit: 100, offset: 0 }),
        listPortalAudits({ limit: 100, offset: 0 }),
      ]);
      setSuppliers(supplierResponse.items ?? []);
      setAudits(auditResponse.items ?? []);
      if (selectedId) await loadDetail(selectedId, false);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Nem sikerült betölteni az audit munkaterületet."
      );
    } finally {
      setLoading(false);
    }
  }

  async function loadDetail(id: string, setBusy = true) {
    if (setBusy) setLoading(true);
    setError(null);
    setConnectorPlan(null);
    setSafeExport(null);
    setCheckSettings(null);
    try {
      const detail = await getPortalAudit(id);
      setSelectedAudit(detail);
      setSelectedSupplierId(detail.supplierId);
      setEditForm(formFromAudit(detail));
      const [plan, settings, exportSummary] = await Promise.all([
        getPortalAuditConnectorPlan(id),
        getSupplierCheckSettings(detail.supplierId),
        getPortalAuditSafeExport(id),
      ]);
      setConnectorPlan(plan);
      setCheckSettings(settings);
      setSafeExport(exportSummary);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Nem sikerült betölteni az audit munkaterület részleteit."
      );
    } finally {
      if (setBusy) setLoading(false);
    }
  }

  useEffect(() => {
    void refresh(undefined);
  }, []);

  async function handleCreate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError(null);
    try {
      const audit = await createPortalAudit({
        supplierId: createForm.supplierId,
        auditTitle: createForm.auditTitle,
        portalBaseUrl: emptyToNull(createForm.portalBaseUrl),
        loginUrl: emptyToNull(createForm.loginUrl),
      });
      setCreateForm(defaultCreateForm);
      await refresh(audit.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Nem sikerült létrehozni a portál auditot.");
    } finally {
      setSaving(false);
    }
  }

  async function handleEdit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedAudit) return;
    setSaving(true);
    setError(null);
    try {
      await patchPortalAudit(selectedAudit.id, {
        portalBaseUrl: emptyToNull(editForm.portalBaseUrl),
        loginUrl: emptyToNull(editForm.loginUrl),
        has2fa: parseNullableBoolean(editForm.has2fa),
        hasCaptcha: parseNullableBoolean(editForm.hasCaptcha),
        hasAccountLockRisk: parseNullableBoolean(editForm.hasAccountLockRisk),
        loginFlowNotes: emptyToNull(editForm.loginFlowNotes),
        sessionLifetimeNotes: emptyToNull(editForm.sessionLifetimeNotes),
        searchUrl: emptyToNull(editForm.searchUrl),
        searchMethod: emptyToNull(editForm.searchMethod),
        searchInputNotes: emptyToNull(editForm.searchInputNotes),
        skuExactMatchRequired: parseStrictBoolean(editForm.skuExactMatchRequired),
        resultPageType: editForm.resultPageType as PortalAudit["resultPageType"],
        priceVisibleOn: emptyToNull(editForm.priceVisibleOn),
        stockVisibleOn: emptyToNull(editForm.stockVisibleOn),
        availabilityTextNotes: emptyToNull(editForm.availabilityTextNotes),
        productIdentityNotes: emptyToNull(editForm.productIdentityNotes),
        cartIndicatorSelector: emptyToNull(editForm.cartIndicatorSelector),
        dangerousUrlPatterns: splitLines(editForm.dangerousUrlPatterns),
        allowedUrlPatterns: splitLines(editForm.allowedUrlPatterns),
        allowedDomains: splitLines(editForm.allowedDomains),
        allowedMethods: splitLines(editForm.allowedMethods),
        allowedPostPatterns: splitLines(editForm.allowedPostPatterns),
        suggestedRateLimitPerMinute: editForm.suggestedRateLimitPerMinute,
        parserNotes: emptyToNull(editForm.parserNotes),
        evidenceExpectations: emptyToNull(editForm.evidenceExpectations),
        knownBlockers: emptyToNull(editForm.knownBlockers),
        goNoGoDecision: emptyToNull(editForm.goNoGoDecision),
        openQuestions: emptyToNull(editForm.openQuestions),
        auditNotes: emptyToNull(editForm.auditNotes),
        safetyNotes: emptyToNull(editForm.safetyNotes),
      });
      await refresh(selectedAudit.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Nem sikerült menteni a portál auditot.");
    } finally {
      setSaving(false);
    }
  }

  async function updateCheck(check: PortalAuditCheck, status: PortalAuditCheckStatus) {
    if (!selectedAudit) return;
    setSaving(true);
    setError(null);
    try {
      await patchPortalAuditCheck(selectedAudit.id, check.id, { status, notes: check.notes });
      await loadDetail(selectedAudit.id, false);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Nem sikerült módosítani az ellenőrzőlista elemet."
      );
    } finally {
      setSaving(false);
    }
  }

  async function handleEvidence(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedAudit) return;
    setSaving(true);
    setError(null);
    try {
      if (looksLikeForbiddenEvidenceContent(evidenceForm.content)) {
        throw new Error(
          "Raw HTML, képernyőkép vagy képfájl tartalom nem menthető. Csak rövid szöveges hivatkozást adj meg."
        );
      }
      await createPortalAuditEvidenceNote(selectedAudit.id, {
        title: evidenceForm.title,
        evidenceType: evidenceForm.evidenceType,
        content: evidenceForm.content,
        containsSensitiveData: false,
        createdBy: emptyToNull(evidenceForm.createdBy),
      });
      setEvidenceForm(defaultEvidenceForm);
      await loadDetail(selectedAudit.id, false);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Nem sikerült hozzáadni a bizonyíték megjegyzést."
      );
    } finally {
      setSaving(false);
    }
  }

  async function transition(action: "submit" | "approve" | "reject") {
    if (!selectedAudit) return;
    setSaving(true);
    setError(null);
    try {
      if (action === "submit") await submitPortalAuditForReview(selectedAudit.id);
      if (action === "approve") await approvePortalAudit(selectedAudit.id, reviewerName);
      if (action === "reject") await rejectPortalAudit(selectedAudit.id, reviewerName, rejectNotes);
      await refresh(selectedAudit.id);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Nem sikerült módosítani az audit állapotát.");
    } finally {
      setSaving(false);
    }
  }

  function clearSelectionForSupplier(supplierId: string) {
    setSelectedSupplierId(supplierId);
    setSelectedAudit(null);
    setConnectorPlan(null);
    setSafeExport(null);
    setCheckSettings(null);
  }

  const filteredAudits = selectedSupplierId
    ? audits.filter((audit) => audit.supplierId === selectedSupplierId)
    : audits;
  const readiness = connectorPlan?.readiness ?? null;
  const canApprove = selectedAudit?.status === "in_review" && isApprovalCandidate(readiness);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1 className="page-title">Audit munkaterület</h1>
        </div>
      </div>

      <section className="card">
        <h2 className="section-title">Biztonsági szabály</h2>
        <div className="workflow-grid">
          <InfoTile title="Nincs automatizált belépés" value="Kézi audit, szöveges jegyzet" />
          <InfoTile
            title="Nincs nyers bizonyíték"
            value="Cookie, storageState, HTML, privát kép tiltott"
          />
          <InfoTile
            title="DVG credential"
            value="Helyi Credential Manager vagy runtime env, nincs DB"
          />
          <InfoTile title="Connector csak kapu után" value="Jóváhagyott és ready audit kell" />
        </div>
      </section>

      <section className="card">
        <h2 className="section-title">Audit létrehozása</h2>
        <form onSubmit={handleCreate}>
          <div className="form-grid">
            <label className="field-label">
              Beszállító
              <select
                className="input"
                value={createForm.supplierId}
                onChange={(event) =>
                  setCreateForm({ ...createForm, supplierId: event.target.value })
                }
                required
              >
                <option value="">Válassz beszállítót</option>
                {suppliers.map((supplier) => (
                  <option key={supplier.id} value={supplier.id}>
                    {supplier.code} - {supplier.name}
                  </option>
                ))}
              </select>
            </label>
            <TextField
              label="Audit cím"
              value={createForm.auditTitle}
              onChange={(value) => setCreateForm({ ...createForm, auditTitle: value })}
              placeholder="Supplier #1 portál audit"
              required
            />
            <TextField
              label="Portál alap URL"
              value={createForm.portalBaseUrl}
              onChange={(value) => setCreateForm({ ...createForm, portalBaseUrl: value })}
              placeholder="https://supplier.example.invalid"
            />
            <TextField
              label="Belépési URL"
              value={createForm.loginUrl}
              onChange={(value) => setCreateForm({ ...createForm, loginUrl: value })}
              placeholder="Csak dokumentáció; belépési adatot ne adj meg"
            />
          </div>
          <div className="action-row">
            <button className="button" type="submit" disabled={saving}>
              {saving ? "Mentés..." : "Audit létrehozása"}
            </button>
            <span className="status">Alap jóváhagyási ellenőrzőlista automatikusan létrejön.</span>
          </div>
        </form>
      </section>

      {loading ? <LoadingState /> : null}
      {error ? <ErrorState message={error} /> : null}

      {!loading && !error && audits.length === 0 ? (
        <EmptyState title="Még nincs portál audit">
          Előbb hozz létre beszállítót, utána dokumentáld a biztonságos portál folyamatot.
        </EmptyState>
      ) : null}

      <section className="card">
        <h2 className="section-title">Munkaterület választó</h2>
        <div className="form-grid">
          <label className="field-label">
            Beszállító szűrő
            <select
              className="input"
              value={selectedSupplierId}
              onChange={(event) => clearSelectionForSupplier(event.target.value)}
            >
              <option value="">Összes beszállító</option>
              {suppliers.map((supplier) => (
                <option key={supplier.id} value={supplier.id}>
                  {supplier.code} - {supplier.name}
                </option>
              ))}
            </select>
          </label>
          <label className="field-label">
            Kiválasztott audit
            <select
              className="input"
              value={selectedAudit?.id ?? ""}
              onChange={(event) => {
                if (event.target.value) void loadDetail(event.target.value);
              }}
            >
              <option value="">Válassz auditot</option>
              {filteredAudits.map((audit) => (
                <option key={audit.id} value={audit.id}>
                  {audit.supplierCode ?? audit.supplierId} - {audit.auditTitle}
                </option>
              ))}
            </select>
          </label>
        </div>
      </section>

      {audits.length ? (
        <section className="card table-card">
          <h2 className="section-title">Auditok</h2>
          <div className="table-scroll">
            <table className="table data-table data-table--compact">
              <colgroup>
                <col className="col-id" />
                <col className="col-name" />
                <col className="col-status" />
                <col className="col-strategy" />
                <col className="col-number" />
                <col className="col-action" />
              </colgroup>
              <thead>
                <tr>
                  <th className="cell-nowrap">Beszállító</th>
                  <th>Cím</th>
                  <th className="cell-nowrap">Állapot</th>
                  <th className="cell-nowrap">Stratégia</th>
                  <th className="numeric cell-nowrap">Korlát</th>
                  <th className="actions">Művelet</th>
                </tr>
              </thead>
              <tbody>
                {filteredAudits.map((audit) => (
                  <tr key={audit.id}>
                    <td
                      className="cell-mono cell-truncate"
                      title={audit.supplierCode ?? audit.supplierId}
                    >
                      {audit.supplierCode ?? audit.supplierId}
                    </td>
                    <td className="cell-truncate" title={audit.auditTitle}>
                      {audit.auditTitle}
                    </td>
                    <td className="actions">
                      <span className="badge">{labelPortalAuditStatus(audit.status)}</span>
                    </td>
                    <td
                      className="cell-truncate"
                      title={labelPortalAuditResultPageType(audit.resultPageType)}
                    >
                      {labelPortalAuditResultPageType(audit.resultPageType)}
                    </td>
                    <td className="numeric cell-nowrap">{audit.suggestedRateLimitPerMinute}/min</td>
                    <td className="actions">
                      <button className="button secondary" onClick={() => loadDetail(audit.id)}>
                        Megnyitás
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}

      {selectedAudit ? (
        <section className="card">
          <h2 className="section-title">Állapot és következő lépés</h2>
          <div className="card-grid">
            <StatusTile
              title="Audit állapot"
              value={labelPortalAuditStatus(selectedAudit.status)}
            />
            <StatusTile
              title="Readiness"
              value={readiness?.ready ? "Ready" : "Nem kész"}
              tone={readiness?.ready ? "success" : "warning"}
            />
            <StatusTile
              title="Hiányzó mezők"
              value={String(readiness?.missingRequiredFields.length ?? 0)}
            />
            <StatusTile
              title="Checklist hibák"
              value={String(readiness?.failingChecks.length ?? 0)}
            />
            <StatusTile
              title="Stratégia jelölt"
              value={
                readiness?.recommendedStrategy
                  ? labelPortalAuditResultPageType(readiness.recommendedStrategy)
                  : "Nincs"
              }
            />
            <StatusTile title="Következő lépés" value={labelNextAction(readiness)} />
          </div>
          <ListBlock
            title="Hiányzó kötelező mezők"
            items={readiness?.missingRequiredFields ?? []}
          />
          <ListBlock
            title="Hiányos ellenőrzések"
            items={readiness?.failingChecks ?? []}
            checkLabels
          />
          <ListBlock title="Figyelmeztetések" items={readiness?.warnings ?? []} />
          <RunSettingsSummary settings={checkSettings} />
        </section>
      ) : null}

      {selectedAudit ? (
        <section className="card">
          <h2 className="section-title">
            Részlet: {selectedAudit.supplierCode} / {selectedAudit.auditTitle}
          </h2>
          <p className="helper-text">
            Minden mező kézi auditból jön. Ne írj be credentialt, cookie-t, storageState adatot,
            nyers HTML-t vagy privát képernyőképet.
          </p>

          <form onSubmit={handleEdit}>
            <AuditSection title="A) Portál alapadatok">
              <TextField
                label="Portál alap URL"
                value={editForm.portalBaseUrl}
                onChange={(value) => setEditForm({ ...editForm, portalBaseUrl: value })}
              />
              <TextField
                label="Belépési URL"
                value={editForm.loginUrl}
                onChange={(value) => setEditForm({ ...editForm, loginUrl: value })}
              />
              <TextAreaField
                label="Engedélyezett domainek"
                value={editForm.allowedDomains}
                onChange={(value) => setEditForm({ ...editForm, allowedDomains: value })}
              />
              <TextAreaField
                label="Általános audit megjegyzés"
                value={editForm.auditNotes}
                onChange={(value) => setEditForm({ ...editForm, auditNotes: value })}
              />
            </AuditSection>

            <AuditSection title="B) Bejelentkezés és hozzáférés">
              <NullableBooleanField
                label="Van 2FA"
                value={editForm.has2fa}
                onChange={(value) => setEditForm({ ...editForm, has2fa: value })}
              />
              <NullableBooleanField
                label="Van CAPTCHA"
                value={editForm.hasCaptcha}
                onChange={(value) => setEditForm({ ...editForm, hasCaptcha: value })}
              />
              <NullableBooleanField
                label="Fiókzárolási kockázat"
                value={editForm.hasAccountLockRisk}
                onChange={(value) => setEditForm({ ...editForm, hasAccountLockRisk: value })}
              />
              <TextAreaField
                label="Belépési folyamat megjegyzés"
                value={editForm.loginFlowNotes}
                onChange={(value) => setEditForm({ ...editForm, loginFlowNotes: value })}
              />
              <TextAreaField
                label="Munkamenet élettartam megjegyzés"
                value={editForm.sessionLifetimeNotes}
                onChange={(value) => setEditForm({ ...editForm, sessionLifetimeNotes: value })}
              />
            </AuditSection>

            <AuditSection title="C) Keresés és találatok">
              <TextField
                label="Keresési URL"
                value={editForm.searchUrl}
                onChange={(value) => setEditForm({ ...editForm, searchUrl: value })}
              />
              <TextField
                label="Keresési metódus"
                value={editForm.searchMethod}
                onChange={(value) => setEditForm({ ...editForm, searchMethod: value })}
                placeholder="GET vagy POST"
              />
              <TextAreaField
                label="Keresőmező megjegyzés"
                value={editForm.searchInputNotes}
                onChange={(value) => setEditForm({ ...editForm, searchInputNotes: value })}
              />
              <label className="field-label">
                Pontos SKU egyezés kötelező
                <select
                  className="input"
                  value={editForm.skuExactMatchRequired}
                  onChange={(event) =>
                    setEditForm({ ...editForm, skuExactMatchRequired: event.target.value })
                  }
                >
                  <option value="true">igen</option>
                  <option value="false">nem / nem ismert</option>
                </select>
              </label>
              <label className="field-label">
                Találati oldal típusa
                <select
                  className="input"
                  value={editForm.resultPageType}
                  onChange={(event) =>
                    setEditForm({ ...editForm, resultPageType: event.target.value })
                  }
                >
                  {portalAuditResultPageTypes.map((type) => (
                    <option key={type} value={type}>
                      {labelPortalAuditResultPageType(type)}
                    </option>
                  ))}
                </select>
              </label>
            </AuditSection>

            <AuditSection title="D) Ár és készlet">
              <TextAreaField
                label="Ár itt látható"
                value={editForm.priceVisibleOn}
                onChange={(value) => setEditForm({ ...editForm, priceVisibleOn: value })}
              />
              <TextAreaField
                label="Készlet itt látható"
                value={editForm.stockVisibleOn}
                onChange={(value) => setEditForm({ ...editForm, stockVisibleOn: value })}
              />
              <TextAreaField
                label="Elérhetőségi szöveg megjegyzés"
                value={editForm.availabilityTextNotes}
                onChange={(value) => setEditForm({ ...editForm, availabilityTextNotes: value })}
              />
              <TextAreaField
                label="Terméknév / cikkszám láthatóság"
                value={editForm.productIdentityNotes}
                onChange={(value) => setEditForm({ ...editForm, productIdentityNotes: value })}
              />
            </AuditSection>

            <AuditSection title="E) Biztonság">
              <TextField
                label="Kosárjelző szelektor"
                value={editForm.cartIndicatorSelector}
                onChange={(value) => setEditForm({ ...editForm, cartIndicatorSelector: value })}
              />
              <TextAreaField
                label="Tiltott / veszélyes URL minták"
                value={editForm.dangerousUrlPatterns}
                onChange={(value) => setEditForm({ ...editForm, dangerousUrlPatterns: value })}
              />
              <TextAreaField
                label="Engedélyezett URL minták"
                value={editForm.allowedUrlPatterns}
                onChange={(value) => setEditForm({ ...editForm, allowedUrlPatterns: value })}
              />
              <TextAreaField
                label="Engedélyezett metódusok"
                value={editForm.allowedMethods}
                onChange={(value) => setEditForm({ ...editForm, allowedMethods: value })}
              />
              <TextAreaField
                label="Engedélyezett POST minták"
                value={editForm.allowedPostPatterns}
                onChange={(value) => setEditForm({ ...editForm, allowedPostPatterns: value })}
              />
              <TextAreaField
                label="Biztonsági megjegyzés"
                value={editForm.safetyNotes}
                onChange={(value) => setEditForm({ ...editForm, safetyNotes: value })}
              />
            </AuditSection>

            <AuditSection title="F) Futási szabályok">
              <label className="field-label">
                Audit javasolt termék / perc
                <input
                  className="input"
                  type="number"
                  min="1"
                  value={editForm.suggestedRateLimitPerMinute}
                  onChange={(event) =>
                    setEditForm({
                      ...editForm,
                      suggestedRateLimitPerMinute: Number(event.target.value),
                    })
                  }
                />
              </label>
              <ReadOnlyField label="Termék / perc" value={checkSettings?.productsPerMinute} />
              <ReadOnlyField
                label="Várakozás termékek között"
                value={formatSeconds(checkSettings?.delayBetweenProductsSeconds)}
              />
              <ReadOnlyField
                label="Jitter"
                value={
                  checkSettings
                    ? `${checkSettings.jitterMinSeconds}-${checkSettings.jitterMaxSeconds} mp`
                    : null
                }
              />
              <ReadOnlyField label="Max retry" value={checkSettings?.maxRetriesPerItem} />
              <ReadOnlyField
                label="Timeoutok"
                value={
                  checkSettings
                    ? `${checkSettings.navigationTimeoutSeconds}/${checkSettings.itemTimeoutSeconds} mp`
                    : null
                }
              />
              <ReadOnlyField
                label="Hibák utáni stop"
                value={checkSettings?.stopAfterConsecutiveFailures}
              />
              <ReadOnlyField
                label="Safety/cart stop"
                value={
                  checkSettings
                    ? `${checkSettings.stopOnSafetyEvent ? "safety igen" : "safety nem"}, ${
                        checkSettings.stopOnCartChange ? "kosár igen" : "kosár nem"
                      }`
                    : null
                }
              />
            </AuditSection>

            <AuditSection title="G) Connector terv">
              <TextAreaField
                label="Parser megjegyzések"
                value={editForm.parserNotes}
                onChange={(value) => setEditForm({ ...editForm, parserNotes: value })}
              />
              <TextAreaField
                label="Bizonyíték elvárások"
                value={editForm.evidenceExpectations}
                onChange={(value) => setEditForm({ ...editForm, evidenceExpectations: value })}
              />
              <TextAreaField
                label="Ismert blokkolók"
                value={editForm.knownBlockers}
                onChange={(value) => setEditForm({ ...editForm, knownBlockers: value })}
              />
              <TextAreaField
                label="Go / no-go döntés"
                value={editForm.goNoGoDecision}
                onChange={(value) => setEditForm({ ...editForm, goNoGoDecision: value })}
              />
              <TextAreaField
                label="Nyitott kérdések"
                value={editForm.openQuestions}
                onChange={(value) => setEditForm({ ...editForm, openQuestions: value })}
              />
            </AuditSection>

            <div className="action-row">
              <button className="button" type="submit" disabled={saving}>
                Audit részletek mentése
              </button>
              <span className="status">Minta, domain és metódus mezőknél soronként egy érték.</span>
            </div>
          </form>
        </section>
      ) : null}

      {selectedAudit ? (
        <section className="card table-card">
          <h2 className="section-title">Jóváhagyási ellenőrzőlista</h2>
          <div className="table-scroll">
            <table className="table data-table data-table--compact">
              <colgroup>
                <col className="col-message" />
                <col className="col-status" />
                <col className="col-action" />
              </colgroup>
              <thead>
                <tr>
                  <th>Ellenőrzés</th>
                  <th className="cell-nowrap">Állapot</th>
                  <th className="actions">Módosítás</th>
                </tr>
              </thead>
              <tbody>
                {selectedAudit.checks.map((check) => (
                  <tr key={check.id}>
                    <td className="cell-wrap">
                      {labelPortalAuditCheckLabel(check.checkKey, check.label)}
                    </td>
                    <td className="cell-nowrap">{labelPortalAuditCheckStatus(check.status)}</td>
                    <td className="actions">
                      <select
                        className="input"
                        value={check.status}
                        onChange={(event) =>
                          updateCheck(check, event.target.value as PortalAuditCheckStatus)
                        }
                      >
                        {portalAuditCheckStatuses.map((status) => (
                          <option key={status} value={status}>
                            {labelPortalAuditCheckStatus(status)}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}

      {selectedAudit ? (
        <section className="card">
          <h2 className="section-title">Bizonyíték megjegyzések</h2>
          <p className="helper-text">
            Csak szöveges hivatkozás. Az API elutasítja az egyértelmű credential, cookie,
            storageState, bearer, authorization és session token jellegű tartalmat.
          </p>
          <form onSubmit={handleEvidence}>
            <div className="form-grid">
              <TextField
                label="Cím"
                value={evidenceForm.title}
                onChange={(value) => setEvidenceForm({ ...evidenceForm, title: value })}
                required
              />
              <label className="field-label">
                Bizonyíték típusa
                <select
                  className="input"
                  value={evidenceForm.evidenceType}
                  onChange={(event) =>
                    setEvidenceForm({
                      ...evidenceForm,
                      evidenceType: event.target.value as PortalAuditEvidenceType,
                    })
                  }
                >
                  {portalAuditEvidenceTypes.map((type) => (
                    <option key={type} value={type}>
                      {labelPortalAuditEvidenceType(type)}
                    </option>
                  ))}
                </select>
              </label>
              <TextField
                label="Létrehozta"
                value={evidenceForm.createdBy}
                onChange={(value) => setEvidenceForm({ ...evidenceForm, createdBy: value })}
              />
            </div>
            <div className="action-row">
              <TextAreaField
                label="Tartalom"
                value={evidenceForm.content}
                onChange={(value) => setEvidenceForm({ ...evidenceForm, content: value })}
                required
              />
            </div>
            <div className="action-row">
              <button className="button" type="submit" disabled={saving}>
                Bizonyíték megjegyzés hozzáadása
              </button>
            </div>
          </form>

          {selectedAudit.evidenceNotes.length ? (
            <div className="table-scroll">
              <table className="table data-table data-table--compact">
                <colgroup>
                  <col className="col-name" />
                  <col className="col-status" />
                  <col className="col-message" />
                </colgroup>
                <thead>
                  <tr>
                    <th>Cím</th>
                    <th className="cell-nowrap">Típus</th>
                    <th>Tartalom</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedAudit.evidenceNotes.map((note) => (
                    <tr key={note.id}>
                      <td className="cell-truncate" title={note.title}>
                        {note.title}
                      </td>
                      <td className="cell-nowrap">
                        {labelPortalAuditEvidenceType(note.evidenceType)}
                      </td>
                      <td className="cell-wrap">{safeEvidenceContent(note.content)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="helper-text">Még nincs bizonyíték megjegyzés.</p>
          )}
        </section>
      ) : null}

      {selectedAudit && connectorPlan ? (
        <section className="card">
          <h2 className="section-title">Connector terv</h2>
          {connectorPlan.readiness.ready ? (
            <p>
              <span className="badge success">Kész connector implementációs promptra</span>
            </p>
          ) : (
            <p>
              <span className="badge warning">Még nem építhető connector</span>
            </p>
          )}
          <div className="table-scroll">
            <table className="table data-table data-table--compact">
              <colgroup>
                <col className="col-medium" />
                <col className="col-message" />
              </colgroup>
              <tbody>
                <PlanRow
                  label="Connector ID javaslat"
                  value={connectorPlan.connectorPlan.connectorIdSuggestion}
                />
                <PlanRow
                  label="Megjelenített név"
                  value={connectorPlan.connectorPlan.displayNameSuggestion}
                />
                <PlanRow
                  label="Lookup stratégia"
                  value={
                    connectorPlan.connectorPlan.lookupStrategy
                      ? labelPortalAuditResultPageType(connectorPlan.connectorPlan.lookupStrategy)
                      : "Nincs"
                  }
                />
                <PlanRow
                  label="Oldaltípus"
                  value={labelPortalAuditResultPageType(
                    connectorPlan.connectorPlan.expectedPageKind
                  )}
                />
                <PlanRow
                  label="Domainek"
                  value={arraySummary(connectorPlan.connectorPlan.allowedDomains)}
                />
                <PlanRow
                  label="Metódusok"
                  value={arraySummary(connectorPlan.connectorPlan.allowedMethods)}
                />
              </tbody>
            </table>
          </div>
          <ListBlock
            title="Safety stop szabályok"
            items={connectorPlan.connectorPlan.safetyStopRules}
          />
          <ListBlock
            title="Implementációs lépések"
            items={connectorPlan.connectorPlan.implementationSteps}
          />
          <ListBlock
            title="Elfogadási kritériumok"
            items={connectorPlan.connectorPlan.acceptanceCriteria}
          />
          <ListBlock title="Teszt terv" items={connectorPlan.connectorPlan.testPlan} />
          <h3 className="section-title">Biztonságos export</h3>
          <p className="helper-text">
            Export nem tartalmaz credentialt, cookie-t, storageState-et, nyers HTML-t vagy
            screenshotot. Evidence note tartalom kimarad; csak cím/típus/meta marad.
          </p>
          <pre className="command-block">
            {JSON.stringify(safeExport ?? connectorPlan, null, 2)}
          </pre>
        </section>
      ) : null}

      {selectedAudit ? (
        <section className="card">
          <h2 className="section-title">Jóváhagyási kapu</h2>
          <div className="form-grid">
            <TextField
              label="Ellenőrző / jóváhagyó"
              value={reviewerName}
              onChange={setReviewerName}
            />
            <TextField
              label="Elutasítás megjegyzés"
              value={rejectNotes}
              onChange={setRejectNotes}
            />
          </div>
          <div className="action-row">
            <button
              className="button secondary"
              onClick={() => transition("submit")}
              disabled={saving}
            >
              Ellenőrzésre küldés
            </button>
            <button
              className="button"
              onClick={() => transition("approve")}
              disabled={saving || !reviewerName.trim() || !canApprove}
            >
              Jóváhagyás
            </button>
            <button
              className="button secondary"
              onClick={() => transition("reject")}
              disabled={saving || !reviewerName.trim() || !rejectNotes.trim()}
            >
              Elutasítás
            </button>
            {!canApprove ? (
              <span className="status">
                Jóváhagyás csak kitöltött, ellenőrzés alatt álló auditnál aktív.
              </span>
            ) : null}
          </div>
        </section>
      ) : null}
    </div>
  );
}

function AuditSection(props: { title: string; children: ReactNode }) {
  return (
    <section className="notice info">
      <h3 className="section-title">{props.title}</h3>
      <div className="form-grid">{props.children}</div>
    </section>
  );
}

function TextField(props: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="field-label">
      {props.label}
      <input
        className="input"
        value={props.value}
        onChange={(event) => props.onChange(event.target.value)}
        required={props.required}
        placeholder={props.placeholder}
      />
    </label>
  );
}

function TextAreaField(props: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
}) {
  return (
    <label className="field-label">
      {props.label}
      <textarea
        className="input"
        rows={3}
        value={props.value}
        onChange={(event) => props.onChange(event.target.value)}
        required={props.required}
      />
    </label>
  );
}

function NullableBooleanField(props: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="field-label">
      {props.label}
      <select
        className="input"
        value={props.value}
        onChange={(event) => props.onChange(event.target.value)}
      >
        <option value="unknown">{labelNullableBoolean("unknown")}</option>
        <option value="true">{labelNullableBoolean("true")}</option>
        <option value="false">{labelNullableBoolean("false")}</option>
      </select>
    </label>
  );
}

function ReadOnlyField(props: { label: string; value: string | number | null | undefined }) {
  return (
    <label className="field-label">
      {props.label}
      <input className="input" value={props.value ?? "Nincs adat"} disabled readOnly />
    </label>
  );
}

function InfoTile(props: { title: string; value: string }) {
  return (
    <div className="workflow-item">
      <p className="card-title">{props.title}</p>
      <p className="helper-text">{props.value}</p>
    </div>
  );
}

function StatusTile(props: { title: string; value: string; tone?: "success" | "warning" }) {
  return (
    <div className="card summary-metric">
      <p className="card-title">{props.title}</p>
      <p className="card-value">
        <span className={`badge ${props.tone ?? ""}`.trim()}>{props.value}</span>
      </p>
    </div>
  );
}

function ListBlock(props: { title: string; items: string[]; checkLabels?: boolean }) {
  if (!props.items.length) return null;
  return (
    <div className="notice">
      <h3 className="section-title">{props.title}</h3>
      <ul>
        {props.items.map((item) => (
          <li key={item}>
            {props.checkLabels ? labelPortalAuditCheckLabel(item, item) : labelField(item)}
          </li>
        ))}
      </ul>
    </div>
  );
}

function RunSettingsSummary(props: { settings: SupplierCheckSettings | null }) {
  if (!props.settings) {
    return <p className="helper-text">Beszállítói futási beállítás nincs betöltve.</p>;
  }

  return (
    <div className="notice info">
      <h3 className="section-title">Beszállítói futási beállítás összefoglaló</h3>
      <p className="helper-text">
        {props.settings.productsPerMinute}/min, {props.settings.delayBetweenProductsSeconds} mp
        delay, jitter {props.settings.jitterMinSeconds}-{props.settings.jitterMaxSeconds} mp, max
        retry {props.settings.maxRetriesPerItem}, safety stop{" "}
        {props.settings.stopOnSafetyEvent ? "igen" : "nem"}, kosár stop{" "}
        {props.settings.stopOnCartChange ? "igen" : "nem"}.
      </p>
    </div>
  );
}

function PlanRow(props: { label: string; value: string }) {
  return (
    <tr>
      <th className="cell-nowrap">{props.label}</th>
      <td className="cell-wrap">{props.value}</td>
    </tr>
  );
}

function formFromAudit(audit: PortalAuditDetail) {
  return {
    portalBaseUrl: audit.portalBaseUrl ?? "",
    loginUrl: audit.loginUrl ?? "",
    has2fa: booleanToForm(audit.has2fa),
    hasCaptcha: booleanToForm(audit.hasCaptcha),
    hasAccountLockRisk: booleanToForm(audit.hasAccountLockRisk),
    loginFlowNotes: audit.loginFlowNotes ?? "",
    sessionLifetimeNotes: audit.sessionLifetimeNotes ?? "",
    searchUrl: audit.searchUrl ?? "",
    searchMethod: audit.searchMethod ?? "",
    searchInputNotes: audit.searchInputNotes ?? "",
    skuExactMatchRequired: booleanToForm(audit.skuExactMatchRequired),
    resultPageType: audit.resultPageType,
    priceVisibleOn: audit.priceVisibleOn ?? "",
    stockVisibleOn: audit.stockVisibleOn ?? "",
    availabilityTextNotes: audit.availabilityTextNotes ?? "",
    productIdentityNotes: audit.productIdentityNotes ?? "",
    cartIndicatorSelector: audit.cartIndicatorSelector ?? "",
    dangerousUrlPatterns: joinLines(audit.dangerousUrlPatterns),
    allowedUrlPatterns: joinLines(audit.allowedUrlPatterns),
    allowedDomains: joinLines(audit.allowedDomains),
    allowedMethods: joinLines(audit.allowedMethods),
    allowedPostPatterns: joinLines(audit.allowedPostPatterns),
    suggestedRateLimitPerMinute: audit.suggestedRateLimitPerMinute,
    parserNotes: audit.parserNotes ?? "",
    evidenceExpectations: audit.evidenceExpectations ?? "",
    knownBlockers: audit.knownBlockers ?? "",
    goNoGoDecision: audit.goNoGoDecision ?? "",
    openQuestions: audit.openQuestions ?? "",
    auditNotes: audit.auditNotes ?? "",
    safetyNotes: audit.safetyNotes ?? "",
  };
}

function splitLines(value: string): string[] {
  return value
    .split(/[,\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function joinLines(value: string[] | null): string {
  return value?.join("\n") ?? "";
}

function emptyToNull(value: string): string | null {
  const trimmed = value.trim();
  return trimmed.length ? trimmed : null;
}

function booleanToForm(value: boolean | null): string {
  if (value === true) return "true";
  if (value === false) return "false";
  return "unknown";
}

function parseNullableBoolean(value: string): boolean | null {
  if (value === "true") return true;
  if (value === "false") return false;
  return null;
}

function parseStrictBoolean(value: string): boolean {
  return value === "true";
}

function labelField(value: string): string {
  return fieldLabels[value] ?? value.replace(/^Complete /, "Pótold: ");
}

function labelNextAction(readiness: PortalAuditConnectorPlanResponse["readiness"] | null): string {
  if (!readiness) return "Audit kiválasztása";
  if (readiness.ready) return "Kész connector implementációs promptra";
  if (isApprovalCandidate(readiness)) return "Jóváhagyás, majd connector terv export";
  if (readiness.missingRequiredFields.length) {
    return `Pótold: ${labelField(readiness.missingRequiredFields[0] ?? "")}`;
  }
  if (readiness.failingChecks.length) {
    return `Checklist: ${labelPortalAuditCheckLabel(
      readiness.failingChecks[0] ?? "",
      readiness.failingChecks[0] ?? ""
    )}`;
  }
  return "Ellenőrzés szükséges";
}

function formatSeconds(value: number | null | undefined): string | null {
  return value === undefined || value === null ? null : `${value} mp`;
}

function arraySummary(value: string[]): string {
  return value.length ? value.join(", ") : "-";
}

function isApprovalCandidate(
  readiness: PortalAuditConnectorPlanResponse["readiness"] | null
): boolean {
  return (
    readiness !== null &&
    readiness.failingChecks.length === 0 &&
    readiness.missingRequiredFields.length === 1 &&
    readiness.missingRequiredFields[0] === "status=approved"
  );
}

function safeEvidenceContent(content: string): string {
  return looksLikeForbiddenEvidenceContent(content)
    ? "[Elrejtve: raw HTML vagy képernyőkép jellegű bizonyíték tartalom]"
    : content;
}

function looksLikeForbiddenEvidenceContent(content: string): boolean {
  return FORBIDDEN_EVIDENCE_CONTENT_PATTERN.test(content);
}

const FORBIDDEN_EVIDENCE_CONTENT_PATTERN =
  /<!doctype|<html\b|<body\b|<script\b|<form\b|data:image\/|!\[[^\]]*\]\([^)]*\.(?:png|jpe?g|webp|gif)\)|<img\b|[A-Za-z]:\\[^\n]+\.(?:png|jpe?g|webp|gif|html?)\b|\.(?:png|jpe?g|webp|gif)\b/i;
