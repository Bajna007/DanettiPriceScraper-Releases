"use client";

import { useEffect, useState } from "react";
import { ErrorState, LoadingState } from "../../src/components/States";
import { getSetupStatus, type SetupStatusResponse } from "../../src/lib/api";
import { labelRuntimeStatus } from "../../src/lib/labels";

export default function SetupPage() {
  const [status, setStatus] = useState<SetupStatusResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    setLoading(true);
    setError(null);

    try {
      setStatus(await getSetupStatus());
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Nem sikerült betölteni a beállítási státuszt."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void refresh();
  }, []);

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Beállítás varázsló</h1>
      </div>

      <section className="card">
        <h2 className="section-title">Állapot</h2>
        <p className="card-value">{status ? labelRuntimeStatus(status.status) : "Betöltés..."}</p>
        <div className="action-row">
          <button className="button secondary" onClick={refresh} disabled={loading}>
            Frissítés
          </button>
          <span className="status">Csak olvasó diagnosztika.</span>
        </div>
      </section>

      <section className="card">
        <h2 className="section-title">Web-only futtatás</h2>
        <div className="grid-2">
          <div>
            <h3 className="section-title">Mi indul helyben?</h3>
            <p className="helper-text">
              A helyi API és a dashboard fut. A DVG operator oldal a böngészőből érhető el:
              http://localhost:3000/operator/dvg.
            </p>
          </div>
          <div>
            <h3 className="section-title">Mi kell a helyi futtatáshoz?</h3>
            <p className="helper-text">
              Docker Desktop, Postgres és Redis továbbra is külső helyi függőség. Fejlesztői módban
              először futtasd: npm.cmd run local:web:doctor. Indítás: npm.cmd run local:web.
            </p>
          </div>
        </div>
        <p className="helper-text">
          A böngészős UI nem futtat admin parancsot, Docker telepítést vagy Docker leállítást.
        </p>
      </section>

      {loading ? <LoadingState message="Beállítási státusz betöltése..." /> : null}
      {error ? <ErrorState message={error} /> : null}

      {status ? (
        <section className="card table-card">
          <div className="table-scroll">
            <table className="table data-table data-table--status">
              <colgroup>
                <col className="col-medium" />
                <col className="col-status" />
                <col className="col-message" />
                <col className="col-message" />
              </colgroup>
              <thead>
                <tr>
                  <th className="cell-nowrap">Lépés</th>
                  <th className="cell-nowrap">Állapot</th>
                  <th>Üzenet</th>
                  <th>Teendő</th>
                </tr>
              </thead>
              <tbody>
                {status.steps.map((step) => (
                  <tr key={step.key}>
                    <td className="cell-nowrap">{step.label}</td>
                    <td className="cell-nowrap">
                      <span className="badge">{labelRuntimeStatus(step.status)}</span>
                    </td>
                    <td className="cell-wrap">{step.message}</td>
                    <td className="cell-wrap">{step.action ?? "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}

      {status ? (
        <section className="card">
          <h2 className="section-title">Javasolt indítási sorrend</h2>
          <pre className="command-block">
            <code>{status.commands.join("\n")}</code>
          </pre>
          <h2 className="section-title">Biztonsági korlátok</h2>
          <ul className="helper-text">
            {status.safetyNotes.map((note) => (
              <li key={note}>{note}</li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
