"use client";

import { useEffect, useMemo, useState } from "react";
import {
  getImport,
  listImports,
  type ImportDetailResponse,
  type CatalogImportRun,
} from "../../src/lib/api";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import { TablePagination } from "../../src/components/TablePagination";
import { formatDate } from "../../src/lib/formatters";
import { labelImportStatus } from "../../src/lib/labels";

const DEFAULT_LIMIT = 50;

export default function ImportHistoryPage() {
  const [data, setData] = useState<{ items: CatalogImportRun[]; total?: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<ImportDetailResponse | null>(null);
  const [offset, setOffset] = useState(0);
  const canGoBack = offset > 0;
  const canGoNext =
    data?.total !== undefined ? offset + (data?.items.length ?? 0) < data.total : false;
  const paginationLabel = useMemo(() => {
    const total = data?.total;
    if (total === undefined) return `Megjelenítve: ${offset + 1}-${offset + DEFAULT_LIMIT}`;
    const start = total === 0 ? 0 : offset + 1;
    const end = Math.min(offset + DEFAULT_LIMIT, total);
    return `Megjelenítve: ${start}-${end} / ${total}`;
  }, [data?.total, offset]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);

    listImports({ limit: DEFAULT_LIMIT, offset })
      .then((response) => {
        if (active) setData(response);
      })
      .catch((err) => {
        if (active)
          setError(err instanceof Error ? err.message : "Nem sikerült betölteni az importokat.");
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [offset]);

  useEffect(() => {
    if (!data || data.total === undefined) return;
    if (data.total === 0 && offset !== 0) {
      setOffset(0);
      return;
    }
    if (data.total > 0 && offset >= data.total) {
      setOffset(Math.floor((data.total - 1) / DEFAULT_LIMIT) * DEFAULT_LIMIT);
    }
  }, [data?.total, offset]);

  const handleSelect = async (id: string) => {
    setSelected(null);
    try {
      const detail = await getImport(id);
      setSelected(detail);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Nem sikerült betölteni az import részleteit.");
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1 className="page-title">Import előzmények</h1>
      </div>

      {loading ? <LoadingState /> : null}
      {error ? <ErrorState message={error} /> : null}

      {!loading && !error && (!data?.items || data.items.length === 0) ? (
        <EmptyState title="Még nincs import">Tölts fel CSV-t a katalógus importhoz.</EmptyState>
      ) : null}

      {data?.items?.length ? (
        <section className="card table-card">
          <div className="table-toolbar product-table-toolbar">
            <TablePagination
              canGoBack={canGoBack}
              canGoNext={canGoNext}
              label={paginationLabel}
              onBack={() => setOffset(Math.max(0, offset - DEFAULT_LIMIT))}
              onNext={() => setOffset(offset + DEFAULT_LIMIT)}
              compact
            />
            <div className="product-view-controls" role="group" aria-label="Import lista nézet">
              <span className="table-toolbar-status">Legújabb importok elöl</span>
            </div>
          </div>
          <div className="table-scroll">
            <table className="table data-table data-table--wide">
              <colgroup>
                <col className="col-date" />
                <col className="col-long" />
                <col className="col-short" />
                <col className="col-status" />
                <col className="col-number" />
                <col className="col-number" />
                <col className="col-number" />
                <col className="col-number" />
                <col className="col-number" />
                <col className="col-number" />
                <col className="col-number" />
                <col className="col-number" />
                <col className="col-action" />
              </colgroup>
              <thead>
                <tr>
                  <th className="cell-nowrap">Létrehozva</th>
                  <th>Fájl</th>
                  <th className="cell-nowrap">Mód</th>
                  <th className="cell-nowrap">Állapot</th>
                  <th className="numeric cell-nowrap">Összes</th>
                  <th className="numeric cell-nowrap">Új</th>
                  <th className="numeric cell-nowrap">Frissített</th>
                  <th className="numeric cell-nowrap">Törölt</th>
                  <th className="numeric cell-nowrap">Duplikált</th>
                  <th className="numeric cell-nowrap">Hiányzó SKU</th>
                  <th className="numeric cell-nowrap">Hibás</th>
                  <th className="numeric cell-nowrap">Sikertelen</th>
                  <th className="actions">Művelet</th>
                </tr>
              </thead>
              <tbody>
                {data.items.map((importRun: any) => (
                  <tr key={importRun.id} onClick={() => handleSelect(importRun.id)}>
                    <td className="cell-nowrap">{formatDate(importRun.createdAt)}</td>
                    <td className="cell-truncate" title={importRun.originalFilename ?? ""}>
                      {importRun.originalFilename ?? "(névtelen)"}
                    </td>
                    <td className="cell-nowrap">{importRun.mode}</td>
                    <td className="cell-nowrap">{labelImportStatus(importRun.status)}</td>
                    <td className="numeric cell-nowrap">{importRun.totalRows}</td>
                    <td className="numeric cell-nowrap">{importRun.insertedCount}</td>
                    <td className="numeric cell-nowrap">{importRun.updatedCount ?? 0}</td>
                    <td className="numeric cell-nowrap">{importRun.deletedCount ?? 0}</td>
                    <td className="numeric cell-nowrap">{importRun.skippedDuplicateCount}</td>
                    <td className="numeric cell-nowrap">{importRun.skippedMissingSkuCount}</td>
                    <td className="numeric cell-nowrap">{importRun.invalidCount}</td>
                    <td className="numeric cell-nowrap">{importRun.failedCount}</td>
                    <td className="actions">
                      <button
                        className="button secondary"
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          void handleSelect(importRun.id);
                        }}
                      >
                        Részletek
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="table-footer">Sor megnyitása: kattints az import sorára.</p>
        </section>
      ) : null}

      {data?.items?.length ? (
        <TablePagination
          canGoBack={canGoBack}
          canGoNext={canGoNext}
          label={paginationLabel}
          onBack={() => setOffset(Math.max(0, offset - DEFAULT_LIMIT))}
          onNext={() => setOffset(offset + DEFAULT_LIMIT)}
        />
      ) : null}

      {selected ? (
        <section className="card">
          <h2 className="section-title">Import részletek</h2>
          <p className="helper-text">{selected.originalFilename ?? "(névtelen)"}</p>
          {Array.isArray(selected.rows) && selected.rows.length > 0 ? (
            <div className="table-scroll">
              <table className="table data-table data-table--compact">
                <colgroup>
                  <col className="col-number" />
                  <col className="col-status" />
                  <col className="col-sku" />
                  <col className="col-name" />
                  <col className="col-sku" />
                  <col className="col-error" />
                </colgroup>
                <thead>
                  <tr>
                    <th className="numeric cell-nowrap">Sor</th>
                    <th className="cell-nowrap">Állapot</th>
                    <th className="cell-nowrap">SKU</th>
                    <th>Név</th>
                    <th className="cell-nowrap">Javasolt cikkszám</th>
                    <th>Hiba</th>
                  </tr>
                </thead>
                <tbody>
                  {selected.rows.slice(0, 12).map((row: any) => (
                    <tr key={row.id}>
                      <td className="numeric cell-nowrap">{row.rowNumber}</td>
                      <td className="cell-nowrap">{labelImportStatus(row.status)}</td>
                      <td className="cell-mono cell-truncate" title={row.sku ?? ""}>
                        {row.sku ?? "—"}
                      </td>
                      <td className="cell-truncate" title={row.name ?? ""}>
                        {row.name ?? "—"}
                      </td>
                      <td
                        className="cell-mono cell-truncate"
                        title={row.suggestedSupplierArticle ?? ""}
                      >
                        {row.suggestedSupplierArticle ?? "—"}
                      </td>
                      <td className="cell-wrap">{row.errorMessage ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="helper-text">Még nincs sor részlet.</p>
          )}
        </section>
      ) : null}
    </div>
  );
}
