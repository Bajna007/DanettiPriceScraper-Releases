:HL["/_next/static/chunks/1elf2ru2rablc.css","style"]
:HL["/_next/static/chunks/01xmb4ta_bsq1.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"supplier-price-changes","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"yh5HzRw2fwW5o3p9IFk2i"}
