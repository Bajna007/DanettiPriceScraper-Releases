import assert from "node:assert/strict";
import Fastify from "fastify";
import type {
  SupplierPriceChangesRepositoryLike,
  SupplierPriceChangeSnapshotRow,
  SupplierPriceChangeSupplierScope,
} from "./supplier-price-changes.repository.js";
import { registerSupplierPriceChangeRoutes } from "./supplier-price-changes.routes.js";

const productId = "11111111-1111-4111-8111-111111111111";
const supplierId = "22222222-2222-4222-8222-222222222222";
const lfSupplierId = "22222222-2222-4222-8222-222222222223";
const mappingId = "33333333-3333-4333-8333-333333333333";

class InMemoryPriceChangeRepository implements SupplierPriceChangesRepositoryLike {
  readonly requestedScopes: SupplierPriceChangeSupplierScope[] = [];

  constructor(
    private readonly rows: SupplierPriceChangeSnapshotRow[],
    private readonly rate: number | null = 400
  ) {}

  async getLatestEurHufRate(): Promise<number | null> {
    return this.rate;
  }

  async listRecentCatalogSnapshots(
    _limit: number,
    supplierScope: SupplierPriceChangeSupplierScope
  ): Promise<SupplierPriceChangeSnapshotRow[]> {
    this.requestedScopes.push(supplierScope);
    if (supplierScope === "dvg") return this.rows.filter((row) => row.supplierId === supplierId);
    if (supplierScope === "lf") return this.rows.filter((row) => row.supplierId === lfSupplierId);
    return this.rows;
  }
}

const rows: SupplierPriceChangeSnapshotRow[] = [
  snapshotRow({
    snapshotId: "44444444-4444-4444-8444-000000000002",
    priceNetEur: "5.00",
    observedAt: new Date("2026-06-14T08:00:00.000Z"),
  }),
  snapshotRow({
    snapshotId: "44444444-4444-4444-8444-000000000001",
    priceNetEur: "4.00",
    observedAt: new Date("2026-06-13T08:00:00.000Z"),
  }),
];

const server = Fastify({ logger: false });
await registerSupplierPriceChangeRoutes(server, {
  repository: new InMemoryPriceChangeRepository(rows),
  now: () => new Date("2026-06-14T09:00:00.000Z"),
});

try {
  const response = await server.inject({
    method: "GET",
    url: "/supplier-price-changes?direction=increase&roundingIncrementHuf=100",
  });
  assert.equal(response.statusCode, 200);
  const body = response.json();
  assert.equal(body.settings.supplierScope, "all");
  assert.equal(body.total, 1);
  assert.equal(body.summary.changedCount, 1);
  assert.equal(body.summary.increaseCount, 1);
  assert.equal(body.items[0].sku, "CS-A2200247_SAE125");
  assert.equal(body.items[0].oldSupplierNetEur, 4);
  assert.equal(body.items[0].newSupplierNetEur, 5);
  assert.equal(body.items[0].supplierChangePercent, 25);
  assert.equal(body.items[0].currentWooPriceHuf, 7620);
  assert.equal(body.items[0].preservedProfitPercent, 275);
  assert.equal(body.items[0].currentProfitPercentWithNewCost, 200);
  assert.equal(body.items[0].suggestedGrossPriceRoundedHuf, 9600);
  assert.equal(body.items[0].suggestedPriceDeltaHuf, 1980);

  const roundingDisabled = await server.inject({
    method: "GET",
    url: "/supplier-price-changes?roundingEnabled=false&roundingIncrementHuf=100",
  });
  assert.equal(roundingDisabled.statusCode, 200);
  assert.equal(roundingDisabled.json().items[0].suggestedGrossPriceRoundedHuf, 9525);
  assert.equal(roundingDisabled.json().settings.roundingEnabled, false);

  const decreaseOnly = await server.inject({
    method: "GET",
    url: "/supplier-price-changes?direction=decrease",
  });
  assert.equal(decreaseOnly.statusCode, 200);
  assert.equal(decreaseOnly.json().total, 0);
} finally {
  await server.close();
}

const defaultDirectionServer = Fastify({ logger: false });
await registerSupplierPriceChangeRoutes(defaultDirectionServer, {
  repository: new InMemoryPriceChangeRepository([
    ...rows,
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000006",
      supplierMappingId: "33333333-3333-4333-8333-333333333336",
      supplierArticleNumber: "CS-A2200250",
      priceNetEur: "3.00",
      observedAt: new Date("2026-06-14T08:00:00.000Z"),
    }),
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000005",
      supplierMappingId: "33333333-3333-4333-8333-333333333336",
      supplierArticleNumber: "CS-A2200250",
      priceNetEur: "4.00",
      observedAt: new Date("2026-06-13T08:00:00.000Z"),
    }),
  ]),
});
try {
  const defaultDirection = await defaultDirectionServer.inject({
    method: "GET",
    url: "/supplier-price-changes",
  });
  assert.equal(defaultDirection.statusCode, 200);
  assert.equal(defaultDirection.json().settings.direction, "all");
  assert.equal(defaultDirection.json().settings.supplierScope, "all");
  assert.equal(defaultDirection.json().total, 2);
  assert.equal(defaultDirection.json().summary.increaseCount, 1);
  assert.equal(defaultDirection.json().summary.decreaseCount, 1);
} finally {
  await defaultDirectionServer.close();
}

const missingRateServer = Fastify({ logger: false });
await registerSupplierPriceChangeRoutes(missingRateServer, {
  repository: new InMemoryPriceChangeRepository(rows, null),
});
try {
  const missingRate = await missingRateServer.inject({
    method: "GET",
    url: "/supplier-price-changes",
  });
  assert.equal(missingRate.statusCode, 400);
  assert.equal(missingRate.json().error.code, "eur_huf_rate_required");
} finally {
  await missingRateServer.close();
}

const separateMappingsServer = Fastify({ logger: false });
await registerSupplierPriceChangeRoutes(separateMappingsServer, {
  repository: new InMemoryPriceChangeRepository([
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000004",
      supplierMappingId: "33333333-3333-4333-8333-333333333334",
      supplierArticleNumber: "CS-A2200248",
      priceNetEur: "5.00",
      observedAt: new Date("2026-06-14T08:00:00.000Z"),
    }),
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000003",
      supplierMappingId: "33333333-3333-4333-8333-333333333335",
      supplierArticleNumber: "CS-A2200249",
      priceNetEur: "4.00",
      observedAt: new Date("2026-06-13T08:00:00.000Z"),
    }),
  ]),
});
try {
  const separateMappings = await separateMappingsServer.inject({
    method: "GET",
    url: "/supplier-price-changes",
  });
  assert.equal(separateMappings.statusCode, 200);
  assert.equal(separateMappings.json().total, 0);
  assert.equal(separateMappings.json().summary.noPreviousPriceCount, 2);
} finally {
  await separateMappingsServer.close();
}

const wooOnlyChangeServer = Fastify({ logger: false });
await registerSupplierPriceChangeRoutes(wooOnlyChangeServer, {
  repository: new InMemoryPriceChangeRepository([
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000008",
      priceNetEur: "4.00",
      currentPrice: "8900",
      observedAt: new Date("2026-06-14T08:00:00.000Z"),
    }),
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000007",
      priceNetEur: "4.00",
      currentPrice: "7620",
      observedAt: new Date("2026-06-13T08:00:00.000Z"),
    }),
  ]),
});
try {
  const wooOnlyChange = await wooOnlyChangeServer.inject({
    method: "GET",
    url: "/supplier-price-changes",
  });
  assert.equal(wooOnlyChange.statusCode, 200);
  assert.equal(wooOnlyChange.json().total, 0);
  assert.equal(wooOnlyChange.json().summary.changedCount, 0);
  assert.equal(wooOnlyChange.json().summary.noPreviousPriceCount, 0);
} finally {
  await wooOnlyChangeServer.close();
}

const duplicateLatestSnapshotServer = Fastify({ logger: false });
await registerSupplierPriceChangeRoutes(duplicateLatestSnapshotServer, {
  repository: new InMemoryPriceChangeRepository([
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000011",
      priceNetEur: "5.00",
      observedAt: new Date("2026-06-14T08:01:00.000Z"),
    }),
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000010",
      priceNetEur: "5.00",
      observedAt: new Date("2026-06-14T08:00:00.000Z"),
    }),
    snapshotRow({
      snapshotId: "44444444-4444-4444-8444-000000000009",
      priceNetEur: "4.00",
      observedAt: new Date("2026-06-13T08:00:00.000Z"),
    }),
  ]),
});
try {
  const duplicateLatestSnapshot = await duplicateLatestSnapshotServer.inject({
    method: "GET",
    url: "/supplier-price-changes",
  });
  assert.equal(duplicateLatestSnapshot.statusCode, 200);
  assert.equal(duplicateLatestSnapshot.json().total, 1);
  assert.equal(duplicateLatestSnapshot.json().items[0].oldSupplierNetEur, 4);
  assert.equal(duplicateLatestSnapshot.json().items[0].newSupplierNetEur, 5);
  assert.equal(
    duplicateLatestSnapshot.json().items[0].newSnapshotId,
    "44444444-4444-4444-8444-000000000011"
  );
  assert.equal(
    duplicateLatestSnapshot.json().items[0].oldSnapshotId,
    "44444444-4444-4444-8444-000000000009"
  );
  assert.equal(duplicateLatestSnapshot.json().summary.noPreviousPriceCount, 0);
} finally {
  await duplicateLatestSnapshotServer.close();
}

const supplierScopeRepository = new InMemoryPriceChangeRepository([
  ...rows,
  snapshotRow({
    snapshotId: "44444444-4444-4444-8444-000000000013",
    supplierId: lfSupplierId,
    supplierName: "LF Spare Parts 724",
    supplierMappingId: "33333333-3333-4333-8333-333333333337",
    supplierArticleNumber: "5072594",
    priceNetEur: "7.00",
    observedAt: new Date("2026-06-14T08:00:00.000Z"),
  }),
  snapshotRow({
    snapshotId: "44444444-4444-4444-8444-000000000012",
    supplierId: lfSupplierId,
    supplierName: "LF Spare Parts 724",
    supplierMappingId: "33333333-3333-4333-8333-333333333337",
    supplierArticleNumber: "5072594",
    priceNetEur: "6.00",
    observedAt: new Date("2026-06-13T08:00:00.000Z"),
  }),
]);
const supplierScopeServer = Fastify({ logger: false });
await registerSupplierPriceChangeRoutes(supplierScopeServer, {
  repository: supplierScopeRepository,
});
try {
  const lfScope = await supplierScopeServer.inject({
    method: "GET",
    url: "/supplier-price-changes?supplierScope=lf",
  });
  assert.equal(lfScope.statusCode, 200);
  assert.equal(supplierScopeRepository.requestedScopes.at(-1), "lf");
  assert.equal(lfScope.json().settings.supplierScope, "lf");
  assert.equal(lfScope.json().total, 1);
  assert.equal(lfScope.json().items[0].supplierName, "LF Spare Parts 724");
} finally {
  await supplierScopeServer.close();
}

const reversalServer = Fastify({ logger: false });
await registerSupplierPriceChangeRoutes(reversalServer, {
  repository: new InMemoryPriceChangeRepository([
    snapshotRow({
      snapshotId: "snapshot-1",
      priceNetEur: "4.00",
      observedAt: new Date("2026-06-10T08:00:00.000Z"),
    }),
    snapshotRow({
      snapshotId: "snapshot-3",
      priceNetEur: "4.00",
      observedAt: new Date("2026-06-12T08:00:00.000Z"),
    }),
    snapshotRow({
      snapshotId: "snapshot-2",
      priceNetEur: "5.00",
      observedAt: new Date("2026-06-11T08:00:00.000Z"),
    }),
    snapshotRow({
      snapshotId: "snapshot-4",
      priceNetEur: "4.00",
      observedAt: new Date("2026-06-13T08:00:00.000Z"),
    }),
  ]),
});
try {
  const response = await reversalServer.inject("/supplier-price-changes?direction=decrease");
  assert.equal(response.statusCode, 200);
  const body = response.json();
  assert.equal(body.total, 1);
  assert.equal(body.summary.decreaseCount, 1);
  assert.equal(body.items[0].oldSupplierNetEur, 5);
  assert.equal(body.items[0].newSupplierNetEur, 4);
  assert.equal(body.items[0].oldSnapshotId, "snapshot-2");
  assert.equal(body.items[0].newSnapshotId, "snapshot-4");
  assert.equal(body.items[0].supplierChangePercent, -20);
  assert.equal(
    (await reversalServer.inject("/supplier-price-changes?direction=increase")).json().total,
    0
  );
  assert.equal(
    (await reversalServer.inject("/supplier-price-changes?minChangePercent=21")).json().total,
    0
  );
} finally {
  await reversalServer.close();
}

console.log("Supplier price changes route tests passed");

function snapshotRow(input: {
  snapshotId: string;
  supplierId?: string;
  supplierName?: string;
  supplierMappingId?: string | null;
  supplierArticleNumber?: string;
  priceNetEur: string;
  currentPrice?: string | null;
  observedAt: Date;
}): SupplierPriceChangeSnapshotRow {
  return {
    snapshotId: input.snapshotId,
    supplierId: input.supplierId ?? supplierId,
    supplierName: input.supplierName ?? "DVG De Vecchi",
    supplierMappingId: input.supplierMappingId ?? mappingId,
    catalogProductId: productId,
    sku: "CS-A2200247_SAE125",
    productName: "Teszt termek",
    supplierArticleNumber: input.supplierArticleNumber ?? "CS-A2200247",
    priceNetEur: input.priceNetEur,
    observedAt: input.observedAt,
    createdAt: input.observedAt,
    currentPrice: input.currentPrice ?? "7620",
    salePrice: null,
    regularPrice: null,
  };
}
