import { createHash } from "node:crypto";
import multipart, { type MultipartFile } from "@fastify/multipart";
import { createDbClient, type DanettiDbClient } from "@danetti/db";
import type { FastifyInstance, FastifyReply } from "fastify";
import {
  CSV_IMPORT_MAX_BYTES,
  DEFAULT_IMPORT_ROW_LIMIT,
  DEFAULT_LIST_LIMIT,
  MAX_IMPORT_ROW_LIMIT,
  MAX_LIST_LIMIT,
} from "./catalog-import.constants.js";
import { CatalogImportRepository } from "./catalog-import.repository.js";
import type {
  CatalogProductListFilters,
  CatalogProductSortBy,
  CatalogProductUpdateInput,
  UnifiedStatusFilter,
} from "./catalog-import.repository.js";
import { CatalogImportService, parseWooCsv } from "./catalog-import.service.js";
import {
  CatalogImportDatabaseError,
  CatalogImportValidationError,
  type CatalogImportColumnMappingInput,
  type CatalogImportMode,
  type UploadedCatalogCsv,
} from "./catalog-import.types.js";

interface CatalogImportRouteOptions {
  dbClient?: DanettiDbClient;
  databaseUrl?: string;
}

interface ListQuery {
  limit?: string;
  offset?: string;
  search?: string;
  sortBy?: string;
  sortDirection?: string;
  eurHufRate?: string;
  vatPercent?: string;
  supplierId?: string;
  articleStructure?: string;
  worklistView?: string;
  profitBandMode?: string;
  profitBandMinPercent?: string;
  profitBandMaxPercent?: string;
  calculability?: string;
  minProfitPercent?: string;
  maxProfitPercent?: string;
  minProfitHuf?: string;
  maxProfitHuf?: string;
  minDvgPurchaseHuf?: string;
  maxDvgPurchaseHuf?: string;
  minWooNetHuf?: string;
  maxWooNetHuf?: string;
  minRegularPrice?: string;
  maxRegularPrice?: string;
  hasDvgPrice?: string;
  unifiedStatus?: string;
}

interface IdParams {
  id: string;
}

const TEXT_CSV_LIKE_MIMETYPES = new Set([
  "text/csv",
  "application/csv",
  "application/vnd.ms-excel",
  "text/plain",
]);

export async function registerCatalogImportRoutes(
  server: FastifyInstance,
  options: CatalogImportRouteOptions = {}
): Promise<void> {
  await server.register(multipart, {
    limits: {
      fileSize: CSV_IMPORT_MAX_BYTES,
      files: 1,
    },
  });

  let dbClient = options.dbClient ?? null;

  server.addHook("onClose", async () => {
    if (options.dbClient === undefined && dbClient !== null) {
      await dbClient.close();
    }
  });

  function getRepository(): CatalogImportRepository {
    try {
      dbClient ??= createDbClient(options.databaseUrl);
      return new CatalogImportRepository(dbClient.db);
    } catch (error) {
      throw new CatalogImportDatabaseError(
        error instanceof Error ? error.message : "Database unavailable"
      );
    }
  }

  server.get("/catalog/imports", async (request, reply) => {
    try {
      const query = request.query as ListQuery;
      const limit = parseBoundedInteger(query.limit, DEFAULT_LIST_LIMIT, MAX_LIST_LIMIT, "limit");
      const offset = parseBoundedInteger(query.offset, 0, Number.MAX_SAFE_INTEGER, "offset");
      const result = await getRepository().listImportRuns({ limit, offset });
      return { runs: result.runs, total: result.total, limit, offset };
    } catch (error) {
      return handleRouteError(server, reply, error);
    }
  });

  server.get("/catalog/imports/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");

      const query = request.query as ListQuery;
      const limit = parseBoundedInteger(
        query.limit,
        DEFAULT_IMPORT_ROW_LIMIT,
        MAX_IMPORT_ROW_LIMIT,
        "limit"
      );
      const repository = getRepository();
      const importRun = await repository.getImportRun(params.id);

      if (importRun === null) {
        return reply
          .code(404)
          .send({ error: { code: "not_found", message: "Import run not found" } });
      }

      const rows = await repository.listImportRows(params.id, limit);
      return { importRun, rows: rows.map(omitRawRow) };
    } catch (error) {
      return handleRouteError(server, reply, error);
    }
  });

  server.post("/catalog/imports/preview", async (request, reply) => {
    try {
      return await handleImportRequest(request.file(), "preview_only", getRepository);
    } catch (error) {
      return handleRouteError(server, reply, error);
    }
  });

  server.post("/catalog/imports/add-only", async (request, reply) => {
    try {
      return await handleImportRequest(request.file(), "add_only", getRepository);
    } catch (error) {
      return handleRouteError(server, reply, error);
    }
  });

  server.post("/catalog/imports/full-sync", async (request, reply) => {
    try {
      return await handleImportRequest(request.file(), "update_existing", getRepository);
    } catch (error) {
      return handleRouteError(server, reply, error);
    }
  });

  server.get("/catalog/products/summary", async (_request, reply) => {
    try {
      const summary = await getRepository().getProductsSummary();
      return { summary, generatedAt: new Date().toISOString() };
    } catch (error) {
      return handleRouteError(server, reply, error);
    }
  });

  server.get("/catalog/products", async (request, reply) => {
    try {
      const query = request.query as ListQuery;
      const limit = parseBoundedInteger(query.limit, DEFAULT_LIST_LIMIT, MAX_LIST_LIMIT, "limit");
      const offset = parseBoundedInteger(query.offset, 0, Number.MAX_SAFE_INTEGER, "offset");
      const result = await getRepository().listProducts(
        parseProductListFilters(query, limit, offset)
      );
      return { products: result.products.map(omitRawRow), total: result.total, limit, offset };
    } catch (error) {
      return handleRouteError(server, reply, error);
    }
  });

  server.patch("/catalog/products/:id", async (request, reply) => {
    try {
      const params = request.params as IdParams;
      validateUuid(params.id, "id");

      const product = await getRepository().updateCatalogProduct(
        params.id,
        parseCatalogProductUpdateInput(request.body)
      );
      if (product === null) {
        return reply
          .code(404)
          .send({ error: { code: "not_found", message: "Catalog product not found" } });
      }

      return { product: omitRawRow(product) };
    } catch (error) {
      return handleRouteError(server, reply, error);
    }
  });
}

async function handleImportRequest(
  multipartFilePromise: Promise<MultipartFile | undefined>,
  mode: CatalogImportMode,
  getRepository: () => CatalogImportRepository
) {
  const multipartFile = await multipartFilePromise;

  if (multipartFile === undefined) {
    throw new CatalogImportValidationError("missing_file", "Multipart field 'file' is required");
  }

  const uploadedCsv = await readUploadedCatalogCsv(multipartFile);
  const columnMapping = readColumnMappingInput(multipartFile);
  const parsedCsv = parseWooCsv(uploadedCsv.buffer, columnMapping);
  const service = new CatalogImportService(getRepository());

  return service.importCsv({ mode, uploadedCsv, parsedCsv });
}

function readColumnMappingInput(file: MultipartFile): CatalogImportColumnMappingInput {
  const fields = file.fields as Record<string, unknown> | undefined;
  const rawField = fields?.columnMapping;
  const rawValue =
    rawField && typeof rawField === "object" && "value" in rawField
      ? (rawField as { value?: unknown }).value
      : undefined;

  if (rawValue === undefined || rawValue === null || rawValue === "") {
    return {};
  }

  if (typeof rawValue !== "string") {
    throw new CatalogImportValidationError(
      "invalid_column_mapping",
      "columnMapping multipart field must be JSON"
    );
  }

  try {
    const parsed = JSON.parse(rawValue) as unknown;
    if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
      throw new Error("columnMapping must be an object");
    }
    return parsed as CatalogImportColumnMappingInput;
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invalid JSON";
    throw new CatalogImportValidationError(
      "invalid_column_mapping",
      `columnMapping multipart field must be valid JSON: ${message}`
    );
  }
}

async function readUploadedCatalogCsv(file: MultipartFile): Promise<UploadedCatalogCsv> {
  if (file.fieldname !== "file") {
    throw new CatalogImportValidationError("missing_file", "Multipart field 'file' is required");
  }

  validateCsvFileType(file);

  const chunks: Buffer[] = [];
  let fileSizeBytes = 0;
  const hash = createHash("sha256");

  for await (const chunk of file.file) {
    const bufferChunk = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    fileSizeBytes += bufferChunk.length;

    if (fileSizeBytes > CSV_IMPORT_MAX_BYTES) {
      throw new CatalogImportValidationError(
        "file_too_large",
        `CSV file exceeds ${CSV_IMPORT_MAX_BYTES} byte limit`,
        413
      );
    }

    hash.update(bufferChunk);
    chunks.push(bufferChunk);
  }

  const streamState = file.file as NodeJS.ReadableStream & { truncated?: boolean };

  if (streamState.truncated === true) {
    throw new CatalogImportValidationError(
      "file_too_large",
      `CSV file exceeds ${CSV_IMPORT_MAX_BYTES} byte limit`,
      413
    );
  }

  return {
    filename: file.filename ?? null,
    mimetype: file.mimetype ?? null,
    buffer: Buffer.concat(chunks),
    fileSha256: hash.digest("hex"),
    fileSizeBytes,
  };
}

function validateCsvFileType(file: MultipartFile): void {
  const filename = file.filename?.toLowerCase() ?? "";
  const mimetype = file.mimetype?.toLowerCase().split(";")[0]?.trim() ?? "";
  const hasCsvFilename = filename.endsWith(".csv");
  const hasCsvLikeMime = TEXT_CSV_LIKE_MIMETYPES.has(mimetype);

  if (!hasCsvFilename && !hasCsvLikeMime) {
    throw new CatalogImportValidationError(
      "invalid_file_type",
      "Upload must be a .csv file or use a text/csv-like content type"
    );
  }
}

const PRODUCT_SORT_FIELDS = new Set<CatalogProductSortBy>([
  "sku",
  "name",
  "dvgPurchaseEur",
  "dvgPurchaseHuf",
  "dvgWooNet",
  "dvgProfitHuf",
  "dvgProfitPercent",
  "dvgUpdated",
  "dvgStatus",
  "suggestedArticle",
  "suffix",
  "type",
  "regularPrice",
  "salePrice",
  "stock",
  "lastSeen",
]);

function parseProductListFilters(
  query: ListQuery,
  limit: number,
  offset: number
): CatalogProductListFilters {
  return {
    limit,
    offset,
    search: readOptionalText(query.search),
    sortBy: readSortBy(query.sortBy),
    sortDirection: query.sortDirection === "asc" ? "asc" : "desc",
    eurHufRate: parseOptionalNumber(query.eurHufRate, 100, 1000, "eurHufRate"),
    vatPercent: parseOptionalNumber(query.vatPercent, 0, 50, "vatPercent"),
    supplierId: readSupplierIdFilter(query.supplierId),
    articleStructure:
      query.articleStructure === "single" || query.articleStructure === "multiple"
        ? query.articleStructure
        : undefined,
    worklistView: query.worklistView === "attention" ? "attention" : undefined,
    profitBandMode: readProfitBandMode(query.profitBandMode),
    profitBandMinPercent: parseOptionalNumber(
      query.profitBandMinPercent,
      -1000,
      10000,
      "profitBandMinPercent"
    ),
    profitBandMaxPercent: parseOptionalNumber(
      query.profitBandMaxPercent,
      -1000,
      10000,
      "profitBandMaxPercent"
    ),
    calculability: readCalculability(query.calculability),
    minProfitPercent: parseOptionalNumber(query.minProfitPercent, -1000, 10000, "minProfitPercent"),
    maxProfitPercent: parseOptionalNumber(query.maxProfitPercent, -1000, 10000, "maxProfitPercent"),
    minProfitHuf: parseOptionalNumber(query.minProfitHuf, -100000000, 100000000, "minProfitHuf"),
    maxProfitHuf: parseOptionalNumber(query.maxProfitHuf, -100000000, 100000000, "maxProfitHuf"),
    minDvgPurchaseHuf: parseOptionalNumber(
      query.minDvgPurchaseHuf,
      0,
      100000000,
      "minDvgPurchaseHuf"
    ),
    maxDvgPurchaseHuf: parseOptionalNumber(
      query.maxDvgPurchaseHuf,
      0,
      100000000,
      "maxDvgPurchaseHuf"
    ),
    minWooNetHuf: parseOptionalNumber(query.minWooNetHuf, 0, 100000000, "minWooNetHuf"),
    maxWooNetHuf: parseOptionalNumber(query.maxWooNetHuf, 0, 100000000, "maxWooNetHuf"),
    minRegularPrice: parseOptionalNumber(query.minRegularPrice, 0, 100000000, "minRegularPrice"),
    maxRegularPrice: parseOptionalNumber(query.maxRegularPrice, 0, 100000000, "maxRegularPrice"),
    hasDvgPrice:
      query.hasDvgPrice === "yes" || query.hasDvgPrice === "no" ? query.hasDvgPrice : undefined,
    unifiedStatus: readUnifiedStatusFilter(query.unifiedStatus),
  };
}

const UNIFIED_STATUS_FILTERS = new Set([
  "not_ok",
  "ok",
  "no_product_page",
  "missing_price",
  "article_changed",
  "unavailable",
  "not_supplier_own_article",
  "ambiguous_match",
  "login_required",
  "timeout",
  "safety_stopped",
  "failed",
  "skipped",
  "no_run",
]);

const PROFIT_BAND_MODES = new Set(["inside", "outside", "below", "above"]);

function readProfitBandMode(value: string | undefined) {
  return value && PROFIT_BAND_MODES.has(value)
    ? (value as "inside" | "outside" | "below" | "above")
    : undefined;
}

function readCalculability(value: string | undefined) {
  return value === "calculable" || value === "not_calculable" ? value : undefined;
}

function readUnifiedStatusFilter(value: string | undefined): UnifiedStatusFilter | undefined {
  return value && UNIFIED_STATUS_FILTERS.has(value) ? (value as UnifiedStatusFilter) : undefined;
}

function readSupplierIdFilter(value: string | undefined): string | "none" | undefined {
  const trimmed = value?.trim();
  if (!trimmed) return undefined;
  if (trimmed === "none") return "none";
  validateUuid(trimmed, "supplierId");
  return trimmed;
}

export function parseCatalogProductUpdateInput(body: unknown): CatalogProductUpdateInput {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw new CatalogImportValidationError(
      "invalid_product_update",
      "Product update body must be an object"
    );
  }

  const record = body as Record<string, unknown>;
  const input: CatalogProductUpdateInput = {};

  readRequiredTextPatch(record, input, "sku", 120);
  readRequiredTextPatch(record, input, "name", 500);
  readNullableTextPatch(record, input, "barcodeOrGlobalId", 120);
  readNullableTextPatch(record, input, "suggestedSupplierArticle", 160);
  readNullableTextPatch(record, input, "internalSkuSuffix", 160);
  readNullableTextPatch(record, input, "type", 80);
  readNullableTextPatch(record, input, "stockStatus", 80);
  readNullableTextPatch(record, input, "dvgSupplierArticleNumber", 160);
  readNullableTextPatch(record, input, "lfSupplierArticleNumber", 160);
  readNullableDecimalPatch(record, input, "regularPrice", 0, 100000000);
  readNullableDecimalPatch(record, input, "salePrice", 0, 100000000);
  readNullableDecimalPatch(record, input, "currentPrice", 0, 100000000);
  readNullableDecimalPatch(record, input, "stockQuantity", -1000000, 1000000);
  readNullableDecimalPatch(record, input, "dvgPurchasePriceEur", 0, 100000000);
  readNullableDecimalPatch(record, input, "dvgPurchasePriceHuf", 0, 100000000);
  readNullableDecimalPatch(record, input, "dvgWooGrossHuf", 0, 100000000);
  readNullableDecimalPatch(record, input, "dvgWooNetHuf", 0, 100000000);
  readNullableDecimalPatch(record, input, "dvgProfitNetHuf", -100000000, 100000000);
  readNullableDecimalPatch(record, input, "dvgProfitPercent", -10000, 10000);
  readNullableDecimalPatch(record, input, "lfPurchasePriceEur", 0, 100000000);
  readNullableDecimalPatch(record, input, "lfPurchasePriceHuf", 0, 100000000);
  readNullableDecimalPatch(record, input, "lfWooGrossHuf", 0, 100000000);
  readNullableDecimalPatch(record, input, "lfWooNetHuf", 0, 100000000);
  readNullableDecimalPatch(record, input, "lfProfitNetHuf", -100000000, 100000000);
  readNullableDecimalPatch(record, input, "lfProfitPercent", -10000, 10000);

  if (Object.keys(input).length === 0) {
    throw new CatalogImportValidationError(
      "invalid_product_update",
      "Product update must contain at least one editable field"
    );
  }

  return input;
}

function readRequiredTextPatch<K extends keyof CatalogProductUpdateInput>(
  record: Record<string, unknown>,
  input: CatalogProductUpdateInput,
  key: K,
  maxLength: number
): void {
  if (!(key in record)) return;
  const value = record[key];
  if (typeof value !== "string") {
    throw new CatalogImportValidationError("invalid_product_update", `${String(key)} must be text`);
  }
  const trimmed = value.trim();
  if (!trimmed) {
    throw new CatalogImportValidationError(
      "invalid_product_update",
      `${String(key)} cannot be empty`
    );
  }
  if (trimmed.length > maxLength) {
    throw new CatalogImportValidationError("invalid_product_update", `${String(key)} is too long`);
  }
  input[key] = trimmed as never;
}

function readNullableTextPatch<K extends keyof CatalogProductUpdateInput>(
  record: Record<string, unknown>,
  input: CatalogProductUpdateInput,
  key: K,
  maxLength: number
): void {
  if (!(key in record)) return;
  const value = record[key];
  if (value === null) {
    input[key] = null as never;
    return;
  }
  if (typeof value !== "string") {
    throw new CatalogImportValidationError("invalid_product_update", `${String(key)} must be text`);
  }
  const trimmed = value.trim();
  if (trimmed.length > maxLength) {
    throw new CatalogImportValidationError("invalid_product_update", `${String(key)} is too long`);
  }
  input[key] = (trimmed || null) as never;
}

function readNullableDecimalPatch<K extends keyof CatalogProductUpdateInput>(
  record: Record<string, unknown>,
  input: CatalogProductUpdateInput,
  key: K,
  min: number,
  max: number
): void {
  if (!(key in record)) return;
  const value = record[key];
  if (value === null || value === "") {
    input[key] = null as never;
    return;
  }
  if (typeof value !== "string" && typeof value !== "number") {
    throw new CatalogImportValidationError(
      "invalid_product_update",
      `${String(key)} must be a number`
    );
  }
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new CatalogImportValidationError(
      "invalid_product_update",
      `${String(key)} must be a number between ${min} and ${max}`
    );
  }
  input[key] = String(parsed) as never;
}

function readSortBy(value: string | undefined): CatalogProductSortBy | undefined {
  return value && PRODUCT_SORT_FIELDS.has(value as CatalogProductSortBy)
    ? (value as CatalogProductSortBy)
    : undefined;
}

function readOptionalText(value: string | undefined): string | undefined {
  const trimmed = value?.trim();
  return trimmed ? trimmed : undefined;
}

function parseOptionalNumber(
  value: string | undefined,
  min: number,
  max: number,
  field: string
): number | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new CatalogImportValidationError(
      "invalid_query",
      `${field} must be a number between ${min} and ${max}`
    );
  }
  return parsed;
}

function parseBoundedInteger(
  value: string | undefined,
  defaultValue: number,
  maxValue: number,
  fieldName: string
): number {
  if (value === undefined || value.trim().length === 0) {
    return defaultValue;
  }

  const parsed = Number(value);

  if (!Number.isInteger(parsed) || parsed < 0 || parsed > maxValue) {
    throw new CatalogImportValidationError(
      "invalid_query",
      `${fieldName} must be an integer between 0 and ${maxValue}`
    );
  }

  return parsed;
}

function validateUuid(value: string, fieldName: string): void {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)) {
    throw new CatalogImportValidationError("invalid_id", `${fieldName} must be a UUID`);
  }
}

function handleRouteError(server: FastifyInstance, reply: FastifyReply, error: unknown) {
  if (error instanceof CatalogImportValidationError) {
    return reply.code(error.httpStatus).send({
      error: {
        code: error.code,
        message: error.message,
      },
    });
  }

  if (isMultipartTooLargeError(error)) {
    return reply.code(413).send({
      error: {
        code: "file_too_large",
        message: `CSV file exceeds ${CSV_IMPORT_MAX_BYTES} byte limit`,
      },
    });
  }

  if (isMultipartMissingFileError(error)) {
    return reply.code(400).send({
      error: {
        code: "missing_file",
        message: "Multipart field 'file' is required",
      },
    });
  }

  if (error instanceof CatalogImportDatabaseError || isDatabaseLikeError(error)) {
    server.log.error(error);
    return reply.code(503).send({
      error: {
        code: "database_unavailable",
        message: "Database unavailable for catalog import API",
      },
    });
  }

  if (isUniqueViolation(error)) {
    return reply.code(409).send({
      error: {
        code: "catalog_product_sku_exists",
        message: "Catalog product SKU already exists",
      },
    });
  }

  server.log.error(error);
  return reply.code(500).send({
    error: {
      code: "internal_error",
      message: "Catalog import request failed",
    },
  });
}

function omitRawRow<T extends { rawRow?: unknown }>(value: T): Omit<T, "rawRow"> {
  const { rawRow: _rawRow, ...safeValue } = value;
  return safeValue;
}

function isUniqueViolation(error: unknown): boolean {
  return Boolean(
    error && typeof error === "object" && (error as { code?: string }).code === "23505"
  );
}

function isMultipartTooLargeError(error: unknown): boolean {
  if (!(error instanceof Error)) {
    return false;
  }

  const code = (error as Error & { code?: string }).code;
  return code === "FST_REQ_FILE_TOO_LARGE";
}

function isMultipartMissingFileError(error: unknown): boolean {
  if (!(error instanceof Error)) {
    return false;
  }

  const code = (error as Error & { code?: string }).code;
  return code === "FST_INVALID_MULTIPART_CONTENT_TYPE";
}

function isDatabaseLikeError(error: unknown): boolean {
  if (!(error instanceof Error)) {
    return false;
  }

  const code = (error as Error & { code?: string }).code;
  return (
    code === "ECONNREFUSED" ||
    code === "ENOTFOUND" ||
    code === "ETIMEDOUT" ||
    error.message.includes("DATABASE_URL") ||
    error.message.toLowerCase().includes("database")
  );
}
