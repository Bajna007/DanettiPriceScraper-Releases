import { DVG_CONNECTOR_ID, LF_CONNECTOR_ID } from "@danetti/connectors";
import {
  catalogProducts,
  exchangeRates,
  supplierPriceSnapshots,
  suppliers,
  type DanettiDatabase,
} from "@danetti/db";
import { and, desc, eq, isNotNull, lte, or, sql } from "drizzle-orm";

export type SupplierPriceChangeSupplierScope = "all" | "dvg" | "lf";

export interface SupplierPriceChangeSnapshotRow {
  snapshotId: string;
  supplierId: string;
  supplierName: string | null;
  supplierMappingId: string | null;
  catalogProductId: string;
  sku: string;
  productName: string;
  supplierArticleNumber: string;
  priceNetEur: string | number | null;
  observedAt: Date;
  createdAt: Date;
  currentPrice: string | number | null;
  salePrice: string | number | null;
  regularPrice: string | number | null;
}

export interface SupplierPriceChangesRepositoryLike {
  getLatestEurHufRate(): Promise<number | null>;
  listRecentCatalogSnapshots(
    limit: number,
    supplierScope: SupplierPriceChangeSupplierScope
  ): Promise<SupplierPriceChangeSnapshotRow[]>;
}

export class SupplierPriceChangesRepository implements SupplierPriceChangesRepositoryLike {
  constructor(private readonly db: DanettiDatabase) {}

  async getLatestEurHufRate(): Promise<number | null> {
    const [rate] = await this.db
      .select({ eurHufRate: exchangeRates.eurHufRate })
      .from(exchangeRates)
      .orderBy(desc(exchangeRates.effectiveAt), desc(exchangeRates.createdAt))
      .limit(1);
    return numberOrNull(rate?.eurHufRate);
  }

  async listRecentCatalogSnapshots(
    _limit: number,
    supplierScope: SupplierPriceChangeSupplierScope
  ): Promise<SupplierPriceChangeSnapshotRow[]> {
    const supplierCode = readSupplierCodeFilter(supplierScope);
    const snapshotFilters = supplierCode
      ? and(
          isNotNull(supplierPriceSnapshots.priceNetEur),
          eq(supplierPriceSnapshots.currency, "EUR"),
          eq(suppliers.code, supplierCode)
        )
      : and(
          isNotNull(supplierPriceSnapshots.priceNetEur),
          eq(supplierPriceSnapshots.currency, "EUR")
        );

    // Search the complete history before returning at most three candidates per
    // identity. Keep the newest occurrence of each price and the second observation
    // so unchanged history is distinguishable from a single baseline observation.
    // The legacy raw scan limit must not hide older changes.
    const identity = sql`${supplierPriceSnapshots.catalogProductId},
      ${supplierPriceSnapshots.supplierId}, ${supplierPriceSnapshots.supplierMappingId},
      ${supplierPriceSnapshots.supplierArticleNumber}`;
    const newestFirst = sql`${supplierPriceSnapshots.observedAt} desc,
      ${supplierPriceSnapshots.createdAt} desc, ${supplierPriceSnapshots.id} desc`;
    const distinctPrices = this.db
      .select({
        snapshotId: sql<string>`${supplierPriceSnapshots.id}`.as("snapshot_id"),
        supplierId: supplierPriceSnapshots.supplierId,
        supplierName: sql<string | null>`${suppliers.name}`.as("supplier_name"),
        supplierMappingId: supplierPriceSnapshots.supplierMappingId,
        catalogProductId: sql<string>`${catalogProducts.id}`.as("catalog_product_id"),
        sku: catalogProducts.sku,
        productName: sql<string>`${catalogProducts.name}`.as("product_name"),
        supplierArticleNumber: supplierPriceSnapshots.supplierArticleNumber,
        priceNetEur: supplierPriceSnapshots.priceNetEur,
        observedAt: supplierPriceSnapshots.observedAt,
        createdAt: supplierPriceSnapshots.createdAt,
        currentPrice: catalogProducts.currentPrice,
        salePrice: catalogProducts.salePrice,
        regularPrice: catalogProducts.regularPrice,
        priceOccurrence: sql<number>`row_number() over (
          partition by ${identity}, ${supplierPriceSnapshots.priceNetEur}
          order by ${newestFirst}
        )`.as("price_occurrence"),
        observationRank: sql<number>`row_number() over (
          partition by ${identity} order by ${newestFirst}
        )`.as("observation_rank"),
      })
      .from(supplierPriceSnapshots)
      .innerJoin(catalogProducts, eq(supplierPriceSnapshots.catalogProductId, catalogProducts.id))
      .leftJoin(suppliers, eq(supplierPriceSnapshots.supplierId, suppliers.id))
      .where(snapshotFilters)
      .as("price_observations");

    const rankedPrices = this.db
      .select({
        snapshotId: distinctPrices.snapshotId,
        supplierId: distinctPrices.supplierId,
        supplierName: distinctPrices.supplierName,
        supplierMappingId: distinctPrices.supplierMappingId,
        catalogProductId: distinctPrices.catalogProductId,
        sku: distinctPrices.sku,
        productName: distinctPrices.productName,
        supplierArticleNumber: distinctPrices.supplierArticleNumber,
        priceNetEur: distinctPrices.priceNetEur,
        observedAt: distinctPrices.observedAt,
        createdAt: distinctPrices.createdAt,
        currentPrice: distinctPrices.currentPrice,
        salePrice: distinctPrices.salePrice,
        regularPrice: distinctPrices.regularPrice,
        priceRank: sql<number>`row_number() over (
          partition by ${distinctPrices.catalogProductId}, ${distinctPrices.supplierId},
            ${distinctPrices.supplierMappingId}, ${distinctPrices.supplierArticleNumber}
          order by ${distinctPrices.observedAt} desc, ${distinctPrices.createdAt} desc,
            ${distinctPrices.snapshotId} desc
        )`.as("price_rank"),
      })
      .from(distinctPrices)
      .where(or(eq(distinctPrices.priceOccurrence, 1), eq(distinctPrices.observationRank, 2)))
      .as("ranked_prices");

    return this.db
      .select({
        snapshotId: rankedPrices.snapshotId,
        supplierId: rankedPrices.supplierId,
        supplierName: rankedPrices.supplierName,
        supplierMappingId: rankedPrices.supplierMappingId,
        catalogProductId: rankedPrices.catalogProductId,
        sku: rankedPrices.sku,
        productName: rankedPrices.productName,
        supplierArticleNumber: rankedPrices.supplierArticleNumber,
        priceNetEur: rankedPrices.priceNetEur,
        observedAt: rankedPrices.observedAt,
        createdAt: rankedPrices.createdAt,
        currentPrice: rankedPrices.currentPrice,
        salePrice: rankedPrices.salePrice,
        regularPrice: rankedPrices.regularPrice,
      })
      .from(rankedPrices)
      .where(lte(rankedPrices.priceRank, 3))
      .orderBy(
        desc(rankedPrices.observedAt),
        desc(rankedPrices.createdAt),
        desc(rankedPrices.snapshotId)
      );
  }
}

function readSupplierCodeFilter(scope: SupplierPriceChangeSupplierScope): string | null {
  if (scope === "dvg") return DVG_CONNECTOR_ID;
  if (scope === "lf") return LF_CONNECTOR_ID;
  return null;
}

function numberOrNull(value: string | number | null | undefined): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}
