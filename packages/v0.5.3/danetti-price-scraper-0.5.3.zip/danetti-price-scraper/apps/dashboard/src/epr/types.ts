export type Period = {
  id: string;
  code: string;
  startsAt: string;
  endsAt: string;
  status: string;
  accountingBasis: string | null;
  accountingEventType: string | null;
  accountingDateField: "manual" | "issueDate" | "performanceDate";
};
export type Purchase = {
  id: string;
  periodId: string;
  supplier: string;
  supplierIdentity: string | null;
  reference: string | null;
  status: string;
  accountingEventDate: string | null;
  reasonCodes: string[];
};
export type Rule = {
  id: string;
  key: string;
  version: number;
  name: string;
  supplierIdentity: string;
  supplierSku: string;
  validFrom: string;
  validTo: string | null;
  unit: string;
  applicability: string;
  source: string;
  components: { name: string; material: string; grams: string; classification: string | null }[];
};
export type Line = {
  id: string;
  description: string;
  supplierSku: string | null;
  quantity: string | null;
  unit: string | null;
  ruleVersionId: string | null;
  safeErrorCode: string | null;
  businessDocumentLineId: string;
  factors: Record<string, string> | null;
};
export type Trace = {
  normalizedQuantity: string;
  factor: string;
  totalGrams: string;
  components: { name: string; material: string; gramsPerUnit: string; grams: string }[];
};
export type Detail = {
  purchase: Purchase;
  lines: Line[];
  documents: {
    business: {
      id: string;
      documentType: string;
      invoiceNumber: string | null;
      conflict: boolean;
      data: Record<string, unknown>;
    };
    source: {
      id: string;
      filename: string;
      hash: string;
      mime: string;
      safeErrorCode: string | null;
    };
  }[];
  extractedLines: {
    id: string;
    data: {
      provenance?: { page?: number | null; documentId?: string; sourceText?: string | null };
    };
  }[];
  entries: { purchaseLineId: string; ruleVersionId: string; grams: string; trace: Trace }[];
  decisions: { id: string; action: string; reason: string; operator: string; createdAt: string }[];
  messages: {
    id: string;
    folder: string;
    internalDate: string | null;
    metadata: {
      subject?: string;
      originalEmailDocumentId?: string;
      from?: { name?: string; address?: string }[];
    };
  }[];
};
export type Summary = {
  period: Period;
  totals: Record<string, string>;
  unresolved: number;
  details: Detail[];
  closed?: boolean;
  digest?: string;
};
export type Scan = {
  id: string;
  status: string;
  progress: Record<string, number>;
  safeErrorCode: string | null;
};
export const purchaseStatus: Record<string, string> = {
  ok: "Rendben",
  review: "Teendő",
  potential: "Potenciális",
  excluded: "Kizárt",
  error: "Hiba",
};
export const periodStatus: Record<string, string> = {
  OPEN: "Nyitott",
  REVIEW_REQUIRED: "Ellenőrzés szükséges",
  READY: "Lezárható",
  CLOSED: "Lezárt",
};
