"use client";
import { useEffect, useState, type FormEvent } from "react";
import { eprError, eprRequest } from "./api";
import type { Period } from "./types";
export function ProcessingSettings() {
  const [items, setItems] = useState<Period[]>([]),
    [selected, setSelected] = useState(""),
    [policy, setPolicy] = useState<{ systemPrompt: string; extractorVersion: string } | null>(null),
    [archive, setArchive] = useState<{ documentCount: number; directory: string } | null>(null),
    [error, setError] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    Promise.all([
      eprRequest<{ items: Period[] }>("/epr/periods"),
      eprRequest<typeof policy>("/epr/processing-policy"),
      eprRequest<typeof archive>("/epr/archive/status"),
    ])
      .then(([p, s, a]) => {
        setItems(p.items);
        setSelected(p.items.find((x) => x.status !== "CLOSED")?.id ?? "");
        setPolicy(s);
        setArchive(a);
      })
      .catch((e) => setError(eprError(e)));
  }, []);
  const period = items.find((p) => p.id === selected);
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setBusy(true);
    setError("");
    try {
      const p = await eprRequest<Period>(`/epr/periods/${selected}/settings`, "PUT", {
        accountingEventType: data.get("event"),
        accountingBasis: data.get("basis"),
        accountingDateField: data.get("dateField"),
      });
      setItems((old) => old.map((x) => (x.id === p.id ? p : x)));
      setMessage("Elszámolási beállítások mentve.");
    } catch (e) {
      setError(eprError(e));
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <section className="epr-section">
        <h2>EPR elszámolási beállítások</h2>
        <p>
          Rögzítsd a jóváhagyott elszámolási eseményt és annak alapját. A rendszer nem feltételez
          jogi eseményt a levél érkezési dátumából.
        </p>
        {items.some((p) => p.status !== "CLOSED") ? (
          <form onSubmit={save} key={selected}>
            <label className="epr-field">
              Időszak
              <select value={selected} onChange={(e) => setSelected(e.target.value)}>
                {items
                  .filter((p) => p.status !== "CLOSED")
                  .map((p) => (
                    <option value={p.id} key={p.id}>
                      {p.code}
                    </option>
                  ))}
              </select>
            </label>
            <label className="epr-field">
              Elszámolási esemény
              <input
                name="event"
                defaultValue={period?.accountingEventType ?? ""}
                required
                maxLength={200}
              />
            </label>
            <label className="epr-field">
              Jóváhagyott elszámolási alap
              <textarea
                name="basis"
                defaultValue={period?.accountingBasis ?? ""}
                required
                maxLength={2000}
                rows={3}
              />
            </label>
            <label className="epr-field">
              Elszámolási dátum forrása
              <select name="dateField" defaultValue={period?.accountingDateField ?? "manual"}>
                <option value="manual">Kézi jóváhagyás beszerzésenként</option>
                <option value="issueDate">Számla kelte · ismert beszállítóknál automatikus</option>
                <option value="performanceDate">
                  Teljesítés dátuma · ismert beszállítóknál automatikus
                </option>
              </select>
            </label>
            <p>
              Az automatikus dátumforrást csak a jóváhagyott elszámolási alap szerint válaszd.
              Hiányzó dátum, ismeretlen beszállító, jóváírás vagy dokumentumütközés esetén kézi
              ellenőrzés szükséges.
            </p>
            <button className="button" disabled={busy}>
              Mentés
            </button>
          </form>
        ) : (
          <p>Először hozz létre egy nyitott időszakot az EPR-oldalon.</p>
        )}
        {error ? (
          <p role="alert" className="epr-error">
            {error}
          </p>
        ) : null}
        {message ? <p role="status">{message}</p> : null}
      </section>
      <section className="epr-section">
        <h2>Adattárolás és AI feldolgozás</h2>
        {archive ? (
          <p>
            Indexelt dokumentumok: {archive.documentCount} · Archívum:{" "}
            <span className="epr-storage-path">{archive.directory}</span>
          </p>
        ) : null}
        <p>
          A dokumentumarchívum a Windows-felhasználó helyi Danetti adatkönyvtárában található. A
          bizonylatok megmaradnak a mailbox vagy az AI-kapcsolat leválasztása után is. A
          helyreállításhoz az adatbázis és a dokumentumarchívum együtt szükséges; a titkokat a gépen
          újra kell csatlakoztatni.
        </p>
        <p>
          AI csak az adott dokumentum szükséges tartalmát kapja meg. Mennyiség, egységátváltás,
          anyagsúly és EPR-besorolás jóváhagyása az operátor feladata.
        </p>
        <details>
          <summary>
            Dokumentumfeldolgozási system prompt · {policy?.extractorVersion ?? "betöltés"}
          </summary>
          <pre className="epr-prompt">{policy?.systemPrompt}</pre>
        </details>
      </section>
    </>
  );
}
