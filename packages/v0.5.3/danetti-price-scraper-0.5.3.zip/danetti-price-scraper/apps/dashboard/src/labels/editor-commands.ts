import {
  ptToMm,
  scaleArtworkNode,
  isBeanOnInfoText,
  INFO_TYPOGRAPHY_KEYS,
  isLabelBodyText,
  setLabelInk,
  setLabelBodySize,
  isLabelBodySizeText,
  isRiccaComposition,
  type LabelNode,
  type LabelScene,
  type LineNode,
  type SceneColor,
  type TextNode,
} from "@danetti/label-engine/browser";

export const BACKGROUND_LAYER_ID = "__label-background__";
export function expandSelectionIds(scene: LabelScene, ids: string[]): string[] {
  const selected = new Set(ids);
  for (let count = -1; count !== selected.size; ) {
    count = selected.size;
    for (const node of scene.nodes)
      if (node.type === "group" && selected.has(node.id))
        for (const child of node.childIds) selected.add(child);
  }
  return [...selected];
}

export function backgroundLayer(scene: LabelScene): LabelNode {
  return {
    id: BACKGROUND_LAYER_ID,
    name: "Háttér",
    type: "rect",
    x: 0,
    y: 0,
    width: scene.widthMm,
    height: scene.heightMm,
    rotation: 0,
    opacity: 1,
    visible: true,
    locked: false,
    fill: scene.background,
  };
}

function editableText(node: TextNode, value: string): TextNode {
  return {
    ...node,
    wrap: true,
    height: node.wrap
      ? node.height
      : Math.max(
          node.height,
          ptToMm(
            node.fontSizePt * (1.4 + Math.max(0, value.split(/\r?\n/).length - 1) * node.lineHeight)
          ) * (node.scaleY ?? 1)
        ),
  };
}

export function updateText(scene: LabelScene, id: string, value: string): LabelScene {
  const node = scene.nodes.find((item) => item.id === id);
  if (!node || node.type !== "text") return scene;
  if (node.binding?.property === "text") return updateTextField(scene, node.binding.field, value);
  return {
    ...scene,
    nodes: scene.nodes.map((item) =>
      item.id === id ? { ...editableText(node, value), text: value } : item
    ),
  };
}

export function updateTextField(scene: LabelScene, field: string, value: string): LabelScene {
  return {
    ...scene,
    fields: { ...scene.fields, [field]: value },
    nodes: scene.nodes.map((node) =>
      node.type === "text" && node.binding?.property === "text" && node.binding.field === field
        ? editableText(node, value)
        : node
    ),
  };
}

export type SeparatorLineStyle = "solid" | "dotted" | "dashed";
export type ResizeHandle = "n" | "ne" | "e" | "se" | "s" | "sw" | "w" | "nw";

const WHITE: SceneColor = { rgb: "#FFFFFF", cmyk: { c: 0, m: 0, y: 0, k: 0 } };
const ROAST_DATE_BOX_DEFAULTS: Record<
  LabelScene["brand"],
  Pick<LabelNode, "x" | "y" | "width" | "height">
> = {
  custom: { x: 0, y: 0, width: 30, height: 8 },
  utopia: { x: 50.907, y: 27.912, width: 47.128, height: 5.62 },
  bean_on: { x: 61, y: 27.4, width: 51.6, height: 7.4 },
};

const SEPARATOR_IDS: Record<LabelScene["brand"], readonly string[]> = {
  custom: [],
  utopia: ["brand-divider", "footer-line", "weight-line", "date-divider"],
  bean_on: ["main-divider", "footer-line", "lower-divider", "weight-line", "date-divider"],
};

const SEPARATOR_DASH: Record<SeparatorLineStyle, number[] | undefined> = {
  solid: undefined,
  dotted: [0.01, 0.75],
  dashed: [1.4, 0.8],
};

export function updateNode(scene: LabelScene, id: string, patch: Partial<LabelNode>): LabelScene {
  const target = scene.nodes.find((node) => node.id === id);
  if (
    scene.brand === "bean_on" &&
    "fontSizePt" in patch &&
    typeof patch.fontSizePt === "number" &&
    target &&
    !isRiccaComposition(scene, target) &&
    (isLabelBodySizeText(target) ||
      (target.type === "group" &&
        scene.nodes.some((node) => target.childIds.includes(node.id) && isLabelBodySizeText(node))))
  )
    scene = setLabelBodySize(scene, patch.fontSizePt);
  if (
    patch.fill &&
    target &&
    (isLabelBodyText(target, scene.brand) ||
      (target.type === "group" &&
        scene.nodes.some(
          (node) => target.childIds.includes(node.id) && isLabelBodyText(node, scene.brand)
        )))
  )
    scene = setLabelInk(scene, patch.fill);
  if (target?.type === "group") {
    const updated = { ...target, ...patch };
    const sx = updated.width / Math.max(target.width, 0.001),
      sy = updated.height / Math.max(target.height, 0.001);
    const shared = Object.fromEntries(
      [...INFO_TYPOGRAPHY_KEYS, "fill", "stroke", "opacity", "visible", "locked"]
        .filter((key) => key in patch)
        .map((key) => [key, (patch as unknown as Record<string, unknown>)[key]])
    );
    const descendants = new Set(expandSelectionIds(scene, target.childIds));
    return {
      ...scene,
      nodes: scene.nodes.map((node) =>
        node.id === id
          ? (updated as LabelNode)
          : descendants.has(node.id)
            ? ({
                ...scaleArtworkNode(node, sx, sy),
                ...shared,
                x: round(updated.x + (node.x - target.x) * sx),
                y: round(updated.y + (node.y - target.y) * sy),
                width: round(node.width * sx),
                height: round(node.height * sy),
                ...(node.type === "line"
                  ? {
                      x2: round(updated.x + (node.x2 - target.x) * sx),
                      y2: round(updated.y + (node.y2 - target.y) * sy),
                    }
                  : {}),
                ...(node.type === "text"
                  ? { maxWidth: round(node.maxWidth * sx), wrap: true, referenceText: undefined }
                  : {}),
              } as LabelNode)
            : node
      ),
    };
  }
  const colour =
    id === "qr-product" ? patch.fill : isSeparatorNode(scene, id) ? patch.stroke : undefined;
  const source = colour ? updateSeparatorStyle(scene, { stroke: colour }) : scene;
  const sharedTypography =
    scene.brand === "bean_on" &&
    scene.nodes.some((node) => node.id === id && isBeanOnInfoText(node))
      ? Object.fromEntries(
          INFO_TYPOGRAPHY_KEYS.filter((key) => key in patch).map((key) => [
            key,
            (patch as Partial<TextNode>)[key],
          ])
        )
      : {};
  return {
    ...source,
    nodes: source.nodes.map((node) =>
      node.id === id
        ? ({
            ...node,
            ...(patch.width !== undefined || patch.height !== undefined
              ? scaleArtworkNode(
                  node,
                  (patch.width ?? node.width) / Math.max(node.width, 0.001),
                  (patch.height ?? node.height) / Math.max(node.height, 0.001)
                )
              : {}),
            x: node.x,
            y: node.y,
            ...(node.type === "line" &&
            (patch.width !== undefined ||
              patch.height !== undefined ||
              patch.x !== undefined ||
              patch.y !== undefined)
              ? {
                  x2:
                    (patch.x ?? node.x) +
                    (node.x2 - node.x) *
                      ((patch.width ?? node.width) / Math.max(node.width, 0.001)),
                  y2:
                    (patch.y ?? node.y) +
                    (node.y2 - node.y) *
                      ((patch.height ?? node.height) / Math.max(node.height, 0.001)),
                }
              : {}),
            ...(node.type === "text" ? { fontSizePt: node.fontSizePt } : {}),
            ...(node.type === "text" &&
            [
              "width",
              "height",
              "maxWidth",
              "fontSizePt",
              "trackingPt",
              "fontAssetId",
              "fontFamily",
              "lineHeight",
              "scaleX",
              "scaleY",
            ].some((key) => key in patch)
              ? { referenceText: undefined }
              : {}),
            ...(node.type === "text" &&
            !("wrap" in patch) &&
            (patch.width !== undefined || patch.height !== undefined || "maxWidth" in patch)
              ? { wrap: true, maxWidth: patch.width ?? node.width }
              : {}),
            ...patch,
          } as LabelNode)
        : source.brand === "bean_on" && isBeanOnInfoText(node)
          ? ({ ...node, ...sharedTypography } as TextNode)
          : node
    ),
  };
}
export function updateNodes(
  scene: LabelScene,
  ids: string[],
  patch: (node: LabelNode) => Partial<LabelNode>
): LabelScene {
  const selected = new Set(expandSelectionIds(scene, ids));
  return {
    ...scene,
    nodes: scene.nodes.map((node) =>
      selected.has(node.id) ? ({ ...node, ...patch(node) } as LabelNode) : node
    ),
  };
}

export function separatorNodes(scene: LabelScene): LineNode[] {
  const ids = new Set(SEPARATOR_IDS[scene.brand]);
  return scene.nodes.filter(
    (node): node is LineNode =>
      node.type === "line" && (ids.has(node.id) || node.id.startsWith("line-"))
  );
}

export function isSeparatorNode(scene: LabelScene, nodeId: string): boolean {
  return SEPARATOR_IDS[scene.brand].includes(nodeId) || nodeId.startsWith("line-");
}

export function separatorLineStyle(node: LineNode): SeparatorLineStyle {
  if (!node.dash?.length) return "solid";
  return (node.dash[0] ?? 1) <= 0.05 ? "dotted" : "dashed";
}

export function updateSeparatorStyle(
  scene: LabelScene,
  patch: { stroke?: SceneColor; strokeWidth?: number; style?: SeparatorLineStyle }
): LabelScene {
  if (patch.stroke) scene = setLabelInk(scene, patch.stroke);
  const ids = new Set(SEPARATOR_IDS[scene.brand]);
  return {
    ...scene,
    nodes: scene.nodes.map((node) => {
      if (node.id === "qr-product" && node.type === "path" && patch.stroke)
        return { ...node, fill: structuredClone(patch.stroke) };
      if (node.type !== "line" || (!ids.has(node.id) && !node.id.startsWith("line-"))) return node;
      return {
        ...node,
        // Structural separator lines are stroke-only.  Clearing a stale fill
        // also repairs scenes saved by the pre-1.0 colour editor.
        fill: undefined,
        ...(patch.stroke ? { stroke: structuredClone(patch.stroke) } : {}),
        ...(patch.strokeWidth !== undefined ? { strokeWidth: patch.strokeWidth } : {}),
        ...(patch.style ? { dash: SEPARATOR_DASH[patch.style] } : {}),
      };
    }),
  };
}

export function updateNodeVisibilityField(
  scene: LabelScene,
  nodeId: string,
  field: string,
  visible: boolean
): LabelScene {
  return {
    ...scene,
    fields: { ...scene.fields, [field]: visible },
    nodes: scene.nodes.map((node) =>
      node.id === nodeId
        ? { ...node, visible: true, binding: { field, property: "visible" as const } }
        : node
    ),
  };
}

export function updateRoastDateBoxVisibility(scene: LabelScene, visible: boolean): LabelScene {
  const next = updateNodeVisibilityField(scene, "date-field", "showRoastDateBox", visible);
  if (!visible) return next;
  const geometry = ROAST_DATE_BOX_DEFAULTS[scene.brand];
  return updateNode(next, "date-field", {
    ...geometry,
    fill: structuredClone(WHITE),
    stroke: undefined,
    strokeWidth: 0,
    opacity: 1,
    rotation: 0,
    radius: 0,
  } as Partial<LabelNode>);
}

export function resizeNodeFromHandle(
  scene: LabelScene,
  nodeId: string,
  handle: ResizeHandle,
  dx: number,
  dy: number
): LabelScene {
  const node = scene.nodes.find((item) => item.id === nodeId);
  if (!node) return scene;
  const radians = (node.rotation * Math.PI) / 180;
  const cosine = Math.cos(radians),
    sine = Math.sin(radians);
  [dx, dy] = [dx * cosine + dy * sine, dy * cosine - dx * sine];
  const minSize = 0.5;
  let x = node.x;
  let y = node.y;
  let width = node.width;
  let height = node.height;

  if (handle.includes("e")) width = Math.max(minSize, node.width + dx);
  if (handle.includes("s")) height = Math.max(minSize, node.height + dy);
  if (handle.includes("w")) {
    x = Math.min(node.x + dx, node.x + node.width - minSize);
    width = node.width - (x - node.x);
  }
  if (handle.includes("n")) {
    y = Math.min(node.y + dy, node.y + node.height - minSize);
    height = node.height - (y - node.y);
  }

  const centerX = node.x + node.width / 2,
    centerY = node.y + node.height / 2;
  const shiftX = x + width / 2 - centerX,
    shiftY = y + height / 2 - centerY;
  x = centerX + shiftX * cosine - shiftY * sine - width / 2;
  y = centerY + shiftX * sine + shiftY * cosine - height / 2;

  return updateNode(scene, nodeId, {
    x: round(x),
    y: round(y),
    width: round(width),
    height: round(height),
    ...(node.type === "text" ? { maxWidth: round(width) } : {}),
  } as Partial<LabelNode>);
}

export function isNodeVisible(scene: LabelScene, node: LabelNode): boolean {
  return node.binding?.property === "visible"
    ? Boolean(scene.fields[node.binding.field])
    : node.visible;
}
export function moveNodes(scene: LabelScene, ids: string[], dx: number, dy: number): LabelScene {
  return updateNodes(scene, ids, (node) => ({
    x: round(node.x + dx),
    y: round(node.y + dy),
    ...(node.type === "line" ? { x2: round(node.x2 + dx), y2: round(node.y2 + dy) } : {}),
  }));
}
export function removeNodes(scene: LabelScene, ids: string[]): LabelScene {
  const removed = new Set(expandSelectionIds(scene, ids));
  return {
    ...scene,
    nodes: scene.nodes
      .filter((node) => !removed.has(node.id) && (!node.parentId || !removed.has(node.parentId)))
      .map((node) =>
        node.type === "group"
          ? { ...node, childIds: node.childIds.filter((id) => !removed.has(id)) }
          : node
      ),
  };
}
export function duplicateNodes(
  scene: LabelScene,
  ids: string[]
): { scene: LabelScene; ids: string[] } {
  const expanded = new Set(expandSelectionIds(scene, ids));
  const selected = scene.nodes.filter((node) => expanded.has(node.id));
  const copyIds = new Map(
    selected.map((node, index) => [node.id, `${node.id}-copy-${Date.now()}-${index}`])
  );
  const copies = selected.map(
    (node, index) =>
      ({
        ...structuredClone(node),
        id: copyIds.get(node.id)!,
        name: `${node.name} másolat`,
        x: round(node.x + 1),
        y: round(node.y + 1),
        ...(node.type === "line" ? { x2: round(node.x2 + 1), y2: round(node.y2 + 1) } : {}),
        parentId: node.parentId ? copyIds.get(node.parentId) : undefined,
        ...(node.type === "group"
          ? { childIds: node.childIds.map((id) => copyIds.get(id)!).filter(Boolean) }
          : {}),
      }) as LabelNode
  );
  return {
    scene: { ...scene, nodes: [...scene.nodes, ...copies] },
    ids: ids.map((id) => copyIds.get(id)!).filter(Boolean),
  };
}
export function reorderNode(scene: LabelScene, activeId: string, overId: string): LabelScene {
  const from = scene.nodes.findIndex((node) => node.id === activeId);
  const to = scene.nodes.findIndex((node) => node.id === overId);
  if (from < 0 || to < 0 || from === to) return scene;
  const nodes = [...scene.nodes];
  const [node] = nodes.splice(from, 1);
  nodes.splice(to, 0, node!);
  return { ...scene, nodes };
}
export function bring(
  scene: LabelScene,
  ids: string[],
  direction: "front" | "back" | "forward" | "backward"
): LabelScene {
  const selected = new Set(expandSelectionIds(scene, ids));
  const nodes = [...scene.nodes];
  if (direction === "front")
    return {
      ...scene,
      nodes: [
        ...nodes.filter((node) => !selected.has(node.id)),
        ...nodes.filter((node) => selected.has(node.id)),
      ],
    };
  if (direction === "back")
    return {
      ...scene,
      nodes: [
        ...nodes.filter((node) => selected.has(node.id)),
        ...nodes.filter((node) => !selected.has(node.id)),
      ],
    };
  for (const id of direction === "forward" ? [...ids].reverse() : ids) {
    const index = nodes.findIndex((node) => node.id === id);
    const target =
      direction === "forward" ? Math.min(nodes.length - 1, index + 1) : Math.max(0, index - 1);
    if (index >= 0 && target !== index)
      [nodes[index], nodes[target]] = [nodes[target]!, nodes[index]!];
  }
  return { ...scene, nodes };
}
export function groupNodes(scene: LabelScene, ids: string[]): { scene: LabelScene; id: string } {
  const children = scene.nodes.filter((node) => ids.includes(node.id));
  const id = `group-${Date.now()}`;
  const minX = Math.min(...children.map((node) => node.x));
  const minY = Math.min(...children.map((node) => node.y));
  const maxX = Math.max(...children.map((node) => node.x + node.width));
  const maxY = Math.max(...children.map((node) => node.y + node.height));
  const group: LabelNode = {
    id,
    name: "Csoport",
    type: "group",
    x: minX,
    y: minY,
    width: maxX - minX,
    height: maxY - minY,
    rotation: 0,
    opacity: 1,
    visible: true,
    locked: false,
    childIds: ids,
  };
  return {
    id,
    scene: {
      ...scene,
      nodes: [
        ...scene.nodes.map((node) => (ids.includes(node.id) ? { ...node, parentId: id } : node)),
        group,
      ],
    },
  };
}
export function ungroupNodes(
  scene: LabelScene,
  groupId: string
): { scene: LabelScene; ids: string[] } {
  const group = scene.nodes.find((node) => node.id === groupId && node.type === "group");
  if (!group || group.type !== "group") return { scene, ids: [] };
  return {
    ids: group.childIds,
    scene: {
      ...scene,
      nodes: scene.nodes
        .filter((node) => node.id !== groupId)
        .map((node) => (node.parentId === groupId ? { ...node, parentId: undefined } : node)),
    },
  };
}
export function alignNodes(
  scene: LabelScene,
  ids: string[],
  mode: "left" | "hcenter" | "right" | "top" | "vcenter" | "bottom"
): LabelScene {
  const nodes = scene.nodes.filter((node) => ids.includes(node.id));
  if (nodes.length < 2) return scene;
  const minX = Math.min(...nodes.map((node) => node.x));
  const maxX = Math.max(...nodes.map((node) => node.x + node.width));
  const minY = Math.min(...nodes.map((node) => node.y));
  const maxY = Math.max(...nodes.map((node) => node.y + node.height));
  return updateNodes(scene, ids, (node) =>
    mode === "left"
      ? { x: minX }
      : mode === "right"
        ? { x: maxX - node.width }
        : mode === "hcenter"
          ? { x: (minX + maxX - node.width) / 2 }
          : mode === "top"
            ? { y: minY }
            : mode === "bottom"
              ? { y: maxY - node.height }
              : { y: (minY + maxY - node.height) / 2 }
  );
}
export function distributeNodes(
  scene: LabelScene,
  ids: string[],
  axis: "horizontal" | "vertical"
): LabelScene {
  const selected = scene.nodes
    .filter((node) => ids.includes(node.id))
    .sort((left, right) =>
      axis === "horizontal"
        ? left.x + left.width / 2 - (right.x + right.width / 2)
        : left.y + left.height / 2 - (right.y + right.height / 2)
    );
  if (selected.length < 3) return scene;
  const first = selected[0]!;
  const last = selected.at(-1)!;
  const start = axis === "horizontal" ? first.x + first.width / 2 : first.y + first.height / 2;
  const end = axis === "horizontal" ? last.x + last.width / 2 : last.y + last.height / 2;
  const positions = new Map(
    selected.map((node, index) => [
      node.id,
      start + ((end - start) * index) / (selected.length - 1),
    ])
  );
  return updateNodes(scene, ids, (node) =>
    axis === "horizontal"
      ? { x: round(positions.get(node.id)! - node.width / 2) }
      : { y: round(positions.get(node.id)! - node.height / 2) }
  );
}
function round(value: number): number {
  return Math.round(value * 100) / 100;
}
