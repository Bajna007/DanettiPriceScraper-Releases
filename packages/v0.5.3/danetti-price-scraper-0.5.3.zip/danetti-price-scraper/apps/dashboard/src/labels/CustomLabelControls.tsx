"use client";
import {
  resizeLabelScene,
  type LabelNode,
  type LabelScene,
  type TextNode,
} from "@danetti/label-engine/browser";
import { useEffect, useState } from "react";
import type { LabelAssetRecord } from "./labels-api";
import styles from "./LabelStudio.module.css";

export function CustomLabelControls({
  scene,
  fonts,
  onChange,
  onSelect,
}: {
  scene: LabelScene;
  fonts: LabelAssetRecord[];
  onChange: (scene: LabelScene) => void;
  onSelect: (id: string) => void;
}) {
  const [width, setWidth] = useState(String(scene.widthMm));
  const [height, setHeight] = useState(String(scene.heightMm));
  const [scaleContent, setScaleContent] = useState(true);
  useEffect(() => {
    setWidth(String(scene.widthMm));
    setHeight(String(scene.heightMm));
  }, [scene.widthMm, scene.heightMm]);
  function insert(type: "text" | "rect") {
    const id = `custom-${type}-${crypto.randomUUID()}`;
    const font =
      fonts.find((item) => item.active && item.family === "Arial" && item.weight === 400) ??
      fonts.find((item) => item.active && item.metadata.isCompleteLatinAlphabet);
    if (type === "text" && !font) return;
    const insetX = Math.min(2, scene.widthMm / 10),
      insetY = Math.min(2, scene.heightMm / 10);
    const node: LabelNode =
      type === "text"
        ? ({
            id,
            name: "Új szöveg",
            type,
            x: insetX,
            y: insetY,
            width: scene.widthMm - insetX * 2,
            height: Math.min(12, scene.heightMm - insetY * 2),
            rotation: 0,
            visible: true,
            locked: false,
            opacity: 1,
            text: "Új szöveg",
            fontAssetId: font!.id,
            fontFamily: font!.family,
            fontStyle: font!.style,
            fontWeight: font!.weight,
            fontSizePt: 12,
            trackingPt: 0,
            lineHeight: 1.2,
            align: "left",
            transform: "none",
            maxWidth: scene.widthMm - insetX * 2,
            overflow: "shrink",
            minFontSizePt: 1,
            wrap: true,
            fill: { rgb: "#000000", cmyk: { c: 0, m: 0, y: 0, k: 1 } },
          } as TextNode)
        : {
            id,
            name: "Új téglalap",
            type,
            x: insetX,
            y: insetY,
            width: Math.min(20, scene.widthMm - insetX * 2),
            height: Math.min(10, scene.heightMm - insetY * 2),
            rotation: 0,
            visible: true,
            locked: false,
            opacity: 1,
            fill: { rgb: "#255F49", cmyk: { c: 0.61, m: 0, y: 0.23, k: 0.63 } },
          };
    onChange({ ...scene, nodes: [...scene.nodes, node] });
    onSelect(id);
  }
  function download() {
    const url = URL.createObjectURL(
      new Blob([JSON.stringify(scene, null, 2)], { type: "application/json" })
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "egyedi-cimke.json";
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return (
    <section className={styles.sidePanel}>
      <h2>Egyedi címke</h2>
      <label className={styles.fieldLabel}>
        <span>Címke neve</span>
        <input
          value={scene.metadata.name}
          onChange={(event) =>
            onChange({ ...scene, metadata: { ...scene.metadata, name: event.target.value } })
          }
        />
      </label>
      <fieldset className={styles.sizeSettings}>
        <legend>Vágott méret</legend>
        <div className={styles.numericGrid}>
          <label className={styles.fieldLabel}>
            <span>Szélesség (mm)</span>
            <input
              type="number"
              min="1"
              max="1000"
              step="0.5"
              value={width}
              onChange={(event) => setWidth(event.target.value)}
            />
          </label>
          <label className={styles.fieldLabel}>
            <span>Magasság (mm)</span>
            <input
              type="number"
              min="1"
              max="1000"
              step="0.5"
              value={height}
              onChange={(event) => setHeight(event.target.value)}
            />
          </label>
        </div>
        <label className={styles.checkRow}>
          <input
            type="checkbox"
            checked={scaleContent}
            onChange={(event) => setScaleContent(event.target.checked)}
          />
          A tartalom együtt méreteződjön
        </label>
        <button
          disabled={
            ![Number(width), Number(height)].every(
              (value) => Number.isFinite(value) && value >= 1 && value <= 1000
            ) ||
            (Number(width) === scene.widthMm && Number(height) === scene.heightMm)
          }
          onClick={() =>
            onChange(resizeLabelScene(scene, Number(width), Number(height), scaleContent))
          }
        >
          Méret alkalmazása
        </button>
        <p className={styles.panelHelp}>
          A nyomdai fájl ezt a méretet használja, 2,5 mm kifutóval. Nagy címkénél a rendelési lap is
          nagyobb lesz.
        </p>
      </fieldset>
      <div className={styles.buttonRow}>
        <button onClick={() => insert("text")} disabled={!fonts.length}>
          Szöveg hozzáadása
        </button>
        <button onClick={() => insert("rect")}>Téglalap hozzáadása</button>
      </div>
      <button className={styles.secondaryWide} onClick={download}>
        Szerkeszthető címke letöltése
      </button>
      <p className={styles.panelHelp}>A JSON fájl később visszatölthető az egyedi címketárba.</p>
    </section>
  );
}
