import type { LabelScene } from "@danetti/label-engine/browser";

export type SaveStatus = "saved" | "saving" | "error" | "dirty";
export interface EditorState {
  scene: LabelScene;
  past: LabelScene[];
  future: LabelScene[];
  selectedIds: string[];
  zoom: number;
  pan: { x: number; y: number };
  grid: boolean;
  guides: boolean;
  snap: boolean;
  preview: boolean;
  saveStatus: SaveStatus;
  revision: number;
}
export type EditorAction =
  | { type: "init"; scene: LabelScene; revision: number }
  | { type: "commit"; scene: LabelScene; selectedIds?: string[]; previous?: LabelScene }
  | { type: "transient"; scene: LabelScene }
  | { type: "select"; ids: string[] }
  | { type: "undo" }
  | { type: "redo" }
  | { type: "zoom"; value: number }
  | { type: "pan"; x: number; y: number }
  | { type: "toggle"; key: "grid" | "guides" | "snap" | "preview" }
  | { type: "save"; status: SaveStatus; revision?: number; savedScene?: LabelScene };

export function createEditorState(scene: LabelScene, revision: number): EditorState {
  return {
    scene,
    past: [],
    future: [],
    selectedIds: [],
    zoom: 1,
    pan: { x: 0, y: 0 },
    grid: true,
    guides: true,
    snap: true,
    preview: false,
    saveStatus: "saved",
    revision,
  };
}
export function editorReducer(state: EditorState, action: EditorAction): EditorState {
  switch (action.type) {
    case "init":
      return {
        ...createEditorState(action.scene, action.revision),
        zoom: state.zoom,
        grid: state.grid,
        guides: state.guides,
        snap: state.snap,
      };
    case "commit": {
      const previous = action.previous ?? state.scene;
      if (JSON.stringify(previous) === JSON.stringify(action.scene))
        return { ...state, scene: action.scene };
      return {
        ...state,
        scene: action.scene,
        past: [...state.past.slice(-99), previous],
        future: [],
        selectedIds: action.selectedIds ?? state.selectedIds,
        saveStatus: "dirty",
      };
    }
    case "transient":
      return { ...state, scene: action.scene };
    case "select":
      return { ...state, selectedIds: action.ids };
    case "undo": {
      const scene = state.past.at(-1);
      if (!scene) return state;
      return {
        ...state,
        scene,
        past: state.past.slice(0, -1),
        future: [state.scene, ...state.future],
        saveStatus: "dirty",
      };
    }
    case "redo": {
      const scene = state.future[0];
      if (!scene) return state;
      return {
        ...state,
        scene,
        past: [...state.past, state.scene],
        future: state.future.slice(1),
        saveStatus: "dirty",
      };
    }
    case "zoom":
      return { ...state, zoom: Math.min(4, Math.max(0.25, action.value)) };
    case "pan":
      return { ...state, pan: { x: action.x, y: action.y } };
    case "toggle":
      return { ...state, [action.key]: !state[action.key] };
    case "save":
      return {
        ...state,
        saveStatus:
          action.status === "saved" &&
          action.savedScene &&
          JSON.stringify(state.scene) !== JSON.stringify(action.savedScene)
            ? "dirty"
            : action.status,
        revision: action.revision ?? state.revision,
      };
  }
}
