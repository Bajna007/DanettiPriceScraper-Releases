"use client";
import { useRef, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import {
  createCustomLabelScene,
  resizeLabelScene,
  type LabelScene,
} from "@danetti/label-engine/browser";
import { LabelBrandNav } from "./LabelBrandNav";
import { LabelLibrary } from "./LabelLibrary";
import { LabelStudioHistory } from "./LabelStudioHistory";
import { LabelFontLibrary } from "./LabelFontLibrary";
import { createLabel, listTemplates } from "./labels-api";
import { importCustomLabel } from "./import-custom-label";
import { useSearchParams } from "next/navigation";
import styles from "./LabelStudio.module.css";

export function CustomLabelWorkspace() {
  const router = useRouter();
  const params = useSearchParams();
  const [creating, setCreating] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const [name, setName] = useState(""),
    [width, setWidth] = useState("80"),
    [height, setHeight] = useState("40");
  const [importFailed, setImportFailed] = useState(false);
  const [source, setSource] = useState<LabelScene | null>(null),
    [filename, setFilename] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  async function importFile(file: File) {
    setBusy(true);
    setError("");
    setImportFailed(false);
    try {
      const imported = await importCustomLabel(file, Number(width), Number(height));
      setSource(imported);
      setWidth(String(imported.widthMm));
      setHeight(String(imported.heightMm));
      setFilename(file.name);
      if (!name) setName(file.name.replace(/\.(svg|json)$/i, ""));
    } catch (reason) {
      setSource(null);
      setFilename("");
      setImportFailed(true);
      setError(reason instanceof Error ? reason.message : "A fájl nem importálható.");
    } finally {
      setBusy(false);
    }
  }
  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const template = (await listTemplates("custom")).find((item) => item.code === "custom-blank");
      if (!template)
        throw new Error("Az egyedi sablon hiányzik. Indítsd újra a Danetti alkalmazást.");
      const scene = source
        ? resizeLabelScene(source, Number(width), Number(height), true)
        : createCustomLabelScene(Number(width), Number(height));
      scene.metadata.name = name.trim();
      const item = await createLabel({
        brand: "custom",
        templateId: template.id,
        name: name.trim(),
        internalCode: `EGY-${crypto.randomUUID().slice(0, 8)}`,
        scene,
      });
      router.push(`/labels/custom/${item.id}`);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "A címke nem menthető.");
      setBusy(false);
    }
  }
  const view = params.get("view");
  return (
    <div className={styles.workspace}>
      <header className={styles.workspaceHeader}>
        <div>
          <h1>Egyedi címkék</h1>
          <p>Saját grafikák és méretek. Mentsd el, szerkeszd, majd add a nyomdai rendeléshez.</p>
        </div>
        <span className={styles.brandDimension}>Szabad méret · 2,5 mm kifutó</span>
      </header>
      <LabelBrandNav
        brand="custom"
        active={view === "history" ? "history" : view === "fonts" ? "fonts" : "library"}
      />
      {view === "history" ? (
        <LabelStudioHistory brand="custom" />
      ) : view === "fonts" ? (
        <LabelFontLibrary />
      ) : (
        <>
          {creating ? (
            <form className={styles.customCreatePanel} onSubmit={(event) => void submit(event)}>
              <div className={styles.sectionHeading}>
                <div>
                  <h2>Új egyedi címke</h2>
                  <p>Indulj üres címkéből, vagy töltsd be a meglévő grafikát.</p>
                </div>
                <button type="button" onClick={() => setCreating(false)} disabled={busy}>
                  Bezárás
                </button>
              </div>
              <div className={styles.customFormGrid}>
                <label className={styles.fieldLabel}>
                  <span>Címke neve</span>
                  <input
                    required
                    autoFocus
                    value={name}
                    placeholder="Például: csomagzáró matrica"
                    onChange={(event) => setName(event.target.value)}
                  />
                </label>
                <label className={styles.fieldLabel}>
                  <span>Szélesség (mm)</span>
                  <input
                    required
                    type="number"
                    min="1"
                    max="1000"
                    step="0.5"
                    value={width}
                    onChange={(event) => setWidth(event.target.value)}
                  />
                </label>
                <label className={styles.fieldLabel}>
                  <span>Magasság (mm)</span>
                  <input
                    required
                    type="number"
                    min="1"
                    max="1000"
                    step="0.5"
                    value={height}
                    onChange={(event) => setHeight(event.target.value)}
                  />
                </label>
              </div>
              <div className={styles.customImportRow}>
                <input
                  ref={fileRef}
                  type="file"
                  accept=".svg,.json"
                  aria-label="Meglévő címke importálása"
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (file) void importFile(file);
                  }}
                  disabled={busy}
                />
                <p>
                  SVG: görbévé alakított szöveg és egyszínű vektorok. JSON: korábban elmentett,
                  szerkeszthető címke.
                </p>
              </div>
              {filename ? (
                <p className={styles.successBanner}>
                  {filename} betöltve · {source?.nodes.length} szerkeszthető elem
                </p>
              ) : null}
              {error ? (
                <p role="alert" className={styles.errorBanner}>
                  {error}
                </p>
              ) : null}
              <div className={styles.buttonRow}>
                <button
                  className={styles.primaryButton}
                  disabled={
                    busy ||
                    importFailed ||
                    !name.trim() ||
                    ![Number(width), Number(height)].every(
                      (value) => Number.isFinite(value) && value >= 1 && value <= 1000
                    )
                  }
                >
                  {busy ? "Címke előkészítése…" : "Létrehozás és szerkesztés"}
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    setSource(null);
                    setFilename("");
                    setImportFailed(false);
                    setError("");
                    if (fileRef.current) fileRef.current.value = "";
                  }}
                >
                  Üres címkéből indulok
                </button>
              </div>
            </form>
          ) : null}
          <LabelLibrary brand="custom" onNewLabel={() => setCreating(true)} />
        </>
      )}
    </div>
  );
}
