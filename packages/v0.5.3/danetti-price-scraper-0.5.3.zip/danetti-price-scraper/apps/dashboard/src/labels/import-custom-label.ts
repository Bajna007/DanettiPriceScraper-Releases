import {
  createCustomLabelScene,
  rgbToCmyk,
  transformArtworkPath,
  validateScene,
  type LabelScene,
  type PathNode,
  type SceneColor,
} from "@danetti/label-engine/browser";

const NS = "http://www.w3.org/2000/svg";
const allowedTags = new Set([
  "svg",
  "g",
  "path",
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "title",
  "desc",
  "metadata",
]);
const attributes = new Set([
  "d",
  "x",
  "y",
  "x1",
  "y1",
  "x2",
  "y2",
  "width",
  "height",
  "rx",
  "ry",
  "r",
  "cx",
  "cy",
  "points",
  "viewBox",
  "transform",
  "fill",
  "stroke",
  "stroke-width",
  "opacity",
  "fill-opacity",
  "stroke-opacity",
  "fill-rule",
  "display",
  "visibility",
  "id",
]);
const paintProperties = new Set([
  "fill",
  "stroke",
  "stroke-width",
  "opacity",
  "fill-opacity",
  "stroke-opacity",
  "fill-rule",
  "display",
  "visibility",
]);

export async function importCustomLabel(
  file: File,
  widthMm: number,
  heightMm: number
): Promise<LabelScene> {
  if (file.size > 5 * 1024 * 1024)
    throw new Error("Legfeljebb 5 MB-os SVG vagy címke-JSON tölthető be.");
  const source = await file.text();
  if (file.name.toLowerCase().endsWith(".json")) {
    const result = validateScene(JSON.parse(source));
    if (!result.scene) throw new Error(result.issues.map((issue) => issue.message).join(" "));
    return {
      ...result.scene,
      brand: "custom",
      metadata: { ...result.scene.metadata, templateCode: "custom-blank" },
    };
  }
  return importSvg(source, widthMm, heightMm);
}

/** Never mount source XML. Build a new, geometry-only SVG before measuring its paths. */
export function importSvg(source: string, widthMm: number, heightMm: number): LabelScene {
  if (/<!DOCTYPE|<!ENTITY/i.test(source))
    throw new Error("Az SVG külső hivatkozást tartalmaz. Exportáld önálló vektorként.");
  const parsed = new DOMParser().parseFromString(source, "image/svg+xml");
  if (parsed.querySelector("parsererror") || parsed.documentElement.localName !== "svg")
    throw new Error("A fájl nem érvényes SVG.");
  const holder = document.createElement("div");
  holder.style.cssText = "position:fixed;left:-10000px;top:0;opacity:0;pointer-events:none";
  const clean = document.createElementNS(NS, "svg");
  const root = parsed.documentElement;
  for (const attribute of Array.from(root.attributes)) {
    if (
      /^(clip-path|mask|filter|stroke-dasharray|stroke-linecap|stroke-linejoin|vector-effect)$|^on|href/i.test(
        attribute.name
      )
    )
      throw new Error(
        `Nem támogatott SVG beállítás: ${attribute.name}. Exportálj önálló, egyszerűsített vektort.`
      );
  }
  const viewBox = root
    .getAttribute("viewBox")
    ?.trim()
    .split(/[\s,]+/)
    .map(Number);
  const width = viewBox?.[2] ?? parseFloat(root.getAttribute("width") ?? "0");
  const height = viewBox?.[3] ?? parseFloat(root.getAttribute("height") ?? "0");
  if (![width, height, widthMm, heightMm].every((value) => Number.isFinite(value) && value > 0))
    throw new Error("Az SVG mérete hiányzik. Exportálj viewBox-szal rendelkező SVG-t.");
  clean.setAttribute(
    "viewBox",
    viewBox?.length === 4 ? viewBox.join(" ") : `0 0 ${width} ${height}`
  );
  clean.setAttribute("width", String(width));
  clean.setAttribute("height", String(height));
  let count = 0;
  const copy = (element: Element, parent: Element) => {
    const tag = element.localName;
    if (["title", "desc", "metadata"].includes(tag)) return;
    if (tag === "svg") throw new Error("Beágyazott SVG helyett exportálj egyetlen vektorgrafikát.");
    if (!allowedTags.has(tag))
      throw new Error(
        `Az SVG „${tag}” eleme nem importálható. A szövegeket alakítsd görbévé; használj egyszínű vektorokat képek, effektek és külső hivatkozások nélkül.`
      );
    if (++count > 2000)
      throw new Error("Az SVG túl sok elemet tartalmaz. Egyszerűsítsd a görbéket.");
    const node = document.createElementNS(NS, tag);
    for (const attribute of Array.from(element.attributes)) {
      if (/url\(|javascript:|data:|https?:/i.test(attribute.value) && attribute.name !== "xmlns")
        throw new Error("Az SVG külső hivatkozást vagy effektet tartalmaz.");
      if (attribute.name === "style") {
        for (const entry of attribute.value.split(";")) {
          const [key, value] = entry.split(":").map((part) => part.trim());
          if (key && value && paintProperties.has(key)) node.setAttribute(key, value);
          else if (key && !["font-family", "font-size", "font-weight"].includes(key))
            throw new Error(
              `Nem támogatott SVG stílus: ${key}. Exportálj egyszerűsített, görbévé alakított SVG-t.`
            );
        }
      } else if (attributes.has(attribute.name)) node.setAttribute(attribute.name, attribute.value);
      else if (
        /^(clip-path|mask|filter|stroke-dasharray|stroke-linecap|stroke-linejoin|vector-effect)$/i.test(
          attribute.name
        )
      )
        throw new Error(
          `Nem támogatott SVG beállítás: ${attribute.name}. Alakítsd körvonallá az effektet.`
        );
      else if (/^on|href/i.test(attribute.name))
        throw new Error("Aktív SVG tartalom nem importálható.");
    }
    parent.append(node);
    for (const child of Array.from(element.children)) copy(child, node);
  };
  // Keep inherited paint/transform from the outer SVG without its viewport attributes.
  const rootGroup = document.createElementNS(NS, "g");
  for (const key of [...paintProperties, "transform"])
    if (root.hasAttribute(key)) {
      const value = root.getAttribute(key)!;
      if (/url\(|javascript:|data:|https?:/i.test(value))
        throw new Error("Az SVG külső hivatkozást tartalmaz.");
      rootGroup.setAttribute(key, value);
    }
  if (root.hasAttribute("style")) {
    for (const entry of root.getAttribute("style")!.split(";")) {
      const [key, value] = entry.split(":").map((part) => part.trim());
      if (!key) continue;
      if (!paintProperties.has(key) || /url\(|javascript:|data:|https?:/i.test(value))
        throw new Error(`Nem támogatott SVG stílus: ${key}.`);
      rootGroup.setAttribute(key, value);
    }
  }
  clean.append(rootGroup);
  for (const child of Array.from(root.children)) copy(child, rootGroup);
  holder.append(clean);
  document.body.append(holder);
  try {
    const scene = createCustomLabelScene(widthMm, heightMm);
    for (const [index, element] of Array.from(
      clean.querySelectorAll<SVGGraphicsElement>("path,rect,circle,ellipse,line,polyline,polygon")
    ).entries()) {
      const style = getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden") continue;
      let hidden = false;
      for (
        let ancestor: Element | null = element.parentElement;
        ancestor && ancestor !== clean;
        ancestor = ancestor.parentElement
      )
        if (getComputedStyle(ancestor).display === "none") hidden = true;
      if (hidden) continue;
      const matrix = element.getCTM();
      if (!matrix) throw new Error("Az SVG geometriája nem olvasható.");
      const sx = widthMm / width,
        sy = heightMm / height;
      const transformed = transformArtworkPath(shapePath(element), [
        matrix.a * sx,
        matrix.b * sy,
        matrix.c * sx,
        matrix.d * sy,
        matrix.e * sx,
        matrix.f * sy,
      ]);
      const probe = document.createElementNS(NS, "path");
      probe.setAttribute("d", transformed);
      clean.append(probe);
      const bounds = probe.getBBox();
      probe.remove();
      if (![bounds.x, bounds.y, bounds.width, bounds.height].every(Number.isFinite))
        throw new Error("Érvénytelen SVG görbe.");
      let opacity = 1;
      for (
        let ancestor: Element | null = element;
        ancestor && ancestor !== clean;
        ancestor = ancestor.parentElement
      )
        opacity *= Number(getComputedStyle(ancestor).opacity);
      const fillOpacity = Number(style.fillOpacity),
        strokeOpacity = Number(style.strokeOpacity);
      if (style.fill !== "none" && style.stroke !== "none" && fillOpacity !== strokeOpacity)
        throw new Error(
          "Eltérő kitöltés- és körvonal-átlátszóság helyett exportálj külön görbéket."
        );
      opacity *= style.fill !== "none" ? fillOpacity : strokeOpacity;
      const node: PathNode = {
        id: `custom-artwork-${index}`,
        name: element.id || `Vektor ${index + 1}`,
        type: "path",
        x: bounds.x,
        y: bounds.y,
        width: bounds.width,
        height: bounds.height,
        rotation: 0,
        opacity,
        visible: true,
        locked: false,
        d: transformArtworkPath(transformed, [1, 0, 0, 1, -bounds.x, -bounds.y]),
        fill: solidColor(style.fill),
        stroke: solidColor(style.stroke),
        strokeWidth:
          parseFloat(style.strokeWidth) *
          Math.sqrt(Math.abs(matrix.a * matrix.d - matrix.b * matrix.c) * sx * sy),
        fillRule: style.fillRule === "evenodd" ? "evenodd" : "nonzero",
      };
      scene.nodes.push(node);
    }
    if (!scene.nodes.length) throw new Error("Az SVG nem tartalmaz látható vektoros elemet.");
    return scene;
  } finally {
    holder.remove();
  }
}

function solidColor(value: string): SceneColor | undefined {
  if (value === "none") return undefined;
  const context = document.createElement("canvas").getContext("2d")!;
  context.fillStyle = value;
  const normalized = context.fillStyle;
  if (!/^#[0-9a-f]{6}$/i.test(normalized))
    throw new Error("Csak egyszínű, átlátszatlan SVG festék importálható.");
  return { rgb: normalized, cmyk: rgbToCmyk(normalized), printSpace: "rgb" };
}
function shapePath(element: SVGGraphicsElement): string {
  const n = (key: string, fallback = 0) =>
    parseFloat(element.getAttribute(key) ?? String(fallback));
  switch (element.localName) {
    case "path":
      return element.getAttribute("d") ?? "";
    case "line":
      return `M${n("x1")} ${n("y1")}L${n("x2")} ${n("y2")}`;
    case "polyline":
    case "polygon":
      return `M${element.getAttribute("points") ?? ""}${element.localName === "polygon" ? "Z" : ""}`;
    case "circle":
    case "ellipse": {
      const x = n("cx"),
        y = n("cy"),
        rx = n("rx", n("r")),
        ry = n("ry", n("r"));
      return `M${x - rx} ${y}a${rx} ${ry} 0 1 0 ${rx * 2} 0a${rx} ${ry} 0 1 0 ${-rx * 2} 0Z`;
    }
    default: {
      const x = n("x"),
        y = n("y"),
        w = n("width"),
        h = n("height"),
        rx = Math.min(w / 2, n("rx", n("ry"))),
        ry = Math.min(h / 2, n("ry", rx));
      return rx && ry
        ? `M${x + rx} ${y}H${x + w - rx}A${rx} ${ry} 0 0 1 ${x + w} ${y + ry}V${y + h - ry}A${rx} ${ry} 0 0 1 ${x + w - rx} ${y + h}H${x + rx}A${rx} ${ry} 0 0 1 ${x} ${y + h - ry}V${y + ry}A${rx} ${ry} 0 0 1 ${x + rx} ${y}Z`
        : `M${x} ${y}h${w}v${h}h${-w}Z`;
    }
  }
}
