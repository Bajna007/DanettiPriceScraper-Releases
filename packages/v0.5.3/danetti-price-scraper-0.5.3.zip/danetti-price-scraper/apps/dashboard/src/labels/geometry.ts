import type { LabelNode } from "@danetti/label-engine/browser";
export interface Bounds {
  x: number;
  y: number;
  width: number;
  height: number;
}
export function selectionBounds(nodes: LabelNode[]): Bounds | null {
  if (!nodes.length) return null;
  const x = Math.min(...nodes.map((node) => node.x));
  const y = Math.min(...nodes.map((node) => node.y));
  const right = Math.max(...nodes.map((node) => node.x + node.width));
  const bottom = Math.max(...nodes.map((node) => node.y + node.height));
  return { x, y, width: right - x, height: bottom - y };
}
export function clientToScene(
  svg: SVGSVGElement,
  clientX: number,
  clientY: number
): { x: number; y: number } {
  const point = svg.createSVGPoint();
  point.x = clientX;
  point.y = clientY;
  const matrix = svg.getScreenCTM();
  if (!matrix) return { x: 0, y: 0 };
  const result = point.matrixTransform(matrix.inverse());
  return { x: result.x, y: result.y };
}
