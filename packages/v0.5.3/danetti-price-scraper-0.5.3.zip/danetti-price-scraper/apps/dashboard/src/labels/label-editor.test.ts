import assert from "node:assert/strict";
import {
  createBeanOnSeeds,
  createCustomLabelScene,
  createUtopiaSeeds,
  createBeanOnBalancedTemplateScene,
  resolveBindings,
  TASTE_BOX_ID,
  isLabelBodySizeText,
  isRiccaComposition,
  upgradeLabelScene,
} from "@danetti/label-engine";
import {
  alignNodes,
  BACKGROUND_LAYER_ID,
  backgroundLayer,
  updateText,
  updateTextField,
  distributeNodes,
  groupNodes,
  isNodeVisible,
  moveNodes,
  duplicateNodes,
  removeNodes,
  reorderNode,
  resizeNodeFromHandle,
  separatorLineStyle,
  separatorNodes,
  ungroupNodes,
  updateNode,
  updateNodeVisibilityField,
  updateRoastDateBoxVisibility,
  updateSeparatorStyle,
} from "./editor-commands.js";
import { createEditorState, editorReducer } from "./editor-reducer.js";
import { snapDelta } from "./snapping.js";
import type { LineNode } from "@danetti/label-engine";

const customLine: LineNode = {
  id: "line-test",
  name: "Vonal",
  type: "line",
  x: 10,
  y: 5,
  x2: 30,
  y2: 15,
  width: 20,
  height: 10,
  visible: true,
  locked: false,
  rotation: 0,
  opacity: 1,
};
const lineScene = { ...createCustomLabelScene(), nodes: [customLine] };
const resizedLine = updateNode(lineScene, customLine.id, { x: 8, width: 40, height: 20 })
  .nodes[0] as LineNode;
assert.deepEqual([resizedLine.x, resizedLine.y, resizedLine.x2, resizedLine.y2], [8, 5, 48, 25]);
const copiedLine = duplicateNodes(lineScene, [customLine.id]).scene.nodes[1] as LineNode;
assert.deepEqual([copiedLine.x, copiedLine.y, copiedLine.x2, copiedLine.y2], [11, 6, 31, 16]);

const scene = createUtopiaSeeds()[0]!.scene;
const start = createEditorState(scene, 1);
const background = editorReducer(start, {
  type: "commit",
  scene: { ...scene, background: { rgb: "#00BDB7" } },
  selectedIds: [BACKGROUND_LAYER_ID],
});
assert.deepEqual(editorReducer(background, { type: "undo" }).scene.background, scene.background);
assert.equal(backgroundLayer(background.scene).fill?.rgb, "#00BDB7");
assert.equal(
  background.scene.nodes.length,
  scene.nodes.length,
  "the background is never inserted as duplicate artwork"
);
const editedName = updateText(scene, "name", "ELSŐ\nMÁSODIK\nHARMADIK");
assert.equal(editedName.fields.name, "ELSŐ\nMÁSODIK\nHARMADIK");
const nameBox = editedName.nodes.find((node) => node.id === "name");
assert.ok(nameBox?.type === "text" && nameBox.wrap);
assert.ok(nameBox.height >= scene.nodes.find((node) => node.id === "name")!.height);
const again = updateTextField(editedName, "name", "ÚJ\nSZÖVEG");
assert.equal(again.nodes.find((node) => node.id === "name")?.height, nameBox.height);
const narrower = resizeNodeFromHandle(again, "name", "e", -3, 0).nodes.find(
  (node) => node.id === "name"
);
assert.ok(narrower?.type === "text" && narrower.wrap && narrower.width === narrower.maxWidth);
const moved = moveNodes(scene, ["country"], 1.25, -0.5);
const committed = editorReducer(start, { type: "commit", scene: moved });
assert.equal(committed.past.length, 1);
assert.equal(committed.saveStatus, "dirty");
assert.ok(
  Math.abs(
    committed.scene.nodes.find((node) => node.id === "country")!.x -
      (scene.nodes.find((node) => node.id === "country")!.x + 1.25)
  ) < 0.01
);
const undone = editorReducer(committed, { type: "undo" });
assert.deepEqual(undone.scene, scene);
const redone = editorReducer(undone, { type: "redo" });
assert.deepEqual(redone.scene, moved);

const transient = editorReducer(start, { type: "transient", scene: moved });
assert.equal(transient.past.length, 0, "a frame-közbeni mozgatás nem írhat undo commandot");
const final = editorReducer(transient, { type: "commit", scene: moved, previous: scene });
assert.equal(final.past.length, 1, "a pointer-up egyetlen undo commandot ír");

const grouped = groupNodes(scene, ["country", "name"]);
assert.ok(grouped.scene.nodes.some((node) => node.id === grouped.id && node.type === "group"));
assert.ok(
  grouped.scene.nodes
    .filter((node) => ["country", "name"].includes(node.id))
    .every((node) => node.parentId === grouped.id)
);
const ungrouped = ungroupNodes(grouped.scene, grouped.id);
assert.deepEqual(ungrouped.ids, ["country", "name"]);
assert.ok(
  ungrouped.scene.nodes
    .filter((node) => ["country", "name"].includes(node.id))
    .every((node) => !node.parentId)
);

const reordered = reorderNode(scene, "country", "roastDate");
assert.equal(
  reordered.nodes.findIndex((node) => node.id === "country"),
  scene.nodes.findIndex((node) => node.id === "roastDate")
);
const aligned = alignNodes(scene, ["country", "name"], "left");
assert.equal(
  aligned.nodes.find((node) => node.id === "country")?.x,
  aligned.nodes.find((node) => node.id === "name")?.x
);

const distributionScene = {
  ...scene,
  nodes: scene.nodes.map((node) =>
    node.id === "country"
      ? { ...node, x: 0 }
      : node.id === "name"
        ? { ...node, x: 50 }
        : node.id === "brand-divider"
          ? { ...node, x: 100 }
          : node
  ),
};
const distributed = distributeNodes(
  distributionScene,
  ["country", "name", "brand-divider"],
  "horizontal"
);
const centers = ["country", "name", "brand-divider"].map((id) => {
  const node = distributed.nodes.find((item) => item.id === id)!;
  return node.x + node.width / 2;
});
assert.ok(Math.abs(centers[1]! - centers[0]! - (centers[2]! - centers[1]!)) < 0.02);

const hidden = updateNode(scene, "country", { visible: false });
assert.equal(hidden.nodes.find((node) => node.id === "country")?.visible, false);
assert.ok(!removeNodes(scene, ["country"]).nodes.some((node) => node.id === "country"));

const hiddenDateField = updateNodeVisibilityField(scene, "date-field", "showRoastDateBox", false);
const hiddenDateNode = hiddenDateField.nodes.find((node) => node.id === "date-field")!;
assert.equal(hiddenDateField.fields.showRoastDateBox, false);
assert.deepEqual(hiddenDateNode.binding, {
  field: "showRoastDateBox",
  property: "visible",
});
assert.equal(isNodeVisible(hiddenDateField, hiddenDateNode), false);
const shownDateField = updateNodeVisibilityField(
  hiddenDateField,
  "date-field",
  "showRoastDateBox",
  true
);
assert.equal(
  isNodeVisible(shownDateField, shownDateField.nodes.find((node) => node.id === "date-field")!),
  true
);

const alteredDateBox = updateNode(scene, "date-field", {
  x: 2,
  y: 3,
  width: 4,
  height: 5,
  fill: { rgb: "#000000", cmyk: { c: 0, m: 0, y: 0, k: 1 } },
  opacity: 0.25,
});
const restoredUtopiaDateBox = updateRoastDateBoxVisibility(alteredDateBox, true).nodes.find(
  (node) => node.id === "date-field"
)!;
assert.deepEqual(
  {
    x: restoredUtopiaDateBox.x,
    y: restoredUtopiaDateBox.y,
    width: restoredUtopiaDateBox.width,
    height: restoredUtopiaDateBox.height,
    fill: restoredUtopiaDateBox.fill,
    opacity: restoredUtopiaDateBox.opacity,
  },
  {
    x: 50.907,
    y: 27.912,
    width: 47.128,
    height: 5.62,
    fill: { rgb: "#FFFFFF", cmyk: { c: 0, m: 0, y: 0, k: 0 } },
    opacity: 1,
  }
);
const beanScene = createBeanOnSeeds()[0]!.scene;
const restoredBeanDateBox = updateRoastDateBoxVisibility(beanScene, true).nodes.find(
  (node) => node.id === "date-field"
)!;
assert.deepEqual(
  {
    x: restoredBeanDateBox.x,
    y: restoredBeanDateBox.y,
    width: restoredBeanDateBox.width,
    height: restoredBeanDateBox.height,
    fill: restoredBeanDateBox.fill,
  },
  {
    x: 61,
    y: 27.4,
    width: 51.6,
    height: 7.4,
    fill: { rgb: "#FFFFFF", cmyk: { c: 0, m: 0, y: 0, k: 0 } },
  }
);

const resizedEast = resizeNodeFromHandle(scene, "date-field", "e", 4, 9).nodes.find(
  (node) => node.id === "date-field"
)!;
assert.ok(
  Math.abs(resizedEast.width - (scene.nodes.find((node) => node.id === "date-field")!.width + 4)) <
    0.01
);
assert.equal(resizedEast.height, scene.nodes.find((node) => node.id === "date-field")!.height);
const resizedNorthWest = resizeNodeFromHandle(scene, "date-field", "nw", -2, -1).nodes.find(
  (node) => node.id === "date-field"
)!;
assert.ok(
  Math.abs(resizedNorthWest.x - (scene.nodes.find((node) => node.id === "date-field")!.x - 2)) <
    0.01
);
assert.ok(
  Math.abs(resizedNorthWest.y - (scene.nodes.find((node) => node.id === "date-field")!.y - 1)) <
    0.01
);
assert.ok(
  Math.abs(
    resizedNorthWest.width - (scene.nodes.find((node) => node.id === "date-field")!.width + 2)
  ) < 0.01
);
assert.ok(
  Math.abs(
    resizedNorthWest.height - (scene.nodes.find((node) => node.id === "date-field")!.height + 1)
  ) < 0.01
);

const styledSeparators = updateSeparatorStyle(scene, {
  style: "solid",
  strokeWidth: 0.4,
  stroke: { rgb: "#00BDB7", cmyk: { c: 1, m: 0, y: 0.03, k: 0.26 } },
});
const qrTemplate = createBeanOnBalancedTemplateScene();
for (const base of [qrTemplate]) {
  const title = base.nodes.find((n) => n.id === "name");
  const resizedType = updateNode(base, "bestBefore", { fontSizePt: 8 });
  assert.ok(
    resizedType.nodes
      .filter(isLabelBodySizeText)
      .every((n) => n.fontSizePt === 8 && n.minFontSizePt === 8)
  );
  assert.deepEqual(
    resizedType.nodes.find((n) => n.id === "name"),
    title
  );
  const infoType = updateNode(base, "value-notes", { fontSizePt: 6 });
  assert.ok(infoType.nodes.filter(isLabelBodySizeText).every((n) => n.fontSizePt === 6));
}
const riccaSource = createBeanOnSeeds().find((seed) =>
  /RICCA/iu.test(String(seed.scene.fields.name))
)!.scene;
const ricca = upgradeLabelScene(riccaSource)!;
const composition = ricca.nodes.find((node) => isRiccaComposition(ricca, node))!;
assert.ok(composition);
assert.deepEqual(
  updateNode(ricca, "bestBefore", { fontSizePt: 8 }).nodes.find(
    (node) => node.id === composition.id
  ),
  composition
);
assert.deepEqual(
  updateNode(ricca, composition.id, { fontSizePt: 9 }).nodes.find(
    (node) => node.id === "bestBefore"
  ),
  ricca.nodes.find((node) => node.id === "bestBefore")
);
const white = { rgb: "#FFFFFF", cmyk: { c: 0, m: 0, y: 0, k: 0 } };
const whiteSeparators = updateSeparatorStyle(qrTemplate, { stroke: white });
assert.deepEqual(
  resolveBindings(whiteSeparators).nodes.find((n) => n.id === "qr-product")?.fill,
  white
);
assert.deepEqual(whiteSeparators.nodes.find((n) => n.id === "lower-divider")?.stroke, white);
assert.ok(
  whiteSeparators.nodes.filter((n) => n.type === "text").every((n) => n.fill?.rgb === white.rgb)
);
const fontColourChanged = updateNode(qrTemplate, "value-farm", { fill: white });
assert.deepEqual(
  resolveBindings(fontColourChanged).nodes.find((n) => n.id === "qr-product")?.fill,
  white
);
assert.ok(
  fontColourChanged.nodes.filter((n) => n.type === "line").every((n) => n.stroke?.rgb === white.rgb)
);
assert.deepEqual(
  updateNode(qrTemplate, "qr-product", { fill: white }).nodes.find((n) => n.id === "footer-line")
    ?.stroke,
  white
);
assert.equal(separatorNodes(styledSeparators).length, 10);
assert.ok(separatorNodes(styledSeparators).every((node) => separatorLineStyle(node) === "solid"));
assert.ok(separatorNodes(styledSeparators).every((node) => node.strokeWidth === 0.4));
assert.ok(separatorNodes(styledSeparators).every((node) => node.stroke?.rgb === "#00BDB7"));
assert.equal(
  styledSeparators.nodes.find((node) => node.id === "line-region")?.stroke?.rgb,
  "#00BDB7"
);
const costaBeanScene = createBeanOnSeeds().find(
  (seed) => seed.internalCode === "BO-COSTA-RICA-CASA-DE-PIEDRA"
)!.scene;
const beanStyledSeparators = updateSeparatorStyle(costaBeanScene, {
  stroke: { rgb: "#00BDB7", cmyk: { c: 1, m: 0, y: 0.03, k: 0.26 } },
  strokeWidth: 0.4,
  style: "solid",
});
assert.deepEqual(
  separatorNodes(beanStyledSeparators)
    .map((node) => node.id)
    .sort(),
  [
    "date-divider",
    "footer-line",
    "line-altitude",
    "line-farm",
    "line-notes",
    "line-process",
    "line-region",
    "line-variety",
    "main-divider",
    "weight-line",
  ].sort()
);
assert.ok(
  separatorNodes(beanStyledSeparators).every(
    (node) => node.stroke?.rgb === "#00BDB7" && node.strokeWidth === 0.4 && node.fill === undefined
  )
);
const country = scene.nodes.find((node) => node.id === "country")!;
const uniformInfo = updateNode(qrTemplate, "value-notes", { fontSizePt: 8, fontWeight: 700 });
const movedTastes = moveNodes(qrTemplate, [TASTE_BOX_ID], 2, 1);
for (const id of [TASTE_BOX_ID, "value-notes", "value-notes-en"]) {
  const old = qrTemplate.nodes.find((node) => node.id === id)!;
  const moved = movedTastes.nodes.find((node) => node.id === id)!;
  assert.equal(moved.x, Math.round((old.x + 2) * 100) / 100);
  assert.equal(moved.y, Math.round((old.y + 1) * 100) / 100);
}
const smallerTasteBox = resizeNodeFromHandle(qrTemplate, TASTE_BOX_ID, "e", -10, 0);
assert.equal(
  smallerTasteBox.nodes.find((node) => node.id === "value-notes")?.width,
  smallerTasteBox.nodes.find((node) => node.id === "value-notes-en")?.width
);
assert.ok(
  smallerTasteBox.nodes.find((node) => node.id === "value-notes")!.width <
    qrTemplate.nodes.find((node) => node.id === "value-notes")!.width
);
const tasteCopy = duplicateNodes(qrTemplate, [TASTE_BOX_ID]);
assert.equal(tasteCopy.scene.nodes.length, qrTemplate.nodes.length + 3);
const copyGroup = tasteCopy.scene.nodes.find((node) => node.id === tasteCopy.ids[0])!;
const onlyTasteBox = {
  ...qrTemplate,
  guides: [],
  nodes: qrTemplate.nodes.filter((node) =>
    [TASTE_BOX_ID, "value-notes", "value-notes-en"].includes(node.id)
  ),
};
const selfSnap = snapDelta(
  onlyTasteBox,
  [onlyTasteBox.nodes.find((node) => node.id === TASTE_BOX_ID)!],
  0.2,
  0.2,
  true
);
assert.equal(selfSnap.dx, 0.2, "Dragging a box does not snap to its own children");
assert.equal(selfSnap.dy, 0.2);
assert.ok(
  copyGroup.type === "group" &&
    copyGroup.childIds.every(
      (id) => tasteCopy.scene.nodes.find((node) => node.id === id)?.parentId === copyGroup.id
    )
);
assert.ok(
  uniformInfo.nodes
    .filter((node) => node.type === "text" && /^(?:label|value)-/u.test(node.id))
    .every((node) => node.type === "text" && node.fontSizePt === 8 && node.fontWeight === 700)
);
assert.deepEqual(
  uniformInfo.nodes.find((node) => node.id === "name"),
  qrTemplate.nodes.find((node) => node.id === "name")
);
const snapped = snapDelta(scene, [country], 32.45, 0, true);
assert.ok(Number.isFinite(snapped.dx));
assert.ok(Array.isArray(snapped.guides));
const saving = editorReducer(committed, { type: "save", status: "saving" });
const changedWhileSaving = editorReducer(saving, { type: "commit", scene: again });
const savedEarlier = editorReducer(changedWhileSaving, {
  type: "save",
  status: "saved",
  revision: 2,
  savedScene: committed.scene,
});
assert.equal(savedEarlier.saveStatus, "dirty");
assert.equal(savedEarlier.revision, 2);
assert.deepEqual(savedEarlier.scene, again);

const customGeometry = createCustomLabelScene(80, 40);
customGeometry.nodes = [
  {
    id: "path",
    name: "Artwork",
    type: "path",
    x: 10,
    y: 5,
    width: 20,
    height: 10,
    rotation: 0,
    opacity: 1,
    visible: true,
    locked: false,
    d: "M0 0L20 10",
  },
];
const grownPath = updateNode(customGeometry, "path", { width: 40, height: 20 }).nodes[0]!;
assert.ok(grownPath.type === "path" && grownPath.d.includes("40 20"));
assert.equal(grownPath.x, 10);
const rotatedScene = { ...customGeometry, nodes: [{ ...customGeometry.nodes[0]!, rotation: 90 }] };
const rotatedResize = resizeNodeFromHandle(rotatedScene, "path", "e", 0, 10).nodes[0]!;
assert.equal(rotatedResize.width, 30);
assert.ok(Math.abs(rotatedResize.y - 10) < 0.001);
console.log("Label editor command/reducer tests passed");
