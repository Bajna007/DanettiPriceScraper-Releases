import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
} from "react";
import { sanitizeApiErrorDetail } from "../lib/api";
import { AppUpdateControl } from "./AppUpdateControl";

export function DashboardShell({
  title,
  nav,
  children,
}: {
  title: string;
  nav: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="app-brand" aria-label={title}>
          <span className="app-title-mark" aria-hidden="true" />
          <div className="app-title">{title}</div>
        </div>
        {nav}
        <AppUpdateControl />
      </header>
      <main className="app-main">{children}</main>
    </div>
  );
}

export function PageHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="page-header">
      <h1 className="page-title">{title}</h1>
      {subtitle ? <p className="page-subtitle">{subtitle}</p> : null}
    </div>
  );
}

export function Toolbar({ children }: { children: ReactNode }) {
  return <div className="toolbar">{children}</div>;
}

export function ToolbarGroup({ children }: { children: ReactNode }) {
  return <div className="toolbar-group">{children}</div>;
}

export function DataTableShell({ children, footer, help, title }: DataTableShellProps) {
  return (
    <section className="card table-card">
      {title ? <h2 className="section-title">{title}</h2> : null}
      {help ? <p className="helper-text">{help}</p> : null}
      <div className="table-scroll">{children}</div>
      {footer ? <div className="table-footer">{footer}</div> : null}
    </section>
  );
}

interface DataTableShellProps {
  children: ReactNode;
  title?: string;
  help?: ReactNode;
  footer?: ReactNode;
}

export function DataTable({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <table className={`table data-table ${className}`.trim()}>{children}</table>;
}

export function DataTableEmpty({ children }: { children: ReactNode }) {
  return (
    <tbody>
      <tr>
        <td className="table-empty" colSpan={99}>
          {children}
        </td>
      </tr>
    </tbody>
  );
}

export function StatusBadge({ children, tone = "neutral" }: StatusBadgeProps) {
  return <span className={`badge ${tone === "neutral" ? "" : tone}`.trim()}>{children}</span>;
}

interface StatusBadgeProps {
  children: ReactNode;
  tone?: "neutral" | "success" | "warning" | "danger" | "muted";
}

export function Button({
  variant = "primary",
  small = false,
  className = "",
  ...props
}: ButtonProps) {
  return (
    <button
      className={`button ${variant}${small ? " small" : ""} ${className}`.trim()}
      {...props}
    />
  );
}

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  small?: boolean;
}

export function Field({
  label,
  helper,
  ...props
}: { label: string; helper?: string } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="field-label">
      {label}
      <input className="input" {...props} />
      {helper ? <span className="field-help">{helper}</span> : null}
    </label>
  );
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input className="input" {...props} />;
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className="input" {...props} />;
}

export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className="input" {...props} />;
}

export function Notice({ title, children, variant = "info" }: NoticeProps) {
  return (
    <div className={`notice ${variant}`}>
      <p className="card-title">{title}</p>
      {children ? <div className="helper-text">{children}</div> : null}
    </div>
  );
}

interface NoticeProps {
  title: string;
  children?: ReactNode;
  variant?: "info" | "warning" | "error" | "success";
}

export function ErrorDetails({ message }: { message: string }) {
  const safeMessage = sanitizeApiErrorDetail(message);
  const redacted = safeMessage !== message;
  return (
    <details className="error-details">
      <summary>Biztonságos technikai részletek</summary>
      {redacted ? (
        <p className="helper-text">A nyers részlet érzékeny tartalmat rejthetett.</p>
      ) : null}
      <pre className="helper-text">
        <code>{safeMessage}</code>
      </pre>
    </details>
  );
}

export function SummaryMetric({ title, value, helper }: SummaryMetricProps) {
  return (
    <div className="card summary-metric">
      <p className="card-title">{title}</p>
      <p className="card-value">{value}</p>
      {helper ? <p className="helper-text">{helper}</p> : null}
    </div>
  );
}

interface SummaryMetricProps {
  title: string;
  value: string | number;
  helper?: string;
}
