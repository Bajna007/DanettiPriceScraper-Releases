import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const source = readFileSync(new URL("../app/imports/page.tsx", import.meta.url), "utf8");

assert.match(source, /TablePagination/);
assert.match(source, /DEFAULT_LIMIT/);
assert.match(source, /listImports\(\{ limit: DEFAULT_LIMIT, offset \}\)/);
assert.match(source, /product-table-toolbar/);
assert.match(source, /product-view-controls/);
assert.match(source, /Legújabb importok elöl/);
assert.match(source, /Sor megnyitása/);

console.log("Imports page UI tests passed");
