import { expect, test } from "@playwright/test";

const availableUpdate = {
  status: "available",
  currentVersion: "0.2.4",
  availableVersion: "9.9.9",
  changelog: "Helyi frissítésgomb-ellenőrzés.",
  message: "Elérhető a 9.9.9 verzió.",
};

test("a fejléc frissítés gombja megjeleníti és elindítja a frissítési folyamatot", async ({
  page,
}) => {
  let checkCalls = 0;
  let installCalls = 0;
  let statusCalls = 0;

  await page.route("**/app-update", async (route) => {
    await route.fulfill({ contentType: "application/json", json: { item: availableUpdate } });
  });
  await page.route("**/app-update/check", async (route) => {
    checkCalls += 1;
    await route.fulfill({ contentType: "application/json", json: { item: availableUpdate } });
  });
  await page.route("**/app-update/install", async (route) => {
    installCalls += 1;
    expect(route.request().postDataJSON()).toEqual({ version: "9.9.9" });
    await route.fulfill({
      status: 202,
      contentType: "application/json",
      json: {
        item: {
          ...availableUpdate,
          message: "A 9.9.9 frissítése elindult.",
        },
      },
    });
  });
  await page.route("**/app-update/install-status", async (route) => {
    statusCalls += 1;
    await route.fulfill({
      contentType: "application/json",
      json: {
        item: {
          state: "queued",
          version: "9.9.9",
          message: "A frissítő háttérfolyamata fut.",
        },
      },
    });
  });

  await page.goto("/");
  const headerButton = page.getByRole("button", { name: "Danetti frissítés ellenőrzése" });
  await expect(headerButton).toBeVisible();
  await expect(headerButton).toContainText("v9.9.9");

  const dialog = page.getByRole("dialog");
  await expect(dialog).toContainText("Frissítés: v9.9.9");
  await expect(dialog).toContainText("Helyi frissítésgomb-ellenőrzés.");
  await page.getByRole("button", { name: "Később" }).click();
  await expect(dialog).toBeHidden();

  await headerButton.click();
  await expect.poll(() => checkCalls).toBe(1);
  await expect(dialog).toBeVisible();
  await page.getByRole("button", { name: "Frissítés és újraindítás" }).click();
  await expect.poll(() => installCalls).toBe(1);
  await expect.poll(() => statusCalls).toBeGreaterThan(0);
  await expect(dialog).toContainText("A frissítő háttérfolyamata fut.");
  await expect(page.getByRole("button", { name: "Ablak bezárása" })).toBeEnabled();
});
