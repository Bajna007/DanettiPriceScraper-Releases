"use client";

import {
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type MouseEvent as ReactMouseEvent,
  type Ref,
} from "react";
import { ErrorState, LoadingState } from "../../../src/components/States";
import { TablePagination } from "../../../src/components/TablePagination";
import {
  formatSupplierWarnings,
  normalizeSupplierDisplayStatus,
  type SupplierDisplayStatus,
} from "@danetti/shared";
import {
  cancelLfManualBatch,
  continueLfManualBatch,
  formatApiErrorMessage,
  getCurrentLfManualBatch,
  getLfManualBatch,
  getLfManualBatchProgress,
  getSavedLfManualBatchState,
  listSupplierMappings,
  listSuppliers,
  saveLfOperatorPreferences,
  startLfManualBatch,
  type LfExactAutoPairResponse,
  type LfManualBatchProgress,
  type LfManualBatchRow,
  type LfManualBatchSpeedMode,
  type LfManualBatchState,
  type LfOperatorPreferences,
  type Supplier,
  type SupplierMapping,
} from "../../../src/lib/api";

const LF_CONNECTOR_ID = "lf-spare-parts-724";
const ALL_LF_BATCH_LIMIT = 10_000;
const MAPPING_PAGE_SIZE = 200;
const RUN_STORAGE_KEY = "danetti:lf-operator-active-run-id";
const PRICE_RUN_STORAGE_KEY = "danetti:lf-operator-active-price-run-id";
const PAIRING_RUN_STORAGE_KEY = "danetti:lf-operator-active-pairing-run-id";
const PRICE_PROGRESS_STORAGE_KEY = "danetti:lf-operator-price-progress";
const PAIRING_PROGRESS_STORAGE_KEY = "danetti:lf-operator-pairing-progress";
const LF_RESULT_COLUMN_STORAGE_KEY = "danetti:lf-results:columns";
const INITIAL_API_LOAD_ATTEMPTS = 6;
const INITIAL_API_RETRY_WAIT_MS = 1_250;
const CLOAKBROWSER_MANAGER_URL =
  process.env.NEXT_PUBLIC_CLOAKBROWSER_MANAGER_URL ?? "http://127.0.0.1:18080";
const LF_TABLE_PAGE_SIZE = 50;

type OperatorNotice = { message: string; tone: "info" | "success" | "warning" | "error" };

const speedModeOptions: Array<{
  value: LfManualBatchSpeedMode;
  label: string;
  help: string;
}> = [
  {
    value: "normal",
    label: "Normál",
    help: "Biztonsági tempó: legfeljebb 6 termék percenként.",
  },
  {
    value: "fast",
    label: "Gyors",
    help: "Nincs szándékos várakozás LF tételek között.",
  },
  {
    value: "very_fast",
    label: "Nagyon gyors",
    help: "Nincs szándékos várakozás; csak külön indokolt kézi teszthez.",
  },
];

const lfResultColumns = [
  { id: "status", label: "Státusz", width: 132, minWidth: 104 },
  { id: "sku", label: "SKU", width: 170, minWidth: 120 },
  { id: "name", label: "Termék", width: 360, minWidth: 220 },
  { id: "mainSource", label: "Fő forrás", width: 190, minWidth: 150 },
  { id: "article", label: "LF keresett", width: 150, minWidth: 116 },
  { id: "autocomplete", label: "LF találati bizonyíték", width: 260, minWidth: 170 },
  { id: "partNumber", label: "LF cikkszám", width: 140, minWidth: 112 },
  { id: "supplierNetEur", label: "LF nettó EUR", width: 132, minWidth: 112, numeric: true },
  { id: "supplierNetHuf", label: "Beszerzés nettó HUF", width: 170, minWidth: 130, numeric: true },
  { id: "wooGrossHuf", label: "Jelenlegi Woo bruttó", width: 170, minWidth: 130, numeric: true },
  { id: "wooNetHuf", label: "Jelenlegi Woo nettó", width: 160, minWidth: 124, numeric: true },
  { id: "profitHuf", label: "Tiszta profit HUF", width: 158, minWidth: 124, numeric: true },
  { id: "profitPercent", label: "Haszon %", width: 112, minWidth: 92, numeric: true },
  { id: "warnings", label: "Figyelmeztetés", width: 300, minWidth: 180 },
] as const;

type LfResultColumnId = (typeof lfResultColumns)[number]["id"];

type LiveStatus = {
  headline: string;
  phase: string;
  badgeTone: string;
  detail: string;
  fields: Array<{ label: string; value: string }>;
};

type OperatorGuidance = {
  title: string;
  body: string;
  badge: string;
  tone: "success" | "warning" | "danger" | "muted";
};

type WorkbenchStatusTile = {
  label: string;
  value: number;
  detail: string;
  tone: "success" | "warning" | "danger" | "muted";
};

type LfRunKind = "pairing" | "price";

type ScopedRunProgress = {
  runId: string;
  kind: LfRunKind;
  status: LfManualBatchState["status"];
  processed: number;
  total: number;
  nextOffset: number;
  updatedAt: string | null;
};

const defaultLfResultColumnWidths = lfResultColumns.reduce(
  (widths, column) => ({ ...widths, [column.id]: column.width }),
  {} as Record<LfResultColumnId, number>
);

const defaultLfResultColumnVisibility = lfResultColumns.reduce(
  (visibility, column) => ({ ...visibility, [column.id]: true }),
  {} as Record<LfResultColumnId, boolean>
);

const fixedLfResultColumnIds = new Set<LfResultColumnId>(["status", "name"]);

const terminalStatuses = new Set([
  "completed",
  "cancelled",
  "login_timeout",
  "detached_session_failed",
  "failed",
  "session_lost",
  "interrupted",
]);

const fallbackLfSupplier: Supplier = {
  id: LF_CONNECTOR_ID,
  code: LF_CONNECTOR_ID,
  name: "LF Spare Parts 724",
  baseUrl: "https://b2bnet.lfspareparts724.com",
  enabled: true,
  allowedDomains: ["b2bnet.lfspareparts724.com"],
  supportedLookupStrategies: ["search_then_detail"],
  defaultRateLimitPerMinute: 6,
  healthStatus: "unknown",
  lastSuccessAt: null,
  lastFailureAt: null,
  createdAt: "",
  updatedAt: "",
};

export default function LfOperatorPage() {
  const [mappings, setMappings] = useState<SupplierMapping[]>([]);
  const savedPreferencesRef = useRef<LfOperatorPreferences>({ autoResume: true, vatPercent: 27 });
  const [speedMode, setSpeedMode] = useState<LfManualBatchSpeedMode>("normal");
  const [rerunPreviousNonOkOnly, setRerunPreviousNonOkOnly] = useState(false);
  const [autoResume, setAutoResume] = useState(true);
  const [preferencesLoaded, setPreferencesLoaded] = useState(false);
  const [preferenceStatus, setPreferenceStatus] = useState<"saved" | "saving" | "error" | null>(
    null
  );
  const [state, setState] = useState<LfManualBatchState | null>(null);
  const [savedProgress, setSavedProgress] = useState<LfManualBatchProgress | null>(null);
  const [pairingProgress, setPairingProgress] = useState<ScopedRunProgress | null>(() =>
    readStoredScopedRunProgress("pairing")
  );
  const [priceProgress, setPriceProgress] = useState<ScopedRunProgress | null>(() =>
    readStoredScopedRunProgress("price")
  );
  const [action, setAction] = useState<"start" | "continue" | "cancel" | null>(null);
  const [pairingAction, setPairingAction] = useState<"save" | "resume" | null>(null);
  const [exactPairResult, setExactPairResult] = useState<LfExactAutoPairResponse | null>(null);
  const [operatorNotice, setOperatorNotice] = useState<OperatorNotice | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const liveTrackingCardRef = useRef<HTMLDivElement | null>(null);
  const terminalCardRef = useRef<HTMLDivElement | null>(null);
  const reconnectRecoveryInFlightRef = useRef(false);
  const startActionInFlightRef = useRef(false);
  const cloakBrowserManagerWindowRef = useRef<Window | null>(null);

  const active = state ? !terminalStatuses.has(state.status) : false;
  const activeRunKind = getLfRunKind(state);
  const isPairingRun = activeRunKind === "pairing";
  const totalMapped = mappings.length;
  const runOffset = state?.settings.offset ?? 0;
  const activeSavedProgress = savedProgress?.runId === state?.runId ? savedProgress : null;
  const displayedTotal = state ? getLfRunDisplayedTotal(state, totalMapped) : totalMapped;
  const runChecked = state ? countProgressAdvancingRows(state.rows) : 0;
  const stateProcessedOverall = Math.min(displayedTotal, runOffset + runChecked);
  const savedProcessedOverall = Math.min(displayedTotal, activeSavedProgress?.nextOffset ?? 0);
  const inactivePriceProcessed = Math.min(totalMapped, priceProgress?.nextOffset ?? 0);
  const processedOverall = state
    ? active
      ? stateProcessedOverall
      : Math.max(stateProcessedOverall, savedProcessedOverall)
    : inactivePriceProcessed;
  const hasVisibleRunProgress = state !== null || inactivePriceProcessed > 0;
  const remainingOverall = Math.max(displayedTotal - processedOverall, 0);
  const progressPercent = displayedTotal > 0 ? (processedOverall / displayedTotal) * 100 : 0;
  const progressVerb = isPairingRun ? "ellenőrizve" : "feldolgozva";
  const progressCounterLabel = hasVisibleRunProgress
    ? `${processedOverall}/${displayedTotal || 0} ${progressVerb}`
    : "Nincs aktív LF árfrissítés";
  const remainingCounterLabel = hasVisibleRunProgress
    ? `${remainingOverall} hátra`
    : `${totalMapped} mentett LF mapping`;
  const nextPointLabel = hasVisibleRunProgress
    ? `következő pont ${savedProgress?.nextOffset ?? runOffset}`
    : "következő pont nincs";
  const updatedLabel = hasVisibleRunProgress
    ? `frissítve ${formatDateTime(savedProgress?.updatedAt ?? null)}`
    : "frissítve -";
  const currentGlobalIndex = state?.currentItem ? runOffset + state.currentItem.index : null;
  const priceResumeOffset = Math.min(totalMapped, priceProgress?.nextOffset ?? 0);
  const pairingResumeOffset = pairingProgress?.nextOffset ?? 0;
  const pairingResumeTotal = pairingProgress?.total ?? (isPairingRun ? displayedTotal : 0);
  const canStart = action === null && !active && totalMapped > 0;
  const canRestartLogin =
    action === null &&
    !isPairingRun &&
    state !== null &&
    totalMapped > 0 &&
    runChecked === 0 &&
    ["opening_browser", "waiting_for_manual_login", "login_detected"].includes(state.status);
  const canResume =
    canStart && !rerunPreviousNonOkOnly && priceResumeOffset > 0 && priceResumeOffset < totalMapped;
  const canContinueCurrent =
    !isPairingRun &&
    action === null &&
    state !== null &&
    state.status === "waiting_for_manual_login";
  const canRunPairing = pairingAction === null && !active && action === null;
  const canResumePairing =
    canRunPairing && pairingResumeOffset > 0 && pairingResumeOffset < pairingResumeTotal;
  const resultRows = state?.rows ?? [];
  const latestEvents = useMemo(() => (state?.events ?? []).slice().reverse(), [state?.events]);
  const terminalEvents = useMemo(() => state?.events ?? [], [state?.events]);
  const runTelemetry = state?.telemetry ?? null;
  const averageItemDuration = formatAverageItemDuration({ state, telemetry: runTelemetry });
  const estimatedFullRunDuration = formatEstimatedFullRunDuration({
    state,
    telemetry: runTelemetry,
    totalItems: displayedTotal,
  });
  const workbenchStatusTiles = useMemo(
    () =>
      buildWorkbenchStatusTiles({
        rows: resultRows,
        state,
        savedProgress: activeSavedProgress,
        isPairingRun,
      }),
    [activeSavedProgress, isPairingRun, resultRows, state]
  );
  const preferences = useMemo<LfOperatorPreferences>(
    () => ({ ...savedPreferencesRef.current, autoResume }),
    [autoResume, preferencesLoaded]
  );
  const liveStatus = useMemo(
    () =>
      buildLiveStatus({
        state,
        totalMapped: displayedTotal,
        runOffset,
        currentGlobalIndex,
        latestEvents,
        resultRows,
      }),
    [currentGlobalIndex, displayedTotal, latestEvents, resultRows, runOffset, state]
  );
  const guidance = useMemo(
    () =>
      buildOperatorGuidance({
        action,
        active,
        state,
        savedProgress: activeSavedProgress,
        isPairingRun,
        processedOverall,
        totalMapped: displayedTotal,
      }),
    [action, active, activeSavedProgress, displayedTotal, isPairingRun, processedOverall, state]
  );

  useEffect(() => {
    let mounted = true;
    loadInitialDataWithRetry()
      .catch((err) => {
        if (mounted) setError(formatLfOperatorErrorMessage(err));
      })
      .finally(() => {
        if (mounted) {
          setLoading(false);
          setOperatorNotice(null);
        }
      });

    async function loadInitialDataWithRetry() {
      let lastError: unknown = null;
      for (let attempt = 1; attempt <= INITIAL_API_LOAD_ATTEMPTS; attempt += 1) {
        try {
          await loadInitialData();
          return;
        } catch (err) {
          lastError = err;
          if (!mounted || attempt === INITIAL_API_LOAD_ATTEMPTS) break;
          showOperatorNotice(
            `Helyi API ellenőrzése... újrapróbálás ${attempt}/${INITIAL_API_LOAD_ATTEMPTS - 1}`,
            "warning"
          );
          await wait(INITIAL_API_RETRY_WAIT_MS);
        }
      }
      throw lastError;
    }

    async function loadInitialData() {
      const [supplierResponse, savedState, progress, current] = await Promise.all([
        listSuppliers({ limit: 100 }),
        getSavedLfManualBatchState(),
        getLfManualBatchProgress(),
        getCurrentLfManualBatch(),
      ]);
      if (!mounted) return;

      const nextSupplier = supplierResponse.items.find(isLfSupplier) ?? fallbackLfSupplier;
      applyOperatorPreferences(savedState.preferences);

      const nextMappings = isUuid(nextSupplier.id)
        ? await listAllSupplierMappings(nextSupplier.id)
        : [];
      if (!mounted) return;
      setMappings(nextMappings);

      setSavedProgress(progress.progress);
      if (current.run) {
        storeRunId(current.run.runId, getLfRunKind(current.run));
        setState(current.run);
        return;
      }
      if (savedState.run) {
        storeRunId(savedState.run.runId, getLfRunKind(savedState.run));
        setState(normalizeInactiveSavedRun(savedState.run));
        return;
      }

      const storedRunIds = readStoredRunIds();
      for (const storedRunId of storedRunIds) {
        try {
          const restored = await getLfManualBatch(storedRunId);
          if (mounted) {
            storeRunId(restored.runId, getLfRunKind(restored));
            setState(restored);
          }
          return;
        } catch {
          clearStoredRunId(storedRunId);
        }
      }
    }

    return () => {
      mounted = false;
    };
  }, []);

  useLayoutEffect(() => {
    const trackingCard = liveTrackingCardRef.current;
    const terminalCard = terminalCardRef.current;
    if (!trackingCard || !terminalCard) return;

    let frame = 0;
    const syncTrackingHeight = () => {
      const nextHeight = terminalCard.offsetHeight;
      if (nextHeight <= 0) return;
      const height = `${nextHeight}px`;
      trackingCard.style.height = height;
      trackingCard.style.maxHeight = height;
    };
    const scheduleSync = () => {
      window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(syncTrackingHeight);
    };

    scheduleSync();
    const observer = new ResizeObserver(scheduleSync);
    observer.observe(terminalCard);
    window.addEventListener("resize", scheduleSync);
    return () => {
      window.cancelAnimationFrame(frame);
      window.removeEventListener("resize", scheduleSync);
      observer.disconnect();
      trackingCard.style.height = "";
      trackingCard.style.maxHeight = "";
    };
  }, []);

  useEffect(() => {
    if (!preferencesLoaded || preferences === null) return;
    const timer = window.setTimeout(() => {
      setPreferenceStatus("saving");
      saveLfOperatorPreferences(preferences)
        .then(() => setPreferenceStatus("saved"))
        .catch(() => setPreferenceStatus("error"));
    }, 600);
    return () => window.clearTimeout(timer);
  }, [preferences, preferencesLoaded]);

  useEffect(() => {
    const snapshot = buildScopedRunProgress(state, savedProgress, totalMapped);
    if (!snapshot) return;
    storeScopedRunProgress(snapshot);
    storeRunId(snapshot.runId, snapshot.kind);
    if (snapshot.kind === "pairing") {
      setPairingProgress(snapshot);
      return;
    }
    setPriceProgress(snapshot);
  }, [savedProgress, state, totalMapped]);

  useEffect(() => {
    if (!state?.runId || !active) return;
    const timer = window.setInterval(() => {
      Promise.all([getLfManualBatch(state.runId), getLfManualBatchProgress()])
        .then(([nextState, progress]) => {
          setState(nextState);
          setSavedProgress(progress.progress);
          setError(null);
          setOperatorNotice(null);
        })
        .catch((err) => {
          if (isLocalApiUnavailableError(err)) {
            showOperatorNotice(
              "Helyi API kapcsolat megszakadt. Ellenőrzöm az aktív LF futást; új login csak kézi folytatáskor indul.",
              "warning"
            );
          } else {
            setError(formatLfOperatorErrorMessage(err));
          }
          void recoverAfterReconnect("poll_error");
        });
    }, 1500);
    return () => window.clearInterval(timer);
  }, [active, state?.runId]);

  useEffect(() => {
    function recoverWhenVisible() {
      if (document.visibilityState === "visible") void recoverAfterReconnect("visible");
    }
    function recoverWhenOnline() {
      showOperatorNotice("Kapcsolat visszatért. LF futás ellenőrzése...", "info");
      void recoverAfterReconnect("online");
    }
    function recoverWhenFocused() {
      void recoverAfterReconnect("focus");
    }

    window.addEventListener("online", recoverWhenOnline);
    window.addEventListener("focus", recoverWhenFocused);
    window.addEventListener("pageshow", recoverWhenFocused);
    document.addEventListener("visibilitychange", recoverWhenVisible);
    return () => {
      window.removeEventListener("online", recoverWhenOnline);
      window.removeEventListener("focus", recoverWhenFocused);
      window.removeEventListener("pageshow", recoverWhenFocused);
      document.removeEventListener("visibilitychange", recoverWhenVisible);
    };
  }, [autoResume, processedOverall, state?.runId, totalMapped]);

  useEffect(() => {
    if (!state || !["login_detected", "running", "completed"].includes(state.status)) return;
    closeCloakBrowserManagerWindow(cloakBrowserManagerWindowRef);
  }, [state?.status]);

  function applyOperatorPreferences(nextPreferences: LfOperatorPreferences) {
    setAutoResume(nextPreferences.autoResume);
    savedPreferencesRef.current = nextPreferences;
    setPreferencesLoaded(true);
  }

  function showOperatorNotice(message: string, tone: OperatorNotice["tone"] = "info") {
    setOperatorNotice({ message, tone });
  }

  async function pairLfExactProducts(offset = 0) {
    if (pairingAction !== null || active || action !== null) return;
    setPairingAction(offset > 0 ? "resume" : "save");
    setError(null);
    setExactPairResult(null);
    showOperatorNotice(
      offset > 0
        ? `LF párosítás folytatása a mentett ponttól: ${offset}.`
        : "LF exact párosítás indul. Csak saját C: találatnál ment mappinget és termékoldal URL-t; ár/profit adatot nem ír.",
      "info"
    );
    openCloakBrowserManagerWindow(
      cloakBrowserManagerWindowRef,
      (message, tone) => showOperatorNotice(message, tone),
      "info",
      "CloakBrowser megnyitva. Jelentkezz be a Danetti LF profilban, ha az oldal kéri."
    );
    try {
      const started = await startLfManualBatch({
        markupPercent: 0,
        vatPercent: savedPreferencesRef.current.vatPercent,
        wooPricesIncludeVat: true,
        speedMode,
        limit: ALL_LF_BATCH_LIMIT,
        offset,
        onlyMappedLf: false,
        allowSuggestedLfArticle: true,
        allowSkuPrefixCandidate: true,
        dryRun: false,
        allowSnapshotWrite: false,
        manualLoginTimeoutMs: 900_000,
      });
      storeRunId(started.runId, "pairing");
      setState(started);
      showOperatorNotice(
        offset > 0
          ? `LF exact párosítás háttérfutás folytatása mentett ponttól: ${offset}.`
          : "LF exact párosítás háttérfutás indítva. Saját C: találatnál mappinget és linket ment, árat nem ír.",
        "success"
      );
      void continueLfManualBatch(started.runId)
        .then((nextState) => {
          setState(nextState);
          return getLfManualBatchProgress();
        })
        .then((progress) => setSavedProgress(progress.progress))
        .catch((err) => setError(formatLfOperatorErrorMessage(err)));
      const supplierResponse = await listSuppliers({ limit: 100 });
      const nextSupplier = supplierResponse.items.find(isLfSupplier) ?? fallbackLfSupplier;
      if (isUuid(nextSupplier.id)) setMappings(await listAllSupplierMappings(nextSupplier.id));
    } catch (err) {
      setError(formatLfOperatorErrorMessage(err));
    } finally {
      setPairingAction(null);
    }
  }

  async function startFullRun() {
    if (canRestartLogin && state) {
      await restartFullRun(state.runId);
      return;
    }
    await startRunAtOffset(0);
  }

  async function resumeRun() {
    await startRunAtOffset(priceResumeOffset);
  }

  async function startRunAtOffset(offset: number) {
    if (action !== null || startActionInFlightRef.current) return;
    const runOffset = rerunPreviousNonOkOnly ? 0 : offset;
    const remaining = Math.max(totalMapped - runOffset, 0);
    if (remaining === 0) {
      setError("Nincs hátralévő LF mapping.");
      return;
    }

    startActionInFlightRef.current = true;
    setAction(runOffset === 0 ? "start" : "continue");
    setError(null);
    setOperatorNotice(null);
    showOperatorNotice("Danetti LF profil indítása a CloakBrowserben...", "info");
    const cloakBrowserWindowReserved = reserveCloakBrowserManagerWindow(
      cloakBrowserManagerWindowRef,
      (message) => showOperatorNotice(message, "warning")
    );
    try {
      const started = await startLfManualBatch({
        markupPercent: 0,
        vatPercent: savedPreferencesRef.current.vatPercent,
        wooPricesIncludeVat: true,
        speedMode,
        limit: Math.min(remaining, ALL_LF_BATCH_LIMIT),
        offset: runOffset,
        onlyMappedLf: true,
        rerunPreviousNonOkOnly,
        allowSuggestedLfArticle: false,
        allowSkuPrefixCandidate: false,
        dryRun: true,
        allowSnapshotWrite: false,
        manualLoginTimeoutMs: 900_000,
      });
      storeRunId(started.runId, "price");
      setState(started);
      showOperatorNotice(
        rerunPreviousNonOkOnly
          ? "LF futás indítva csak az előző nem OK tételekre."
          : runOffset > 0
            ? `LF futás kézi folytatása mentett ponttól: ${runOffset}.`
            : "LF futás indítva. A Danetti LF profil login oldala nyílik; sikeres login után a futás automatikusan továbbmegy.",
        "success"
      );
      openCloakBrowserManagerWindow(cloakBrowserManagerWindowRef, (message, tone) =>
        showOperatorNotice(message, tone)
      );

      void continueLfManualBatch(started.runId)
        .then(setState)
        .catch((err) => setError(formatLfOperatorErrorMessage(err)));
    } catch (err) {
      setError(formatLfOperatorErrorMessage(err));
      if (isCloakBrowserError(err)) {
        openCloakBrowserManagerWindow(
          cloakBrowserManagerWindowRef,
          (message, tone) => showOperatorNotice(message, tone),
          "warning",
          "CloakBrowser Manager megnyitva. Válaszd a Danetti LF profilt, ha nem indult el automatikusan."
        );
      } else if (cloakBrowserWindowReserved) {
        closeCloakBrowserManagerWindow(cloakBrowserManagerWindowRef);
      }
    } finally {
      startActionInFlightRef.current = false;
      setAction(null);
    }
  }

  async function recoverAfterReconnect(reason: string) {
    if (reconnectRecoveryInFlightRef.current) return;
    reconnectRecoveryInFlightRef.current = true;
    try {
      const [current, progress, savedState] = await Promise.all([
        getCurrentLfManualBatch(),
        getLfManualBatchProgress(),
        getSavedLfManualBatchState(),
      ]);
      setSavedProgress(progress.progress);

      if (current.run) {
        storeRunId(current.run.runId, getLfRunKind(current.run));
        setState(current.run);
        setError(null);
        return;
      }

      const savedRun = savedState.run ? normalizeInactiveSavedRun(savedState.run) : null;
      if (savedRun) {
        storeRunId(savedRun.runId, getLfRunKind(savedRun));
        setState(savedRun);
      }

      const nextOffset = readRecoveredOffset(progress.progress, savedRun, state, processedOverall);
      const recoverySource = savedRun ?? state;
      const recoveryTotal = recoverySource
        ? getLfRunDisplayedTotal(recoverySource, totalMapped)
        : totalMapped;
      if (!autoResume || nextOffset >= recoveryTotal || nextOffset < 0) return;
      if (savedRun?.status === "completed") return;

      showOperatorNotice(
        `${labelLfRunKind(getLfRunKind(recoverySource))} megszakadt, mentett pont elérhető: ${nextOffset}. Új login/session csak a saját folytatás gombbal indul. (${reason})`,
        "warning"
      );
    } catch (err) {
      if (isLocalApiUnavailableError(err)) {
        showOperatorNotice(
          "Helyi API kapcsolat ellenőrzése folyamatban. Az LF futás mentett pontból folytatható.",
          "warning"
        );
      } else {
        setError(formatLfOperatorErrorMessage(err));
      }
    } finally {
      reconnectRecoveryInFlightRef.current = false;
    }
  }

  async function restartFullRun(runId: string) {
    setAction("start");
    setError(null);
    showOperatorNotice("Beragadt LF futás leállítása, majd új login indítása...", "warning");
    try {
      await cancelLfManualBatch(runId).catch(() => undefined);
      await startRunAtOffset(0);
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setAction(null);
    }
  }

  async function continueCurrentRun() {
    if (!state) return;
    setAction("continue");
    setError(null);
    try {
      setState(await continueLfManualBatch(state.runId));
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setAction(null);
    }
  }

  async function cancelRun() {
    if (!state) return;
    if (
      !window.confirm(
        "Leállítod az aktív LF futást? A mentett pont megmarad, de folytatáshoz új LF login kellhet."
      )
    ) {
      return;
    }
    setAction("cancel");
    setError(null);
    try {
      setState(await cancelLfManualBatch(state.runId));
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setAction(null);
    }
  }

  if (loading) return <LoadingState message="LF operátor betöltése..." />;

  return (
    <div className="page dvg-operator-page">
      {error ? <ErrorState message={error} /> : null}
      {operatorNotice ? (
        <div className={`notice ${operatorNotice.tone} dvg-operator-notice`}>
          {operatorNotice.message}
        </div>
      ) : null}

      <section className="dvg-cockpit" aria-labelledby="lf-cockpit-title">
        <div className="dvg-cockpit-header">
          <div className="dvg-cockpit-title-block">
            <p className="dvg-kicker">LF operátor</p>
            <h1 className="page-title" id="lf-cockpit-title">
              LF profit futás
            </h1>
          </div>
        </div>

        <div className="dvg-operator-card dvg-settings-band">
          <div className="dvg-card-heading">
            <span>Indítási beállítások</span>
          </div>
          <div className="form-grid dvg-settings-grid">
            <label className="field-label">
              Sebesség
              <select
                className="input"
                value={speedMode}
                onChange={(event) => setSpeedMode(event.target.value as LfManualBatchSpeedMode)}
                disabled={active || action !== null}
              >
                {speedModeOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <span className="field-help">
                {speedModeOptions.find((option) => option.value === speedMode)?.help}
              </span>
            </label>
            <div className="field-label">
              Újrafuttatás
              <label className="supplier-changes-toggle">
                <input
                  type="checkbox"
                  checked={rerunPreviousNonOkOnly}
                  disabled={active || action !== null}
                  onChange={(event) => setRerunPreviousNonOkOnly(event.target.checked)}
                />
                <span>Csak előző nem OK tételek</span>
              </label>
              <span className="field-help">OK státuszú és még sosem futott mapping kimarad.</span>
            </div>
            <div className="supplier-pairing-field">
              <div className="supplier-pairing-panel">
                <div className="supplier-pairing-copy">
                  <span className="supplier-pairing-eyebrow">Termékpárosító</span>
                  <strong>LF linkpárosítás DVG nélküli termékekre</strong>
                  <span>
                    Ez nem árlekérés: csak exact LF saját terméket, cikkszámot és detail URL-t
                    validál. Saját C: találatnál mappinget és linket ment; árat nem ír. Az A:
                    kereszthivatkozás csak a főforrás-jelöltet mutatja.
                  </span>
                </div>
                <div className="supplier-pairing-actions">
                  <button
                    className="button"
                    type="button"
                    onClick={() => pairLfExactProducts()}
                    disabled={!canRunPairing}
                  >
                    {pairingAction === "save"
                      ? "Exact LF mappingek mentése..."
                      : "LF bejelentkezés + exact mappingek mentése"}
                  </button>
                  <button
                    className="button secondary"
                    type="button"
                    onClick={() => pairLfExactProducts(pairingResumeOffset)}
                    disabled={!canResumePairing}
                  >
                    {pairingAction === "resume"
                      ? "Folytatás folyamatban..."
                      : "Linkpárosítás folytatása"}
                  </button>
                </div>
                <span className="field-help">
                  {exactPairResult
                    ? formatLfExactAutoPairCompactResult(exactPairResult)
                    : canResumePairing
                      ? `LF linkpárosítási folytatási pont: ${pairingResumeOffset}/${pairingResumeTotal}. Innen folytatható.`
                      : "Nincs félbehagyott linkpárosítás. Az exact C: találat mappinget és linket ment; árfrissítéshez az alsó gomb való."}
                </span>
              </div>
            </div>
          </div>
          <div className="dvg-settings-actions">
            <span>
              {preferenceStatus === "saving"
                ? "Beállítás mentése..."
                : preferenceStatus === "error"
                  ? "Beállítás mentés hiba"
                  : "Módosítás után automatikusan mentve"}
            </span>
          </div>
        </div>

        <div className="dvg-action-grid">
          <div className="dvg-operator-card dvg-next-action-card">
            <div className="dvg-card-heading">
              <span>Következő lépés</span>
              <strong>{guidance.title}</strong>
            </div>
            <p>{guidance.body}</p>
            <p className="dvg-run-note">
              Mentett LF ár-mappingek: {totalMapped}. Árfrissítési folytatás:{" "}
              {priceResumeOffset > 0 ? priceResumeOffset : "nincs mentett pont"}.
            </p>
            {rerunPreviousNonOkOnly ? (
              <p className="dvg-run-note">
                Bekapcsolva: indításkor csak az előző LF árfrissítésben nem OK státuszú mentett
                mappingek kerülnek sorra.
              </p>
            ) : null}
            <div className="dvg-action-row dvg-action-row--primary">
              <button
                className="button"
                onClick={startFullRun}
                disabled={!canStart && !canRestartLogin}
              >
                {action === "start"
                  ? "CloakBrowser nyitása..."
                  : canRestartLogin
                    ? "LF login újranyitása"
                    : "LF bejelentkezés + árak frissítése"}
              </button>
              <button className="button secondary" onClick={resumeRun} disabled={!canResume}>
                {action === "continue" ? "Folytatás indítása..." : "Árfrissítés folytatása"}
              </button>
              {canContinueCurrent ? (
                <button
                  className="button secondary"
                  onClick={continueCurrentRun}
                  disabled={action !== null}
                >
                  Login után folytatás
                </button>
              ) : null}
              {active ? (
                <button className="button secondary" onClick={cancelRun} disabled={action !== null}>
                  {action === "cancel" ? "Leállítás..." : "Futás leállítása"}
                </button>
              ) : null}
            </div>
          </div>

          <div className="dvg-operator-card dvg-login-state-card">
            <span className={`badge ${guidance.tone}`}>{guidance.badge}</span>
            <strong>{labelRunStatus(state?.status ?? "not_started")}</strong>
            <span>{progressCounterLabel}</span>
            <small>{liveStatus.detail}</small>
          </div>
        </div>

        <div className="dvg-live-terminal-grid">
          <div className="dvg-operator-card dvg-live-tracking-card" ref={liveTrackingCardRef}>
            <div className="dvg-live-tracking-content">
              <div className="dvg-workbench-topline">
                <div>
                  <span>Futás állapota</span>
                  <strong>{progressPercent.toFixed(1)}%</strong>
                </div>
                <div className="dvg-workbench-counters" aria-label="LF futás számlálók">
                  <span>{progressCounterLabel}</span>
                  <span>{remainingCounterLabel}</span>
                  <span>{nextPointLabel}</span>
                  <span>{updatedLabel}</span>
                </div>
              </div>
              <div
                className="dvg-progress-track"
                role="progressbar"
                aria-label="LF feldolgozási arány"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Math.round(Math.min(progressPercent, 100))}
              >
                <div
                  className="dvg-progress-fill"
                  style={{ width: `${Math.min(progressPercent, 100)}%` }}
                />
                <span className="dvg-progress-scan" />
              </div>
              <div className="dvg-workbench-command">
                <span className={`badge ${liveStatus.badgeTone}`}>{liveStatus.phase}</span>
                <strong>{liveStatus.headline}</strong>
                <code>{labelRunStatus(state?.status ?? "not_started")}</code>
              </div>

              <div className="dvg-workbench-main">
                <section className="dvg-active-target" aria-label="Aktuális LF célpont">
                  <div className="dvg-active-target-identity">
                    <span>Aktuális célpont</span>
                    <strong>
                      {state?.currentItem?.supplierArticleNumber ?? "nincs aktív tétel"}
                    </strong>
                    <code>{state?.currentItem?.wooSku ?? "-"}</code>
                    <p>
                      {state?.currentItem?.wooName ??
                        "Indítás után itt látszik az éppen keresett LF termék."}
                    </p>
                  </div>
                  <div className="dvg-active-target-runtime">
                    <CockpitFact label="Run" value={readLiveField(liveStatus, "Run idő")} />
                    <CockpitFact label="Tétel" value={readLiveField(liveStatus, "Tétel idő")} />
                    <CockpitFact label="Átlag/tétel" value={averageItemDuration} />
                    <CockpitFact label="Teljes becslés" value={estimatedFullRunDuration} />
                    <CockpitFact label="Következő" value={readLiveField(liveStatus, "Következő")} />
                  </div>
                </section>

                <section className="dvg-status-board" aria-label="LF státusz bontás">
                  <div className="dvg-status-board-header">
                    <span>Státusz bontás</span>
                    <strong>{runChecked || savedProgress?.checked || 0} sor</strong>
                  </div>
                  <div className="dvg-status-tiles">
                    {workbenchStatusTiles.map((tile) => (
                      <WorkbenchStatusTileView key={tile.label} tile={tile} />
                    ))}
                  </div>
                </section>
              </div>

              <div className="dvg-workbench-telemetry" aria-label="LF futás telemetria">
                <CockpitMetric label="Fetch" value={runTelemetry?.detailFetchCompleted ?? 0} />
                <CockpitMetric
                  label="Átlag"
                  value={formatMilliseconds(runTelemetry?.avgDetailFetchMs ?? null)}
                />
                <CockpitMetric
                  label="P95"
                  value={formatMilliseconds(runTelemetry?.p95DetailFetchMs ?? null)}
                />
                <CockpitMetric
                  label="/perc"
                  value={formatRate(runTelemetry?.itemsPerMinute ?? null)}
                />
                <CockpitMetric label="Recovery" value={runTelemetry?.sessionRecoveries ?? 0} />
                <CockpitMetric label="Pacing" value={runTelemetry?.rateLimitWaits ?? 0} />
              </div>
            </div>
          </div>

          <TerminalLog events={terminalEvents} cardRef={terminalCardRef} />
        </div>
      </section>

      {resultRows.length > 0 ? (
        <ResultsTable rows={resultRows} isPairingRun={isPairingRun} />
      ) : null}
    </div>
  );
}

function WorkbenchStatusTileView({ tile }: { tile: WorkbenchStatusTile }) {
  return (
    <div className={`dvg-status-tile ${tile.tone}`}>
      <span>{tile.label}</span>
      <strong>{tile.value}</strong>
      <small>{tile.detail}</small>
    </div>
  );
}

function CockpitMetric({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="dvg-cockpit-metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function CockpitFact({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="dvg-current-fact">
      <span>{label}</span>
      <strong className={tone ? `badge ${tone}` : undefined}>{value}</strong>
    </div>
  );
}

function ResultsTable({ rows, isPairingRun }: { rows: LfManualBatchRow[]; isPairingRun: boolean }) {
  const [columnWidths, setColumnWidths] = useState(defaultLfResultColumnWidths);
  const [columnVisibility, setColumnVisibility] = useState(readStoredLfResultColumnVisibility);
  const [columnMenuOpen, setColumnMenuOpen] = useState(false);
  const [offset, setOffset] = useState(0);
  const columnOptions = useMemo(
    () => lfResultColumns.filter((column) => !fixedLfResultColumnIds.has(column.id)),
    []
  );
  const visibleColumns = useMemo(
    () => lfResultColumns.filter((column) => columnVisibility[column.id] !== false),
    [columnVisibility]
  );
  const visibleOptionalColumnCount = useMemo(
    () => columnOptions.filter((column) => columnVisibility[column.id] !== false).length,
    [columnOptions, columnVisibility]
  );
  const totalTableWidth = useMemo(
    () => visibleColumns.reduce((total, column) => total + columnWidths[column.id], 0),
    [columnWidths, visibleColumns]
  );
  const pageRows = rows.slice(offset, offset + LF_TABLE_PAGE_SIZE);
  const canGoBack = offset > 0;
  const canGoNext = offset + pageRows.length < rows.length;
  const paginationLabel = buildLocalPaginationLabel(rows.length, offset, pageRows.length);

  useEffect(() => {
    if (rows.length === 0 && offset !== 0) {
      setOffset(0);
      return;
    }
    if (rows.length > 0 && offset >= rows.length) {
      setOffset(Math.floor((rows.length - 1) / LF_TABLE_PAGE_SIZE) * LF_TABLE_PAGE_SIZE);
    }
  }, [offset, rows.length]);

  function beginColumnResize(columnId: LfResultColumnId, event: ReactMouseEvent<HTMLSpanElement>) {
    event.preventDefault();
    const startX = event.clientX;
    const startWidth = columnWidths[columnId];
    const minWidth = lfResultColumns.find((column) => column.id === columnId)?.minWidth ?? 90;
    const previousCursor = document.body.style.cursor;
    const previousUserSelect = document.body.style.userSelect;

    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";

    function handleMouseMove(moveEvent: MouseEvent) {
      const nextWidth = Math.max(minWidth, startWidth + moveEvent.clientX - startX);
      setColumnWidths((current) => ({ ...current, [columnId]: nextWidth }));
    }

    function stopResize() {
      window.removeEventListener("mousemove", handleMouseMove);
      document.body.style.cursor = previousCursor;
      document.body.style.userSelect = previousUserSelect;
    }

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", stopResize, { once: true });
  }

  function toggleColumn(columnId: LfResultColumnId, visible: boolean) {
    setColumnVisibility((current) => {
      const next = { ...current, [columnId]: visible };
      storeLfResultColumnVisibility(next);
      return next;
    });
  }

  function showAllColumns() {
    setColumnVisibility(defaultLfResultColumnVisibility);
    storeLfResultColumnVisibility(defaultLfResultColumnVisibility);
  }

  return (
    <section className="card table-card dvg-results-card">
      <div className="table-toolbar product-table-toolbar dvg-table-header">
        <div>
          <p className="card-title">{isPairingRun ? "Párosítási bizonyíték" : "Profit táblázat"}</p>
          <h2 className="section-title">
            {isPairingRun ? "LF párosítás és főforrás" : "LF eredmények"}
          </h2>
        </div>
        <TablePagination
          canGoBack={canGoBack}
          canGoNext={canGoNext}
          label={paginationLabel}
          onBack={() => setOffset(Math.max(0, offset - LF_TABLE_PAGE_SIZE))}
          onNext={() => setOffset(offset + LF_TABLE_PAGE_SIZE)}
          compact
        />
        <div
          className="product-view-controls dvg-table-actions"
          role="group"
          aria-label="LF eredmény nézet"
        >
          <span className="badge muted">{rows.length} sor</span>
          <div className="column-menu-wrap dvg-column-menu-wrap">
            <button
              className="button secondary product-column-menu-button"
              type="button"
              aria-expanded={columnMenuOpen}
              onClick={() => setColumnMenuOpen((current) => !current)}
            >
              Oszlopok ({visibleOptionalColumnCount}/{columnOptions.length})
            </button>
            {columnMenuOpen ? (
              <div className="column-menu" role="menu">
                <div className="column-menu-header">
                  <strong>Oszlopok megjelenítése</strong>
                  <button className="button small secondary" type="button" onClick={showAllColumns}>
                    Mind vissza
                  </button>
                </div>
                {columnOptions.map((column) => (
                  <label className="column-toggle" key={column.id}>
                    <input
                      type="checkbox"
                      checked={columnVisibility[column.id] !== false}
                      onChange={(event) => toggleColumn(column.id, event.target.checked)}
                    />
                    <span>{column.label}</span>
                  </label>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      </div>
      <div className="table-scroll dvg-table-scroll">
        <table
          className="table data-table data-table--wide dvg-profit-table data-table--sheet"
          style={{ width: "100%", minWidth: totalTableWidth }}
        >
          <colgroup>
            {visibleColumns.map((column) => (
              <col key={column.id} style={{ width: columnWidths[column.id] }} />
            ))}
          </colgroup>
          <thead>
            <tr>
              {visibleColumns.map((column) => (
                <th
                  className={`resizable-header cell-nowrap ${"numeric" in column && column.numeric ? "numeric" : ""}`}
                  key={column.id}
                >
                  {column.label}
                  <span
                    aria-hidden="true"
                    className="column-resizer"
                    onMouseDown={(event) => beginColumnResize(column.id, event)}
                  />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((row) => (
              <tr key={`${row.catalogProductId}-${row.supplierArticleNumber}`}>
                {visibleColumns.map((column) => renderLfResultCell(row, column.id))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <TablePagination
        canGoBack={canGoBack}
        canGoNext={canGoNext}
        label={paginationLabel}
        onBack={() => setOffset(Math.max(0, offset - LF_TABLE_PAGE_SIZE))}
        onNext={() => setOffset(offset + LF_TABLE_PAGE_SIZE)}
      />
    </section>
  );
}

function renderLfResultCell(row: LfManualBatchRow, columnId: LfResultColumnId) {
  switch (columnId) {
    case "status": {
      const statusInfo = lfRowStatusInfo(row);
      return (
        <td key={columnId}>
          <span className={`badge ${statusInfo.tone}`}>{statusInfo.label}</span>
        </td>
      );
    }
    case "sku":
      return (
        <td className="cell-mono cell-nowrap" key={columnId}>
          {row.wooSku}
        </td>
      );
    case "name":
      return (
        <td className="cell-wrap" key={columnId}>
          {row.wooName}
        </td>
      );
    case "mainSource": {
      const source = readLfMainSource(row);
      return (
        <td className="cell-wrap" key={columnId}>
          <span className={`badge ${source.tone}`}>{source.label}</span>
          <div className="cell-muted">{source.detail}</div>
        </td>
      );
    }
    case "article":
      return (
        <td className="cell-mono cell-nowrap" key={columnId}>
          {row.supplierArticleNumber}
        </td>
      );
    case "autocomplete":
      return (
        <td className="cell-wrap" key={columnId}>
          <div className="cell-mono">{row.lfAutocompleteId ?? "-"}</div>
          {row.lfAutocompleteValue ? (
            <div className="cell-muted">{row.lfAutocompleteValue}</div>
          ) : null}
        </td>
      );
    case "partNumber":
      return (
        <td className="cell-mono cell-nowrap" key={columnId}>
          {row.lfPartNumber ?? "-"}
        </td>
      );
    case "supplierNetEur":
      return <td key={columnId}>{formatMoney(row.supplierNetEur, row.currency)}</td>;
    case "supplierNetHuf":
      return <td key={columnId}>{formatHuf(row.supplierNetHuf)}</td>;
    case "wooGrossHuf":
      return <td key={columnId}>{formatHuf(row.wooGrossHuf)}</td>;
    case "wooNetHuf":
      return <td key={columnId}>{formatHuf(row.wooNetHuf)}</td>;
    case "profitHuf":
      return <td key={columnId}>{formatHuf(row.actualProfitNetHuf)}</td>;
    case "profitPercent":
      return <td key={columnId}>{formatPercent(row.actualProfitPercentOnCost)}</td>;
    case "warnings":
      return (
        <td className="cell-wrap" key={columnId}>
          {formatSupplierWarnings(row.warnings, row.matchConfidence || "-")}
        </td>
      );
  }
}

function readLfMainSource(row: LfManualBatchRow): {
  label: string;
  detail: string;
  tone: "success" | "warning" | "muted";
} {
  const autocompleteId = row.lfAutocompleteId?.trim() ?? "";
  const manufacturer = row.lfManufacturerName?.trim() ?? "";

  if (autocompleteId.startsWith("C:")) {
    return { label: "LF", detail: "saját exact C: találat", tone: "success" };
  }
  if (row.status === "cross_reference_only" || autocompleteId.startsWith("A:")) {
    if (/de\s*vecchi|devecchi/i.test(manufacturer)) {
      return {
        label: "DVG-jelölt",
        detail: manufacturer || "LF kereszthivatkozás",
        tone: "warning",
      };
    }
    return {
      label: "Külső jelölt",
      detail: manufacturer || "LF kereszthivatkozás; forrásellenőrzés kell",
      tone: "warning",
    };
  }
  if (row.supplierMappingId && row.candidateSource === "saved_mapping") {
    return { label: "LF", detail: "mentett LF mapping", tone: "success" };
  }
  return { label: "Nincs igazolva", detail: "nem találtunk biztos főforrást", tone: "muted" };
}

function TerminalLog({
  events,
  cardRef,
}: {
  events: NonNullable<LfManualBatchState["events"]>;
  cardRef: Ref<HTMLDivElement>;
}) {
  const visibleEvents = events.slice(-80);
  const lastVisibleEventId = visibleEvents[visibleEvents.length - 1]?.id ?? "empty";
  const screenRef = useRef<HTMLDivElement | null>(null);

  useLayoutEffect(() => {
    const screen = screenRef.current;
    if (!screen) return;
    const frame = window.requestAnimationFrame(() => {
      screen.scrollTop = screen.scrollHeight;
    });
    return () => window.cancelAnimationFrame(frame);
  }, [lastVisibleEventId]);

  return (
    <div className="dvg-operator-card dvg-terminal-card" ref={cardRef}>
      <div className="dvg-terminal-header">
        <div>
          <span>Live preview</span>
          <strong>LF futási események</strong>
        </div>
      </div>
      <div className="dvg-terminal-screen" ref={screenRef} role="log" aria-label="LF live preview">
        {visibleEvents.length === 0 ? (
          <div className="dvg-terminal-line is-muted">
            <time>--:--:--</time>
            <code>idle</code>
            <span>-</span>
            <strong>Indítás után itt jelenik meg minden LF lépés.</strong>
          </div>
        ) : (
          visibleEvents.map((event) => (
            <div className="dvg-terminal-line" key={event.id}>
              <time>{formatTime(event.createdAt)}</time>
              <code>{labelLfEventType(event.type)}</code>
              <span>{event.article ?? event.path ?? "-"}</span>
              <strong>{formatLfEventMessage(event)}</strong>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function labelLfEventType(type: LfManualBatchState["events"][number]["type"]): string {
  const labels: Record<LfManualBatchState["events"][number]["type"], string> = {
    runStarted: "indítás",
    browserOpened: "böngésző",
    manualLoginWaiting: "login kell",
    loginDetected: "login OK",
    itemStarted: "termék",
    autocompleteStarted: "keresés",
    autocompleteDone: "találatok",
    candidateSelected: "választás",
    detailOpened: "termékoldal",
    priceParsed: "ár",
    calculationDone: "számítás",
    itemFailed: "nem menthető",
    itemSkipped: "kihagyva",
    rateLimitWait: "várakozás",
    browserRecovery: "session",
    runCompleted: "kész",
    runStopped: "megállt",
  };
  return labels[type] ?? type;
}

function formatLfEventMessage(event: LfManualBatchState["events"][number]): string {
  if (/LF exact auto-pair run created/i.test(event.message)) {
    return "LF párosítási futás létrehozva.";
  }
  if (/LF manual batch run created/i.test(event.message)) {
    return "LF árlekérő futás létrehozva.";
  }
  if (/LF browser opened/i.test(event.message)) {
    return "LF böngésző megnyitva.";
  }
  if (/Manual LF login waiting/i.test(event.message)) {
    return "Jelentkezz be az LF ablakban.";
  }
  if (/LF login detected/i.test(event.message)) {
    return "LF belépés érzékelve, indulhat a keresés.";
  }
  if (/Manual LF login timeout/i.test(event.message)) {
    return "LF belépési idő lejárt.";
  }
  if (/No LF exact candidates found/i.test(event.message)) {
    return "Nincs új DVG nélküli LF jelölt ebben a csomagban.";
  }
  return event.message;
}

async function listAllSupplierMappings(supplierId: string): Promise<SupplierMapping[]> {
  const items: SupplierMapping[] = [];
  let offset = 0;

  while (true) {
    const response = await listSupplierMappings({
      supplierId,
      enabled: true,
      limit: MAPPING_PAGE_SIZE,
      offset,
    });
    const pageItems = response.items ?? [];
    items.push(...pageItems);
    if (pageItems.length < MAPPING_PAGE_SIZE) break;
    if (response.total !== undefined && items.length >= response.total) break;
    offset += pageItems.length;
    if (pageItems.length === 0) break;
  }

  return items;
}

function openCloakBrowserManagerWindow(
  managerWindowRef: { current: Window | null },
  setNotice: (message: string, tone: OperatorNotice["tone"]) => void,
  openedTone: OperatorNotice["tone"] = "success",
  openedMessage = "CloakBrowser megnyitva. Ha az LF login oldal még nem látszik, kattints a Danetti LF profilra."
): void {
  if (typeof window === "undefined") return;
  const existingWindow = managerWindowRef.current;
  if (existingWindow && !existingWindow.closed) {
    existingWindow.location.href = CLOAKBROWSER_MANAGER_URL;
    existingWindow.focus();
    setNotice(openedMessage, openedTone);
    return;
  }

  const opened = window.open(CLOAKBROWSER_MANAGER_URL, "danetti-cloakbrowser-manager");
  if (opened) {
    managerWindowRef.current = opened;
    opened.focus();
    setNotice(openedMessage, openedTone);
    return;
  }
  setNotice(
    `A böngésző blokkolta az automatikus Manager tabot. Nyisd meg kézzel: ${CLOAKBROWSER_MANAGER_URL}`,
    "warning"
  );
}

function reserveCloakBrowserManagerWindow(
  managerWindowRef: { current: Window | null },
  setNotice: (message: string) => void
): boolean {
  if (typeof window === "undefined") return false;
  const existingWindow = managerWindowRef.current;
  if (existingWindow && !existingWindow.closed) {
    existingWindow.focus();
    return true;
  }

  const opened = window.open("about:blank", "danetti-cloakbrowser-manager");
  if (!opened) {
    setNotice(
      `A böngésző blokkolta a CloakBrowser ablakot. Ha nem nyílik meg, engedélyezd a popupot vagy nyisd meg kézzel: ${CLOAKBROWSER_MANAGER_URL}`
    );
    return false;
  }

  managerWindowRef.current = opened;
  try {
    opened.document.title = "Danetti LF indítás";
    opened.document.body.textContent = "Danetti LF profil indítása...";
  } catch {
    return true;
  }
  opened.focus();
  return true;
}

function closeCloakBrowserManagerWindow(managerWindowRef: { current: Window | null }): void {
  const managerWindow = managerWindowRef.current;
  if (!managerWindow || managerWindow.closed) return;
  managerWindow.close();
  managerWindowRef.current = null;
}

function isCloakBrowserError(error: unknown): boolean {
  const text = error instanceof Error ? `${error.name} ${error.message}` : String(error ?? "");
  return /cloakbrowser|cloak browser|cdp_unavailable|profile_launch/i.test(text);
}

function readStoredLfResultColumnVisibility(): Record<LfResultColumnId, boolean> {
  if (typeof window === "undefined") return defaultLfResultColumnVisibility;
  try {
    const parsed = JSON.parse(
      window.localStorage.getItem(LF_RESULT_COLUMN_STORAGE_KEY) ?? "{}"
    ) as Partial<Record<LfResultColumnId, boolean>>;
    return normalizeLfResultColumnVisibility(parsed);
  } catch {
    return defaultLfResultColumnVisibility;
  }
}

function storeLfResultColumnVisibility(visibility: Record<LfResultColumnId, boolean>): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(LF_RESULT_COLUMN_STORAGE_KEY, JSON.stringify(visibility));
}

function normalizeLfResultColumnVisibility(
  value: Partial<Record<LfResultColumnId, boolean>>
): Record<LfResultColumnId, boolean> {
  return lfResultColumns.reduce(
    (visibility, column) => ({
      ...visibility,
      [column.id]: fixedLfResultColumnIds.has(column.id) ? true : value[column.id] !== false,
    }),
    {} as Record<LfResultColumnId, boolean>
  );
}

function normalizeInactiveSavedRun(run: LfManualBatchState): LfManualBatchState {
  if (terminalStatuses.has(run.status)) return run;
  return {
    ...run,
    status: "interrupted",
    completedAt: run.completedAt ?? run.startedAt,
  };
}

function readRecoveredOffset(
  progress: LfManualBatchProgress | null,
  savedRun: LfManualBatchState | null,
  currentState: LfManualBatchState | null,
  fallbackOffset: number
): number {
  const source = savedRun ?? currentState;
  if (progress?.nextOffset !== undefined && (!source || progress.runId === source.runId)) {
    return progress.nextOffset;
  }
  if (!source) return fallbackOffset;
  return source.settings.offset + countProgressAdvancingRows(source.rows);
}

function getLfRunKind(state: LfManualBatchState | null): LfRunKind | null {
  if (!state) return null;
  return state.settings.onlyMappedLf === false ? "pairing" : "price";
}

function labelLfRunKind(kind: LfRunKind | null): string {
  if (kind === "pairing") return "LF linkpárosítás";
  if (kind === "price") return "LF árfrissítés";
  return "LF futás";
}

function getLfRunDisplayedTotal(state: LfManualBatchState, totalMapped: number): number {
  return getLfRunKind(state) === "pairing" || state.settings.rerunPreviousNonOkOnly
    ? state.settings.offset + state.totals.candidates
    : totalMapped;
}

function buildScopedRunProgress(
  state: LfManualBatchState | null,
  progress: LfManualBatchProgress | null,
  totalMapped: number
): ScopedRunProgress | null {
  const kind = getLfRunKind(state);
  if (!state || !kind) return null;
  const total = getLfRunDisplayedTotal(state, totalMapped);
  const rowNextOffset = state.settings.offset + countProgressAdvancingRows(state.rows);
  const savedNextOffset = progress?.runId === state.runId ? progress.nextOffset : 0;
  const nextOffset = Math.max(rowNextOffset, savedNextOffset);
  return {
    runId: state.runId,
    kind,
    status: state.status,
    processed: Math.min(total, nextOffset),
    total,
    nextOffset,
    updatedAt:
      progress?.runId === state.runId ? progress.updatedAt : (state.completedAt ?? state.startedAt),
  };
}

function countProgressAdvancingRows(rows: readonly LfManualBatchRow[]): number {
  return rows.filter((row) => row.status !== "redirected_to_login").length;
}

function buildOperatorGuidance(input: {
  action: "start" | "continue" | "cancel" | null;
  active: boolean;
  state: LfManualBatchState | null;
  savedProgress: LfManualBatchProgress | null;
  isPairingRun: boolean;
  processedOverall: number;
  totalMapped: number;
}): OperatorGuidance {
  const { action, active, state, savedProgress, isPairingRun, processedOverall, totalMapped } =
    input;
  const status = state?.status ?? "not_started";
  const hasSavedResume = processedOverall > 0 && processedOverall < totalMapped;

  if (totalMapped === 0 && !isPairingRun) {
    return {
      title: "Indítható LF párosítás",
      body: "Árfrissítéshez még nincs mentett LF mapping. Előbb fent mentsd az LF linkeket a DVG nélküli termékekhez.",
      badge: "Párosítás kell",
      tone: "muted",
    };
  }

  if (action === "start") {
    return {
      title: "CloakBrowser ablak nyílik",
      body: "Várj pár másodpercet.",
      badge: "Indítás",
      tone: "warning",
    };
  }

  if (action === "continue") {
    return {
      title: "Folytatás előkészítése",
      body: `Mentett ponttól indul: ${processedOverall}.`,
      badge: "Folytatás",
      tone: "warning",
    };
  }

  if (status === "waiting_for_manual_login") {
    return {
      title: "Jelentkezz be a megnyílt LF ablakban",
      body: "Sikeres login után a futás automatikusan továbbmegy. Ha mégsem, használd a Login után folytatás gombot.",
      badge: "Te jössz",
      tone: "warning",
    };
  }

  if (active || status === "running" || status === "login_detected") {
    return {
      title: isPairingRun ? "Az LF párosítás dolgozik" : "Az LF árlekérés dolgozik",
      body: isPairingRun
        ? "LF keresővel exact saját terméket és detail URL-t validál. Nem ár/profit futás."
        : "A már mentett LF mappingek detail oldalát olvassa, árakat és profitot számol.",
      badge: "Futásban",
      tone: "success",
    };
  }

  if (status === "detached_session_failed") {
    return {
      title: "Az LF login megvolt, de a HTTP session nem indult el",
      body: "Indíts új LF logint. Credential nem kell a Danetti appba.",
      badge: "Session detach hiba",
      tone: "warning",
    };
  }

  if (status === "session_lost") {
    return {
      title: hasSavedResume
        ? "LF session elveszett, mentett pontról folytatható"
        : "LF session elveszett",
      body: hasSavedResume
        ? `Új login után innen folytatható: ${savedProgress?.nextOffset ?? processedOverall}.`
        : "Indíts új LF logint, majd futtasd újra.",
      badge: hasSavedResume ? "Új login kell" : "Session lost",
      tone: "warning",
    };
  }

  if (status === "interrupted") {
    return {
      title: hasSavedResume ? "Runtime restart után folytatható" : "A futás megszakadt",
      body: hasSavedResume
        ? `Mentett pont: ${savedProgress?.nextOffset ?? processedOverall}. Új login után folytatható.`
        : "Indíts új LF futást.",
      badge: hasSavedResume ? "Interrupted" : "Megszakadt",
      tone: "warning",
    };
  }

  if (status === "failed") {
    return {
      title: hasSavedResume ? "Megállt, de mentett pontról folytatható" : "A futás hibával megállt",
      body: hasSavedResume
        ? `Mentett pont innen folytatható: ${savedProgress?.nextOffset ?? processedOverall}.`
        : "Indítsd újra az LF bejelentkezést.",
      badge: hasSavedResume ? "Folytatható" : "Hiba",
      tone: hasSavedResume ? "warning" : "danger",
    };
  }

  if (status === "login_timeout") {
    return {
      title: hasSavedResume ? "Login timeout után folytatható" : "LF login időtúllépés",
      body: hasSavedResume
        ? `${processedOverall}/${totalMapped} kész. Új login után innen megy tovább.`
        : "Indítsd újra az LF bejelentkezést.",
      badge: hasSavedResume ? "Mentett pont van" : "Login timeout",
      tone: hasSavedResume ? "warning" : "danger",
    };
  }

  if (status === "cancelled") {
    return {
      title: hasSavedResume ? "Folytatható mentett státuszból" : "Indítható új LF futás",
      body: hasSavedResume
        ? `${processedOverall}/${totalMapped} kész. Innen megy tovább.`
        : "Nyisd meg, jelentkezz be, kész.",
      badge: hasSavedResume ? "Mentett pont van" : "Készen áll",
      tone: hasSavedResume ? "warning" : "success",
    };
  }

  if (status === "completed") {
    return {
      title: isPairingRun ? "Az LF linkpárosítás kész" : "Az LF árfrissítés kész",
      body: isPairingRun
        ? "A biztos LF cikkszámok és termékoldal URL-ek mentve vannak. Ami nem LF vagy bizonytalan, kimaradt."
        : "Az OK ár/profit sorok mentve vannak.",
      badge: "Kész",
      tone: "success",
    };
  }

  return {
    title: hasSavedResume
      ? "Folytasd a legutóbbi mentett ponttól"
      : "Indítsd el az LF árfrissítést",
    body: hasSavedResume
      ? `${processedOverall}/${totalMapped} már kész.`
      : "A már mentett LF mappingekhez kér árakat és profitot számol.",
    badge: hasSavedResume ? "Folytatható" : "Készen áll",
    tone: hasSavedResume ? "warning" : "success",
  };
}

function readLiveField(status: LiveStatus, label: string): string {
  return status.fields.find((field) => field.label === label)?.value ?? "-";
}

function buildLiveStatus(input: {
  state: LfManualBatchState | null;
  totalMapped: number;
  runOffset: number;
  currentGlobalIndex: number | null;
  latestEvents: NonNullable<LfManualBatchState["events"]>;
  resultRows: LfManualBatchRow[];
}): LiveStatus {
  const { state, totalMapped, runOffset, currentGlobalIndex, latestEvents, resultRows } = input;
  const current = state?.currentItem ?? null;
  const latestEvent = latestEvents[0] ?? null;
  const lastOk =
    resultRows
      .slice()
      .reverse()
      .find((row) => row.status === "ok") ?? null;
  const lastProblem =
    resultRows
      .slice()
      .reverse()
      .find((row) => row.status !== "ok") ?? null;
  const itemStartedAt = findLatestItemStartedAt(
    latestEvents,
    current?.supplierArticleNumber ?? null
  );
  const phase = current
    ? labelCurrentItemStatus(current.status)
    : labelRunStatus(state?.status ?? "not_started");
  const headline = current
    ? `${current.supplierArticleNumber} feldolgozása`
    : state
      ? `Run állapot: ${labelRunStatus(state.status)}`
      : "Nincs aktív LF futás";
  const latestMessage = latestEvent
    ? `${formatTime(latestEvent.createdAt)} - ${latestEvent.message}`
    : "Még nincs esemény.";

  return {
    headline,
    phase,
    badgeTone: liveStatusTone(state?.status ?? "not_started", current?.status ?? null),
    detail: `Utolsó esemény: ${latestMessage}`,
    fields: [
      { label: "Run", value: state?.runId ?? "nincs" },
      { label: "Állapot", value: labelRunStatus(state?.status ?? "not_started") },
      {
        label: "Aktuális",
        value: currentGlobalIndex
          ? `${currentGlobalIndex}/${totalMapped || current?.total || "-"}`
          : "-",
      },
      { label: "Offset", value: String(runOffset) },
      { label: "SKU", value: current?.wooSku ?? "-" },
      { label: "LF cikkszám", value: current?.supplierArticleNumber ?? "-" },
      { label: "Termék", value: current?.wooName ?? "-" },
      { label: "Run idő", value: state?.startedAt ? formatElapsedSince(state.startedAt) : "-" },
      { label: "Tétel idő", value: itemStartedAt ? formatElapsedSince(itemStartedAt) : "-" },
      {
        label: "Utolsó OK",
        value: lastOk ? `${lastOk.supplierArticleNumber} / ${lastOk.wooSku}` : "-",
      },
      {
        label: "Utolsó hiba",
        value: lastProblem
          ? `${labelItemStatus(lastProblem.status)} / ${lastProblem.supplierArticleNumber}`
          : "-",
      },
      {
        label: "Következő",
        value: nextStepForCurrentStatus(current?.status ?? state?.status ?? null),
      },
    ],
  };
}

function buildWorkbenchStatusTiles(input: {
  rows: LfManualBatchRow[];
  state: LfManualBatchState | null;
  savedProgress: LfManualBatchProgress | null;
  isPairingRun: boolean;
}): WorkbenchStatusTile[] {
  const { rows, state, savedProgress, isPairingRun } = input;
  const summary = state?.summary ?? null;
  const totals = state?.totals ?? null;
  const displayCounts = countRowsByDisplayStatus(rows);
  const hasRows = rows.length > 0;
  const priceMissing = hasRows ? displayCounts.missing_price : (summary?.priceMissing ?? 0);
  const ambiguousMatch = hasRows
    ? displayCounts.ambiguous_match
    : (summary?.needsMappingReview ?? 0);
  const timeoutOrLogin = hasRows
    ? displayCounts.timeout + displayCounts.login_required
    : (summary?.itemTimeouts ?? 0) + (summary?.redirectedToLogin ?? 0);
  const failed = hasRows ? displayCounts.failed : (totals?.failed ?? savedProgress?.failed ?? 0);
  const skipped = totals?.skipped ?? savedProgress?.skipped ?? 0;
  const ok = hasRows ? displayCounts.ok : (totals?.ok ?? savedProgress?.ok ?? 0);

  return [
    {
      label: "OK",
      value: ok,
      detail: isPairingRun ? "exact LF mapping mentve" : "árral feldolgozva",
      tone: "success",
    },
    {
      label: "Ár hiányzik",
      value: priceMissing,
      detail: "nem hiba, külön státusz",
      tone: "warning",
    },
    {
      label: "Nem rendelhető",
      value: displayCounts.unavailable,
      detail: "kifutott vagy törölt cikk",
      tone: "warning",
    },
    {
      label: "Nem saját LF cikk",
      value: displayCounts.not_supplier_own_article,
      detail: "más főforrás; név a táblázatban",
      tone: "warning",
    },
    {
      label: "Nem egyértelmű",
      value: ambiguousMatch,
      detail: "több vagy bizonytalan találat",
      tone: "warning",
    },
    {
      label: "Login / timeout",
      value: timeoutOrLogin,
      detail: "új login vagy újrafutás kell",
      tone: "danger",
    },
    {
      label: "Nincs termékoldal",
      value: displayCounts.no_product_page,
      detail: "LF keresőben nincs saját találat",
      tone: "warning",
    },
    { label: "Egyéb", value: failed + skipped, detail: "failed / kihagyott", tone: "muted" },
  ];
}

function countRowsByDisplayStatus(rows: LfManualBatchRow[]): Record<SupplierDisplayStatus, number> {
  const counts = createEmptyDisplayStatusCounts();
  for (const row of rows) counts[lfRowStatusInfo(row).status] += 1;
  return counts;
}

function findLatestItemStartedAt(
  events: NonNullable<LfManualBatchState["events"]>,
  article: string | null
): string | null {
  if (!article) return null;
  return (
    events.find((event) => event.type === "itemStarted" && event.article === article)?.createdAt ??
    null
  );
}

function formatElapsedSince(value: string): string {
  const elapsedMs = Date.now() - Date.parse(value);
  if (!Number.isFinite(elapsedMs) || elapsedMs < 0) return "-";
  const totalSeconds = Math.floor(elapsedMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes > 0 ? `${minutes}p ${seconds}mp` : `${seconds}mp`;
}

function liveStatusTone(runStatus: string, currentStatus: string | null): string {
  if (
    runStatus === "failed" ||
    runStatus === "login_timeout" ||
    runStatus === "detached_session_failed" ||
    runStatus === "session_lost" ||
    runStatus === "interrupted" ||
    currentStatus === "item_timeout"
  ) {
    return "warning";
  }
  if (runStatus === "completed") return "success";
  if (runStatus === "running" || currentStatus) return "warning";
  return "muted";
}

function labelCurrentItemStatus(status: string): string {
  const labels: Record<string, string> = {
    search_autocomplete: "autocomplete keresés",
    selecting_candidate: "LF találat választása",
    submitting_search: "keresés beküldése",
    reading_page: "oldal olvasása",
    parsing_detail: "ár és cikkszám elemzése",
    price_parsed: "ár beolvasva",
    price_missing: "ár hiányzik",
    item_not_available: "nem rendelhető",
    article_changed: "LF cikkszám változott",
    ambiguous_match: "nem egyértelmű találat",
    article_not_found: "nincs LF cikk",
    redirected_to_login: "loginra dobott",
    needs_mapping_review: "nem egyértelmű találat",
    cross_reference_only: "nem saját LF cikk",
    skipped_not_lf_candidate: "kihagyva",
    item_timeout: "tétel timeout",
    failed: "hiba",
  };
  return labels[status] ?? status;
}

function nextStepForCurrentStatus(status: string | null): string {
  const labels: Record<string, string> = {
    waiting_for_manual_login: "kézi LF login várása",
    login_detected: "terméklista indítása",
    login_timeout: "új kézi LF login indítása",
    detached_session_failed: "új kézi LF login indítása",
    running: "következő mentett LF mapping keresése",
    search_autocomplete: "autocomplete találatok értékelése",
    selecting_candidate: "C: saját LF cikkszám ellenőrzése",
    submitting_search: "detail oldal megnyitása",
    reading_page: "HTML parse",
    parsing_detail: "profit számítás",
    price_parsed: "sor mentése és várakozás",
    price_missing: "ár nélküli státusz mentése",
    item_not_available: "nem rendelhető státusz mentése",
    article_changed: "cikkszámcsere ellenőrzése",
    ambiguous_match: "mapping döntés előkészítése",
    cross_reference_only: "nem saját LF cikk jelölése",
    item_timeout: "következő termékre lépés",
    session_lost: "új kézi LF login után mentett ponttól folytatás",
    interrupted: "mentett pont visszaállítása",
    completed: "eredmények mentése a termékekhez",
  };
  return status ? (labels[status] ?? status) : "nincs aktív lépés";
}

function isLfSupplier(supplier: Supplier): boolean {
  return (
    supplier.code === LF_CONNECTOR_ID ||
    /lf|spare\s*parts\s*724/i.test(`${supplier.code} ${supplier.name}`)
  );
}

function formatLfExactAutoPairNotice(result: LfExactAutoPairResponse): string {
  const savedCount = result.createdCount + result.updatedCount;
  return [
    `LF linkpárosítás kész: ${result.checkedCount}/${result.totalCandidates} jelölt validálva.`,
    `Mapping mentve/frissítve: ${savedCount}.`,
    `Már rendben volt: ${result.verifiedCount}.`,
    `Nem LF vagy bizonytalan: ${result.rejectedCount}.`,
    `Konfliktus: ${result.conflictCount}.`,
    `DVG miatt kihagyva: ${result.skippedDvgMappedCount}.`,
    `Következő csomag: ${result.nextOffset}.`,
  ].join(" ");
}

function formatLfExactAutoPairCompactResult(result: LfExactAutoPairResponse): string {
  const writeCount = result.createdCount + result.updatedCount;
  return [
    `Linkpárosítás: ${result.checkedCount} validálva`,
    `${writeCount} mapping mentve/frissítve`,
    `${result.rejectedCount} nem LF/bizonytalan`,
    `${result.conflictCount} konfliktus`,
    `következő csomag ${result.nextOffset}`,
  ].join(" | ");
}

function isUuid(value: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function buildLocalPaginationLabel(total: number, offset: number, pageLength: number): string {
  const start = total === 0 ? 0 : offset + 1;
  const end = Math.min(offset + pageLength, total);
  return `Megjelenítve: ${start}-${end} / ${total}`;
}

function readStoredRunIds(): string[] {
  const values = [
    readStoredRunId(PRICE_RUN_STORAGE_KEY),
    readStoredRunId(PAIRING_RUN_STORAGE_KEY),
    readStoredRunId(RUN_STORAGE_KEY),
  ];
  return values.filter(
    (value, index): value is string => Boolean(value) && values.indexOf(value) === index
  );
}

function readStoredRunId(storageKey: string): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(storageKey);
  } catch {
    return null;
  }
}

function storeRunId(runId: string, kind: LfRunKind | null) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(RUN_STORAGE_KEY, runId);
    if (kind === "pairing") window.localStorage.setItem(PAIRING_RUN_STORAGE_KEY, runId);
    if (kind === "price") window.localStorage.setItem(PRICE_RUN_STORAGE_KEY, runId);
  } catch {
    return;
  }
}

function clearStoredRunId(runId: string) {
  if (typeof window === "undefined") return;
  try {
    for (const key of [RUN_STORAGE_KEY, PRICE_RUN_STORAGE_KEY, PAIRING_RUN_STORAGE_KEY]) {
      if (window.localStorage.getItem(key) === runId) window.localStorage.removeItem(key);
    }
  } catch {
    return;
  }
}

function readStoredScopedRunProgress(kind: LfRunKind): ScopedRunProgress | null {
  if (typeof window === "undefined") return null;
  try {
    const storageKey =
      kind === "pairing" ? PAIRING_PROGRESS_STORAGE_KEY : PRICE_PROGRESS_STORAGE_KEY;
    const parsed = JSON.parse(window.localStorage.getItem(storageKey) ?? "null") as unknown;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
    const record = parsed as Partial<ScopedRunProgress>;
    if (record.kind !== kind || typeof record.runId !== "string") return null;
    if (typeof record.nextOffset !== "number" || !Number.isFinite(record.nextOffset)) return null;
    if (typeof record.total !== "number" || !Number.isFinite(record.total)) return null;
    return {
      runId: record.runId,
      kind,
      status: (typeof record.status === "string"
        ? record.status
        : "interrupted") as LfManualBatchState["status"],
      processed:
        typeof record.processed === "number" && Number.isFinite(record.processed)
          ? record.processed
          : Math.min(record.total, record.nextOffset),
      total: record.total,
      nextOffset: record.nextOffset,
      updatedAt: typeof record.updatedAt === "string" ? record.updatedAt : null,
    };
  } catch {
    return null;
  }
}

function storeScopedRunProgress(progress: ScopedRunProgress): void {
  if (typeof window === "undefined") return;
  try {
    const storageKey =
      progress.kind === "pairing" ? PAIRING_PROGRESS_STORAGE_KEY : PRICE_PROGRESS_STORAGE_KEY;
    window.localStorage.setItem(storageKey, JSON.stringify(progress));
  } catch {
    return;
  }
}

function formatMoney(value: number | null, currency: string | null): string {
  if (value === null) return "-";
  return `${value.toFixed(2)} ${currency ?? ""}`.trim();
}

function formatHuf(value: number | null): string {
  if (value === null) return "-";
  return `${Math.round(value).toLocaleString("hu-HU")} HUF`;
}

function formatPercent(value: number | null): string {
  if (value === null) return "-";
  return `${value.toFixed(1)}%`;
}

function formatMilliseconds(value: number | null): string {
  if (value === null) return "-";
  if (value >= 1000) return `${(value / 1000).toFixed(1)}s`;
  return `${Math.round(value)}ms`;
}

function formatRate(value: number | null): string {
  if (value === null) return "-";
  return value.toFixed(1);
}

function formatAverageItemDuration(input: {
  state: LfManualBatchState | null;
  telemetry: LfManualBatchState["telemetry"] | null;
}): string {
  return formatMilliseconds(readAverageItemDurationMs(input));
}

function formatEstimatedFullRunDuration(input: {
  state: LfManualBatchState | null;
  telemetry: LfManualBatchState["telemetry"] | null;
  totalItems: number;
}): string {
  const averageItemMs = readAverageItemDurationMs(input);
  if (averageItemMs === null || input.totalItems <= 0) return "-";
  return formatDurationEstimate(averageItemMs * input.totalItems);
}

function readAverageItemDurationMs(input: {
  state: LfManualBatchState | null;
  telemetry: LfManualBatchState["telemetry"] | null;
}): number | null {
  const itemsPerMinute = input.telemetry?.itemsPerMinute ?? null;
  if (itemsPerMinute !== null && Number.isFinite(itemsPerMinute) && itemsPerMinute > 0) {
    return 60_000 / itemsPerMinute;
  }

  const checked = input.state?.totals.checked ?? 0;
  const durationMs = input.telemetry?.durationMs ?? null;
  if (durationMs !== null && Number.isFinite(durationMs) && durationMs > 0 && checked > 0) {
    return durationMs / checked;
  }

  return null;
}

function formatDurationEstimate(valueMs: number): string {
  if (!Number.isFinite(valueMs) || valueMs <= 0) return "-";
  const totalMinutes = Math.max(1, Math.round(valueMs / 60_000));
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0) return `${totalMinutes}p`;
  return minutes > 0 ? `${hours}ó ${minutes}p` : `${hours}ó`;
}

function formatLfOperatorErrorMessage(error: unknown): string {
  const message = formatApiErrorMessage(error);
  if (message === "Helyi API nem érhető el.") {
    return "Helyi API nem érhető el. A háttérszolgáltatás még indulhat vagy újraindult. Frissítsd az oldalt, ha pár másodperc után is marad.";
  }
  return message;
}

function isLocalApiUnavailableError(error: unknown): boolean {
  return formatApiErrorMessage(error) === "Helyi API nem érhető el.";
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function formatTime(value: string): string {
  return new Intl.DateTimeFormat("hu-HU", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(new Date(value));
}

function formatDateTime(value: string | null): string {
  if (!value) return "-";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "-";
  return new Intl.DateTimeFormat("hu-HU", {
    dateStyle: "short",
    timeStyle: "short",
  }).format(date);
}

function labelRunStatus(status: string): string {
  const labels: Record<string, string> = {
    not_started: "nincs futás",
    opening_browser: "böngésző nyílik",
    waiting_for_manual_login: "loginra vár",
    login_detected: "login megvan",
    running: "fut",
    completed: "kész",
    cancelled: "leállítva",
    login_timeout: "login timeout",
    detached_session_failed: "session detach hiba",
    session_lost: "session elveszett",
    interrupted: "megszakadt",
    failed: "hiba",
  };
  return labels[status] ?? status;
}

function labelItemStatus(status: string): string {
  return normalizeSupplierDisplayStatus({ supplier: "lf", status }).label;
}

function lfRowStatusInfo(row: Pick<LfManualBatchRow, "status" | "warnings" | "matchConfidence">) {
  return normalizeSupplierDisplayStatus({
    supplier: "lf",
    status: row.status,
    warnings: row.warnings,
    matchConfidence: row.matchConfidence,
  });
}

function createEmptyDisplayStatusCounts(): Record<SupplierDisplayStatus, number> {
  return {
    ok: 0,
    no_product_page: 0,
    missing_price: 0,
    article_changed: 0,
    unavailable: 0,
    not_supplier_own_article: 0,
    ambiguous_match: 0,
    login_required: 0,
    timeout: 0,
    safety_stopped: 0,
    failed: 0,
    skipped: 0,
    no_run: 0,
  };
}
