"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  formatApiErrorMessage,
  getPricingSettings,
  listSupplierPriceChanges,
  saveEurHufRate,
  type SupplierPriceChangeDirection,
  type SupplierPriceChangeResponse,
  type SupplierPriceChangeRoundingMode,
  type SupplierPriceChangeRow,
  type SupplierPriceChangeSupplierScope,
} from "../../src/lib/api";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import { TablePagination } from "../../src/components/TablePagination";
import { formatDate } from "../../src/lib/formatters";

const DEFAULT_LIMIT = 50;

export default function SupplierPriceChangesPage() {
  const [data, setData] = useState<SupplierPriceChangeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const [eurHufRate, setEurHufRate] = useState<number | "">("");
  const [vatPercent, setVatPercent] = useState<number | "">(27);
  const [roundingEnabled, setRoundingEnabled] = useState(true);
  const [roundingIncrementHuf, setRoundingIncrementHuf] = useState<number | "">(100);
  const [roundingMode, setRoundingMode] = useState<SupplierPriceChangeRoundingMode>("up");
  const [direction, setDirection] = useState<SupplierPriceChangeDirection>("all");
  const [supplierScope, setSupplierScope] = useState<SupplierPriceChangeSupplierScope>("all");
  const [minChangePercent, setMinChangePercent] = useState<number | "">(0);
  const [rateSaveStatus, setRateSaveStatus] = useState<"saved" | "saving" | "error" | null>(null);
  const activeRate = readOptionalNumber(eurHufRate);
  const activeVat = readOptionalNumber(vatPercent) ?? 27;
  const activeRounding = readOptionalNumber(roundingIncrementHuf) ?? 100;
  const activeMinChange = readOptionalNumber(minChangePercent) ?? 0;

  const canGoBack = offset > 0;
  const canGoNext =
    data?.total !== undefined ? offset + (data?.items.length ?? 0) < data.total : false;
  const paginationLabel = useMemo(() => {
    const total = data?.total;
    if (total === undefined) return `Megjelenítve: ${offset + 1}-${offset + DEFAULT_LIMIT}`;
    const start = total === 0 ? 0 : offset + 1;
    const end = Math.min(offset + DEFAULT_LIMIT, total);
    return `Megjelenítve: ${start}-${end} / ${total}`;
  }, [data?.total, offset]);

  useEffect(() => {
    let active = true;
    getPricingSettings()
      .then((settings) => {
        if (!active) return;
        if (settings.eurHufRate !== null) setEurHufRate(settings.eurHufRate);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (activeRate === null) {
      setData(null);
      setLoading(false);
      return;
    }
    let active = true;
    setLoading(true);
    setError(null);

    listSupplierPriceChanges({
      limit: DEFAULT_LIMIT,
      offset,
      eurHufRate: activeRate,
      vatPercent: activeVat,
      roundingEnabled,
      roundingIncrementHuf: activeRounding,
      roundingMode,
      direction,
      supplierScope,
      minChangePercent: activeMinChange,
    })
      .then((response) => {
        if (active) setData(response);
      })
      .catch((err) => {
        if (active) setError(formatApiErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [
    activeMinChange,
    activeRate,
    activeRounding,
    activeVat,
    direction,
    offset,
    roundingEnabled,
    roundingMode,
    supplierScope,
  ]);

  useEffect(() => {
    if (!data) return;
    if (data.total === 0 && offset !== 0) {
      setOffset(0);
      return;
    }
    if (data.total > 0 && offset >= data.total) {
      setOffset(Math.floor((data.total - 1) / DEFAULT_LIMIT) * DEFAULT_LIMIT);
    }
  }, [data, offset]);

  useEffect(() => {
    const rate = readOptionalNumber(eurHufRate);
    if (rate === null) return;
    const timer = window.setTimeout(() => {
      setRateSaveStatus("saving");
      saveEurHufRate({ eurHufRate: rate })
        .then(() => setRateSaveStatus("saved"))
        .catch(() => setRateSaveStatus("error"));
    }, 700);
    return () => window.clearTimeout(timer);
  }, [eurHufRate]);

  function updateDirection(value: SupplierPriceChangeDirection) {
    setOffset(0);
    setDirection(value);
  }

  function updateSupplierScope(value: SupplierPriceChangeSupplierScope) {
    setOffset(0);
    setSupplierScope(value);
  }

  return (
    <div className="page supplier-changes-page">
      <div className="page-header">
        <h1 className="page-title">Beszállítói árváltozások</h1>
      </div>

      <section className="card supplier-changes-controls">
        <div className="supplier-changes-control-header">
          <div>
            <strong>Árjavaslat vezérlőpult</strong>
          </div>
          <span className="supplier-changes-refresh">
            Frissítve: {data?.generatedAt ? formatDate(data.generatedAt) : "-"}
          </span>
        </div>

        <div className="supplier-changes-filter-grid">
          <label className="field-label">
            EUR/HUF árfolyam
            <input
              className="input"
              type="number"
              min="100"
              max="1000"
              step="0.01"
              value={eurHufRate}
              onChange={(event) => setEurHufRate(readNumberInput(event.target.value))}
            />
            <span className="field-help">
              {rateSaveStatus === "saving"
                ? "Mentés..."
                : rateSaveStatus === "error"
                  ? "Mentési hiba"
                  : activeRate === null
                    ? "Adj meg árfolyamot."
                    : "Mentve"}
            </span>
          </label>
          <label className="field-label">
            ÁFA %
            <input
              className="input"
              type="number"
              min="0"
              max="100"
              step="0.01"
              value={vatPercent}
              onChange={(event) => setVatPercent(readNumberInput(event.target.value))}
            />
          </label>
          <label className="field-label">
            Beszállító
            <select
              className="input"
              value={supplierScope}
              onChange={(event) =>
                updateSupplierScope(event.target.value as SupplierPriceChangeSupplierScope)
              }
            >
              <option value="all">DVG + LF</option>
              <option value="dvg">Csak DVG</option>
              <option value="lf">Csak LF</option>
            </select>
          </label>
          <label className="field-label">
            Változás típusa
            <select
              className="input"
              value={direction}
              onChange={(event) =>
                updateDirection(event.target.value as SupplierPriceChangeDirection)
              }
            >
              <option value="all">Minden változás</option>
              <option value="increase">Csak drágult</option>
              <option value="decrease">Csak olcsóbb lett</option>
            </select>
          </label>
          <label className="field-label">
            Minimum változás %
            <input
              className="input"
              type="number"
              min="0"
              max="1000"
              step="0.1"
              value={minChangePercent}
              onChange={(event) => {
                setOffset(0);
                setMinChangePercent(readNumberInput(event.target.value));
              }}
            />
          </label>
          {roundingEnabled ? (
            <label className="field-label supplier-changes-rounding-detail">
              Kerekítés összege
              <select
                className="input"
                value={roundingIncrementHuf}
                onChange={(event) => setRoundingIncrementHuf(readNumberInput(event.target.value))}
              >
                <option value={50}>50 Ft</option>
                <option value={100}>100 Ft</option>
                <option value={500}>500 Ft</option>
                <option value={1000}>1000 Ft</option>
              </select>
            </label>
          ) : null}
          {roundingEnabled ? (
            <label className="field-label supplier-changes-rounding-detail">
              Kerekítés módja
              <select
                className="input"
                value={roundingMode}
                onChange={(event) =>
                  setRoundingMode(event.target.value === "nearest" ? "nearest" : "up")
                }
              >
                <option value="up">Felfelé</option>
                <option value="nearest">Legközelebbi</option>
              </select>
            </label>
          ) : null}
          <div className="field-label supplier-changes-rounding-toggle-field">
            Kerekítés
            <label className="supplier-changes-toggle">
              <input
                type="checkbox"
                checked={roundingEnabled}
                onChange={(event) => {
                  setOffset(0);
                  setRoundingEnabled(event.target.checked);
                }}
              />
              <span>{roundingEnabled ? "Bekapcsolva" : "Kikapcsolva"}</span>
            </label>
          </div>
        </div>
      </section>

      {data ? <SupplierChangeSummary response={data} /> : null}
      {loading ? <LoadingState /> : null}
      {error ? <ErrorState message={error} /> : null}
      {!loading && !error && activeRate === null ? (
        <EmptyState title="Hiányzik az EUR/HUF árfolyam">
          Adj meg árfolyamot az Árjavaslat vezérlőpultban, utána betölt az árváltozás lista.
        </EmptyState>
      ) : null}
      {!loading && !error && data?.items.length === 0 ? (
        <EmptyState title="Nincs beszállítói árváltozás">
          Futtass beszállítói árfigyelést több alkalommal, hogy legyen összehasonlítható régi és új
          ár.
        </EmptyState>
      ) : null}

      {data?.items.length ? (
        <SupplierChangeTable
          rows={data.items}
          pagination={
            <TablePagination
              canGoBack={canGoBack}
              canGoNext={canGoNext}
              label={paginationLabel}
              onBack={() => setOffset(Math.max(0, offset - DEFAULT_LIMIT))}
              onNext={() => setOffset(offset + DEFAULT_LIMIT)}
              compact
            />
          }
        />
      ) : null}

      <TablePagination
        canGoBack={canGoBack}
        canGoNext={canGoNext}
        label={paginationLabel}
        onBack={() => setOffset(Math.max(0, offset - DEFAULT_LIMIT))}
        onNext={() => setOffset(offset + DEFAULT_LIMIT)}
      />
    </div>
  );
}

function SupplierChangeSummary({ response }: { response: SupplierPriceChangeResponse }) {
  return (
    <section className="supplier-changes-summary" aria-label="Árváltozás összegzés">
      <SummaryItem label="Árváltozott" value={formatCount(response.summary.changedCount)} />
      <SummaryItem
        label="Drágult"
        value={formatCount(response.summary.increaseCount)}
        tone="warning"
      />
      <SummaryItem
        label="Olcsóbb lett"
        value={formatCount(response.summary.decreaseCount)}
        tone="success"
      />
      <SummaryItem
        label="Profit csökkenne"
        value={formatCount(response.summary.marginWouldDropCount)}
        tone="warning"
      />
      <SummaryItem
        label="Nincs előző ár"
        value={formatCount(response.summary.noPreviousPriceCount)}
      />
    </section>
  );
}

function SummaryItem({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "success" | "warning";
}) {
  return (
    <div className={`supplier-changes-summary-item tone-${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function SupplierChangeTable({
  rows,
  pagination,
}: {
  rows: SupplierPriceChangeRow[];
  pagination: ReactNode;
}) {
  return (
    <section className="card table-card supplier-changes-table-card">
      <div className="table-toolbar product-table-toolbar">
        {pagination}
        <div className="product-view-controls" role="group" aria-label="Árváltozás lista nézet">
          <span className="table-toolbar-status">Szűrés és árképzés fent állítható</span>
        </div>
      </div>
      <div className="table-scroll">
        <table className="table data-table data-table--wide supplier-changes-table">
          <colgroup>
            <col style={{ width: 280 }} />
            <col style={{ width: 150 }} />
            <col style={{ width: 130 }} />
            <col style={{ width: 130 }} />
            <col style={{ width: 130 }} />
            <col style={{ width: 150 }} />
            <col style={{ width: 120 }} />
            <col style={{ width: 120 }} />
            <col style={{ width: 150 }} />
            <col style={{ width: 140 }} />
            <col style={{ width: 150 }} />
          </colgroup>
          <thead>
            <tr>
              <th>Termék</th>
              <th>Beszállító / cikkszám</th>
              <th className="numeric">Régi beszállítói ár</th>
              <th className="numeric">Új beszállítói ár</th>
              <th className="numeric">Változás</th>
              <th className="numeric">Jelenlegi mi árunk</th>
              <th className="numeric">Profit most</th>
              <th className="numeric">Eddigi profit%</th>
              <th className="numeric">Javasolt új ár</th>
              <th className="numeric">Árváltoztatás</th>
              <th>Utolsó mérés</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.newSnapshotId}>
                <td>
                  <strong>{row.sku}</strong>
                  <span className="muted-cell">{row.productName}</span>
                </td>
                <td>
                  <strong>{row.supplierName ?? row.supplierId}</strong>
                  <span className="muted-cell">{row.supplierArticleNumber}</span>
                </td>
                <td className="numeric">{formatEur(row.oldSupplierNetEur)}</td>
                <td className="numeric">{formatEur(row.newSupplierNetEur)}</td>
                <td
                  className={`numeric ${row.supplierChangeEur > 0 ? "text-warning" : "text-success"}`}
                >
                  {formatPercent(row.supplierChangePercent)}
                  <span className="muted-cell">{formatHuf(row.supplierChangeHuf)}</span>
                </td>
                <td className="numeric">
                  {formatHuf(row.currentWooPriceHuf)}
                  <span className="muted-cell">{labelWooSource(row.currentWooPriceSource)}</span>
                </td>
                <td className="numeric">{formatPercent(row.currentProfitPercentWithNewCost)}</td>
                <td className="numeric">{formatPercent(row.preservedProfitPercent)}</td>
                <td className="numeric strong-price">
                  {formatHuf(row.suggestedGrossPriceRoundedHuf)}
                </td>
                <td className="numeric">{formatSignedHuf(row.suggestedPriceDeltaHuf)}</td>
                <td>{formatDate(row.newObservedAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function readNumberInput(value: string): number | "" {
  if (value.trim() === "") return "";
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : "";
}

function readOptionalNumber(value: number | ""): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function formatCount(value: number): string {
  return value.toLocaleString("hu-HU");
}

function formatEur(value: number | null): string {
  if (value === null) return "-";
  return `${value.toLocaleString("hu-HU", { maximumFractionDigits: 4 })} EUR`;
}

function formatHuf(value: number | null): string {
  if (value === null) return "-";
  return `${Math.round(value).toLocaleString("hu-HU")} Ft`;
}

function formatSignedHuf(value: number | null): string {
  if (value === null) return "-";
  const prefix = value > 0 ? "+" : "";
  return `${prefix}${Math.round(value).toLocaleString("hu-HU")} Ft`;
}

function formatPercent(value: number | null): string {
  if (value === null) return "-";
  return `${value.toLocaleString("hu-HU", { maximumFractionDigits: 2 })}%`;
}

function labelWooSource(source: SupplierPriceChangeRow["currentWooPriceSource"]): string {
  if (source === "currentPrice") return "aktuális ár";
  if (source === "salePrice") return "akciós ár";
  if (source === "regularPrice") return "normál ár";
  return "nincs Woo ár";
}
