import assert from "node:assert/strict";
import sharp from "sharp";
import { randomUUID } from "node:crypto";
import { readFile, rm } from "node:fs/promises";
import path from "node:path";
import {
  buildDanettiDiagramHtml,
  extractDiagramCodes,
  parseCardHtmlName,
  parseDvgDiagramDetail,
  parseSelectOptions,
  slugify,
  DvgDiagramService,
  parseDvgShopDiagramListing,
  prepareDvgDiagram,
  buildDiagramDetailUrl,
  getDiagramImagePath,
} from "./dvg-diagrams.service.js";
import { fitDiagramAreas } from "./dvg-diagrams.geometry.js";

const listingHtml = `
  <select name="CategoriaMenu3">
    <option value="">Choose</option>
    <option value="ASTORIA">Astoria</option>
    <option value="SAN MARCO">La San Marco</option>
  </select>
  <script>showCard({ CodiceArticolo: 'EU01' });</script>
  <a href="/e-commerce/diagrams/index.asp?codice-articolo=EU02">diagram</a>
`;

assert.deepEqual(parseSelectOptions(listingHtml, "CategoriaMenu3"), [
  { value: "ASTORIA", label: "Astoria" },
  { value: "SAN MARCO", label: "La San Marco" },
]);
assert.deepEqual(extractDiagramCodes(listingHtml), ["EU01", "EU02"]);
assert.equal(slugify("Rancilio - Promac"), "rancilio-promac");
assert.equal(
  parseCardHtmlName(`<span class="price"><strong>
    969 - ELBA IV PUMPS AND VALVES
  </strong></span>`),
  "969 - ELBA IV PUMPS AND VALVES"
);

const linkOnlyHtml = `
  <div class="stile-categorie">
    <a href="/e-commerce/cerca.asp?c2=COFFEE%20MACHINES%20-%20Diagrams&c3=WEGA">Wega</a>
  </div>
`;

assert.deepEqual(parseSelectOptions(linkOnlyHtml, "CategoriaMenu3"), [
  { value: "WEGA", label: "Wega" },
]);

const detailHtml = `
  <img src="/e-commerce/welcome/assiemi/EU01.jpg" width="1200" height="900" usemap="#image-map" />
  <map name="image-map" id="image-map">
    <area shape="rect" coords="10,20,30,40" href="/e-commerce/welcome/ordini/dettagli.asp?codice-articolo=EU51040013" />
    <area shape="rect" coords="50,60,70,80" data-code="EU123" href="#" />
    <area shape="rect" coords=" 565, 569, 657, 584 " href="../ordini/dettagli.asp?CodiceArticolo=8C465285010" />
    <area shape="rect" coords="90,100,110,120" href="https://www.dvg.coffee/e-commerce/richiesta-articolo.asp?q=M.1.113" />
    <area shape="rect" coords="130,140,150,160" href="/e-commerce/welcome/ordini/dettagli.asp" />
    <area shape="rect" href="#" />
  </map>
`;

const parsed = parseDvgDiagramDetail(
  detailHtml,
  "https://devecchigiuseppesrl.com/e-commerce/diagrams/index.asp?codice-articolo=EU01"
);
assert.equal(
  parsed.imageSrc,
  "https://devecchigiuseppesrl.com/e-commerce/welcome/assiemi/EU01.jpg"
);
assert.equal(parsed.imageWidth, 1200);
assert.equal(parsed.imageHeight, 900);
assert.equal(parsed.areas.length, 4);
assert.equal(parsed.skippedAreaCount, 1);
assert.deepEqual(parsed.areas[0], { shape: "rect", coords: "10,20,30,40", code: "EU51040013" });
assert.deepEqual(parsed.areas[2], {
  shape: "rect",
  coords: "565,569,657,584",
  code: "8C465285010",
});
assert.deepEqual(parsed.areas[3], { shape: "rect", coords: "90,100,110,120", code: "M.1.113" });

const html = buildDanettiDiagramHtml({
  imageSrc: "__DANETTI_IMAGE_URL__/eu01.jpg",
  width: 1200,
  height: 900,
  alt: "EU01 alkatrész robbantott ábra",
  areas: parsed.areas,
});
assert.match(html, /usemap="#Map"/);
assert.match(html, /<map name="Map" id="Map">/);
assert.match(html, /href="\/search\/EU51040013"/);
assert.match(html, /coords="10,20,30,40"/);
assert.doesNotMatch(html, /dettagli\.asp/);

console.log("DVG diagram parser tests passed");

const shopDetail = `<img src="/image.jpg" width="350" usemap="#actual">
  <map name="unrelated"><area shape="rect" coords="0,0,1,1" data-code="WRONG"></map>
  <map name="actual">
    <area shape="rect" coords="40; 30; 10; 5" href="/company/service/request/request-article?r=EU100050003">
    <area shape="circle" coords="50 60 10" href="/e-commerce/item-details/9R47/tappo">
    <area shape="polygon" coords="-10,10,40,10,40,40,-10,40" data-code="POLY">
    <area shape="rect" coords="10%,20%,50%,60%" data-code="PERCENT">
    <area shape="rect" coords=".5,1.25,4.75,5.5" data-code="DECIMAL">
    <area shape="rect" coords="NaN,2,3,4" data-code="INVALID">
  </map>`;
const shopParsed = parseDvgDiagramDetail(shopDetail, "https://shop.dvgdevecchi.com");
assert.equal(shopParsed.areas.length, 5);
assert.equal(shopParsed.skippedAreaCount, 1);
assert.equal(shopParsed.areas[0].code, "EU100050003");
assert.equal(shopParsed.areas[1].code, "9R47");
const fitted = fitDiagramAreas(shopParsed, 700, 1000);
assert.deepEqual(fitted.areas[0], { shape: "rect", coords: "20,10,80,60", code: "EU100050003" });
assert.equal(fitted.areas[1].coords, "100,120,20");
assert.equal(
  fitted.areas[2].coords
    .split(",")
    .map(Number)
    .every((n) => n >= 0),
  true
);
assert.equal(fitted.areas[3].coords, "70,200,350,600");
assert.equal(fitted.skippedAreaCount, 1);
assert.equal(fitted.scaleX, 2);
assert.equal(fitted.scaleY, 2);
assert.equal(
  fitDiagramAreas({ ...shopParsed, imageWidth: 709, imageHeight: null }, 700, 965).scaleX,
  1,
  "The supplier's 709 px HTML typo must not shift native 700 px labels"
);
const ellipse = fitDiagramAreas(
  {
    ...shopParsed,
    imageWidth: 100,
    imageHeight: 100,
    areas: [{ shape: "circle", coords: "50,50,10", code: "ELLIPSE" }],
  },
  200,
  100
);
assert.equal(ellipse.areas[0].shape, "poly");
assert.equal(
  Math.min(
    ...ellipse.areas[0].coords
      .split(",")
      .map(Number)
      .filter((_, i) => i % 2 === 0)
  ),
  80
);
const edgeCircle = fitDiagramAreas(
  {
    ...shopParsed,
    imageWidth: 100,
    imageHeight: 100,
    areas: [{ shape: "circle", coords: "0,50,10", code: "EDGE" }],
  },
  100,
  100
);
assert.equal(edgeCircle.areas[0].shape, "poly");
assert.equal(
  fitDiagramAreas(
    { ...shopParsed, areas: [{ shape: "rect", code: "OUT", coords: "900,900,1000,1000" }] },
    700,
    1000
  ).skippedAreaCount,
  2
);

// A corrupt optional logo must never prevent image generation. Tiny diagrams cannot
// accept the old fixed 240 px branding overlay, but retain their original aspect ratio.
const tinyImage = await sharp({
  create: { width: 64, height: 40, channels: 3, background: "white" },
})
  .png()
  .toBuffer();
const tinyParsed = parseDvgDiagramDetail(
  `<img src="/tiny.jpg" usemap="#Map"><map name="Map"><area coords="0,0,32,20" data-code="TINY"></map>`
);
for (const logo of [tinyImage, Buffer.from("invalid logo")]) {
  const prepared = await prepareDvgDiagram(tinyParsed, tinyImage, logo);
  const metadata = await sharp(prepared.buffer).metadata();
  assert.equal(metadata.width, 64);
  assert.equal(metadata.height, 40);
  assert.equal(metadata.format, "jpeg");
  assert.equal(prepared.areas.length, 1);
}
await assert.rejects(
  prepareDvgDiagram(tinyParsed, Buffer.from("HTML instead of image"), tinyImage)
);
const safeLogoDetail = parseDvgDiagramDetail(
  '<img src="/safe.jpg" usemap="#Map"><map name="Map"><area coords="400,300,450,320" data-code="SAFE"></map>'
);
const damagedLogo = await prepareDvgDiagram(
  safeLogoDetail,
  await sharp(tinyImage).resize(700, 965).png().toBuffer(),
  Buffer.from("damaged PNG logo")
);
assert.equal(damagedLogo.brandingBounds, null);
assert.match(damagedLogo.warnings.join(" "), /A logócsere nem sikerült/);
assert.equal((await sharp(damagedLogo.buffer).metadata()).format, "jpeg");
const marked = await sharp(
  Buffer.from(
    '<svg xmlns="http://www.w3.org/2000/svg" width="700" height="965"><rect width="700" height="965" fill="white"/><rect x="117" y="78" width="58" height="17" fill="black"/></svg>'
  )
)
  .png()
  .toBuffer();
const markedDetail = parseDvgDiagramDetail(
  '<img src="/marked.jpg" width="700" usemap="#Map"><map name="Map"><area coords="117,78,175,95" data-code="LABEL"></map>'
);
const protectedImage = await prepareDvgDiagram(markedDetail, marked, tinyImage);
const labelPixel = await sharp(protectedImage.buffer)
  .extract({ left: 120, top: 80, width: 1, height: 1 })
  .raw()
  .toBuffer();
assert.ok(
  labelPixel.every((channel) => channel < 40),
  "Branding must not paint over part labels"
);
const blueStamped = await sharp(
  Buffer.from(
    '<svg xmlns="http://www.w3.org/2000/svg" width="700" height="965"><rect width="700" height="965" fill="white"/><rect x="20" y="20" width="80" height="70" fill="#2494c0"/><rect x="117" y="78" width="58" height="17" fill="black"/></svg>'
  )
)
  .png()
  .toBuffer();
const cleanStamp = await prepareDvgDiagram(markedDetail, blueStamped, tinyImage);
assert.equal(cleanStamp.warnings.length, 0, "A narrower safe cover should replace the full stamp");
const cleanPixels = await sharp(cleanStamp.buffer)
  .extract({ left: 0, top: 0, width: 120, height: 90 })
  .raw()
  .toBuffer();
let blueCount = 0;
for (let i = 0; i < cleanPixels.length; i += 3)
  if (
    cleanPixels[i + 2] > 80 &&
    cleanPixels[i + 2] > cleanPixels[i] + 20 &&
    cleanPixels[i + 1] > cleanPixels[i] + 20
  )
    blueCount++;
assert.equal(blueCount, 0, "A clipped supplier stamp must not remain below the replacement logo");
const largeStamped = await sharp(blueStamped).resize(1400, 1930).png().toBuffer();
const largeDetail = parseDvgDiagramDetail(
  '<img src="/large.jpg" width="700" usemap="#Map"><map name="Map"><area coords="117,78,175,95" data-code="LARGE"></map>'
);
const largeClean = await prepareDvgDiagram(largeDetail, largeStamped, tinyImage);
assert.equal(largeClean.warnings.length, 1, "Only coordinate scaling needs a warning");
assert.match(largeClean.warnings[0], /koordinátáját/);
const largePixels = await sharp(largeClean.buffer)
  .extract({ left: 0, top: 0, width: 320, height: 240 })
  .raw()
  .toBuffer();
let largeBlueCount = 0;
for (let i = 0; i < largePixels.length; i += 3)
  if (
    largePixels[i + 2] > 80 &&
    largePixels[i + 2] > largePixels[i] + 20 &&
    largePixels[i + 1] > largePixels[i] + 20
  )
    largeBlueCount++;
assert.equal(largeBlueCount, 0, "High-resolution stamps must be completely covered too");
const closeDetail = parseDvgDiagramDetail(
  '<img src="/close.jpg" usemap="#Map"><map name="Map"><area coords="78,97,147,112" data-code="CLOSE"></map>'
);
const closeSource = await sharp(
  Buffer.from(
    '<svg xmlns="http://www.w3.org/2000/svg" width="700" height="965"><rect width="700" height="965" fill="white"/><rect x="20" y="20" width="80" height="72" fill="#2494c0"/><rect x="78" y="97" width="69" height="15" fill="black"/></svg>'
  )
)
  .png()
  .toBuffer();
const close = await prepareDvgDiagram(closeDetail, closeSource, tinyImage);
assert.ok(
  close.brandingBounds && close.brandingBounds.height < 97,
  "A narrow but real gap below the source stamp is usable"
);
assert.equal(close.warnings.length, 0);
const overlappingDetail = parseDvgDiagramDetail(
  '<img src="/overlap.jpg" usemap="#Map"><map name="Map"><area coords="24,70,61,85" data-code="11992"></map>'
);
const overlap = await prepareDvgDiagram(overlappingDetail, blueStamped, tinyImage);
assert.equal(
  overlap.brandingBounds,
  null,
  "An area placed on the source stamp must preserve the original image"
);
assert.match(overlap.warnings.join(" "), /jelölések védelmében/);
const transparent = await sharp({
  create: { width: 64, height: 40, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } },
})
  .png()
  .toBuffer();
const flattened = await prepareDvgDiagram(tinyParsed, transparent);
assert.ok(
  (
    await sharp(flattened.buffer)
      .extract({ left: 50, top: 30, width: 1, height: 1 })
      .raw()
      .toBuffer()
  ).every((channel) => channel > 245),
  "Transparent diagrams must have a readable white JPEG background"
);
const rotated = await prepareDvgDiagram(
  tinyParsed,
  await sharp(tinyImage).jpeg().withMetadata({ orientation: 6 }).toBuffer()
);
assert.equal(rotated.width, 40);
assert.equal(rotated.height, 64);
assert.equal(
  parseDvgDiagramDetail(
    '<img src=/x.jpg usemap=#Map><map name=Map><area coords=1,2,3,4 href="/e-commerce/item-details/A--B/name"></map>'
  ).areas[0].code,
  "A/B"
);
assert.equal(
  buildDiagramDetailUrl("EU01", "new_shop"),
  "https://shop.dvgdevecchi.com/e-commerce/diagrams-details/EU01"
);
for (const href of [
  "/e-commerce/welcome/assiemi/ELE05.asp",
  "/e-commerce/diagrams-details/ELE05",
]) {
  const linked = parseDvgDiagramDetail(
    `<img src="/x.jpg" usemap="#Map"><map name="Map"><area coords="298,818,421,865" href="${href}"></map>`
  );
  assert.equal(
    linked.areas[0].code,
    "ELE05",
    "Linked diagrams such as CIME01B's ELE05 region must remain clickable"
  );
  assert.equal(linked.skippedAreaCount, 0);
}

const requests: string[] = [];
const newShopService = new DvgDiagramService(async (url) => {
  requests.push(url);
  const u = new URL(url);
  assert.equal(u.hostname, "shop.dvgdevecchi.com");
  assert.equal(u.pathname, "/e-commerce/catalog");
  if (!u.searchParams.has("c1"))
    return new Response('<select name="c1"><option value="C0944">La Spaziale</option></select>');
  if (u.searchParams.get("p") === "2") return new Response("");
  return new Response(`<a href="/e-commerce/diagrams-details/SP01/spaziale">SP01</a>
    <script>var dataArticoli = [{"CodiceArticoloGestionale":"SP01","Descrizione":{"Breve":"LA SPAZIALE"}}];</script>`);
}, "new_shop");
assert.deepEqual(await newShopService.listBrands("coffee"), [
  { family: "coffee", value: "C0944", label: "La Spaziale" },
]);
const newShopList = await newShopService.listDiagrams({ family: "coffee", brand: "C0944" });
assert.equal(newShopList.items.length, 1);
assert.equal(newShopList.items[0].diagramName, "LA SPAZIALE");
assert.equal(
  newShopList.items[0].sourcePageUrl,
  "https://shop.dvgdevecchi.com/e-commerce/diagrams-details/SP01"
);
assert.equal(
  requests.some((url) => url.includes("m=M0052")),
  true
);
assert.deepEqual(parseDvgShopDiagramListing('<a href="/e-commerce/diagrams-details/A%2FB">x</a>'), [
  { code: "A/B", name: null },
]);
console.log("DVG New shop listing, coordinate geometry and image fallback tests passed");

const fallbackBrand = `fallback-${randomUUID()}`;
try {
  const calls: string[] = [];
  const fallback = new DvgDiagramService(async (url) => {
    calls.push(url);
    if (url.includes("/diagrams-details/"))
      return new Response('<img src="/bad.jpg" usemap="#Map"><map name="Map"></map>');
    if (url.endsWith("/bad.jpg")) return new Response("Upstream returned HTML, not a JPEG");
    if (url.includes("/diagrams/index.asp?"))
      return new Response(
        '<h1>Fallback diagram</h1><img src="/good.jpg" usemap="#Map"><map name="Map"><area coords="0,0,32,20" data-code="TINY"></map>'
      );
    if (url.endsWith("/good.jpg")) return new Response(new Uint8Array(tinyImage));
    throw new Error(`Unexpected supplier URL: ${url}`);
  }, "new_shop");
  const result = await fallback.convertDiagram({
    family: "coffee",
    brand: fallbackBrand,
    diagramCode: "A/B.1",
  });
  assert.match(result.sourcePageUrl, /devecchigiuseppesrl/);
  assert.equal(result.imageUrl, "A%2FB.1.jpg");
  assert.match(result.html, /src="A%2FB\.1\.jpg"/);
  assert.equal(result.outputImagePath, getDiagramImagePath(fallbackBrand, "A/B.1", "new_shop"));
  assert.match(result.warnings.join(" "), /Legacy/);
  assert.equal((await sharp(await readFile(result.outputImagePath!)).metadata()).width, 64);
  assert.equal(calls.length, 4);
  const deniedCalls: string[] = [];
  const denied = new DvgDiagramService(async (url) => {
    deniedCalls.push(url);
    return new Response("Access denied", { status: 403 });
  }, "new_shop");
  await assert.rejects(
    denied.convertDiagram({ family: "coffee", brand: fallbackBrand, diagramCode: "DENIED" }),
    /HTTP 403/
  );
  assert.equal(deniedCalls.length, 1, "An access denial must not trigger another supplier request");
} finally {
  await rm(path.dirname(getDiagramImagePath(fallbackBrand, "A/B.1", "new_shop")), {
    recursive: true,
    force: true,
  });
}
console.log("DVG bounded source fallback and access-denial stop tests passed");
