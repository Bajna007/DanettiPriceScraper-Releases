import { randomUUID } from "node:crypto";
import { mkdir, readFile, writeFile, rename, rm } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import sharp from "sharp";
import { fitDiagramAreas, normalizeDiagramCoords } from "./dvg-diagrams.geometry.js";

const DVG_BASE_URL = "https://devecchigiuseppesrl.com";
const DEFAULT_MAX_DIAGRAMS_PER_BRAND = 24;
const DEFAULT_MAX_PAGES_PER_LISTING = 3;
// Both src/ and dist/ keep this module at the same depth in the installed package.
// The production launcher starts the API from the repository root, unlike npm workspaces.
const PACKAGE_ROOT = fileURLToPath(new URL("../../../../../", import.meta.url));
export const OUTPUT_ROOT_CONST = path.join(PACKAGE_ROOT, "artifacts", "dvg-diagrams");
const OUTPUT_ROOT = OUTPUT_ROOT_CONST;
const DANETTI_LOGO_PATH = path.join(PACKAGE_ROOT, "assets", "danetti-logo.png");
const PLACEHOLDER_BASE_URL = "__DANETTI_IMAGE_URL__";

export type DvgDiagramFamily = "coffee" | "grinders";
export type DvgDiagramShopMode = "legacy" | "new_shop";

export interface DvgDiagramBrandOption {
  family: DvgDiagramFamily;
  label: string;
  value: string;
}

export interface DvgDiagramListInput {
  family: DvgDiagramFamily;
  brand: string;
  maxDiagrams?: number;
  maxPagesPerListing?: number;
}

export interface DvgDiagramListItem {
  family: DvgDiagramFamily;
  familyLabel: string;
  brand: string;
  model: string | null;
  diagramCode: string;
  diagramName: string | null;
  sourcePageUrl: string;
}

export interface DvgDiagramListResult {
  family: DvgDiagramFamily;
  brand: string;
  generatedAt: string;
  items: DvgDiagramListItem[];
  warnings: string[];
}

export interface DvgDiagramConvertInput {
  family: DvgDiagramFamily;
  brand: string;
  diagramCode: string;
  model?: string | null;
  imageUrl?: string | null;
}

export interface DvgDiagramConvertResult {
  brandingBounds?: { width: number; height: number } | null;
  family: DvgDiagramFamily;
  familyLabel: string;
  brand: string;
  model: string | null;
  diagramCode: string;
  diagramName: string | null;
  sourcePageUrl: string;
  sourceImageUrl: string;
  imageUrl: string;
  imageWidth: number;
  imageHeight: number;
  areaCount: number;
  skippedAreaCount: number;
  html: string;
  outputImagePath: string | null;
  warnings: string[];
}

export interface DvgDiagramGenerateInput {
  family: DvgDiagramFamily;
  brands: string[];
  logoBuffer: Buffer;
  maxDiagramsPerBrand?: number;
  maxPagesPerListing?: number;
  placeholderBaseUrl?: string;
}

export interface DvgDiagramGeneratedItem {
  family: DvgDiagramFamily;
  familyLabel: string;
  brand: string;
  model: string | null;
  diagramCode: string;
  sourcePageUrl: string;
  sourceImageUrl: string;
  outputImagePath: string;
  outputHtmlPath: string;
  imageFilename: string;
  htmlFilename: string;
  imageWidth: number;
  imageHeight: number;
  areaCount: number;
  skippedAreaCount: number;
  html: string;
  warnings: string[];
}

export interface DvgDiagramServiceLike {
  listBrands(family: DvgDiagramFamily): Promise<DvgDiagramBrandOption[]>;
  listDiagrams(input: DvgDiagramListInput): Promise<DvgDiagramListResult>;
  convertDiagram(input: DvgDiagramConvertInput): Promise<DvgDiagramConvertResult>;
  generate(input: DvgDiagramGenerateInput): Promise<DvgDiagramGenerateResult>;
}

export interface DvgDiagramGenerateResult {
  generatedAt: string;
  outputDir: string;
  placeholderBaseUrl: string;
  requestedBrands: string[];
  items: DvgDiagramGeneratedItem[];
  warnings: string[];
}

export interface DvgDiagramArea {
  coords: string;
  shape: string;
  code: string;
}

export interface ParsedDvgDiagramDetail {
  imageSrc: string;
  imageWidth: number | null;
  imageHeight: number | null;
  areas: DvgDiagramArea[];
  skippedAreaCount: number;
}

interface FetchLike {
  (input: string, init?: RequestInit): Promise<Response>;
}

interface ListingTarget {
  brand: string;
  model: string | null;
}

interface DiagramCodeCandidate extends ListingTarget {
  code: string;
  diagramName: string | null;
}

const familyConfig: Record<DvgDiagramFamily, { label: string; c2: string }> = {
  coffee: { label: "Kávégép", c2: "COFFEE MACHINES - Diagrams" },
  grinders: { label: "Őrlő / daráló", c2: "GRINDERS - Diagrams" },
};

export class DvgDiagramService {
  constructor(
    private readonly fetchImpl: FetchLike = fetch,
    readonly shopMode: DvgDiagramShopMode = "legacy"
  ) {}

  private categoryUrl(
    family: DvgDiagramFamily,
    input: { brand?: string; model?: string | null; offset?: number } = {}
  ) {
    return buildCategoryUrl(family, input, this.shopMode);
  }

  private detailUrl(code: string) {
    return buildDiagramDetailUrl(code, this.shopMode);
  }

  async listBrands(family: DvgDiagramFamily): Promise<DvgDiagramBrandOption[]> {
    const html = await this.fetchText(this.categoryUrl(family));
    return parseSelectOptions(html, this.shopMode === "new_shop" ? "c1" : "CategoriaMenu3").map(
      (option) => ({
        family,
        label: option.label,
        value: option.value,
      })
    );
  }

  async listDiagrams(input: DvgDiagramListInput): Promise<DvgDiagramListResult> {
    validateFamily(input.family);
    const brand = input.brand.trim();
    if (!brand) throw new Error("DVG márka szükséges.");

    const targets = await this.listListingTargets(input.family, brand);
    const candidates = await this.collectDiagramCodes(
      input.family,
      targets,
      input.maxDiagrams ?? DEFAULT_MAX_DIAGRAMS_PER_BRAND,
      input.maxPagesPerListing ?? DEFAULT_MAX_PAGES_PER_LISTING
    );

    const items: DiagramCodeCandidate[] = [];
    for (const candidate of candidates) {
      items.push({
        ...candidate,
        diagramName:
          candidate.diagramName ??
          (this.shopMode === "legacy" ? await this.fetchDiagramName(candidate.code) : null),
      });
    }

    return {
      family: input.family,
      brand,
      generatedAt: new Date().toISOString(),
      items: items.map((candidate) => this.toDiagramListItem(input.family, candidate)),
      warnings: candidates.length === 0 ? [`${brand}: nem találtam publikus DVG diagramot.`] : [],
    };
  }

  async convertDiagram(input: DvgDiagramConvertInput): Promise<DvgDiagramConvertResult> {
    validateFamily(input.family);
    const brand = input.brand.trim();
    const diagramCode = input.diagramCode.trim();
    if (!brand) throw new Error("DVG márka szükséges.");
    if (!diagramCode) throw new Error("DVG diagram kód szükséges.");

    const candidate: DiagramCodeCandidate = {
      brand,
      model: input.model?.trim() || null,
      code: diagramCode,
      diagramName: null,
    };
    const outputImagePath = getDiagramImagePath(brand, diagramCode, this.shopMode);
    const source = await this.readDiagram(diagramCode);
    let logoBuffer: Buffer | undefined;
    const warnings = [...source.warnings];
    try {
      logoBuffer = await readFile(DANETTI_LOGO_PATH);
    } catch {
      warnings.push("A Danetti logó nem olvasható; az eredeti ábrából készült kép.");
    }
    const prepared = await prepareDvgDiagram(source.parsed, source.buffer, logoBuffer);
    await mkdir(path.dirname(outputImagePath), { recursive: true });
    await writeDiagramImage(outputImagePath, prepared.buffer);
    const imageUrl = readOutputImageUrl(input.imageUrl, input.family, candidate);
    const diagramName = source.name;
    const outputAreas = prepared.areas;
    const dimensions = prepared;
    const html = buildDanettiDiagramHtml({
      imageSrc: imageUrl,
      width: dimensions.width,
      height: dimensions.height,
      alt: `${buildDiagramTitle(input.family, candidate)} alkatrész robbantott ábra`,
      areas: outputAreas,
    });

    return {
      family: input.family,
      familyLabel: familyConfig[input.family].label,
      brand,
      model: candidate.model,
      diagramCode,
      diagramName,
      sourcePageUrl: source.url,
      sourceImageUrl: source.imageUrl,
      imageUrl,
      imageWidth: dimensions.width,
      imageHeight: dimensions.height,
      brandingBounds: prepared.brandingBounds,
      areaCount: outputAreas.length,
      skippedAreaCount: prepared.skippedAreaCount,
      html,
      outputImagePath,
      warnings: [...warnings, ...prepared.warnings],
    };
  }

  async generate(input: DvgDiagramGenerateInput): Promise<DvgDiagramGenerateResult> {
    validateGenerateInput(input);
    const maxDiagramsPerBrand = input.maxDiagramsPerBrand ?? DEFAULT_MAX_DIAGRAMS_PER_BRAND;
    const maxPagesPerListing = input.maxPagesPerListing ?? DEFAULT_MAX_PAGES_PER_LISTING;
    const placeholderBaseUrl = normalizePlaceholderBaseUrl(
      input.placeholderBaseUrl ?? PLACEHOLDER_BASE_URL
    );
    const outputDir = path.join(OUTPUT_ROOT, buildRunDirectoryName(input.family));
    await mkdir(outputDir, { recursive: true });

    const items: DvgDiagramGeneratedItem[] = [];
    const warnings: string[] = [];

    for (const brand of input.brands) {
      try {
        const targets = await this.listListingTargets(input.family, brand);
        const candidates = await this.collectDiagramCodes(
          input.family,
          targets,
          maxDiagramsPerBrand,
          maxPagesPerListing
        );

        if (candidates.length === 0) {
          warnings.push(`${brand}: nem találtam publikus DVG diagram kódot.`);
          continue;
        }

        for (const candidate of candidates) {
          try {
            items.push(
              await this.generateDiagramItem({
                family: input.family,
                candidate,
                logoBuffer: input.logoBuffer,
                outputDir,
                placeholderBaseUrl,
              })
            );
          } catch (error) {
            stopOnDvgAccessDenial(error);
            warnings.push(`${brand} / ${candidate.code}: ${readErrorMessage(error)}`);
          }
        }
      } catch (error) {
        stopOnDvgAccessDenial(error);
        warnings.push(`${brand}: ${readErrorMessage(error)}`);
      }
    }

    return {
      generatedAt: new Date().toISOString(),
      outputDir,
      placeholderBaseUrl,
      requestedBrands: input.brands,
      items,
      warnings,
    };
  }

  private async listListingTargets(
    family: DvgDiagramFamily,
    brand: string
  ): Promise<ListingTarget[]> {
    if (this.shopMode === "new_shop") return [{ brand, model: null }];
    const html = await this.fetchText(this.categoryUrl(family, { brand }));
    const models = parseSelectOptions(html, "CategoriaMenu4");
    if (models.length === 0) return [{ brand, model: null }];
    return models.map((model) => ({ brand, model: model.value }));
  }

  private async collectDiagramCodes(
    family: DvgDiagramFamily,
    targets: ListingTarget[],
    maxDiagramsPerBrand: number,
    maxPagesPerListing: number
  ): Promise<DiagramCodeCandidate[]> {
    const candidates: DiagramCodeCandidate[] = [];
    const seen = new Set<string>();

    for (const target of targets) {
      for (let pageIndex = 0; pageIndex < maxPagesPerListing; pageIndex += 1) {
        if (candidates.length >= maxDiagramsPerBrand) return candidates;
        const offset = pageIndex === 0 ? undefined : pageIndex * 24;
        const html = await this.fetchText(this.categoryUrl(family, { ...target, offset }));
        const shopItems = this.shopMode === "new_shop" ? parseDvgShopDiagramListing(html) : [];
        const codes =
          this.shopMode === "new_shop"
            ? shopItems.map((item) => item.code)
            : extractDiagramCodes(html);
        if (codes.length === 0) break;

        let newCodesOnPage = 0;
        for (const code of codes) {
          if (seen.has(code)) continue;
          seen.add(code);
          newCodesOnPage += 1;
          candidates.push({
            ...target,
            code,
            diagramName: shopItems.find((item) => item.code === code)?.name ?? null,
          });
          if (candidates.length >= maxDiagramsPerBrand) return candidates;
        }
        if (newCodesOnPage === 0) break;
      }
    }

    return candidates;
  }

  private async generateDiagramItem(input: {
    family: DvgDiagramFamily;
    candidate: DiagramCodeCandidate;
    logoBuffer: Buffer;
    outputDir: string;
    placeholderBaseUrl: string;
  }): Promise<DvgDiagramGeneratedItem> {
    const source = await this.readDiagram(input.candidate.code);
    const image = await prepareDvgDiagram(source.parsed, source.buffer, input.logoBuffer);
    const outputAreas = image.areas;
    const filenameBase = buildDiagramFilenameBase(input.family, input.candidate);
    const imageFilename = `${filenameBase}.jpg`;
    const htmlFilename = `${filenameBase}.html`;
    const outputImagePath = path.join(input.outputDir, imageFilename);
    const outputHtmlPath = path.join(input.outputDir, htmlFilename);
    const imageSrc = `${input.placeholderBaseUrl}/${imageFilename}`;
    const html = buildDanettiDiagramHtml({
      imageSrc,
      width: image.width,
      height: image.height,
      alt: `${buildDiagramTitle(input.family, input.candidate)} alkatrész robbantott ábra`,
      areas: outputAreas,
    });

    await writeDiagramImage(outputImagePath, image.buffer);
    await writeFile(outputHtmlPath, html, "utf8");

    return {
      family: input.family,
      familyLabel: familyConfig[input.family].label,
      brand: input.candidate.brand,
      model: input.candidate.model,
      diagramCode: input.candidate.code,
      sourcePageUrl: source.url,
      sourceImageUrl: source.imageUrl,
      outputImagePath,
      outputHtmlPath,
      imageFilename,
      htmlFilename,
      imageWidth: image.width,
      imageHeight: image.height,
      areaCount: outputAreas.length,
      skippedAreaCount: image.skippedAreaCount,
      html,
      warnings: [...source.warnings, ...image.warnings],
    };
  }

  private async readDiagram(code: string) {
    const modes: DvgDiagramShopMode[] =
      this.shopMode === "new_shop" ? ["new_shop", "legacy"] : ["legacy", "new_shop"];
    let lastError: unknown;
    for (const mode of modes) {
      try {
        const url = buildDiagramDetailUrl(code, mode);
        const html = await this.fetchText(url);
        const parsed = parseDvgDiagramDetail(html, url);
        const imageUrl = parsed.imageSrc;
        const buffer = await this.fetchBuffer(imageUrl);
        // Validate before considering this source usable; an HTML error page is not an image.
        await sharp(buffer).raw().toBuffer();
        const name = /<h1\b[^>]*>([\s\S]*?)<\/h1>/i.exec(html)?.[1];
        return {
          url,
          parsed,
          imageUrl,
          buffer,
          name: name
            ? normalizeWhitespace(stripTags(decodeHtml(name)))
            : mode === "legacy"
              ? await this.fetchDiagramName(code)
              : null,
          warnings:
            mode === this.shopMode
              ? []
              : [
                  `A választott forrás nem adott használható ábrát; ${mode === "legacy" ? "Legacy" : "New shop"} forrásból készült.`,
                ],
        };
      } catch (error) {
        stopOnDvgAccessDenial(error);
        lastError = error;
      }
    }
    throw new Error(`Egyik DVG forrás sem adott használható ábrát: ${readErrorMessage(lastError)}`);
  }

  private async fetchText(url: string): Promise<string> {
    const response = await this.fetchImpl(url, {
      headers: { "User-Agent": "DanettiPriceScraper/0.1" },
      signal: AbortSignal.timeout(20_000),
    });
    if (!response.ok) throw new Error(`DVG oldal nem érhető el: HTTP ${response.status}`);
    return await response.text();
  }

  private async fetchBuffer(url: string): Promise<Buffer> {
    const response = await this.fetchImpl(url, {
      headers: { "User-Agent": "DanettiPriceScraper/0.1" },
      signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) throw new Error(`DVG kép nem érhető el: HTTP ${response.status}`);
    return Buffer.from(await response.arrayBuffer());
  }

  private async fetchDiagramName(diagramCode: string): Promise<string | null> {
    try {
      const cardUrl = `${DVG_BASE_URL}/assets/include/showCardArticolo.asp?CodiceArticolo=${encodeURIComponent(diagramCode)}&width=1&height=1`;
      const html = await this.fetchText(cardUrl);
      const match = /'name':\s*'([^']+)'/.exec(html);
      if (match) return decodeHtml(match[1]).trim();
      return parseCardHtmlName(html);
    } catch (error) {
      stopOnDvgAccessDenial(error);
      return null;
    }
  }

  private toDiagramListItem(
    family: DvgDiagramFamily,
    candidate: DiagramCodeCandidate
  ): DvgDiagramListItem {
    return {
      family,
      familyLabel: familyConfig[family].label,
      brand: candidate.brand,
      model: candidate.model,
      diagramCode: candidate.code,
      diagramName: candidate.diagramName,
      sourcePageUrl: this.detailUrl(candidate.code),
    };
  }
}

export function parseDvgDiagramDetail(
  html: string,
  baseUrl = DVG_BASE_URL
): ParsedDvgDiagramDetail {
  const imageTag = findImageMapImageTag(html);
  if (!imageTag) throw new Error("A DVG diagram oldalon nincs image-map kép.");
  const imageSrc = readAttribute(imageTag, "src");
  if (!imageSrc) throw new Error("A DVG diagram kép src hiányzik.");

  const mapName = readAttribute(imageTag, "usemap")?.replace(/^#/, "");
  const mapHtml = findImageMapHtml(html, mapName);
  if (mapHtml === null) throw new Error("A DVG diagram oldalon nincs <map> blokk.");

  const areas: DvgDiagramArea[] = [];
  let skippedAreaCount = 0;
  for (const areaAttrs of matchAll(mapHtml, /<area\b([^>]*)>/gi)) {
    const href = readAttribute(areaAttrs, "href");
    const code = readAreaCode(areaAttrs, href ?? "")?.trim() || null;
    const rawShape = (readAttribute(areaAttrs, "shape") ?? "rect").trim().toLowerCase();
    const shape =
      ({ rectangle: "rect", circ: "circle", polygon: "poly" } as Record<string, string>)[
        rawShape
      ] ?? rawShape;
    const coords = normalizeDiagramCoords(readAttribute(areaAttrs, "coords"), shape);
    if (coords === null || !code) {
      if (isIgnorableArea(href, coords, code)) continue;
      skippedAreaCount += 1;
      continue;
    }
    areas.push({ coords, shape, code: decodeHtml(code).trim() });
  }

  return {
    imageSrc: absoluteUrl(imageSrc, baseUrl),
    imageWidth: readNumberAttribute(imageTag, "width"),
    imageHeight: readNumberAttribute(imageTag, "height"),
    areas,
    skippedAreaCount,
  };
}

export function buildDanettiDiagramHtml(input: {
  imageSrc: string;
  width: number;
  height: number;
  alt: string;
  areas: readonly DvgDiagramArea[];
}): string {
  const lines = [
    `<img src="${escapeHtml(input.imageSrc)}" usemap="#Map" width="${input.width}" height="${input.height}" border="0" alt="${escapeHtml(
      input.alt
    )}" />`,
    "",
    '<map name="Map" id="Map">',
    ...input.areas.map(
      (area) =>
        `  <area coords="${escapeHtml(area.coords)}" shape="${escapeHtml(area.shape)}" href="/search/${escapeHtml(
          area.code
        )}" alt="${escapeHtml(area.code)}" />`
    ),
    "</map>",
  ];
  return lines.join("\n");
}

export function parseSelectOptions(
  html: string,
  selectName: string
): Array<{ value: string; label: string }> {
  const selectMatch = new RegExp(
    `<select\\b[^>]*name=["']${escapeRegExp(selectName)}["'][^>]*>([\\s\\S]*?)<\\/select>`,
    "i"
  ).exec(html);
  const options = selectMatch?.[1] ? parseOptions(selectMatch[1]) : [];
  return dedupeByValue(options.length > 0 ? options : parseCategoryLinks(html, selectName));
}

export function extractDiagramCodes(html: string): string[] {
  const codes = new Set<string>();
  for (const code of matchAll(html, /CodiceArticolo:\s*'([^']+)'/gi)) {
    codes.add(decodeHtml(code).trim());
  }
  for (const code of matchAll(
    html,
    /\/e-commerce\/diagrams\/index\.asp\?codice-articolo=([^"'&#\s]+)/gi
  )) {
    codes.add(decodeURIComponentSafe(code));
  }
  return Array.from(codes)
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b));
}

export function parseDvgShopDiagramListing(
  html: string
): Array<{ code: string; name: string | null }> {
  const names = new Map<string, string>();
  const json = /\b(?:var|let|const)\s+dataArticoli\s*=\s*(\[[\s\S]*?\]);/.exec(html)?.[1];
  if (json) {
    try {
      for (const item of JSON.parse(json)) {
        if (
          typeof item.CodiceArticoloGestionale === "string" &&
          typeof item.Descrizione?.Breve === "string"
        ) {
          names.set(item.CodiceArticoloGestionale, decodeHtml(item.Descrizione.Breve).trim());
        }
      }
    } catch {
      /* Links remain authoritative when optional catalogue metadata is absent. */
    }
  }
  const items = new Map<string, { code: string; name: string | null }>();
  for (const match of html.matchAll(
    /href=["']([^"']*\/diagrams-details\/([^/"'?]+)[^"']*)["']/gi
  )) {
    const code = decodeURIComponentSafe(match[2]);
    items.set(code, { code, name: names.get(code) ?? null });
  }
  for (const [code, name] of names) {
    if (!items.has(code)) items.set(code, { code, name });
  }
  return [...items.values()];
}

export function getDiagramImagePath(
  brand: string,
  code: string,
  mode: DvgDiagramShopMode = "legacy"
): string {
  if (!slugify(brand) || !/^[a-z0-9][a-z0-9._/\-]{0,127}$/i.test(code)) {
    throw new Error("Érvénytelen DVG márka vagy diagramkód.");
  }
  return path.join(
    OUTPUT_ROOT,
    ...(mode === "new_shop" ? ["new_shop"] : []),
    slugify(brand),
    `${encodeURIComponent(code)}.jpg`
  );
}

export function parseCardHtmlName(html: string): string | null {
  const priceMatch =
    /<span\b[^>]*class=["'][^"']*price[^"']*["'][^>]*>\s*<strong\b[^>]*>([\s\S]*?)<\/strong>/i.exec(
      html
    );
  if (!priceMatch?.[1]) return null;
  const name = normalizeWhitespace(stripTags(decodeHtml(priceMatch[1])));
  return name || null;
}

function parseOptions(html: string): Array<{ value: string; label: string }> {
  const options: Array<{ value: string; label: string }> = [];
  for (const match of html.matchAll(/<option\b([^>]*)>([\s\S]*?)<\/option>/gi)) {
    const attrs = match[1] ?? "";
    const labelHtml = match[2] ?? "";
    const value = readAttribute(attrs, "value")?.trim() ?? "";
    if (!value) continue;
    const label = normalizeWhitespace(stripTags(decodeHtml(labelHtml)));
    options.push({ value: decodeHtml(value), label: label || decodeHtml(value) });
  }
  return options;
}

export async function prepareDvgDiagram(
  parsed: ParsedDvgDiagramDetail,
  source: Buffer,
  logo?: Buffer
) {
  const normalized = await sharp(source)
    .rotate()
    .flatten({ background: "white" })
    .png()
    .toBuffer({ resolveWithObject: true });
  const width = normalized.info.width;
  const height = normalized.info.height;
  const geometry = fitDiagramAreas(parsed, width, height);
  const warnings: string[] = [];
  let buffer: Buffer;
  let brandingBounds: { width: number; height: number } | null = null;
  try {
    if (!logo) throw new Error("Nincs logó.");
    const branded = await brandDiagramImage(normalized.data, logo, geometry.areas);
    buffer = branded.buffer;
    brandingBounds = { width: branded.patchWidth, height: branded.patchHeight };
  } catch (error) {
    buffer = await sharp(normalized.data).jpeg({ quality: 92, mozjpeg: true }).toBuffer();
    warnings.push(
      error instanceof DvgDiagramBrandingUnsafeError
        ? "A DVG jelölései érintik az eredeti logót; a jelölések védelmében az eredeti képből készült JPEG."
        : "A logócsere nem sikerült; az eredeti ábrából készült használható JPEG."
    );
  }
  if (geometry.adjustedAreaCount)
    warnings.push(
      `${geometry.adjustedAreaCount} kattintható terület koordinátáját a képhez igazítottam.`
    );
  if (geometry.skippedAreaCount)
    warnings.push(
      `${geometry.skippedAreaCount} értelmezhetetlen vagy képen kívüli terület kimaradt; a kép elkészült.`
    );
  if (!geometry.areas.length)
    warnings.push("A DVG forrás nem adott használható alkatrészjelölést; a kép elkészült.");
  return { buffer, width, height, ...geometry, warnings, brandingBounds };
}

function parseCategoryLinks(
  html: string,
  selectName: string
): Array<{ value: string; label: string }> {
  const queryKey = selectName === "CategoriaMenu4" ? "c4" : "c3";
  const options: Array<{ value: string; label: string }> = [];
  for (const match of html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
    const attrs = match[1] ?? "";
    const href = readAttribute(attrs, "href");
    if (!href || !href.includes(`${queryKey}=`)) continue;
    const value = readQueryValue(href, queryKey);
    if (!value) continue;
    const label = normalizeWhitespace(stripTags(decodeHtml(match[2] ?? "")));
    options.push({ value, label: label || value });
  }
  return options;
}

async function brandDiagramImage(
  sourceImageBuffer: Buffer,
  logoBuffer: Buffer,
  areas: readonly DvgDiagramArea[]
) {
  const source = sharp(sourceImageBuffer).rotate();
  const metadata = await source.metadata();
  const width = metadata.width;
  const height = metadata.height;
  if (!width || !height) throw new Error("A DVG kép mérete nem olvasható.");

  const maxWidth = Math.min(width, clamp(Math.round(width * 0.4), 240, 440));
  const baseHeight = Math.min(height, clamp(Math.round(height * 0.1), 54, 90));
  // The source stamp is blue; find its footprint before choosing a safe cover.
  // Reducing only height can leave the bottom of the old logo visible.
  const stamp = await source
    .clone()
    .removeAlpha()
    .toColourspace("srgb")
    .extract({
      left: 0,
      top: 0,
      width: Math.min(width, Math.max(160, Math.ceil((width * 160) / 700))),
      height: Math.min(height, Math.max(120, Math.ceil((width * 120) / 700))),
    })
    .raw()
    .toBuffer({ resolveWithObject: true });
  let bluePixels = 0,
    blueRight = 0,
    blueBottom = 0;
  for (let y = 0; y < stamp.info.height; y++)
    for (let x = 0; x < stamp.info.width; x++) {
      const i = (y * stamp.info.width + x) * stamp.info.channels;
      const [r, g, b] = [stamp.data[i], stamp.data[i + 1], stamp.data[i + 2]];
      if (b > 80 && b > r + 20 && g > r + 20) {
        bluePixels++;
        blueRight = Math.max(blueRight, x + 1);
        blueBottom = Math.max(blueBottom, y + 1);
      }
    }
  const minWidth = bluePixels >= 30 ? Math.min(width, blueRight + 2) : Math.min(120, maxWidth);
  const minHeight = bluePixels >= 30 ? Math.min(height, blueBottom + 2) : baseHeight;
  const maxHeight = Math.max(baseHeight, minHeight);
  const bounds = areas.map((area) => {
    if (area.shape === "default")
      throw new DvgDiagramBrandingUnsafeError(
        "Az egész kép kattintható; a logócsere nem biztonságos."
      );
    const n = area.coords.split(",").map(Number);
    return {
      left: area.shape === "circle" ? n[0] - n[2] : Math.min(...n.filter((_, i) => i % 2 === 0)),
      top: area.shape === "circle" ? n[1] - n[2] : Math.min(...n.filter((_, i) => i % 2 === 1)),
    };
  });
  let safe: { width: number; height: number } | null = null;
  for (const candidateWidth of new Set([maxWidth, ...bounds.map((b) => b.left - 2)])) {
    if (candidateWidth < minWidth || candidateWidth > maxWidth) continue;
    const candidateHeight = Math.min(
      maxHeight,
      ...bounds.filter((b) => b.left < candidateWidth).map((b) => b.top - 2)
    );
    if (candidateHeight < minHeight || candidateHeight < 24) continue;
    if (!safe || candidateWidth * candidateHeight > safe.width * safe.height)
      safe = { width: candidateWidth, height: candidateHeight };
  }
  if (!safe)
    throw new DvgDiagramBrandingUnsafeError(
      "A teljes eredeti logó és az alkatrészjelölések együttes védelme miatt az eredeti kép marad meg."
    );
  const patchWidth = safe.width,
    patchHeight = safe.height;
  const patch = Buffer.from(
    `<svg width="${patchWidth}" height="${patchHeight}" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" fill="white"/></svg>`
  );

  const logoMaxWidth = Math.max(1, Math.round(patchWidth * 0.82));
  const logoMaxHeight = Math.max(1, Math.round(patchHeight * 0.72));
  const resizedLogo = await sharp(logoBuffer)
    .resize({
      width: logoMaxWidth,
      height: logoMaxHeight,
      fit: "inside",
      withoutEnlargement: true,
    })
    .png()
    .toBuffer();

  const logoMeta = await sharp(resizedLogo).metadata();
  const logoW = logoMeta.width ?? logoMaxWidth;
  const logoH = logoMeta.height ?? logoMaxHeight;
  const logoLeft = Math.round((patchWidth - logoW) / 2);
  const logoTop = Math.round((patchHeight - logoH) / 2);

  const buffer = await source
    .composite([
      { input: patch, left: 0, top: 0 },
      { input: resizedLogo, left: logoLeft, top: logoTop },
    ])
    .jpeg({ quality: 92, mozjpeg: true })
    .toBuffer();

  return { buffer, width, height, patchWidth, patchHeight };
}

function validateGenerateInput(input: DvgDiagramGenerateInput): void {
  validateFamily(input.family);
  if (!input.logoBuffer || input.logoBuffer.length === 0)
    throw new Error("Danetti logó fájl szükséges.");
  if (!Array.isArray(input.brands) || input.brands.length === 0) {
    throw new Error("Legalább egy DVG márkát ki kell választani.");
  }
}

function validateFamily(family: DvgDiagramFamily): void {
  if (!familyConfig[family]) throw new Error("Érvénytelen diagram család.");
}

function buildCategoryUrl(
  family: DvgDiagramFamily,
  input: { brand?: string; model?: string | null; offset?: number } = {},
  mode: DvgDiagramShopMode = "legacy"
): string {
  if (mode === "new_shop") {
    const url = new URL("/e-commerce/catalog", "https://shop.dvgdevecchi.com");
    url.searchParams.set("g", "C0627");
    url.searchParams.set("m", family === "coffee" ? "M0052" : "M0063");
    if (input.brand) url.searchParams.set("c1", input.brand);
    if (input.model) url.searchParams.set("c2", input.model);
    url.searchParams.set("i", "24");
    url.searchParams.set("p", String(Math.floor((input.offset ?? 0) / 24) + 1));
    return url.toString();
  }
  const url = new URL("/e-commerce/cerca.asp", DVG_BASE_URL);
  url.searchParams.set("c2", familyConfig[family].c2);
  if (input.brand) url.searchParams.set("c3", input.brand);
  if (input.model) url.searchParams.set("c4", input.model);
  if (typeof input.offset === "number") url.searchParams.set("offset", String(input.offset));
  return url.toString();
}

export function buildDiagramDetailUrl(
  diagramCode: string,
  mode: DvgDiagramShopMode = "legacy"
): string {
  if (mode === "new_shop")
    return `https://shop.dvgdevecchi.com/e-commerce/diagrams-details/${encodeURIComponent(diagramCode)}`;
  return `${DVG_BASE_URL}/e-commerce/diagrams/index.asp?codice-articolo=${encodeURIComponent(
    diagramCode
  )}`;
}

function readOutputImageUrl(
  imageUrl: string | null | undefined,
  _family: DvgDiagramFamily,
  candidate: DiagramCodeCandidate
): string {
  const trimmed = imageUrl?.trim();
  if (trimmed) return trimmed;
  return `${encodeURIComponent(candidate.code)}.jpg`;
}

function buildRunDirectoryName(family: DvgDiagramFamily): string {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  return `${stamp}-${family}-${randomUUID().slice(0, 8)}`;
}

function buildDiagramFilenameBase(
  family: DvgDiagramFamily,
  candidate: DiagramCodeCandidate
): string {
  return [
    family === "coffee" ? "kavegep" : "orlo-daralo",
    candidate.brand,
    candidate.model,
    candidate.code,
    "robbantott-abra",
  ]
    .filter(Boolean)
    .map((part) => slugify(String(part)))
    .join("-");
}

function buildDiagramTitle(family: DvgDiagramFamily, candidate: DiagramCodeCandidate): string {
  return [familyConfig[family].label, candidate.brand, candidate.model, candidate.code]
    .filter(Boolean)
    .join(" ");
}

function findImageMapImageTag(html: string): string | null {
  return /<img\b(?=[^>]*\susemap\s*=)[^>]*>/i.exec(html)?.[0] ?? null;
}

function findImageMapHtml(html: string, mapName?: string): string | null {
  if (mapName) {
    for (const match of html.matchAll(/<map\b([^>]*)>([\s\S]*?)<\/map>/gi)) {
      if (readAttribute(match[1], "name") === mapName || readAttribute(match[1], "id") === mapName)
        return match[2];
    }
    return null;
  }
  return (
    /<map\b[^>]*(?:name|id)=["']image-map["'][^>]*>([\s\S]*?)<\/map>/i.exec(html)?.[1] ??
    /<map\b[^>]*>([\s\S]*?)<\/map>/i.exec(html)?.[1] ??
    null
  );
}

function readAttribute(input: string, name: string): string | null {
  const match = new RegExp(
    `(?:^|\\s)${escapeRegExp(name)}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`,
    "i"
  ).exec(input);
  const value = match?.[1] ?? match?.[2] ?? match?.[3];
  return value ? decodeHtml(value) : null;
}

function readNumberAttribute(input: string, name: string): number | null {
  const value = readAttribute(input, name);
  if (!value) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

function readCodeFromHref(href: string): string | null {
  if (!href) return null;
  try {
    const url = new URL(href, DVG_BASE_URL);
    const detailCode = /\/e-commerce\/(?:item-details|diagrams-details)\/([^/]+)/i.exec(
      url.pathname
    )?.[1];
    const linkedDiagramCode = /\/e-commerce\/welcome\/assiemi\/([^/]+)\.asp$/i.exec(
      url.pathname
    )?.[1];
    return (
      readArticleCodeParam(url.searchParams) ??
      readRequestArticleParam(url) ??
      (detailCode ? decodeURIComponentSafe(detailCode).replaceAll("--", "/") : null) ??
      (linkedDiagramCode ? decodeURIComponentSafe(linkedDiagramCode) : null)
    );
  } catch {
    const match = /[?&]codice[-_]?articolo=([^&#"']+)/i.exec(href);
    if (match?.[1]) return decodeURIComponentSafe(match[1]);
    const requestMatch = /[?&]q=([^&#"']+)/i.exec(href);
    return requestMatch?.[1] ? decodeURIComponentSafe(requestMatch[1]) : null;
  }
}

function readAreaCode(areaAttrs: string, href: string): string | null {
  return (
    (readAttribute(areaAttrs, "data-code")?.trim() || null) ??
    readCodeFromHref(href) ??
    readCodeFromInlineScript(areaAttrs)
  );
}

function readArticleCodeParam(searchParams: URLSearchParams): string | null {
  for (const [name, value] of searchParams.entries()) {
    if (name.toLowerCase().replace(/[-_]/g, "") === "codicearticolo") return value;
  }
  return null;
}

function readRequestArticleParam(url: URL): string | null {
  if (url.pathname.toLowerCase().endsWith("/request-article")) return url.searchParams.get("r");
  if (!url.pathname.toLowerCase().endsWith("/richiesta-articolo.asp")) return null;
  return url.searchParams.get("q");
}

function readCodeFromInlineScript(value: string): string | null {
  return (
    /getDetail\(\s*['"]([^'"]+)['"]\s*\)/i.exec(value)?.[1] ??
    /CodiceArticolo\s*[:=]\s*['"]?([A-Za-z0-9._-]+)/i.exec(value)?.[1] ??
    null
  );
}

function isIgnorableArea(href: string | null, coords: string | null, code: string | null): boolean {
  if (code) return false;
  const normalizedHref = href?.trim().toLowerCase() ?? "";
  if (normalizedHref.startsWith("javascript:") || normalizedHref === "#") return true;
  return !normalizedHref && (!coords || !code);
}

function readQueryValue(href: string, name: string): string | null {
  try {
    return new URL(href, DVG_BASE_URL).searchParams.get(name);
  } catch {
    const match = new RegExp(`[?&]${escapeRegExp(name)}=([^&#"']+)`, "i").exec(href);
    return match?.[1] ? decodeURIComponentSafe(match[1]) : null;
  }
}

function absoluteUrl(value: string, baseUrl: string): string {
  return new URL(value, baseUrl).toString();
}

function normalizePlaceholderBaseUrl(value: string): string {
  return value.trim().replace(/\/+$/, "") || PLACEHOLDER_BASE_URL;
}

function decodeHtml(value: string): string {
  return value
    .replace(/&#(x[0-9a-f]+|\d+);/gi, (entity, code: string) => {
      const point = code.toLowerCase().startsWith("x") ? parseInt(code.slice(1), 16) : Number(code);
      return point > 0 && point <= 0x10ffff && !(point >= 0xd800 && point <= 0xdfff)
        ? String.fromCodePoint(point)
        : entity;
    })
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ");
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function stripTags(value: string): string {
  return value.replace(/<[^>]+>/g, " ");
}

function normalizeWhitespace(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

function dedupeByValue<T extends { value: string }>(items: T[]): T[] {
  const seen = new Set<string>();
  return items.filter((item) => {
    if (seen.has(item.value)) return false;
    seen.add(item.value);
    return true;
  });
}

function matchAll(input: string, pattern: RegExp, group = 1): string[] {
  return Array.from(input.matchAll(pattern))
    .map((match) => match[group])
    .filter((value): value is string => Boolean(value));
}

function decodeURIComponentSafe(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return decodeHtml(value);
  }
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

function readErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "ismeretlen hiba";
}

function stopOnDvgAccessDenial(error: unknown): void {
  if (/HTTP (401|403|429)\b/.test(readErrorMessage(error))) throw error;
}

class DvgDiagramBrandingUnsafeError extends Error {}

async function writeDiagramImage(filename: string, buffer: Buffer) {
  const temporary = `${filename}.${randomUUID()}.tmp`;
  try {
    await writeFile(temporary, buffer);
    await rename(temporary, filename);
  } finally {
    await rm(temporary, { force: true });
  }
}
