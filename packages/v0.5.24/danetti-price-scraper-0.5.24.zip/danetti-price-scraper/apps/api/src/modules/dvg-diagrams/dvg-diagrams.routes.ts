import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import multipart, { type MultipartFile } from "@fastify/multipart";
import type { FastifyInstance, FastifyReply } from "fastify";
import {
  DvgDiagramService,
  getDiagramImagePath,
  type DvgDiagramShopMode,
  type DvgDiagramFamily,
  type DvgDiagramServiceLike,
} from "./dvg-diagrams.service.js";

interface DvgDiagramRouteOptions {
  service?: DvgDiagramServiceLike;
  createService?: (mode: DvgDiagramShopMode) => DvgDiagramServiceLike;
}

interface BrandListQuery {
  family?: string;
  shopMode?: string;
}

interface DiagramListQuery {
  family?: string;
  shopMode?: string;
  brand?: string;
  maxDiagrams?: string;
  maxPagesPerListing?: string;
}

const LOGO_MAX_BYTES = 3 * 1024 * 1024;
const LOGO_MIMETYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
  "image/svg+xml",
]);

export async function registerDvgDiagramRoutes(
  server: FastifyInstance,
  options: DvgDiagramRouteOptions = {}
): Promise<void> {
  await server.register(multipart, {
    limits: {
      fileSize: LOGO_MAX_BYTES,
      files: 1,
      fields: 8,
    },
  });

  const serviceFor = (value: string | undefined) => {
    const mode = readShopMode(value);
    return options.createService?.(mode) ?? options.service ?? new DvgDiagramService(fetch, mode);
  };

  server.get("/dvg-diagrams/brands", async (request, reply) => {
    try {
      const query = request.query as BrandListQuery;
      const family = readFamily(query.family);
      const items = await serviceFor(query.shopMode).listBrands(family);
      return { family, items, generatedAt: new Date().toISOString() };
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/dvg-diagrams/diagrams", async (request, reply) => {
    try {
      const query = request.query as DiagramListQuery;
      const family = readFamily(query.family);
      const brand = readRequiredText(
        query.brand,
        "dvg_diagram_brand_missing",
        "DVG márka szükséges."
      );
      return await serviceFor(query.shopMode).listDiagrams({
        family,
        brand,
        maxDiagrams: readOptionalIntegerFromValue(query.maxDiagrams, "maxDiagrams", 1, 1000),
        maxPagesPerListing: readOptionalIntegerFromValue(
          query.maxPagesPerListing,
          "maxPagesPerListing",
          1,
          100
        ),
      });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/dvg-diagrams/convert", async (request, reply) => {
    try {
      const body = readBodyObject(request.body);
      const family = readFamily(readBodyText(body, "family"));
      const brand = readRequiredText(
        readBodyText(body, "brand"),
        "dvg_diagram_brand_missing",
        "DVG márka szükséges."
      );
      const diagramCode = readRequiredText(
        readBodyText(body, "diagramCode"),
        "dvg_diagram_code_missing",
        "DVG diagram kód szükséges."
      );
      return await serviceFor(readBodyText(body, "shopMode")).convertDiagram({
        family,
        brand,
        diagramCode,
        model: readBodyText(body, "model") ?? null,
        imageUrl: readBodyText(body, "imageUrl") ?? null,
      });
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.post("/dvg-diagrams/generate", async (request, reply) => {
    try {
      const uploadedLogo = await readUploadedLogo(await request.file());
      const fields = uploadedLogo.fields;
      const family = readFamily(readTextField(fields, "family"));
      const brands = readBrandsField(fields);
      const result = await serviceFor(readTextField(fields, "shopMode")).generate({
        family,
        brands,
        logoBuffer: uploadedLogo.buffer,
        maxDiagramsPerBrand: readOptionalInteger(fields, "maxDiagramsPerBrand", 1, 100),
        maxPagesPerListing: readOptionalInteger(fields, "maxPagesPerListing", 1, 10),
        placeholderBaseUrl: readTextField(fields, "placeholderBaseUrl") ?? undefined,
      });
      return reply.code(201).send(result);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });

  server.get("/dvg-diagrams/image", async (request, reply) => {
    try {
      const query = request.query as { brand?: string; code?: string; shopMode?: string };
      const brand = readRequiredText(query.brand, "dvg_diagram_brand_missing", "Márka szükséges.");
      const code = readRequiredText(
        query.code,
        "dvg_diagram_code_missing",
        "Diagram kód szükséges."
      );
      let imagePath: string;
      try {
        imagePath = getDiagramImagePath(brand, code, readShopMode(query.shopMode));
      } catch (error) {
        if (error instanceof DvgDiagramRouteError) throw error;
        throw new DvgDiagramRouteError("dvg_diagram_image_invalid", "Érvénytelen márka vagy kód.");
      }
      const buffer = await readFile(imagePath);
      return reply.header("Cache-Control", "no-store").type("image/jpeg").send(buffer);
    } catch (error) {
      return handleRouteError(reply, error);
    }
  });
}

async function readUploadedLogo(file: MultipartFile | undefined): Promise<{
  buffer: Buffer;
  fields: Record<string, unknown>;
}> {
  if (!file)
    throw new DvgDiagramRouteError("dvg_diagram_logo_missing", "Danetti logó fájl szükséges.");
  if (file.fieldname !== "logo") {
    throw new DvgDiagramRouteError("dvg_diagram_logo_missing", "Multipart mező neve legyen: logo.");
  }

  validateLogoFileType(file);
  const chunks: Buffer[] = [];
  let fileSizeBytes = 0;
  for await (const chunk of file.file) {
    const bufferChunk = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    fileSizeBytes += bufferChunk.length;
    if (fileSizeBytes > LOGO_MAX_BYTES) {
      throw new DvgDiagramRouteError(
        "dvg_diagram_logo_too_large",
        "A Danetti logó maximum 3 MB lehet.",
        413
      );
    }
    chunks.push(bufferChunk);
  }

  const streamState = file.file as NodeJS.ReadableStream & { truncated?: boolean };
  if (streamState.truncated === true) {
    throw new DvgDiagramRouteError(
      "dvg_diagram_logo_too_large",
      "A Danetti logó maximum 3 MB lehet.",
      413
    );
  }

  const buffer = Buffer.concat(chunks);
  if (buffer.length === 0) {
    throw new DvgDiagramRouteError("dvg_diagram_logo_missing", "A feltöltött logó üres.");
  }

  return { buffer, fields: (file.fields as Record<string, unknown> | undefined) ?? {} };
}

function validateLogoFileType(file: MultipartFile): void {
  const filename = file.filename?.toLowerCase() ?? "";
  const mimetype = file.mimetype?.toLowerCase().split(";")[0]?.trim() ?? "";
  const hasImageFilename = /\.(png|jpe?g|webp|svg)$/.test(filename);
  const hasImageMime = LOGO_MIMETYPES.has(mimetype);
  if (!hasImageFilename && !hasImageMime) {
    throw new DvgDiagramRouteError(
      "dvg_diagram_logo_invalid_type",
      "A Danetti logó PNG, JPG, WEBP vagy SVG fájl legyen."
    );
  }
}

function readShopMode(value: string | undefined): DvgDiagramShopMode {
  if (value === undefined || value === "legacy") return "legacy";
  if (value === "new_shop") return "new_shop";
  throw new DvgDiagramRouteError(
    "dvg_diagram_shop_invalid",
    "Érvénytelen DVG forrás. Használd: legacy vagy new_shop."
  );
}

function readFamily(value: string | undefined): DvgDiagramFamily {
  if (value === "coffee" || value === "grinders") return value;
  throw new DvgDiagramRouteError(
    "dvg_diagram_family_invalid",
    "Érvénytelen diagram család. Használd: coffee vagy grinders."
  );
}

function readBrandsField(fields: Record<string, unknown>): string[] {
  const rawValue = readTextField(fields, "brands");
  if (!rawValue) {
    throw new DvgDiagramRouteError(
      "dvg_diagram_brands_missing",
      "Legalább egy DVG márkát ki kell választani."
    );
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(rawValue);
  } catch {
    parsed = rawValue.split(",");
  }

  if (!Array.isArray(parsed)) {
    throw new DvgDiagramRouteError("dvg_diagram_brands_invalid", "A brands mező tömb legyen.");
  }

  const brands = parsed
    .filter((brand): brand is string => typeof brand === "string")
    .map((brand) => brand.trim())
    .filter(Boolean);

  if (brands.length === 0) {
    throw new DvgDiagramRouteError(
      "dvg_diagram_brands_missing",
      "Legalább egy DVG márkát ki kell választani."
    );
  }

  return Array.from(new Set(brands)).slice(0, 50);
}

function readOptionalInteger(
  fields: Record<string, unknown>,
  name: string,
  min: number,
  max: number
): number | undefined {
  const rawValue = readTextField(fields, name);
  if (rawValue === undefined || rawValue === "") return undefined;
  const parsed = Number(rawValue);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new DvgDiagramRouteError(
      "dvg_diagram_limit_invalid",
      `${name} egész szám legyen ${min} és ${max} között.`
    );
  }
  return parsed;
}

function readOptionalIntegerFromValue(
  rawValue: string | undefined,
  name: string,
  min: number,
  max: number
): number | undefined {
  const value = rawValue?.trim();
  if (value === undefined || value === "") return undefined;
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < min || parsed > max) {
    throw new DvgDiagramRouteError(
      "dvg_diagram_limit_invalid",
      `${name} egész szám legyen ${min} és ${max} között.`
    );
  }
  return parsed;
}

function readTextField(fields: Record<string, unknown>, name: string): string | undefined {
  const rawField = fields[name];
  const rawValue =
    rawField && typeof rawField === "object" && "value" in rawField
      ? (rawField as { value?: unknown }).value
      : rawField;
  return typeof rawValue === "string" ? rawValue.trim() : undefined;
}

function readRequiredText(value: string | undefined, code: string, message: string): string {
  const trimmed = value?.trim();
  if (!trimmed) throw new DvgDiagramRouteError(code, message);
  return trimmed;
}

function readBodyObject(body: unknown): Record<string, unknown> {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    throw new DvgDiagramRouteError(
      "dvg_diagram_request_invalid",
      "A DVG diagram kérés JSON objektum legyen."
    );
  }
  return body as Record<string, unknown>;
}

function readBodyText(body: Record<string, unknown>, name: string): string | undefined {
  const value = body[name];
  return typeof value === "string" ? value.trim() : undefined;
}

function handleRouteError(reply: FastifyReply, error: unknown) {
  if (error instanceof DvgDiagramRouteError) {
    return reply.code(error.statusCode).send({
      error: { code: error.code, message: error.message },
    });
  }

  const message = error instanceof Error ? error.message : "Ismeretlen DVG diagram hiba.";
  return reply.code(500).send({
    error: { code: "dvg_diagram_generation_failed", message },
  });
}

class DvgDiagramRouteError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode = 400
  ) {
    super(message);
    this.name = "DvgDiagramRouteError";
  }
}
