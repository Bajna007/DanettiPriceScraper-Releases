import type { DvgDiagramArea, ParsedDvgDiagramDetail } from "./dvg-diagrams.service.js";

export function normalizeDiagramCoords(value: string | null, shape: string): string | null {
  if (shape === "default") return "";
  if (!value) return null;
  const parts = value
    .trim()
    .replace(/^[,;\s]+|[,;\s]+$/g, "")
    .split(/\s*[,;]\s*|\s+/);
  const validLength =
    shape === "rect"
      ? parts.length === 4
      : shape === "circle"
        ? parts.length === 3
        : shape === "poly"
          ? parts.length >= 6 && parts.length % 2 === 0
          : false;
  if (!validLength || parts.some((part) => !/^-?(?:\d+(?:\.\d*)?|\.\d+)%?$/.test(part)))
    return null;
  return parts.join(",");
}

// Output always uses the decoded image's natural aspect ratio. Map coordinates may have
// been authored against smaller HTML dimensions; transform them together with that image.
export function fitDiagramAreas(parsed: ParsedDvgDiagramDetail, width: number, height: number) {
  let authoredWidth =
    parsed.imageWidth ?? (parsed.imageHeight ? (width * parsed.imageHeight) / height : width);
  let authoredHeight = parsed.imageHeight ?? (height * authoredWidth) / width;
  // The supplier uses e.g. width="709" on 700 px JPEGs whose labels/hotspots are
  // authored in native pixels. Small HTML layout discrepancies are not a new map grid.
  if (
    Math.abs(authoredWidth / width - 1) <= 0.02 &&
    Math.abs(authoredHeight / height - 1) <= 0.02
  ) {
    authoredWidth = width;
    authoredHeight = height;
  }
  const numericAreas = parsed.areas.filter((a) => a.shape !== "default" && !a.coords.includes("%"));
  const fits = (w: number, h: number) =>
    numericAreas.filter((a) => {
      const n = a.coords.split(",").map(Number);
      return a.shape === "circle"
        ? n[0] - n[2] >= 0 && n[1] - n[2] >= 0 && n[0] + n[2] <= w && n[1] + n[2] <= h
        : n.every((v, i) => v >= 0 && v <= (i % 2 === 0 ? w : h));
    }).length;
  // Some supplier pages declare thumbnail dimensions but retain native-pixel hotspots.
  // Prefer native coordinates only when they explain more complete areas, never an outlier alone.
  if (
    numericAreas.length &&
    fits(width, height) - fits(authoredWidth, authoredHeight) >=
      Math.min(numericAreas.length, Math.max(3, Math.ceil(numericAreas.length * 0.1))) &&
    fits(width, height) / numericAreas.length >= 0.9
  ) {
    authoredWidth = width;
    authoredHeight = height;
  }
  const scaleX = width / authoredWidth;
  const scaleY = height / authoredHeight;
  let adjusted = 0;
  let skipped = parsed.skippedAreaCount;
  const areas: DvgDiagramArea[] = [];
  for (const area of parsed.areas) {
    if (area.shape === "default") {
      areas.push(area);
      continue;
    }
    const parts = area.coords.split(",");
    const values = parts.map((part, i) => {
      const radius = area.shape === "circle" && i === 2;
      const extent = radius ? Math.min(width, height) : i % 2 === 0 ? width : height;
      const scale = radius ? Math.min(scaleX, scaleY) : i % 2 === 0 ? scaleX : scaleY;
      return part.endsWith("%") ? (parseFloat(part) * extent) / 100 : Number(part) * scale;
    });
    let coords: number[] | null = values;
    let shape = area.shape;
    if (values.some((v) => !Number.isFinite(v))) coords = null;
    else if (area.shape === "rect") {
      const [x1, y1, x2, y2] = values;
      coords = [
        Math.max(0, Math.min(width, Math.min(x1, x2))),
        Math.max(0, Math.min(height, Math.min(y1, y2))),
        Math.max(0, Math.min(width, Math.max(x1, x2))),
        Math.max(0, Math.min(height, Math.max(y1, y2))),
      ];
      if (coords[0] >= coords[2] || coords[1] >= coords[3]) coords = null;
    } else if (area.shape === "circle") {
      const [x, y, radius] = values;
      const rx = parts[2].endsWith("%") ? radius : Number(parts[2]) * scaleX;
      const ry = parts[2].endsWith("%") ? radius : Number(parts[2]) * scaleY;
      if (rx <= 0 || ry <= 0) coords = null;
      else if (
        Math.abs(rx - ry) > 0.001 ||
        x - rx < 0 ||
        y - ry < 0 ||
        x + rx > width ||
        y + ry > height
      ) {
        // HTML has no ellipse shape. A clipped polygon preserves the hotspot instead
        // of shrinking the entire hit target when it crosses the image edge.
        coords = clipPolygon(
          Array.from({ length: 64 }, (_, i) => {
            const angle = (2 * Math.PI * i) / 64;
            return [x + rx * Math.cos(angle), y + ry * Math.sin(angle)];
          }).flat(),
          width,
          height
        );
        shape = "poly";
      } else coords = [x, y, radius];
    } else if (area.shape === "poly") {
      coords = clipPolygon(values, width, height);
    }
    if (!coords) {
      skipped++;
      continue;
    }
    const normalized = coords.map((v) => Math.round(v)).join(",");
    // Reject shapes collapsed by pixel rounding as well as originally degenerate shapes.
    const rounded = normalized.split(",").map(Number);
    if (
      (shape === "rect" && (rounded[0] >= rounded[2] || rounded[1] >= rounded[3])) ||
      (shape === "circle" && rounded[2] <= 0) ||
      (shape === "poly" && !clipPolygon(rounded, width, height))
    ) {
      skipped++;
      continue;
    }
    if (normalized !== area.coords) adjusted++;
    areas.push({ ...area, shape, coords: normalized });
  }
  return { areas, skippedAreaCount: skipped, adjustedAreaCount: adjusted, scaleX, scaleY };
}

function clipPolygon(values: number[], width: number, height: number): number[] | null {
  let points = Array.from({ length: values.length / 2 }, (_, i) => [
    values[2 * i],
    values[2 * i + 1],
  ]);
  for (const [axis, boundary, sign] of [
    [0, 0, 1],
    [0, width, -1],
    [1, 0, 1],
    [1, height, -1],
  ]) {
    const input = points;
    points = [];
    for (let i = 0; i < input.length; i++) {
      const a = input[(i + input.length - 1) % input.length],
        b = input[i];
      const aInside = (a[axis] - boundary) * sign >= 0,
        bInside = (b[axis] - boundary) * sign >= 0;
      if (aInside !== bInside) {
        const t = (boundary - a[axis]) / (b[axis] - a[axis]);
        points.push([a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])]);
      }
      if (bInside) points.push(b);
    }
  }
  if (points.length < 3) return null;
  const area = points.reduce((sum, p, i) => {
    const q = points[(i + 1) % points.length];
    return sum + p[0] * q[1] - q[0] * p[1];
  }, 0);
  return Math.abs(area) >= 1 ? points.flat() : null;
}
