"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import {
  convertDvgDiagram,
  formatApiErrorMessage,
  getApiBaseUrl,
  listDvgDiagramBrands,
  listDvgDiagrams,
  type DvgDiagramBrandOption,
  type DvgDiagramConvertResult,
  type DvgDiagramFamily,
  type DvgDiagramShopMode,
  type DvgDiagramListItem,
} from "../../src/lib/api";

type BrandState = {
  loading: boolean;
  error: string | null;
  items: DvgDiagramBrandOption[];
};

type DiagramState = {
  loading: boolean;
  error: string | null;
  items: DvgDiagramListItem[];
  warnings: string[];
};
type ConvertedDiagram = DvgDiagramConvertResult & { previewRevision: number };

const families: Array<{ value: DvgDiagramFamily; label: string }> = [
  { value: "coffee", label: "Kávégépek" },
  { value: "grinders", label: "Őrlők / darálók" },
];

const emptyBrandState: Record<DvgDiagramFamily, BrandState> = {
  coffee: { loading: false, error: null, items: [] },
  grinders: { loading: false, error: null, items: [] },
};

const emptyDiagramState: DiagramState = {
  loading: false,
  error: null,
  items: [],
  warnings: [],
};

export default function DvgDiagramsPage() {
  const [shopMode, setShopMode] = useState<DvgDiagramShopMode>("legacy");
  const [modeReady, setModeReady] = useState(false);
  const [family, setFamily] = useState<DvgDiagramFamily>("coffee");
  const [brands, setBrands] = useState(emptyBrandState);
  const [selectedBrand, setSelectedBrand] = useState("");
  const [brandSearch, setBrandSearch] = useState("");
  const [diagrams, setDiagrams] = useState(emptyDiagramState);
  const [convertingCode, setConvertingCode] = useState<string | null>(null);
  const [converted, setConverted] = useState<Record<string, ConvertedDiagram>>({});
  const previewRevision = useRef(0);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [copiedImageCode, setCopiedImageCode] = useState<string | null>(null);
  const [imageUrls, setImageUrls] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [brandRetry, setBrandRetry] = useState(0);
  const diagramRequest = useRef<AbortController | null>(null);
  const selectionEpoch = useRef(0);

  const activeBrands = brands[family];
  const selectedBrandLabel =
    activeBrands.items.find((brand) => brand.value === selectedBrand)?.label ?? selectedBrand;
  const filteredBrands = useMemo(() => {
    const query = brandSearch.trim().toLowerCase();
    if (!query) return activeBrands.items;
    return activeBrands.items.filter((brand) => brand.label.toLowerCase().includes(query));
  }, [activeBrands.items, brandSearch]);

  useEffect(() => {
    try {
      if (localStorage.getItem("danetti-dvg-diagram-shop") === "new_shop") setShopMode("new_shop");
    } catch {
      /* The source selector works even when browser storage is unavailable. */
    }
    setModeReady(true);
  }, []);

  function changeShopMode(mode: DvgDiagramShopMode) {
    if (mode === shopMode) return;
    selectionEpoch.current++;
    diagramRequest.current?.abort();
    setBrands(emptyBrandState);
    setSelectedBrand("");
    setDiagrams(emptyDiagramState);
    setConverted({});
    setImageUrls({});
    setShopMode(mode);
    try {
      localStorage.setItem("danetti-dvg-diagram-shop", mode);
    } catch {
      /* Memory-only selection remains usable. */
    }
  }

  useEffect(() => {
    if (!modeReady || brands[family].items.length > 0) return;

    let active = true;
    const controller = new AbortController();
    setBrands((current) => ({
      ...current,
      [family]: { ...current[family], loading: true, error: null },
    }));

    listDvgDiagramBrands(family, controller.signal, shopMode)
      .then((response) => {
        if (!active) return;
        setBrands((current) => ({
          ...current,
          [family]: { loading: false, error: null, items: response.items },
        }));
      })
      .catch((err) => {
        if (!active) return;
        setBrands((current) => ({
          ...current,
          [family]: { ...current[family], loading: false, error: formatApiErrorMessage(err) },
        }));
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [family, brandRetry, shopMode, modeReady]);

  useEffect(() => {
    selectionEpoch.current++;
    diagramRequest.current?.abort();
    setSelectedBrand("");
    setBrandSearch("");
    setDiagrams(emptyDiagramState);
    setConverted({});
    setImageUrls({});
    setCopiedImageCode(null);
    setConvertingCode(null);
    setError(null);
    return () => {
      selectionEpoch.current++;
      diagramRequest.current?.abort();
    };
  }, [family, shopMode]);

  async function chooseBrand(brandValue: string) {
    diagramRequest.current?.abort();
    const controller = new AbortController();
    diagramRequest.current = controller;
    const epoch = ++selectionEpoch.current;
    setSelectedBrand(brandValue);
    setBrandSearch("");
    setConverted({});
    setImageUrls({});
    setCopiedCode(null);
    setCopiedImageCode(null);
    setError(null);
    setConvertingCode(null);
    setDiagrams({ loading: true, error: null, items: [], warnings: [] });

    try {
      const response = await listDvgDiagrams({
        family,
        brand: brandValue,
        shopMode,
        maxDiagrams: 1000,
        maxPagesPerListing: 50,
        signal: controller.signal,
      });
      if (controller.signal.aborted || epoch !== selectionEpoch.current) return;
      setDiagrams({
        loading: false,
        error: null,
        items: response.items,
        warnings: response.warnings,
      });
    } catch (err) {
      if (controller.signal.aborted || epoch !== selectionEpoch.current) return;
      setDiagrams({ loading: false, error: formatApiErrorMessage(err), items: [], warnings: [] });
    }
  }

  async function convertOne(diagram: DvgDiagramListItem) {
    const epoch = selectionEpoch.current;
    setError(null);
    setConvertingCode(diagram.diagramCode);
    try {
      const imageUrl = imageUrls[diagram.diagramCode]?.trim() || undefined;
      const result = await convertDvgDiagram({
        shopMode,
        family: diagram.family,
        brand: diagram.brand,
        model: diagram.model,
        diagramCode: diagram.diagramCode,
        imageUrl,
      });
      if (epoch !== selectionEpoch.current) return;
      const ready = { ...result, previewRevision: ++previewRevision.current };
      setConverted((current) => ({ ...current, [diagram.diagramCode]: ready }));
    } catch (err) {
      if (epoch !== selectionEpoch.current) return;
      setError(formatApiErrorMessage(err));
    } finally {
      if (epoch === selectionEpoch.current) setConvertingCode(null);
    }
  }

  function updateImageUrl(diagramCode: string, value: string) {
    setImageUrls((current) => ({ ...current, [diagramCode]: value }));
    setCopiedCode((current) => (current === diagramCode ? null : current));
  }

  async function copyConvertedHtml(diagram: DvgDiagramListItem) {
    const epoch = selectionEpoch.current;
    const result = converted[diagram.diagramCode];
    if (!result) return;

    try {
      await navigator.clipboard.writeText(
        buildDisplayedHtml(result, resolveOutputImageSrc(diagram, imageUrls[diagram.diagramCode]))
      );
      if (epoch !== selectionEpoch.current) return;
      setCopiedCode(diagram.diagramCode);
      window.setTimeout(
        () => setCopiedCode((current) => (current === diagram.diagramCode ? null : current)),
        1400
      );
    } catch {
      if (epoch !== selectionEpoch.current) return;
      setError("A vágólapra másolás nem sikerült. Jelöld ki a HTML mezőt és másold kézzel.");
    }
  }

  async function copyConvertedImage(diagram: DvgDiagramListItem) {
    const epoch = selectionEpoch.current;
    const result = converted[diagram.diagramCode];
    if (!result?.outputImagePath) return;

    try {
      await copyDiagramImageToClipboard(diagram.brand, diagram.diagramCode, shopMode);
      if (epoch !== selectionEpoch.current) return;
      setCopiedImageCode(diagram.diagramCode);
      window.setTimeout(
        () => setCopiedImageCode((current) => (current === diagram.diagramCode ? null : current)),
        1400
      );
    } catch {
      if (epoch !== selectionEpoch.current) return;
      setError("A kép vágólapra másolása nem sikerült. Nyisd meg a képet és másold kézzel.");
    }
  }

  return (
    <div className="page dvg-diagrams-page dvg-diagrams-page--minimal">
      <header className="dvg-diagram-workflow-header">
        <div>
          <h1 className="page-title">DVG Robbantott ábrák</h1>
          <p className="helper-text">
            Válassz márkát, nézd meg az ábrákat, konvertálj, majd másold a kész HTML-t.
          </p>
        </div>
        <span className="csv-safety-pill">WooCommerce írás nélkül</span>
      </header>

      <section className="card dvg-diagram-workflow">
        <fieldset className="dvg-shop-selector">
          <legend>Ábrák forrása</legend>
          <div className="dvg-shop-options">
            {(
              [
                ["legacy", "Legacy", "devecchigiuseppesrl.com"],
                ["new_shop", "New shop", "shop.dvgdevecchi.com"],
              ] as const
            ).map(([value, label, domain]) => (
              <label
                key={value}
                className={`dvg-shop-option${shopMode === value ? " is-selected" : ""}`}
              >
                <input
                  type="radio"
                  name="dvg-diagram-shop"
                  value={value}
                  checked={shopMode === value}
                  onChange={() => changeShopMode(value)}
                />
                <span>
                  <strong>{label}</strong>
                  <span>{domain}</span>
                </span>
              </label>
            ))}
          </div>
          <p className="field-help">
            Forrásváltás után válassz újra márkát. A korábban másolt HTML és a mentett képek
            megmaradnak.
          </p>
        </fieldset>
        <div className="dvg-diagram-step-row">
          <label className="field-label">
            1. Kategória
            <select
              className="input"
              value={family}
              onChange={(event) => setFamily(event.target.value as DvgDiagramFamily)}
            >
              {families.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </label>
          <label className="field-label">
            2. Márka keresése
            <input
              className="input"
              value={brandSearch}
              placeholder="pl. Astoria, Mazzer, Eureka"
              onChange={(event) => setBrandSearch(event.target.value)}
            />
          </label>
        </div>

        {activeBrands.loading ? <LoadingState message="DVG márkák betöltése..." /> : null}
        {activeBrands.error ? (
          <>
            <ErrorState message={activeBrands.error} />
            <button
              className="button secondary"
              type="button"
              onClick={() => setBrandRetry((value) => value + 1)}
            >
              Márkák újratöltése
            </button>
          </>
        ) : null}

        <div className="dvg-brand-picker" aria-label="DVG márkák">
          {filteredBrands.map((brand) => (
            <button
              key={brand.value}
              className={`dvg-brand-chip${selectedBrand === brand.value ? " active" : ""}`}
              type="button"
              onClick={() => chooseBrand(brand.value)}
            >
              {brand.label}
            </button>
          ))}
        </div>

        {!activeBrands.loading && !activeBrands.error && activeBrands.items.length === 0 ? (
          <EmptyState title="Nincs márkalista">
            A helyi API nem kapott márkákat a DVG publikus listából.
          </EmptyState>
        ) : null}
      </section>

      {selectedBrand ? (
        <section className="card dvg-diagram-list-panel">
          <div className="dvg-diagram-panel-head">
            <div>
              <h2 className="section-title">{selectedBrandLabel} ábrái</h2>
              <p className="helper-text">
                {diagrams.items.length > 0
                  ? `${diagrams.items.length} publikus DVG ábra található.`
                  : "A lista betöltése után itt jelennek meg az ábrák."}
              </p>
            </div>
            <div className="dvg-diagram-panel-actions">
              <a
                className="button secondary small"
                href={buildDvgBrandUrl(family, selectedBrand, shopMode)}
                target="_blank"
              >
                DVG oldal
              </a>
            </div>
          </div>

          {diagrams.loading ? <LoadingState message="DVG ábrák betöltése..." /> : null}
          {diagrams.error ? (
            <>
              <ErrorState message={diagrams.error} />
              <button
                className="button secondary"
                type="button"
                onClick={() => void chooseBrand(selectedBrand)}
              >
                Ábrák újratöltése
              </button>
            </>
          ) : null}
          {diagrams.warnings.length > 0 ? (
            <div className="notice warning">{diagrams.warnings.join(" ")}</div>
          ) : null}

          {!diagrams.loading && !diagrams.error && diagrams.items.length === 0 ? (
            <EmptyState title="Nincs ábra ehhez a márkához">
              Válassz másik márkát, vagy ellenőrizd a DVG oldalt.
            </EmptyState>
          ) : null}

          <div className="dvg-diagram-list">
            {diagrams.items.map((diagram) => (
              <DiagramRow
                key={`${diagram.brand}-${diagram.model ?? "all"}-${diagram.diagramCode}`}
                diagram={diagram}
                shopMode={shopMode}
                converted={converted[diagram.diagramCode] ?? null}
                imageUrl={imageUrls[diagram.diagramCode] ?? ""}
                isConverting={convertingCode === diagram.diagramCode}
                isCopied={copiedCode === diagram.diagramCode}
                isImageCopied={copiedImageCode === diagram.diagramCode}
                onImageUrlChange={(value) => updateImageUrl(diagram.diagramCode, value)}
                onConvert={() => convertOne(diagram)}
                onCopy={() => copyConvertedHtml(diagram)}
                onCopyImage={() => copyConvertedImage(diagram)}
              />
            ))}
          </div>
        </section>
      ) : null}

      {error ? <ErrorState message={error} /> : null}
    </div>
  );
}

function DiagramRow({
  diagram,
  shopMode,
  converted,
  imageUrl,
  isConverting,
  isCopied,
  isImageCopied,
  onImageUrlChange,
  onConvert,
  onCopy,
  onCopyImage,
}: {
  diagram: DvgDiagramListItem;
  shopMode: DvgDiagramShopMode;
  converted: ConvertedDiagram | null;
  imageUrl: string;
  isConverting: boolean;
  isCopied: boolean;
  isImageCopied: boolean;
  onImageUrlChange: (value: string) => void;
  onConvert: () => void;
  onCopy: () => void;
  onCopyImage: () => void;
}) {
  const displayedHtml = converted
    ? buildDisplayedHtml(converted, resolveOutputImageSrc(diagram, imageUrl))
    : "";
  const displayName = converted?.diagramName ?? diagram.diagramName;

  return (
    <article className="dvg-diagram-row">
      <div className="dvg-diagram-row-main">
        <div>
          <strong>{diagram.diagramCode}</strong>
          {displayName ? (
            <p className="helper-text dvg-diagram-product-name">{displayName}</p>
          ) : null}
          <p className="helper-text dvg-diagram-model-name">
            {diagram.model ? diagram.model : "Általános / modell nélkül"}
          </p>
        </div>
        <a
          className="button ghost small"
          href={converted?.sourcePageUrl ?? diagram.sourcePageUrl}
          target="_blank"
          rel="noreferrer"
        >
          Forrás
        </a>
      </div>

      <div className="dvg-diagram-row-actions">
        <label className="field-label dvg-diagram-image-url-field">
          Kép URL ehhez a cikkhez
          <input
            className="input"
            value={imageUrl}
            placeholder={`Üresen: ${diagram.diagramCode}.jpg, vagy teljes WooCommerce URL`}
            onChange={(event) => onImageUrlChange(event.target.value)}
          />
        </label>
        <button
          className="button secondary small"
          type="button"
          onClick={onConvert}
          disabled={isConverting}
        >
          {isConverting ? "Konvertálás..." : converted ? "Újrakonvertálás" : "Konvertálás"}
        </button>
        <button className="button small" type="button" onClick={onCopy} disabled={!converted}>
          {isCopied ? "Másolva" : "HTML másolása"}
        </button>
      </div>

      {converted ? (
        <div className="dvg-diagram-converted">
          <div className="dvg-diagram-image-row">
            {converted.outputImagePath ? (
              <>
                <img
                  className="dvg-diagram-branded-preview"
                  src={buildDiagramImageUrl(
                    diagram.brand,
                    diagram.diagramCode,
                    shopMode,
                    converted.previewRevision
                  )}
                  alt={`${diagram.diagramCode} konvertált robbantott ábra`}
                  loading="lazy"
                />
                <div className="dvg-diagram-image-actions">
                  <a
                    className="button secondary small"
                    href={buildDiagramImageUrl(
                      diagram.brand,
                      diagram.diagramCode,
                      shopMode,
                      converted.previewRevision
                    )}
                    target="_blank"
                  >
                    Kép megnyitása
                  </a>
                  <button className="button ghost small" type="button" onClick={onCopyImage}>
                    {isImageCopied ? "Kép másolva" : "Kép vágólapra másolása"}
                  </button>
                </div>
              </>
            ) : null}
          </div>
          <span>
            {converted.imageWidth} x {converted.imageHeight}px · {converted.areaCount} kattintható
            cikkszám
            {converted.outputImagePath ? (
              <>
                {" "}
                · Mentve: <code>{basename(converted.outputImagePath)}</code>
              </>
            ) : null}
          </span>
          {converted.warnings.length > 0 ? <span>{converted.warnings.join(" ")}</span> : null}
          <textarea className="input dvg-diagram-html-output" readOnly value={displayedHtml} />
        </div>
      ) : null}
    </article>
  );
}

function buildDvgBrandUrl(
  family: DvgDiagramFamily,
  brand: string,
  mode: DvgDiagramShopMode
): string {
  if (mode === "new_shop") {
    const url = new URL("https://shop.dvgdevecchi.com/e-commerce/catalog");
    url.searchParams.set("g", "C0627");
    url.searchParams.set("m", family === "coffee" ? "M0052" : "M0063");
    url.searchParams.set("c1", brand);
    return url.toString();
  }
  const c2 = family === "coffee" ? "COFFEE MACHINES - Diagrams" : "GRINDERS - Diagrams";
  const url = new URL("https://devecchigiuseppesrl.com/e-commerce/cerca.asp");
  url.searchParams.set("c2", c2);
  url.searchParams.set("c3", brand);
  return url.toString();
}

function buildDiagramImageUrl(
  brand: string,
  code: string,
  shopMode: DvgDiagramShopMode,
  revision?: number
): string {
  const params = new URLSearchParams({ brand, code, shopMode });
  if (revision !== undefined) params.set("revision", String(revision));
  return `${getApiBaseUrl()}/dvg-diagrams/image?${params.toString()}`;
}

async function copyDiagramImageToClipboard(
  brand: string,
  code: string,
  shopMode: DvgDiagramShopMode
) {
  if (!navigator.clipboard || typeof ClipboardItem === "undefined") {
    throw new Error("A böngésző nem támogatja a kép vágólapra másolását.");
  }
  const response = await fetch(buildDiagramImageUrl(brand, code, shopMode));
  if (!response.ok) throw new Error("A kép nem tölthető le a vágólaphoz.");
  const blob = await response.blob();
  const file = new File([blob], `${encodeURIComponent(code)}.jpg`, {
    type: blob.type || "image/jpeg",
  });
  try {
    await navigator.clipboard.write([new ClipboardItem({ [file.type]: file })]);
  } catch {
    const pngFile = await convertImageBlobToPngFile(blob, code);
    await navigator.clipboard.write([new ClipboardItem({ [pngFile.type]: pngFile })]);
  }
}

async function convertImageBlobToPngFile(blob: Blob, code: string): Promise<File> {
  const bitmap = await createImageBitmap(blob);
  const canvas = document.createElement("canvas");
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  const context = canvas.getContext("2d");
  if (!context) {
    bitmap.close();
    throw new Error("A kép vágólapra másolása nem támogatott.");
  }
  try {
    context.drawImage(bitmap, 0, 0);
  } finally {
    bitmap.close();
  }
  const pngBlob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (value) => (value ? resolve(value) : reject(new Error("PNG konverzió sikertelen."))),
      "image/png"
    );
  });
  return new File([pngBlob], `${encodeURIComponent(code)}.png`, { type: "image/png" });
}

function resolveOutputImageSrc(diagram: DvgDiagramListItem, imageUrl = ""): string {
  return imageUrl.trim() || `${encodeURIComponent(diagram.diagramCode)}.jpg`;
}

function buildDisplayedHtml(result: DvgDiagramConvertResult, imageSrc: string): string {
  return result.html.replace(/<img\b([^>]*?)\bsrc="[^"]*"/i, (_match, beforeSrc: string) => {
    return `<img${beforeSrc}src="${escapeHtmlAttribute(imageSrc)}"`;
  });
}

function escapeHtmlAttribute(value: string): string {
  return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
}

function basename(filePath: string): string {
  return filePath.split(/[\\/]/).pop() ?? filePath;
}
