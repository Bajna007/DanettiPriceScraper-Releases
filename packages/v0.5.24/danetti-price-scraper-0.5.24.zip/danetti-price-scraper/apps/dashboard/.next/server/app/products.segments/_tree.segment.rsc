:HL["/_next/static/chunks/0bb2k-q9sk5ld.css","style"]
:HL["/_next/static/chunks/1j_4dmeic0mzs.css","style"]
:HL["/_next/static/chunks/094pzmdbfdw32.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"products","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"KvX56fbR_QZeYHaLQlGW9"}
