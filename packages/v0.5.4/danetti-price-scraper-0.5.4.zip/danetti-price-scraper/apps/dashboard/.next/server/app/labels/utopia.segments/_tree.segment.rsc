:HL["/_next/static/chunks/3v8wbfql-b08z.css","style"]
:HL["/_next/static/chunks/2d5yakrqa9wkz.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"labels","param":null,"prefetchHints":4192,"slots":{"children":{"name":"utopia","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"hxdpgnRCPRikC-mM6LvdR"}
