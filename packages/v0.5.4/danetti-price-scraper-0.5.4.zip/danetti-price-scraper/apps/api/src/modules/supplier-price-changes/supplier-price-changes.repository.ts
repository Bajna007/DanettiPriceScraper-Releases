import { DVG_CONNECTOR_ID, LF_CONNECTOR_ID } from "@danetti/connectors";
import {
  catalogProducts,
  exchangeRates,
  supplierPriceSnapshots,
  suppliers,
  type DanettiDatabase,
} from "@danetti/db";
import { and, desc, eq, isNotNull, lte, or, sql } from "drizzle-orm";

export type SupplierPriceChangeSupplierScope = "all" | "dvg" | "lf";

export interface SupplierPriceChangeSnapshotRow {
  snapshotId: string;
  supplierId: string;
  supplierName: string | null;
  supplierMappingId: string | null;
  catalogProductId: string;
  sku: string;
  productName: string;
  supplierArticleNumber: string;
  priceNetEur: string | number | null;
  observedAt: Date;
  createdAt: Date;
  currentPrice: string | number | null;
  salePrice: string | number | null;
  regularPrice: string | number | null;
}

export interface SupplierPriceChangesRepositoryLike {
  getLatestEurHufRate(): Promise<number | null>;
  listRecentCatalogSnapshots(
    limit: number,
    supplierScope: SupplierPriceChangeSupplierScope
  ): Promise<SupplierPriceChangeSnapshotRow[]>;
}

export class SupplierPriceChangesRepository implements SupplierPriceChangesRepositoryLike {
  constructor(private readonly db: DanettiDatabase) {}

  async getLatestEurHufRate(): Promise<number | null> {
    const [rate] = await this.db
      .select({ eurHufRate: exchangeRates.eurHufRate })
      .from(exchangeRates)
      .orderBy(desc(exchangeRates.effectiveAt), desc(exchangeRates.createdAt))
      .limit(1);
    return numberOrNull(rate?.eurHufRate);
  }

  async listRecentCatalogSnapshots(
    _limit: number,
    supplierScope: SupplierPriceChangeSupplierScope
  ): Promise<SupplierPriceChangeSnapshotRow[]> {
    const supplierCode = readSupplierCodeFilter(supplierScope);
    const snapshotFilters = supplierCode
      ? and(
          isNotNull(supplierPriceSnapshots.priceNetEur),
          eq(supplierPriceSnapshots.currency, "EUR"),
          eq(suppliers.code, supplierCode)
        )
      : and(
          isNotNull(supplierPriceSnapshots.priceNetEur),
          eq(supplierPriceSnapshots.currency, "EUR")
        );

    // Search the complete history before returning at most three candidates per
    // identity. Keep the newest occurrence of each price and the second observation
    // so unchanged history is distinguishable from a single baseline observation.
    // The legacy raw scan limit must not hide older changes.
    const identity = sql`${supplierPriceSnapshots.catalogProductId},
      ${supplierPriceSnapshots.supplierId}, ${supplierPriceSnapshots.supplierMappingId},
      ${supplierPriceSnapshots.supplierArticleNumber}`;
    const newestFirst = sql`${supplierPriceSnapshots.observedAt} desc,
      ${supplierPriceSnapshots.createdAt} desc, ${supplierPriceSnapshots.id} desc`;
    const distinctPrices = this.db
      .select({
        snapshotId: sql<string>`${supplierPriceSnapshots.id}`.as("snapshot_id"),
        supplierId: supplierPriceSnapshots.supplierId,
        supplierName: sql<string | null>`${suppliers.name}`.as("supplier_name"),
        supplierMappingId: supplierPriceSnapshots.supplierMappingId,
        catalogProductId: sql<string>`${catalogProducts.id}`.as("catalog_product_id"),
        sku: catalogProducts.sku,
        productName: sql<string>`${catalogProducts.name}`.as("product_name"),
        supplierArticleNumber: supplierPriceSnapshots.supplierArticleNumber,
        priceNetEur: supplierPriceSnapshots.priceNetEur,
        observedAt: supplierPriceSnapshots.observedAt,
        createdAt: supplierPriceSnapshots.createdAt,
        currentPrice: catalogProducts.currentPrice,
        salePrice: catalogProducts.salePrice,
        regularPrice: catalogProducts.regularPrice,
        priceOccurrence: sql<number>`row_number() over (
          partition by ${identity}, ${supplierPriceSnapshots.priceNetEur}
          order by ${newestFirst}
        )`.as("price_occurrence"),
        observationRank: sql<number>`row_number() over (
          partition by ${identity} order by ${newestFirst}
        )`.as("observation_rank"),
      })
      .from(supplierPriceSnapshots)
      .innerJoin(catalogProducts, eq(supplierPriceSnapshots.catalogProductId, catalogProducts.id))
      .leftJoin(suppliers, eq(supplierPriceSnapshots.supplierId, suppliers.id))
      .where(snapshotFilters)
      .as("price_observations");

    const rankedPrices = this.db
      .select({
        snapshotId: distinctPrices.snapshotId,
        supplierId: distinctPrices.supplierId,
        supplierName: distinctPrices.supplierName,
        supplierMappingId: distinctPrices.supplierMappingId,
        catalogProductId: distinctPrices.catalogProductId,
        sku: distinctPrices.sku,
        productName: distinctPrices.productName,
        supplierArticleNumber: distinctPrices.supplierArticleNumber,
        priceNetEur: distinctPrices.priceNetEur,
        observedAt: distinctPrices.observedAt,
        createdAt: distinctPrices.createdAt,
        currentPrice: distinctPrices.currentPrice,
        salePrice: distinctPrices.salePrice,
        regularPrice: distinctPrices.regularPrice,
        priceRank: sql<number>`row_number() over (
          partition by ${distinctPrices.catalogProductId}, ${distinctPrices.supplierId},
            ${distinctPrices.supplierMappingId}, ${distinctPrices.supplierArticleNumber}
          order by ${distinctPrices.observedAt} desc, ${distinctPrices.createdAt} desc,
            ${distinctPrices.snapshotId} desc
        )`.as("price_rank"),
      })
      .from(distinctPrices)
      .where(or(eq(distinctPrices.priceOccurrence, 1), eq(distinctPrices.observationRank, 2)))
      .as("ranked_prices");

    const snapshots = await this.db
      .select({
        snapshotId: rankedPrices.snapshotId,
        supplierId: rankedPrices.supplierId,
        supplierName: rankedPrices.supplierName,
        supplierMappingId: rankedPrices.supplierMappingId,
        catalogProductId: rankedPrices.catalogProductId,
        sku: rankedPrices.sku,
        productName: rankedPrices.productName,
        supplierArticleNumber: rankedPrices.supplierArticleNumber,
        priceNetEur: rankedPrices.priceNetEur,
        observedAt: rankedPrices.observedAt,
        createdAt: rankedPrices.createdAt,
        currentPrice: rankedPrices.currentPrice,
        salePrice: rankedPrices.salePrice,
        regularPrice: rankedPrices.regularPrice,
      })
      .from(rankedPrices)
      .where(lte(rankedPrices.priceRank, 3))
      .orderBy(
        desc(rankedPrices.observedAt),
        desc(rankedPrices.createdAt),
        desc(rankedPrices.snapshotId)
      );
    return [...snapshots, ...(await this.listOperatorHistory(supplierCode))];
  }

  private async listOperatorHistory(
    supplierCode: string | null
  ): Promise<SupplierPriceChangeSnapshotRow[]> {
    // Read-only operator runs retain real observations even when snapshot writes
    // were disabled. Require the saved mapping and connector's exact identity
    // evidence; never promote suggestions or failed reads into price history.
    // Legacy rows have no individual timestamp, so use the run start as their
    // observation date (not updated_at, which can change when a run is resumed).
    const rows = await this.db.execute(sql`
      WITH runs AS (
        SELECT run_id, started_at, rows, ${DVG_CONNECTOR_ID}::text AS code
        FROM dvg_operator_runs
        UNION ALL
        SELECT run_id, started_at, rows, ${LF_CONNECTOR_ID}::text AS code
        FROM lf_operator_runs
      ), observations AS (
        SELECT 'operator:' || r.code || ':' || r.run_id || ':' || item.ordinality AS id,
          m.supplier_id, s.name AS supplier_name, m.id AS supplier_mapping_id,
          p.id AS catalog_product_id, p.sku, p.name AS product_name,
          m.supplier_article_number,
          CASE WHEN (item.value->>'supplierNetEur') ~ '^[0-9]+([.][0-9]+)?$'
            THEN round((item.value->>'supplierNetEur')::numeric, 2) END AS price_net_eur,
          r.started_at AS observed_at, r.started_at AS created_at,
          p.current_price, p.sale_price, p.regular_price
        FROM runs r
        CROSS JOIN LATERAL jsonb_array_elements(r.rows) WITH ORDINALITY item(value, ordinality)
        JOIN supplier_mappings m ON m.id::text = item.value->>'supplierMappingId'
          AND m.catalog_product_id::text = item.value->>'catalogProductId'
          AND m.supplier_id::text = item.value->>'supplierId'
          AND upper(trim(m.supplier_article_number)) = upper(trim(item.value->>'supplierArticleNumber'))
        JOIN suppliers s ON s.id = m.supplier_id AND s.code = r.code
        JOIN catalog_products p ON p.id = m.catalog_product_id
        WHERE (${supplierCode}::text IS NULL OR r.code = ${supplierCode})
          AND item.value->>'status' = 'ok'
          AND item.value->>'currency' = 'EUR'
          AND item.value->>'candidateSource' = 'saved_mapping'
          AND (
            (r.code = ${DVG_CONNECTOR_ID}
              AND item.value->>'matchConfidence' = 'exact_dvg_article'
              AND upper(trim(item.value->>'dvgArticle')) = upper(trim(m.supplier_article_number)))
            OR (r.code = ${LF_CONNECTOR_ID}
              AND item.value->>'matchConfidence' = 'trusted_lf_item'
              AND upper(trim(item.value->>'lfAutocompleteId')) = 'C:' || upper(trim(m.supplier_article_number)))
          )
      ), occurrences AS (
        SELECT *, row_number() OVER (PARTITION BY catalog_product_id, supplier_id,
          supplier_mapping_id, supplier_article_number, price_net_eur
          ORDER BY observed_at DESC, id DESC) AS price_occurrence,
          row_number() OVER (PARTITION BY catalog_product_id, supplier_id,
          supplier_mapping_id, supplier_article_number
          ORDER BY observed_at DESC, id DESC) AS observation_rank
        FROM observations WHERE price_net_eur > 0
      ), ranked AS (
        SELECT *, row_number() OVER (PARTITION BY catalog_product_id, supplier_id,
          supplier_mapping_id, supplier_article_number
          ORDER BY observed_at DESC, id DESC) AS price_rank
        FROM occurrences WHERE price_occurrence = 1 OR observation_rank = 2
      )
      SELECT id AS "snapshotId", supplier_id AS "supplierId",
        supplier_name AS "supplierName", supplier_mapping_id AS "supplierMappingId",
        catalog_product_id AS "catalogProductId", sku, product_name AS "productName",
        supplier_article_number AS "supplierArticleNumber", price_net_eur AS "priceNetEur",
        observed_at AS "observedAt", created_at AS "createdAt",
        current_price AS "currentPrice", sale_price AS "salePrice", regular_price AS "regularPrice"
      FROM ranked WHERE price_rank <= 3
    `);
    return rows.map((row) => ({
      ...(row as unknown as SupplierPriceChangeSnapshotRow),
      observedAt: new Date(row.observedAt as string | Date),
      createdAt: new Date(row.createdAt as string | Date),
    }));
  }
}

function readSupplierCodeFilter(scope: SupplierPriceChangeSupplierScope): string | null {
  if (scope === "dvg") return DVG_CONNECTOR_ID;
  if (scope === "lf") return LF_CONNECTOR_ID;
  return null;
}

function numberOrNull(value: string | number | null | undefined): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}
