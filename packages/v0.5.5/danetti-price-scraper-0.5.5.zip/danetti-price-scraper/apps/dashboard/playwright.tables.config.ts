import { defineConfig } from "@playwright/test";

// Uses the operator runtime explicitly started for this verification; owns only its browser contexts.
export default defineConfig({
  testDir: "./e2e",
  testMatch: "table-experience.spec.ts",
  workers: 1,
  retries: 0,
  timeout: 180_000,
  expect: { timeout: 15_000 },
  use: { baseURL: "http://localhost:3000", trace: "off" },
});
