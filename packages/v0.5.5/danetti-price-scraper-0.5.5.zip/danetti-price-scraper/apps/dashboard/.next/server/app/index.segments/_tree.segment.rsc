:HL["/_next/static/chunks/1429ux59y15e-.css","style"]
:HL["/_next/static/chunks/3dfg4_wb1iiit.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"BCdUClFbU9hwjCUTcgrk_"}
