"use client";

import { useEffect, useMemo, useState, useRef, type ReactNode } from "react";
import {
  formatApiErrorMessage,
  getPricingSettings,
  listSupplierPriceChanges,
  saveEurHufRate,
  type SupplierPriceChangeDirection,
  type SupplierPriceChangeResponse,
  type SupplierPriceChangeRoundingMode,
  type SupplierPriceChangeRow,
  type SupplierPriceChangeSupplierScope,
} from "../../src/lib/api";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import { TablePagination } from "../../src/components/TablePagination";
import { formatDate } from "../../src/lib/formatters";

import type { PriceChangeSortBy } from "@danetti/shared";
import {
  ColumnResizer,
  SortButton,
  useColumnResize,
  useStoredColumnWidths,
} from "../../src/components/SheetHeader";
import {
  priceChangeColumns,
  buildPriceChangesCsv,
  buildPriceChangesPrint,
} from "../../src/products/price-changes-export";

import { TablePrintSettings } from "../../src/components/TablePrintSettings";
import { defaultTablePrintOptions } from "../../src/products/table-print";

const DEFAULT_LIMIT = 50;

export default function SupplierPriceChangesPage() {
  const [data, setData] = useState<SupplierPriceChangeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const [sort, setSort] = useState<{ id: PriceChangeSortBy; direction: "asc" | "desc" }>({
    id: "newObservedAt",
    direction: "desc",
  });
  const [exportColumns, setExportColumns] = useState<PriceChangeSortBy[]>(
    priceChangeColumns.map((column) => column.id)
  );
  const [exportOpen, setExportOpen] = useState(false);
  const [exportStatus, setExportStatus] = useState("");
  const [printOptions, setPrintOptions] = useState(defaultTablePrintOptions);
  const [reload, setReload] = useState(0);
  const [exporting, setExporting] = useState(false);
  const exportAlive = useRef(true);
  useEffect(() => {
    exportAlive.current = true;
    return () => {
      exportAlive.current = false;
    };
  }, []);
  const [eurHufRate, setEurHufRate] = useState<number | "">("");
  const [vatPercent, setVatPercent] = useState<number | "">(27);
  const [roundingEnabled, setRoundingEnabled] = useState(true);
  const [roundingIncrementHuf, setRoundingIncrementHuf] = useState<number | "">(100);
  const [roundingMode, setRoundingMode] = useState<SupplierPriceChangeRoundingMode>("up");
  const [direction, setDirection] = useState<SupplierPriceChangeDirection>("all");
  const [supplierScope, setSupplierScope] = useState<SupplierPriceChangeSupplierScope>("all");
  const [minChangePercent, setMinChangePercent] = useState<number | "">(0);
  const [rateSaveStatus, setRateSaveStatus] = useState<"saved" | "saving" | "error" | null>(null);
  const activeRate = readOptionalNumber(eurHufRate);
  const activeVat = readOptionalNumber(vatPercent) ?? 27;
  const activeRounding = readOptionalNumber(roundingIncrementHuf) ?? 100;
  const activeMinChange = readOptionalNumber(minChangePercent) ?? 0;

  const canGoBack = offset > 0;
  const canGoNext =
    data?.total !== undefined ? offset + (data?.items.length ?? 0) < data.total : false;
  const paginationLabel = useMemo(() => {
    const total = data?.total;
    if (total === undefined) return `Megjelenítve: ${offset + 1}-${offset + DEFAULT_LIMIT}`;
    const start = total === 0 ? 0 : offset + 1;
    const end = Math.min(offset + DEFAULT_LIMIT, total);
    return `Megjelenítve: ${start}-${end} / ${total}`;
  }, [data?.total, offset]);

  useEffect(() => {
    let active = true;
    getPricingSettings()
      .then((settings) => {
        if (!active) return;
        if (settings.eurHufRate !== null) setEurHufRate(settings.eurHufRate);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (activeRate === null) {
      setData(null);
      setLoading(false);
      return;
    }
    let active = true;
    const controller = new AbortController();
    setLoading(true);
    setError(null);

    listSupplierPriceChanges({
      signal: controller.signal,
      sortBy: sort.id,
      sortDirection: sort.direction,
      limit: DEFAULT_LIMIT,
      offset,
      eurHufRate: activeRate,
      vatPercent: activeVat,
      roundingEnabled,
      roundingIncrementHuf: activeRounding,
      roundingMode,
      direction,
      supplierScope,
      minChangePercent: activeMinChange,
    })
      .then((response) => {
        if (active) setData(response);
      })
      .catch((err) => {
        if (active) setError(formatApiErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [
    reload,
    activeMinChange,
    activeRate,
    activeRounding,
    activeVat,
    direction,
    offset,
    roundingEnabled,
    roundingMode,
    supplierScope,
    sort,
  ]);

  useEffect(() => {
    if (!data) return;
    if (data.total === 0 && offset !== 0) {
      setOffset(0);
      return;
    }
    if (data.total > 0 && offset >= data.total) {
      setOffset(Math.floor((data.total - 1) / DEFAULT_LIMIT) * DEFAULT_LIMIT);
    }
  }, [data, offset]);

  useEffect(() => {
    const rate = readOptionalNumber(eurHufRate);
    if (rate === null) return;
    const timer = window.setTimeout(() => {
      setRateSaveStatus("saving");
      saveEurHufRate({ eurHufRate: rate })
        .then(() => setRateSaveStatus("saved"))
        .catch(() => setRateSaveStatus("error"));
    }, 700);
    return () => window.clearTimeout(timer);
  }, [eurHufRate]);

  function updateDirection(value: SupplierPriceChangeDirection) {
    setOffset(0);
    setDirection(value);
  }

  function updateSupplierScope(value: SupplierPriceChangeSupplierScope) {
    setOffset(0);
    setSupplierScope(value);
  }

  async function exportRows(mode: "csv" | "print") {
    if (exporting || activeRate === null || !exportColumns.length || !data?.total) return;
    const printWindow = mode === "print" ? window.open("", "_blank") : null;
    if (mode === "print" && !printWindow) {
      setExportStatus("Engedélyezd a felugró ablakot a nyomtatáshoz.");
      return;
    }
    if (printWindow) printWindow.document.body.textContent = "Nyomtatás előkészítése…";
    setExporting(true);
    setExportStatus("Sorok betöltése…");
    const selectedColumns = [...exportColumns];
    try {
      const rows: SupplierPriceChangeRow[] = [];
      const seen = new Set<string>();
      let total: number | null = null;
      while (total === null || rows.length < total) {
        if (!exportAlive.current) {
          printWindow?.close();
          return;
        }
        const response = await listSupplierPriceChanges({
          limit: 200,
          offset: rows.length,
          eurHufRate: activeRate,
          vatPercent: activeVat,
          roundingEnabled,
          roundingIncrementHuf: activeRounding,
          roundingMode,
          direction,
          supplierScope,
          minChangePercent: activeMinChange,
          sortBy: sort.id,
          sortDirection: sort.direction,
        });
        if (total !== null && response.total !== total)
          throw new Error("A lista közben megváltozott. Indítsd újra az exportot.");
        total = response.total;
        if (!response.items.length && rows.length < total)
          throw new Error("Hiányos lista. Indítsd újra az exportot.");
        for (const row of response.items) {
          if (seen.has(row.newSnapshotId))
            throw new Error("A lista közben megváltozott. Indítsd újra az exportot.");
          seen.add(row.newSnapshotId);
          rows.push(row);
        }
        if (exportAlive.current) setExportStatus(`Betöltve: ${rows.length} / ${total}`);
      }
      if (!exportAlive.current) {
        printWindow?.close();
        return;
      }
      if (printWindow) {
        printWindow.document.open();
        printWindow.document.write(buildPriceChangesPrint(rows, selectedColumns, printOptions));
        printWindow.document.close();
        await printWindow.document.fonts.ready;
        printWindow.focus();
        printWindow.print();
      } else {
        const url = URL.createObjectURL(
          new Blob([buildPriceChangesCsv(rows, selectedColumns)], {
            type: "text/csv;charset=utf-8",
          })
        );
        const link = document.createElement("a");
        link.href = url;
        link.download = `danetti-arvaltozasok-${new Date().toISOString().slice(0, 10)}.csv`;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
      setExportStatus(
        `${rows.length} sor, ${selectedColumns.length} oszlop ${mode === "csv" ? "exportálva" : "nyomtatásra előkészítve"}.`
      );
    } catch (error) {
      printWindow?.close();
      if (exportAlive.current) setExportStatus(formatApiErrorMessage(error));
    } finally {
      if (exportAlive.current) setExporting(false);
    }
  }

  return (
    <div className="page supplier-changes-page">
      <div className="page-header">
        <h1 className="page-title">Beszállítói árváltozások</h1>
      </div>

      <section className="card supplier-changes-controls">
        <div className="supplier-changes-control-header">
          <div>
            <strong>Árjavaslat vezérlőpult</strong>
          </div>
          <span className="supplier-changes-refresh">
            Frissítve: {data?.generatedAt ? formatDate(data.generatedAt) : "-"}
          </span>
        </div>

        <div className="supplier-changes-filter-grid">
          <label className="field-label">
            EUR/HUF árfolyam
            <input
              className="input"
              type="number"
              min="100"
              max="1000"
              step="0.01"
              value={eurHufRate}
              onChange={(event) => setEurHufRate(readNumberInput(event.target.value))}
            />
            <span className="field-help">
              {rateSaveStatus === "saving"
                ? "Mentés..."
                : rateSaveStatus === "error"
                  ? "Mentési hiba"
                  : activeRate === null
                    ? "Adj meg árfolyamot."
                    : "Mentve"}
            </span>
          </label>
          <label className="field-label">
            ÁFA %
            <input
              className="input"
              type="number"
              min="0"
              max="100"
              step="0.01"
              value={vatPercent}
              onChange={(event) => setVatPercent(readNumberInput(event.target.value))}
            />
          </label>
          <label className="field-label">
            Beszállító
            <select
              className="input"
              value={supplierScope}
              onChange={(event) =>
                updateSupplierScope(event.target.value as SupplierPriceChangeSupplierScope)
              }
            >
              <option value="all">DVG + LF</option>
              <option value="dvg">Csak DVG</option>
              <option value="lf">Csak LF</option>
            </select>
          </label>
          <label className="field-label">
            Változás típusa
            <select
              className="input"
              value={direction}
              onChange={(event) =>
                updateDirection(event.target.value as SupplierPriceChangeDirection)
              }
            >
              <option value="all">Minden változás</option>
              <option value="increase">Csak drágult</option>
              <option value="decrease">Csak olcsóbb lett</option>
            </select>
          </label>
          <label className="field-label">
            Minimum változás %
            <input
              className="input"
              type="number"
              min="0"
              max="1000"
              step="0.1"
              value={minChangePercent}
              onChange={(event) => {
                setOffset(0);
                setMinChangePercent(readNumberInput(event.target.value));
              }}
            />
          </label>
          {roundingEnabled ? (
            <label className="field-label supplier-changes-rounding-detail">
              Kerekítés összege
              <select
                className="input"
                value={roundingIncrementHuf}
                onChange={(event) => setRoundingIncrementHuf(readNumberInput(event.target.value))}
              >
                <option value={50}>50 Ft</option>
                <option value={100}>100 Ft</option>
                <option value={500}>500 Ft</option>
                <option value={1000}>1000 Ft</option>
              </select>
            </label>
          ) : null}
          {roundingEnabled ? (
            <label className="field-label supplier-changes-rounding-detail">
              Kerekítés módja
              <select
                className="input"
                value={roundingMode}
                onChange={(event) =>
                  setRoundingMode(event.target.value === "nearest" ? "nearest" : "up")
                }
              >
                <option value="up">Felfelé</option>
                <option value="nearest">Legközelebbi</option>
              </select>
            </label>
          ) : null}
          <div className="field-label supplier-changes-rounding-toggle-field">
            Kerekítés
            <label className="supplier-changes-toggle">
              <input
                type="checkbox"
                checked={roundingEnabled}
                onChange={(event) => {
                  setOffset(0);
                  setRoundingEnabled(event.target.checked);
                }}
              />
              <span>{roundingEnabled ? "Bekapcsolva" : "Kikapcsolva"}</span>
            </label>
          </div>
        </div>
      </section>

      {data ? <SupplierChangeSummary response={data} /> : null}
      {loading ? <LoadingState /> : null}
      {error ? (
        <>
          <ErrorState message={error} />
          <button
            className="button secondary"
            type="button"
            onClick={() => setReload((value) => value + 1)}
          >
            Újrapróbálás
          </button>
        </>
      ) : null}
      {!loading && !error && activeRate === null ? (
        <EmptyState title="Hiányzik az EUR/HUF árfolyam">
          Adj meg árfolyamot az Árjavaslat vezérlőpultban, utána betölt az árváltozás lista.
        </EmptyState>
      ) : null}
      {!loading && !error && data?.items.length === 0 ? (
        <EmptyState title="Nincs beszállítói árváltozás">
          Futtass beszállítói árfigyelést több alkalommal, hogy legyen összehasonlítható régi és új
          ár.
        </EmptyState>
      ) : null}

      {data?.items.length ? (
        <SupplierChangeTable
          rows={data.items}
          sort={sort}
          onSort={(id) => {
            setOffset(0);
            setSort({ id, direction: sort.id === id && sort.direction === "asc" ? "desc" : "asc" });
          }}
          exportControls={
            <div className="price-change-export">
              <button
                className="button secondary"
                type="button"
                aria-expanded={exportOpen}
                onClick={() => setExportOpen(!exportOpen)}
              >
                Export / nyomtatás
              </button>
              {exportOpen && (
                <div className="price-change-export-panel">
                  <fieldset disabled={exporting}>
                    <legend>Exportálandó oszlopok</legend>
                    <p className="helper-text">
                      Az összes szűrt sor, a választott rendezésben kerül a fájlba.
                    </p>
                    <div className="toolbar-group">
                      <button
                        type="button"
                        className="button small secondary"
                        onClick={() =>
                          setExportColumns(priceChangeColumns.map((column) => column.id))
                        }
                      >
                        Mind kijelölése
                      </button>
                      <button
                        type="button"
                        className="button small secondary"
                        onClick={() => setExportColumns([])}
                      >
                        Kijelölés törlése
                      </button>
                    </div>
                    <div className="price-change-export-columns">
                      {priceChangeColumns.map((column) => (
                        <label className="column-toggle" key={column.id}>
                          <input
                            type="checkbox"
                            checked={exportColumns.includes(column.id)}
                            onChange={(event) =>
                              setExportColumns((current) =>
                                event.target.checked
                                  ? [...current, column.id]
                                  : current.filter((id) => id !== column.id)
                              )
                            }
                          />
                          {column.label}
                        </label>
                      ))}
                    </div>
                  </fieldset>
                  <TablePrintSettings value={printOptions} onChange={setPrintOptions} />
                  <div className="toolbar-group">
                    <button
                      type="button"
                      className="button"
                      disabled={exporting || !exportColumns.length || loading}
                      onClick={() => void exportRows("csv")}
                    >
                      CSV letöltése
                    </button>
                    <button
                      type="button"
                      className="button secondary"
                      disabled={exporting || !exportColumns.length || loading}
                      onClick={() => void exportRows("print")}
                    >
                      Nyomtatás / PDF
                    </button>
                  </div>
                </div>
              )}
              <span role="status" className="helper-text">
                {exportStatus}
              </span>
            </div>
          }
          pagination={
            <TablePagination
              canGoBack={canGoBack}
              canGoNext={canGoNext}
              label={paginationLabel}
              onBack={() => setOffset(Math.max(0, offset - DEFAULT_LIMIT))}
              onNext={() => setOffset(offset + DEFAULT_LIMIT)}
              compact
            />
          }
        />
      ) : null}

      <TablePagination
        canGoBack={canGoBack}
        canGoNext={canGoNext}
        label={paginationLabel}
        onBack={() => setOffset(Math.max(0, offset - DEFAULT_LIMIT))}
        onNext={() => setOffset(offset + DEFAULT_LIMIT)}
      />
    </div>
  );
}

function SupplierChangeSummary({ response }: { response: SupplierPriceChangeResponse }) {
  return (
    <section className="supplier-changes-summary" aria-label="Árváltozás összegzés">
      <SummaryItem label="Árváltozott" value={formatCount(response.summary.changedCount)} />
      <SummaryItem
        label="Drágult"
        value={formatCount(response.summary.increaseCount)}
        tone="warning"
      />
      <SummaryItem
        label="Olcsóbb lett"
        value={formatCount(response.summary.decreaseCount)}
        tone="success"
      />
      <SummaryItem
        label="Profit csökkenne"
        value={formatCount(response.summary.marginWouldDropCount)}
        tone="warning"
      />
      <SummaryItem
        label="Nincs előző ár"
        value={formatCount(response.summary.noPreviousPriceCount)}
      />
    </section>
  );
}

function SummaryItem({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "success" | "warning";
}) {
  return (
    <div className={`supplier-changes-summary-item tone-${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function SupplierChangeTable({
  rows,
  pagination,
  sort,
  onSort,
  exportControls,
}: {
  rows: SupplierPriceChangeRow[];
  pagination: ReactNode;
  sort: { id: PriceChangeSortBy; direction: "asc" | "desc" };
  onSort: (id: PriceChangeSortBy) => void;
  exportControls: ReactNode;
}) {
  const [columnWidths, setColumnWidths] = useStoredColumnWidths(
    "danetti:price-changes:column-widths",
    priceChangeColumns
  );
  const beginColumnResize = useColumnResize(columnWidths, setColumnWidths, priceChangeColumns);
  const totalWidth = priceChangeColumns.reduce(
    (total, column) => total + columnWidths[column.id],
    0
  );
  return (
    <section className="card table-card supplier-changes-table-card">
      <div className="table-toolbar product-table-toolbar">
        {pagination}
        <div className="product-view-controls" role="group" aria-label="Árváltozás lista nézet">
          <span className="table-toolbar-status">Szűrés és árképzés fent állítható</span>
        </div>
      </div>
      {exportControls}
      <div className="table-scroll">
        <table
          className="table data-table data-table--wide supplier-changes-table data-table--sheet"
          style={{ width: totalWidth, minWidth: totalWidth }}
        >
          <colgroup>
            {priceChangeColumns.map((column) => (
              <col key={column.id} style={{ width: columnWidths[column.id] }} />
            ))}
          </colgroup>
          <thead>
            <tr>
              {priceChangeColumns.map((column) => (
                <th
                  key={column.id}
                  className={`resizable-header ${column.numeric ? "numeric" : ""}`}
                  aria-sort={
                    sort.id === column.id
                      ? sort.direction === "asc"
                        ? "ascending"
                        : "descending"
                      : "none"
                  }
                >
                  <SortButton
                    label={column.label}
                    direction={sort.id === column.id ? sort.direction : undefined}
                    onClick={() => onSort(column.id)}
                  />
                  <ColumnResizer
                    label={column.label}
                    width={columnWidths[column.id]}
                    minWidth={column.minWidth}
                    onResize={(event) => beginColumnResize(column.id, event)}
                    onWidth={(width) =>
                      setColumnWidths((current) => ({ ...current, [column.id]: width }))
                    }
                  />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.newSnapshotId}>
                {priceChangeColumns.map((column) => (
                  <td key={column.id} className={column.numeric ? "numeric" : "cell-wrap"}>
                    {renderChangeValue(row, column.id)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function renderChangeValue(row: SupplierPriceChangeRow, id: PriceChangeSortBy) {
  switch (id) {
    case "oldSupplierNetEur":
    case "newSupplierNetEur":
      return formatEur(row[id]);
    case "supplierChangePercent":
      return (
        <span className={row.supplierChangeEur > 0 ? "text-warning" : "text-success"}>
          {formatPercent(row[id])}
          <span className="muted-cell">{formatHuf(row.supplierChangeHuf)}</span>
        </span>
      );
    case "currentWooPriceHuf":
      return (
        <>
          {formatHuf(row[id])}
          <span className="muted-cell">{labelWooSource(row.currentWooPriceSource)}</span>
        </>
      );
    case "currentProfitPercentWithNewCost":
    case "preservedProfitPercent":
      return formatPercent(row[id]);
    case "suggestedGrossPriceRoundedHuf":
      return <strong>{formatHuf(row[id])}</strong>;
    case "suggestedPriceDeltaHuf":
      return formatSignedHuf(row[id]);
    case "newObservedAt":
      return formatDate(row[id]);
    default:
      return row[id] ?? "-";
  }
}

function readNumberInput(value: string): number | "" {
  if (value.trim() === "") return "";
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : "";
}

function readOptionalNumber(value: number | ""): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function formatCount(value: number): string {
  return value.toLocaleString("hu-HU");
}

function formatEur(value: number | null): string {
  if (value === null) return "-";
  return `${value.toLocaleString("hu-HU", { maximumFractionDigits: 4 })} EUR`;
}

function formatHuf(value: number | null): string {
  if (value === null) return "-";
  return `${Math.round(value).toLocaleString("hu-HU")} Ft`;
}

function formatSignedHuf(value: number | null): string {
  if (value === null) return "-";
  const prefix = value > 0 ? "+" : "";
  return `${prefix}${Math.round(value).toLocaleString("hu-HU")} Ft`;
}

function formatPercent(value: number | null): string {
  if (value === null) return "-";
  return `${value.toLocaleString("hu-HU", { maximumFractionDigits: 2 })}%`;
}

function labelWooSource(source: SupplierPriceChangeRow["currentWooPriceSource"]): string {
  if (source === "currentPrice") return "aktuális ár";
  if (source === "salePrice") return "akciós ár";
  if (source === "regularPrice") return "normál ár";
  return "nincs Woo ár";
}
