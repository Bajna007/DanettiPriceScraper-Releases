import assert from "node:assert/strict";
import {
  createBeanOnSeeds,
  createUtopiaSeeds,
  upgradeLabelScene,
  resolveBindings,
  type LabelScene,
} from "@danetti/label-engine";
import { migrateStoredLabelScenes } from "./scene-migrations.js";
const single = createBeanOnSeeds().find((seed) =>
  seed.scene.nodes.some((node) => node.id === "label-region")
)!.scene;
const blend = createBeanOnSeeds()[0]!.scene;
const remote = structuredClone(single);
remote.fields.name = "Csak a másik gépen létező címke";
remote.fields.farm = "SAJÁT, EGYEDI SZÖVEG";
const damaged = structuredClone(upgradeLabelScene(single)!);
damaged.metadata.layoutVersion = 5;
const name = damaged.nodes.find((node) => node.id === "name")!;
if (name.type === "text") {
  name.fontFamily = "Wrong font";
  name.fill = { rgb: "#000000" };
  name.x = 20;
}
const remoteCurrent = structuredClone(damaged);
remoteCurrent.fields.name = "Másik gépen újonnan mentett saját címke";
const incorrectlyCurrent = structuredClone(single);
incorrectlyCurrent.metadata.layoutVersion = 9;
incorrectlyCurrent.fields.name = "Másik PC téves verziójú saját címkéje";
incorrectlyCurrent.fields.showRoastDateBox = true;
const utopia = structuredClone(createUtopiaSeeds()[0]!.scene);
utopia.metadata.layoutVersion = 6;
const existing = [
  remote,
  blend,
  upgradeLabelScene(single)!,
  damaged,
  remoteCurrent,
  incorrectlyCurrent,
  utopia,
].map((scene, index) => ({
  id: `local-${index}`,
  current_version_id: `old-${index}`,
  version: 4,
  template_version_id: "template",
  scene,
}));
const history = new Map(
  existing.map((row) => [row.current_version_id, structuredClone(row.scene)])
);
const before = structuredClone(existing);
const writes: Array<{ sql: string; args: unknown[] }> = [];
const query = async (sql: string, args: unknown[] = []) => {
  if (sql.startsWith("SELECT d.id")) return existing;
  if (sql.startsWith("SELECT COALESCE(MAX(version)"))
    return [{ version: args[0] === "local-0" ? 9 : 5 }];
  if (sql.startsWith("SELECT scene FROM label_design_versions"))
    return args[0] === "local-3" ? [{ scene: single }] : [];
  writes.push({ sql, args });
  if (sql.startsWith("INSERT INTO label_design_versions")) {
    const id = `new-${args[0]}`;
    history.set(id, JSON.parse(String(args[3])) as LabelScene);
    assert.equal(args[2], args[0] === "local-0" ? 9 : 5);
    return [{ id }];
  }
  if (sql.startsWith("UPDATE label_designs")) {
    const row = existing.find((row) => row.id === args[0])!;
    row.current_version_id = String(args[1]);
    row.scene = history.get(row.current_version_id)!;
  }
  return [];
};
await migrateStoredLabelScenes(query, (scene) => scene);
assert.equal(existing[0]!.scene.fields.name, remote.fields.name);
assert.equal(existing[0]!.scene.fields.farm, remote.fields.farm);
assert.equal(existing.length, 7);
assert.deepEqual(history.get("old-0"), before[0]!.scene);
assert.equal(existing[2]!.current_version_id, "old-2");
assert.equal(
  writes.filter((write) => write.sql.startsWith("INSERT INTO label_design_versions")).length,
  6
);
assert.deepEqual(
  existing[3]!.scene.nodes.find((node) => node.id === "name"),
  single.nodes.find((node) => node.id === "name")
);
assert.deepEqual(
  existing[4]!.scene.nodes.find((node) => node.id === "name"),
  remoteCurrent.nodes.find((node) => node.id === "name")
);
assert.deepEqual(existing[4]!.scene.fields, { ...remoteCurrent.fields, productUrl: "" });
assert.deepEqual(history.get("old-3"), before[3]!.scene);
assert.equal(existing[5]!.scene.fields.name, incorrectlyCurrent.fields.name);
assert.ok(
  !resolveBindings(existing[5]!.scene).nodes.some(
    (node) =>
      node.visible && ["roastDate", "date-field", "date-divider", "weight-line"].includes(node.id)
  )
);
for (const id of ["name", "country", "value-region"])
  assert.deepEqual(
    existing[6]!.scene.nodes.find((n) => n.id === id),
    JSON.parse(JSON.stringify(before[6]!.scene.nodes.find((n) => n.id === id)))
  );
assert.ok(!resolveBindings(existing[6]!.scene).nodes.some((n) => n.id === "date-field"));
assert.deepEqual(history.get("old-6"), before[6]!.scene);
assert.ok(writes.every((write) => !/\bDELETE\b|\bTRUNCATE\b/.test(write.sql)));
const writeCount = writes.length;
await migrateStoredLabelScenes(query, (scene) => scene);
const currentUtopia = { ...utopia, metadata: { ...utopia.metadata, layoutVersion: 9 } };
const preservedUtopia = structuredClone(currentUtopia);
await migrateStoredLabelScenes(
  async (sql) => {
    assert.ok(sql.startsWith("SELECT d.id"), "Current Utopia must not create any migration writes");
    return [{ ...existing[6], scene: currentUtopia }];
  },
  (scene) => scene
);
assert.deepEqual(currentUtopia, preservedUtopia);
assert.equal(
  writes.length,
  writeCount,
  "the next start cannot overwrite subsequent operator edits"
);
const ownHonduras = structuredClone(
  upgradeLabelScene(
    createBeanOnSeeds().find((seed) => seed.internalCode === "BO-HONDURAS-LAS-MORAS")!.scene
  )!
);
delete ownHonduras.metadata.hondurasBackgroundRestored;
ownHonduras.nodes = JSON.parse(JSON.stringify(ownHonduras.nodes));
ownHonduras.background = { rgb: "#FFFFFF", cmyk: { c: 0, m: 0, y: 0, k: 0 } };
ownHonduras.metadata.name = "Csak másik gépen meglévő Honduras";
ownHonduras.fields.productUrl = "https://utopiacoffee.hu/termek/sajat-honduras/";
const ownHondurasBefore = structuredClone(ownHonduras);
const installedRow = {
  id: "remote-honduras",
  current_version_id: "original-version",
  version: 11,
  template_version_id: "own-template",
  scene: ownHonduras,
};
let backgroundWrites = 0;
const backgroundQuery = async (sql: string, args: unknown[] = []) => {
  if (sql.startsWith("SELECT d.id")) return [installedRow];
  if (sql.startsWith("SELECT COALESCE(MAX(version)")) return [{ version: 12 }];
  if (sql.startsWith("INSERT INTO label_design_versions")) {
    backgroundWrites++;
    installedRow.scene = JSON.parse(String(args[3]));
    return [{ id: "restored-version" }];
  }
  return [];
};
await migrateStoredLabelScenes(backgroundQuery, (scene) => scene);
assert.equal(backgroundWrites, 1);
assert.equal(installedRow.scene.background.rgb, "#69FC0D");
assert.deepEqual(installedRow.scene.nodes, ownHondurasBefore.nodes);
assert.deepEqual(installedRow.scene.fields, ownHondurasBefore.fields);
assert.deepEqual(ownHonduras, ownHondurasBefore);
installedRow.scene.background = { rgb: "#FFFFFF" };
await migrateStoredLabelScenes(backgroundQuery, (scene) => scene);
assert.equal(
  backgroundWrites,
  1,
  "The background repair runs once and preserves later intentional edits"
);
const remoteBlend = structuredClone(upgradeLabelScene(blend)!);
remoteBlend.metadata.layoutVersion = 9;
remoteBlend.fields.name = "Másik gépen mentett saját blend";
const remoteDivider = remoteBlend.nodes.find((node) => node.id === "main-divider")!;
if (remoteDivider.type !== "line") throw new Error("Missing blend divider");
remoteDivider.y2 -= 3.1;
remoteDivider.height -= 3.1;
const savedBlend = structuredClone(remoteBlend);
const remoteRow = { ...existing[1]!, scene: remoteBlend };
const remoteWrites: string[] = [];
await migrateStoredLabelScenes(
  async (sql, args = []) => {
    if (sql.startsWith("SELECT d.id")) return [remoteRow];
    if (sql.startsWith("SELECT COALESCE(MAX(version)")) return [{ version: 6 }];
    remoteWrites.push(sql);
    if (sql.startsWith("INSERT INTO label_design_versions")) {
      remoteRow.scene = JSON.parse(String(args[3]));
      return [{ id: "joined-blend" }];
    }
    return [];
  },
  (scene) => scene
);
const joinedDivider = remoteRow.scene.nodes.find((node) => node.id === "main-divider")!;
assert.equal(
  joinedDivider.type === "line" && joinedDivider.y2,
  remoteRow.scene.nodes.find((node) => node.id === "footer-line")!.y
);
assert.deepEqual(remoteRow.scene.fields, savedBlend.fields);
assert.deepEqual(remoteBlend, savedBlend);
assert.ok(remoteWrites.some((sql) => sql.includes("o.status='draft'")));
await migrateStoredLabelScenes(
  async (sql) => {
    assert.ok(sql.startsWith("SELECT d.id"), "Second startup must not write another version");
    return [remoteRow];
  },
  (scene) => scene
);
console.log(
  "Installed-scene migration preserves remote-only labels, all fields and historical versions"
);
