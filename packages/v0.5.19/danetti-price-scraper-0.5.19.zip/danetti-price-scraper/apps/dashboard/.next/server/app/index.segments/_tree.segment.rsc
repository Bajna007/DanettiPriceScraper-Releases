:HL["/_next/static/chunks/0bb2k-q9sk5ld.css","style"]
:HL["/_next/static/chunks/3dfg4_wb1iiit.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"Ef8AETykH4y1n2WU56HTg"}
