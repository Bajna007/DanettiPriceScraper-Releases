:HL["/_next/static/chunks/0bb2k-q9sk5ld.css","style"]
:HL["/_next/static/chunks/31nms0utq99ef.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"labels","param":null,"prefetchHints":4192,"slots":{"children":{"name":"custom","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"ArKB5PMN60VU71GLMdSAc"}
