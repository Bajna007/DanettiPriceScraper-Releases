import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import Fastify from "fastify";
import sharp from "sharp";
import { registerDvgDiagramRoutes } from "./dvg-diagrams.routes.js";
import { DvgDiagramService, OUTPUT_ROOT_CONST } from "./dvg-diagrams.service.js";
import type {
  DvgDiagramFamily,
  DvgDiagramGenerateInput,
  DvgDiagramListInput,
  DvgDiagramConvertInput,
  DvgDiagramServiceLike,
} from "./dvg-diagrams.service.js";

let capturedGenerateInput: DvgDiagramGenerateInput | null = null;

const service: DvgDiagramServiceLike = {
  async listBrands(family: DvgDiagramFamily) {
    return [{ family, label: "Astoria", value: "ASTORIA" }];
  },
  async listDiagrams(input: DvgDiagramListInput) {
    return {
      family: input.family,
      brand: input.brand,
      generatedAt: "2026-07-01T00:00:00.000Z",
      warnings: [],
      items: [
        {
          family: input.family,
          familyLabel: "Kávégép",
          brand: input.brand,
          model: "ARGENTA",
          diagramCode: "EU01",
          diagramName: null,
          sourcePageUrl:
            "https://devecchigiuseppesrl.com/e-commerce/diagrams/index.asp?codice-articolo=EU01",
        },
      ],
    };
  },
  async convertDiagram(input: DvgDiagramConvertInput) {
    return {
      family: input.family,
      familyLabel: "Kávégép",
      brand: input.brand,
      model: input.model ?? null,
      diagramCode: input.diagramCode,
      diagramName: "RANCILIO - GRUPPO EROGAZIONE",
      sourcePageUrl:
        "https://devecchigiuseppesrl.com/e-commerce/diagrams/index.asp?codice-articolo=EU01",
      sourceImageUrl: "https://devecchigiuseppesrl.com/e-commerce/welcome/assiemi/EU01.jpg",
      imageUrl: input.imageUrl ?? "__DANETTI_IMAGE_URL__/eu01.jpg",
      imageWidth: 1200,
      imageHeight: 900,
      areaCount: 1,
      skippedAreaCount: 0,
      html: `<img src="${input.imageUrl ?? "__DANETTI_IMAGE_URL__/eu01.jpg"}" usemap="#Map" width="1200" height="900" />`,
      outputImagePath: "artifacts/dvg-diagrams/astoria/EU01.jpg",
      warnings: [],
    };
  },
  async generate(input: DvgDiagramGenerateInput) {
    capturedGenerateInput = input;
    return {
      generatedAt: "2026-07-01T00:00:00.000Z",
      outputDir: "artifacts/dvg-diagrams/test",
      placeholderBaseUrl: input.placeholderBaseUrl ?? "__DANETTI_IMAGE_URL__",
      requestedBrands: input.brands,
      warnings: [],
      items: [
        {
          family: input.family,
          familyLabel: "Kávégép",
          brand: input.brands[0] ?? "ASTORIA",
          model: null,
          diagramCode: "EU01",
          sourcePageUrl:
            "https://devecchigiuseppesrl.com/e-commerce/diagrams/index.asp?codice-articolo=EU01",
          sourceImageUrl: "https://devecchigiuseppesrl.com/e-commerce/welcome/assiemi/EU01.jpg",
          outputImagePath: "artifacts/dvg-diagrams/test/eu01.jpg",
          outputHtmlPath: "artifacts/dvg-diagrams/test/eu01.html",
          imageFilename: "eu01.jpg",
          htmlFilename: "eu01.html",
          imageWidth: 1200,
          imageHeight: 900,
          areaCount: 1,
          skippedAreaCount: 0,
          html: "<map></map>",
          warnings: [],
        },
      ],
    };
  },
};

const server = Fastify({ logger: false });
await registerDvgDiagramRoutes(server, { service });

try {
  const brands = await server.inject({ method: "GET", url: "/dvg-diagrams/brands?family=coffee" });
  assert.equal(brands.statusCode, 200);
  assert.equal(brands.json().family, "coffee");
  assert.deepEqual(brands.json().items, [{ family: "coffee", label: "Astoria", value: "ASTORIA" }]);

  const missingFamily = await server.inject({ method: "GET", url: "/dvg-diagrams/brands" });
  assert.equal(missingFamily.statusCode, 400);
  assert.equal(missingFamily.json().error.code, "dvg_diagram_family_invalid");

  const diagrams = await server.inject({
    method: "GET",
    url: "/dvg-diagrams/diagrams?family=coffee&brand=ASTORIA&maxDiagrams=7",
  });
  assert.equal(diagrams.statusCode, 200);
  assert.equal(diagrams.json().items[0].diagramCode, "EU01");
  assert.equal(diagrams.json().items[0].model, "ARGENTA");

  const converted = await server.inject({
    method: "POST",
    url: "/dvg-diagrams/convert",
    payload: {
      family: "coffee",
      brand: "ASTORIA",
      model: "ARGENTA",
      diagramCode: "EU01",
      imageUrl: "https://danetti.hu/eu01.jpg",
    },
  });
  assert.equal(converted.statusCode, 200);
  assert.equal(converted.json().imageUrl, "https://danetti.hu/eu01.jpg");
  assert.match(converted.json().html, /https:\/\/danetti\.hu\/eu01\.jpg/);

  const missingImage = await server.inject({
    method: "GET",
    url: "/dvg-diagrams/image?brand=astoria&code=NOEXIST",
  });
  assert.equal(missingImage.statusCode, 500);

  const rawBrandImage = await server.inject({
    method: "GET",
    url: "/dvg-diagrams/image?brand=Rancilio%20-%20Promac&code=NOEXIST",
  });
  assert.equal(rawBrandImage.statusCode, 500);
  assert.notEqual(rawBrandImage.json().error.code, "dvg_diagram_image_invalid");

  const boundary = "----danetti-dvg-diagram-test";
  const body = [
    multipartField(boundary, "family", "coffee"),
    multipartField(boundary, "brands", JSON.stringify(["ASTORIA"])),
    multipartField(boundary, "maxDiagramsPerBrand", "7"),
    multipartField(boundary, "maxPagesPerListing", "2"),
    multipartField(boundary, "placeholderBaseUrl", "__UPLOAD__"),
    multipartFile(boundary, "logo", "logo.png", "image/png", "fake-logo"),
    `--${boundary}--\r\n`,
  ].join("");

  const generated = await server.inject({
    method: "POST",
    url: "/dvg-diagrams/generate",
    headers: { "content-type": `multipart/form-data; boundary=${boundary}` },
    payload: body,
  });
  assert.equal(generated.statusCode, 201);
  assert.equal(generated.json().items.length, 1);
  const captured = capturedGenerateInput as DvgDiagramGenerateInput | null;
  assert.ok(captured);
  assert.equal(captured.family, "coffee");
  assert.deepEqual(captured.brands, ["ASTORIA"]);
  assert.equal(captured.maxDiagramsPerBrand, 7);
  assert.equal(captured.maxPagesPerListing, 2);
  assert.equal(captured.placeholderBaseUrl, "__UPLOAD__");
  assert.equal(captured.logoBuffer.toString("utf8"), "fake-logo");
} finally {
  await server.close();
}

function multipartField(boundary: string, name: string, value: string): string {
  return `--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`;
}

function multipartFile(
  boundary: string,
  name: string,
  filename: string,
  contentType: string,
  value: string
): string {
  return `--${boundary}\r\nContent-Disposition: form-data; name="${name}"; filename="${filename}"\r\nContent-Type: ${contentType}\r\n\r\n${value}\r\n`;
}

// Exercise the actual image pipeline from both launcher and unrelated working directories.
// Stub only the read-only supplier responses; use the packaged logo and real JPEG encoding.
const packageRoot = fileURLToPath(new URL("../../../../../", import.meta.url));
assert.equal(OUTPUT_ROOT_CONST, path.join(packageRoot, "artifacts", "dvg-diagrams"));
const originalCwd = process.cwd();
const scratch = await mkdtemp(path.join(tmpdir(), "danetti-diagram-cwd-"));
const brand = `test-${randomUUID()}`;
const imageDirectory = path.join(OUTPUT_ROOT_CONST, brand);
const sourceImage = await sharp({
  create: { width: 700, height: 965, channels: 3, background: "white" },
})
  .jpeg()
  .toBuffer();
const imageServer = Fastify({ logger: false });
try {
  await registerDvgDiagramRoutes(imageServer, {
    service: new DvgDiagramService(async (url) => {
      if (url.includes("/diagrams/index.asp?")) {
        return new Response(`<img src="/e-commerce/welcome/assiemi/EU01.jpg" width="700" usemap="#image-map">
          <map name="image-map"><area shape="rect" coords="10,20,30,40" data-code="EU123"></map>`);
      }
      if (url.endsWith("/assiemi/EU01.jpg")) {
        return new Response(new Uint8Array(sourceImage), {
          headers: { "Content-Type": "image/jpeg" },
        });
      }
      if (url.includes("/showCardArticolo.asp?")) return new Response("'name': 'EU01'");
      throw new Error(`Unexpected supplier URL: ${url}`);
    }),
  });
  for (const cwd of [packageRoot, path.join(packageRoot, "apps", "api"), scratch]) {
    process.chdir(cwd);
    const converted = await imageServer.inject({
      method: "POST",
      url: "/dvg-diagrams/convert",
      payload: { family: "coffee", brand, diagramCode: "EU01" },
    });
    assert.equal(converted.statusCode, 200);
    assert.deepEqual(converted.json().warnings, []);
    assert.equal(converted.json().outputImagePath, path.join(imageDirectory, "EU01.jpg"));
    assert.equal(converted.json().areaCount, 1);
    const image = await imageServer.inject({
      method: "GET",
      url: `/dvg-diagrams/image?brand=${brand}&code=EU01`,
    });
    assert.equal(image.statusCode, 200);
    assert.equal(image.headers["content-type"], "image/jpeg");
    const metadata = await sharp(image.rawPayload).metadata();
    assert.equal(metadata.width, 700);
    assert.equal(metadata.height, 965);
    assert.notDeepEqual(image.rawPayload, sourceImage);
  }
} finally {
  process.chdir(originalCwd);
  await imageServer.close();
  await rm(imageDirectory, { recursive: true, force: true });
  await rm(scratch, { recursive: true, force: true });
}

console.log("DVG diagram route and image pipeline tests passed");
