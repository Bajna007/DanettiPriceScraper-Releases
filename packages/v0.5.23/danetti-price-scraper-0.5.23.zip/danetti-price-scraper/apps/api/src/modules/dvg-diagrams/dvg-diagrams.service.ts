import { randomUUID } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import sharp from "sharp";

const DVG_BASE_URL = "https://devecchigiuseppesrl.com";
const DEFAULT_MAX_DIAGRAMS_PER_BRAND = 24;
const DEFAULT_MAX_PAGES_PER_LISTING = 3;
// Both src/ and dist/ keep this module at the same depth in the installed package.
// The production launcher starts the API from the repository root, unlike npm workspaces.
const PACKAGE_ROOT = fileURLToPath(new URL("../../../../../", import.meta.url));
export const OUTPUT_ROOT_CONST = path.join(PACKAGE_ROOT, "artifacts", "dvg-diagrams");
const OUTPUT_ROOT = OUTPUT_ROOT_CONST;
const DANETTI_LOGO_PATH = path.join(PACKAGE_ROOT, "assets", "danetti-logo.png");
const PLACEHOLDER_BASE_URL = "__DANETTI_IMAGE_URL__";

export type DvgDiagramFamily = "coffee" | "grinders";

export interface DvgDiagramBrandOption {
  family: DvgDiagramFamily;
  label: string;
  value: string;
}

export interface DvgDiagramListInput {
  family: DvgDiagramFamily;
  brand: string;
  maxDiagrams?: number;
  maxPagesPerListing?: number;
}

export interface DvgDiagramListItem {
  family: DvgDiagramFamily;
  familyLabel: string;
  brand: string;
  model: string | null;
  diagramCode: string;
  diagramName: string | null;
  sourcePageUrl: string;
}

export interface DvgDiagramListResult {
  family: DvgDiagramFamily;
  brand: string;
  generatedAt: string;
  items: DvgDiagramListItem[];
  warnings: string[];
}

export interface DvgDiagramConvertInput {
  family: DvgDiagramFamily;
  brand: string;
  diagramCode: string;
  model?: string | null;
  imageUrl?: string | null;
}

export interface DvgDiagramConvertResult {
  family: DvgDiagramFamily;
  familyLabel: string;
  brand: string;
  model: string | null;
  diagramCode: string;
  diagramName: string | null;
  sourcePageUrl: string;
  sourceImageUrl: string;
  imageUrl: string;
  imageWidth: number;
  imageHeight: number;
  areaCount: number;
  skippedAreaCount: number;
  html: string;
  outputImagePath: string | null;
  warnings: string[];
}

export interface DvgDiagramGenerateInput {
  family: DvgDiagramFamily;
  brands: string[];
  logoBuffer: Buffer;
  maxDiagramsPerBrand?: number;
  maxPagesPerListing?: number;
  placeholderBaseUrl?: string;
}

export interface DvgDiagramGeneratedItem {
  family: DvgDiagramFamily;
  familyLabel: string;
  brand: string;
  model: string | null;
  diagramCode: string;
  sourcePageUrl: string;
  sourceImageUrl: string;
  outputImagePath: string;
  outputHtmlPath: string;
  imageFilename: string;
  htmlFilename: string;
  imageWidth: number;
  imageHeight: number;
  areaCount: number;
  skippedAreaCount: number;
  html: string;
  warnings: string[];
}

export interface DvgDiagramServiceLike {
  listBrands(family: DvgDiagramFamily): Promise<DvgDiagramBrandOption[]>;
  listDiagrams(input: DvgDiagramListInput): Promise<DvgDiagramListResult>;
  convertDiagram(input: DvgDiagramConvertInput): Promise<DvgDiagramConvertResult>;
  generate(input: DvgDiagramGenerateInput): Promise<DvgDiagramGenerateResult>;
}

export interface DvgDiagramGenerateResult {
  generatedAt: string;
  outputDir: string;
  placeholderBaseUrl: string;
  requestedBrands: string[];
  items: DvgDiagramGeneratedItem[];
  warnings: string[];
}

export interface DvgDiagramArea {
  coords: string;
  shape: string;
  code: string;
}

export interface ParsedDvgDiagramDetail {
  imageSrc: string;
  imageWidth: number | null;
  imageHeight: number | null;
  areas: DvgDiagramArea[];
  skippedAreaCount: number;
}

interface FetchLike {
  (input: string, init?: RequestInit): Promise<Response>;
}

interface ListingTarget {
  brand: string;
  model: string | null;
}

interface DiagramCodeCandidate extends ListingTarget {
  code: string;
  diagramName: string | null;
}

const familyConfig: Record<DvgDiagramFamily, { label: string; c2: string }> = {
  coffee: { label: "Kávégép", c2: "COFFEE MACHINES - Diagrams" },
  grinders: { label: "Őrlő / daráló", c2: "GRINDERS - Diagrams" },
};

export class DvgDiagramService {
  constructor(private readonly fetchImpl: FetchLike = fetch) {}

  async listBrands(family: DvgDiagramFamily): Promise<DvgDiagramBrandOption[]> {
    const html = await this.fetchText(buildCategoryUrl(family));
    return parseSelectOptions(html, "CategoriaMenu3").map((option) => ({
      family,
      label: option.label,
      value: option.value,
    }));
  }

  async listDiagrams(input: DvgDiagramListInput): Promise<DvgDiagramListResult> {
    validateFamily(input.family);
    const brand = input.brand.trim();
    if (!brand) throw new Error("DVG márka szükséges.");

    const targets = await this.listListingTargets(input.family, brand);
    const candidates = await this.collectDiagramCodes(
      input.family,
      targets,
      input.maxDiagrams ?? DEFAULT_MAX_DIAGRAMS_PER_BRAND,
      input.maxPagesPerListing ?? DEFAULT_MAX_PAGES_PER_LISTING
    );

    const items = await Promise.all(
      candidates.map(async (candidate) => ({
        ...candidate,
        diagramName: await this.fetchDiagramName(candidate.code),
      }))
    );

    return {
      family: input.family,
      brand,
      generatedAt: new Date().toISOString(),
      items: items.map((candidate) => this.toDiagramListItem(input.family, candidate)),
      warnings: candidates.length === 0 ? [`${brand}: nem találtam publikus DVG diagramot.`] : [],
    };
  }

  async convertDiagram(input: DvgDiagramConvertInput): Promise<DvgDiagramConvertResult> {
    validateFamily(input.family);
    const brand = input.brand.trim();
    const diagramCode = input.diagramCode.trim();
    if (!brand) throw new Error("DVG márka szükséges.");
    if (!diagramCode) throw new Error("DVG diagram kód szükséges.");

    const candidate: DiagramCodeCandidate = {
      brand,
      model: input.model?.trim() || null,
      code: diagramCode,
      diagramName: null,
    };
    const detailUrl = buildDiagramDetailUrl(diagramCode);
    const detailHtml = await this.fetchText(detailUrl);
    const parsed = parseDvgDiagramDetail(detailHtml, detailUrl);
    const sourceImageUrl = absoluteUrl(parsed.imageSrc, detailUrl);
    const sourceImageBuffer = await this.fetchBuffer(sourceImageUrl);

    const dimensions =
      parsed.imageWidth && parsed.imageHeight
        ? { width: parsed.imageWidth, height: parsed.imageHeight }
        : await sharp(sourceImageBuffer)
            .metadata()
            .then((meta) => {
              if (!meta.width || !meta.height) throw new Error("A DVG kép mérete nem olvasható.");
              return { width: meta.width, height: meta.height };
            });

    let outputImagePath: string | null = null;
    let brandingWarning: string | null = null;
    try {
      const logoBuffer = await readFile(DANETTI_LOGO_PATH);
      const branded = await brandDiagramImage(sourceImageBuffer, logoBuffer);
      const outputDir = path.join(OUTPUT_ROOT, slugify(brand));
      await mkdir(outputDir, { recursive: true });
      outputImagePath = path.join(outputDir, `${diagramCode}.jpg`);
      await writeFile(outputImagePath, branded.buffer);
    } catch (error) {
      brandingWarning = `Logócsere sikertelen: ${readErrorMessage(error)}`;
    }

    const imageUrl = readOutputImageUrl(input.imageUrl, input.family, candidate);
    const diagramName = await this.fetchDiagramName(diagramCode);
    const outputAreas = filterAreasWithinDimensions(
      parsed.areas,
      dimensions.width,
      dimensions.height
    );
    const invalidAreaCount = parsed.areas.length - outputAreas.length;
    const html = buildDanettiDiagramHtml({
      imageSrc: imageUrl,
      width: dimensions.width,
      height: dimensions.height,
      alt: `${buildDiagramTitle(input.family, candidate)} alkatrész robbantott ábra`,
      areas: outputAreas,
    });

    return {
      family: input.family,
      familyLabel: familyConfig[input.family].label,
      brand,
      model: candidate.model,
      diagramCode,
      diagramName,
      sourcePageUrl: detailUrl,
      sourceImageUrl,
      imageUrl,
      imageWidth: dimensions.width,
      imageHeight: dimensions.height,
      areaCount: outputAreas.length,
      skippedAreaCount: parsed.skippedAreaCount + invalidAreaCount,
      html,
      outputImagePath,
      warnings: collectConvertWarnings(parsed.skippedAreaCount + invalidAreaCount, brandingWarning),
    };
  }

  async generate(input: DvgDiagramGenerateInput): Promise<DvgDiagramGenerateResult> {
    validateGenerateInput(input);
    const maxDiagramsPerBrand = input.maxDiagramsPerBrand ?? DEFAULT_MAX_DIAGRAMS_PER_BRAND;
    const maxPagesPerListing = input.maxPagesPerListing ?? DEFAULT_MAX_PAGES_PER_LISTING;
    const placeholderBaseUrl = normalizePlaceholderBaseUrl(
      input.placeholderBaseUrl ?? PLACEHOLDER_BASE_URL
    );
    const outputDir = path.join(OUTPUT_ROOT, buildRunDirectoryName(input.family));
    await mkdir(outputDir, { recursive: true });

    const items: DvgDiagramGeneratedItem[] = [];
    const warnings: string[] = [];

    for (const brand of input.brands) {
      try {
        const targets = await this.listListingTargets(input.family, brand);
        const candidates = await this.collectDiagramCodes(
          input.family,
          targets,
          maxDiagramsPerBrand,
          maxPagesPerListing
        );

        if (candidates.length === 0) {
          warnings.push(`${brand}: nem találtam publikus DVG diagram kódot.`);
          continue;
        }

        for (const candidate of candidates) {
          try {
            items.push(
              await this.generateDiagramItem({
                family: input.family,
                candidate,
                logoBuffer: input.logoBuffer,
                outputDir,
                placeholderBaseUrl,
              })
            );
          } catch (error) {
            warnings.push(`${brand} / ${candidate.code}: ${readErrorMessage(error)}`);
          }
        }
      } catch (error) {
        warnings.push(`${brand}: ${readErrorMessage(error)}`);
      }
    }

    return {
      generatedAt: new Date().toISOString(),
      outputDir,
      placeholderBaseUrl,
      requestedBrands: input.brands,
      items,
      warnings,
    };
  }

  private async listListingTargets(
    family: DvgDiagramFamily,
    brand: string
  ): Promise<ListingTarget[]> {
    const html = await this.fetchText(buildCategoryUrl(family, { brand }));
    const models = parseSelectOptions(html, "CategoriaMenu4");
    if (models.length === 0) return [{ brand, model: null }];
    return models.map((model) => ({ brand, model: model.value }));
  }

  private async collectDiagramCodes(
    family: DvgDiagramFamily,
    targets: ListingTarget[],
    maxDiagramsPerBrand: number,
    maxPagesPerListing: number
  ): Promise<DiagramCodeCandidate[]> {
    const candidates: DiagramCodeCandidate[] = [];
    const seen = new Set<string>();

    for (const target of targets) {
      for (let pageIndex = 0; pageIndex < maxPagesPerListing; pageIndex += 1) {
        if (candidates.length >= maxDiagramsPerBrand) return candidates;
        const offset = pageIndex === 0 ? undefined : pageIndex * 24;
        const html = await this.fetchText(buildCategoryUrl(family, { ...target, offset }));
        const codes = extractDiagramCodes(html);
        if (codes.length === 0) break;

        let newCodesOnPage = 0;
        for (const code of codes) {
          if (seen.has(code)) continue;
          seen.add(code);
          newCodesOnPage += 1;
          candidates.push({ ...target, code, diagramName: null });
          if (candidates.length >= maxDiagramsPerBrand) return candidates;
        }
        if (newCodesOnPage === 0) break;
      }
    }

    return candidates;
  }

  private async generateDiagramItem(input: {
    family: DvgDiagramFamily;
    candidate: DiagramCodeCandidate;
    logoBuffer: Buffer;
    outputDir: string;
    placeholderBaseUrl: string;
  }): Promise<DvgDiagramGeneratedItem> {
    const detailUrl = buildDiagramDetailUrl(input.candidate.code);
    const detailHtml = await this.fetchText(detailUrl);
    const parsed = parseDvgDiagramDetail(detailHtml, detailUrl);
    const sourceImageUrl = absoluteUrl(parsed.imageSrc, detailUrl);
    const sourceImageBuffer = await this.fetchBuffer(sourceImageUrl);
    const image = await brandDiagramImage(sourceImageBuffer, input.logoBuffer);
    const outputAreas = filterAreasWithinDimensions(parsed.areas, image.width, image.height);
    const invalidAreaCount = parsed.areas.length - outputAreas.length;
    const filenameBase = buildDiagramFilenameBase(input.family, input.candidate);
    const imageFilename = `${filenameBase}.jpg`;
    const htmlFilename = `${filenameBase}.html`;
    const outputImagePath = path.join(input.outputDir, imageFilename);
    const outputHtmlPath = path.join(input.outputDir, htmlFilename);
    const imageSrc = `${input.placeholderBaseUrl}/${imageFilename}`;
    const html = buildDanettiDiagramHtml({
      imageSrc,
      width: image.width,
      height: image.height,
      alt: `${buildDiagramTitle(input.family, input.candidate)} alkatrész robbantott ábra`,
      areas: outputAreas,
    });

    await writeFile(outputImagePath, image.buffer);
    await writeFile(outputHtmlPath, html, "utf8");

    return {
      family: input.family,
      familyLabel: familyConfig[input.family].label,
      brand: input.candidate.brand,
      model: input.candidate.model,
      diagramCode: input.candidate.code,
      sourcePageUrl: detailUrl,
      sourceImageUrl,
      outputImagePath,
      outputHtmlPath,
      imageFilename,
      htmlFilename,
      imageWidth: image.width,
      imageHeight: image.height,
      areaCount: outputAreas.length,
      skippedAreaCount: parsed.skippedAreaCount + invalidAreaCount,
      html,
      warnings:
        parsed.skippedAreaCount + invalidAreaCount > 0
          ? [
              `${parsed.skippedAreaCount + invalidAreaCount} area kimaradt hibás vagy hiányzó kód/coords miatt.`,
            ]
          : [],
    };
  }

  private async fetchText(url: string): Promise<string> {
    const response = await this.fetchImpl(url, {
      headers: { "User-Agent": "DanettiPriceScraper/0.1" },
      signal: AbortSignal.timeout(20_000),
    });
    if (!response.ok) throw new Error(`DVG oldal nem érhető el: HTTP ${response.status}`);
    return await response.text();
  }

  private async fetchBuffer(url: string): Promise<Buffer> {
    const response = await this.fetchImpl(url, {
      headers: { "User-Agent": "DanettiPriceScraper/0.1" },
      signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) throw new Error(`DVG kép nem érhető el: HTTP ${response.status}`);
    return Buffer.from(await response.arrayBuffer());
  }

  private async fetchDiagramName(diagramCode: string): Promise<string | null> {
    try {
      const cardUrl = `${DVG_BASE_URL}/assets/include/showCardArticolo.asp?CodiceArticolo=${encodeURIComponent(diagramCode)}&width=1&height=1`;
      const html = await this.fetchText(cardUrl);
      const match = /'name':\s*'([^']+)'/.exec(html);
      if (match) return decodeHtml(match[1]).trim();
      return parseCardHtmlName(html);
    } catch {
      return null;
    }
  }

  private async readDiagramDimensions(parsed: ParsedDvgDiagramDetail, sourceImageUrl: string) {
    if (parsed.imageWidth && parsed.imageHeight) {
      return { width: parsed.imageWidth, height: parsed.imageHeight };
    }
    const sourceImageBuffer = await this.fetchBuffer(sourceImageUrl);
    const metadata = await sharp(sourceImageBuffer).metadata();
    if (!metadata.width || !metadata.height) throw new Error("A DVG kép mérete nem olvasható.");
    return { width: metadata.width, height: metadata.height };
  }

  private toDiagramListItem(
    family: DvgDiagramFamily,
    candidate: DiagramCodeCandidate
  ): DvgDiagramListItem {
    return {
      family,
      familyLabel: familyConfig[family].label,
      brand: candidate.brand,
      model: candidate.model,
      diagramCode: candidate.code,
      diagramName: candidate.diagramName,
      sourcePageUrl: buildDiagramDetailUrl(candidate.code),
    };
  }
}

export function parseDvgDiagramDetail(
  html: string,
  baseUrl = DVG_BASE_URL
): ParsedDvgDiagramDetail {
  const imageTag = findImageMapImageTag(html);
  if (!imageTag) throw new Error("A DVG diagram oldalon nincs image-map kép.");
  const imageSrc = readAttribute(imageTag, "src");
  if (!imageSrc) throw new Error("A DVG diagram kép src hiányzik.");

  const mapHtml = findImageMapHtml(html);
  if (!mapHtml) throw new Error("A DVG diagram oldalon nincs <map> blokk.");

  const areas: DvgDiagramArea[] = [];
  let skippedAreaCount = 0;
  for (const areaAttrs of matchAll(mapHtml, /<area\b([^>]*)>/gi)) {
    const coords = normalizeCoords(readAttribute(areaAttrs, "coords"));
    const href = readAttribute(areaAttrs, "href");
    const code = readAreaCode(areaAttrs, href ?? "");
    const shape = (readAttribute(areaAttrs, "shape") ?? "rect").toLowerCase();
    if (!coords || !code) {
      if (isIgnorableArea(href, coords, code)) continue;
      skippedAreaCount += 1;
      continue;
    }
    areas.push({ coords, shape, code: decodeHtml(code).trim() });
  }

  return {
    imageSrc: absoluteUrl(imageSrc, baseUrl),
    imageWidth: readNumberAttribute(imageTag, "width"),
    imageHeight: readNumberAttribute(imageTag, "height"),
    areas,
    skippedAreaCount,
  };
}

export function buildDanettiDiagramHtml(input: {
  imageSrc: string;
  width: number;
  height: number;
  alt: string;
  areas: readonly DvgDiagramArea[];
}): string {
  const lines = [
    `<img src="${escapeHtml(input.imageSrc)}" usemap="#Map" width="${input.width}" height="${input.height}" border="0" alt="${escapeHtml(
      input.alt
    )}" />`,
    "",
    '<map name="Map" id="Map">',
    ...input.areas.map(
      (area) =>
        `  <area coords="${escapeHtml(area.coords)}" shape="${escapeHtml(area.shape)}" href="/search/${escapeHtml(
          area.code
        )}" alt="${escapeHtml(area.code)}" />`
    ),
    "</map>",
  ];
  return lines.join("\n");
}

export function parseSelectOptions(
  html: string,
  selectName: string
): Array<{ value: string; label: string }> {
  const selectMatch = new RegExp(
    `<select\\b[^>]*name=["']${escapeRegExp(selectName)}["'][^>]*>([\\s\\S]*?)<\\/select>`,
    "i"
  ).exec(html);
  const options = selectMatch?.[1] ? parseOptions(selectMatch[1]) : [];
  return dedupeByValue(options.length > 0 ? options : parseCategoryLinks(html, selectName));
}

export function extractDiagramCodes(html: string): string[] {
  const codes = new Set<string>();
  for (const code of matchAll(html, /CodiceArticolo:\s*'([^']+)'/gi)) {
    codes.add(decodeHtml(code).trim());
  }
  for (const code of matchAll(
    html,
    /\/e-commerce\/diagrams\/index\.asp\?codice-articolo=([^"'&#\s]+)/gi
  )) {
    codes.add(decodeURIComponentSafe(code));
  }
  return Array.from(codes)
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b));
}

export function parseCardHtmlName(html: string): string | null {
  const priceMatch =
    /<span\b[^>]*class=["'][^"']*price[^"']*["'][^>]*>\s*<strong\b[^>]*>([\s\S]*?)<\/strong>/i.exec(
      html
    );
  if (!priceMatch?.[1]) return null;
  const name = normalizeWhitespace(stripTags(decodeHtml(priceMatch[1])));
  return name || null;
}

function parseOptions(html: string): Array<{ value: string; label: string }> {
  const options: Array<{ value: string; label: string }> = [];
  for (const match of html.matchAll(/<option\b([^>]*)>([\s\S]*?)<\/option>/gi)) {
    const attrs = match[1] ?? "";
    const labelHtml = match[2] ?? "";
    const value = readAttribute(attrs, "value")?.trim() ?? "";
    if (!value) continue;
    const label = normalizeWhitespace(stripTags(decodeHtml(labelHtml)));
    options.push({ value: decodeHtml(value), label: label || decodeHtml(value) });
  }
  return options;
}

function parseCategoryLinks(
  html: string,
  selectName: string
): Array<{ value: string; label: string }> {
  const queryKey = selectName === "CategoriaMenu4" ? "c4" : "c3";
  const options: Array<{ value: string; label: string }> = [];
  for (const match of html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
    const attrs = match[1] ?? "";
    const href = readAttribute(attrs, "href");
    if (!href || !href.includes(`${queryKey}=`)) continue;
    const value = readQueryValue(href, queryKey);
    if (!value) continue;
    const label = normalizeWhitespace(stripTags(decodeHtml(match[2] ?? "")));
    options.push({ value, label: label || value });
  }
  return options;
}

async function brandDiagramImage(sourceImageBuffer: Buffer, logoBuffer: Buffer) {
  const source = sharp(sourceImageBuffer).rotate();
  const metadata = await source.metadata();
  const width = metadata.width;
  const height = metadata.height;
  if (!width || !height) throw new Error("A DVG kép mérete nem olvasható.");

  const patchWidth = clamp(Math.round(width * 0.4), 240, 440);
  const patchHeight = clamp(Math.round(height * 0.1), 54, 90);
  const patch = Buffer.from(
    `<svg width="${patchWidth}" height="${patchHeight}" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" fill="white"/></svg>`
  );

  const logoMaxWidth = Math.round(patchWidth * 0.82);
  const logoMaxHeight = Math.round(patchHeight * 0.72);
  const resizedLogo = await sharp(logoBuffer)
    .resize({
      width: logoMaxWidth,
      height: logoMaxHeight,
      fit: "inside",
      withoutEnlargement: true,
    })
    .png()
    .toBuffer();

  const logoMeta = await sharp(resizedLogo).metadata();
  const logoW = logoMeta.width ?? logoMaxWidth;
  const logoH = logoMeta.height ?? logoMaxHeight;
  const logoLeft = Math.round((patchWidth - logoW) / 2);
  const logoTop = Math.round((patchHeight - logoH) / 2);

  const buffer = await source
    .composite([
      { input: patch, left: 0, top: 0 },
      { input: resizedLogo, left: logoLeft, top: logoTop },
    ])
    .jpeg({ quality: 92, mozjpeg: true })
    .toBuffer();

  return { buffer, width, height };
}

function validateGenerateInput(input: DvgDiagramGenerateInput): void {
  validateFamily(input.family);
  if (!input.logoBuffer || input.logoBuffer.length === 0)
    throw new Error("Danetti logó fájl szükséges.");
  if (!Array.isArray(input.brands) || input.brands.length === 0) {
    throw new Error("Legalább egy DVG márkát ki kell választani.");
  }
}

function validateFamily(family: DvgDiagramFamily): void {
  if (!familyConfig[family]) throw new Error("Érvénytelen diagram család.");
}

function collectConvertWarnings(
  skippedAreaCount: number,
  brandingWarning: string | null
): string[] {
  const warnings: string[] = [];
  if (skippedAreaCount > 0) {
    warnings.push(`${skippedAreaCount} area kimaradt hibás vagy hiányzó kód/coords miatt.`);
  }
  if (brandingWarning) warnings.push(brandingWarning);
  return warnings;
}

function buildCategoryUrl(
  family: DvgDiagramFamily,
  input: { brand?: string; model?: string | null; offset?: number } = {}
): string {
  const url = new URL("/e-commerce/cerca.asp", DVG_BASE_URL);
  url.searchParams.set("c2", familyConfig[family].c2);
  if (input.brand) url.searchParams.set("c3", input.brand);
  if (input.model) url.searchParams.set("c4", input.model);
  if (typeof input.offset === "number") url.searchParams.set("offset", String(input.offset));
  return url.toString();
}

function buildDiagramDetailUrl(diagramCode: string): string {
  return `${DVG_BASE_URL}/e-commerce/diagrams/index.asp?codice-articolo=${encodeURIComponent(
    diagramCode
  )}`;
}

function readOutputImageUrl(
  imageUrl: string | null | undefined,
  _family: DvgDiagramFamily,
  candidate: DiagramCodeCandidate
): string {
  const trimmed = imageUrl?.trim();
  if (trimmed) return trimmed;
  return `${candidate.code}.jpg`;
}

function buildRunDirectoryName(family: DvgDiagramFamily): string {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  return `${stamp}-${family}-${randomUUID().slice(0, 8)}`;
}

function buildDiagramFilenameBase(
  family: DvgDiagramFamily,
  candidate: DiagramCodeCandidate
): string {
  return [
    family === "coffee" ? "kavegep" : "orlo-daralo",
    candidate.brand,
    candidate.model,
    candidate.code,
    "robbantott-abra",
  ]
    .filter(Boolean)
    .map((part) => slugify(String(part)))
    .join("-");
}

function buildDiagramTitle(family: DvgDiagramFamily, candidate: DiagramCodeCandidate): string {
  return [familyConfig[family].label, candidate.brand, candidate.model, candidate.code]
    .filter(Boolean)
    .join(" ");
}

function findImageMapImageTag(html: string): string | null {
  return /<img\b[^>]*usemap=["'][^"']+["'][^>]*>/i.exec(html)?.[0] ?? null;
}

function findImageMapHtml(html: string): string | null {
  return (
    /<map\b[^>]*(?:name|id)=["']image-map["'][^>]*>([\s\S]*?)<\/map>/i.exec(html)?.[1] ??
    /<map\b[^>]*>([\s\S]*?)<\/map>/i.exec(html)?.[1] ??
    null
  );
}

function readAttribute(input: string, name: string): string | null {
  const match = new RegExp(`${escapeRegExp(name)}\\s*=\\s*(["'])([\\s\\S]*?)\\1`, "i").exec(input);
  return match?.[2] ? decodeHtml(match[2]) : null;
}

function readNumberAttribute(input: string, name: string): number | null {
  const value = readAttribute(input, name);
  if (!value) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function readCodeFromHref(href: string): string | null {
  if (!href) return null;
  try {
    const url = new URL(href, DVG_BASE_URL);
    return readArticleCodeParam(url.searchParams) ?? readRequestArticleParam(url);
  } catch {
    const match = /[?&]codice[-_]?articolo=([^&#"']+)/i.exec(href);
    if (match?.[1]) return decodeURIComponentSafe(match[1]);
    const requestMatch = /[?&]q=([^&#"']+)/i.exec(href);
    return requestMatch?.[1] ? decodeURIComponentSafe(requestMatch[1]) : null;
  }
}

function readAreaCode(areaAttrs: string, href: string): string | null {
  return (
    readAttribute(areaAttrs, "data-code") ??
    readCodeFromHref(href) ??
    readCodeFromInlineScript(areaAttrs)
  );
}

function readArticleCodeParam(searchParams: URLSearchParams): string | null {
  for (const [name, value] of searchParams.entries()) {
    if (name.toLowerCase().replace(/[-_]/g, "") === "codicearticolo") return value;
  }
  return null;
}

function readRequestArticleParam(url: URL): string | null {
  if (!url.pathname.toLowerCase().endsWith("/richiesta-articolo.asp")) return null;
  return url.searchParams.get("q");
}

function readCodeFromInlineScript(value: string): string | null {
  return (
    /getDetail\(\s*['"]([^'"]+)['"]\s*\)/i.exec(value)?.[1] ??
    /CodiceArticolo\s*[:=]\s*['"]?([A-Za-z0-9._-]+)/i.exec(value)?.[1] ??
    null
  );
}

function isIgnorableArea(href: string | null, coords: string | null, code: string | null): boolean {
  const normalizedHref = href?.trim().toLowerCase() ?? "";
  if (normalizedHref.startsWith("javascript:") || normalizedHref === "#") return true;
  return !normalizedHref && (!coords || !code);
}

function readQueryValue(href: string, name: string): string | null {
  try {
    return new URL(href, DVG_BASE_URL).searchParams.get(name);
  } catch {
    const match = new RegExp(`[?&]${escapeRegExp(name)}=([^&#"']+)`, "i").exec(href);
    return match?.[1] ? decodeURIComponentSafe(match[1]) : null;
  }
}

function normalizeCoords(value: string | null): string | null {
  if (!value) return null;
  const parts = value.split(",").map((part) => part.trim());
  if (parts.length < 4 || parts.some((part) => !/^\d+$/.test(part))) return null;
  return parts.join(",");
}

function filterAreasWithinDimensions(
  areas: readonly DvgDiagramArea[],
  width: number,
  height: number
): DvgDiagramArea[] {
  return areas.filter((area) => {
    const coords = area.coords.split(",").map(Number);
    if (coords.some((coord) => !Number.isFinite(coord))) return false;
    const xs = coords.filter((_, index) => index % 2 === 0);
    const ys = coords.filter((_, index) => index % 2 === 1);
    return xs.every((x) => x >= 0 && x <= width) && ys.every((y) => y >= 0 && y <= height);
  });
}

function absoluteUrl(value: string, baseUrl: string): string {
  return new URL(value, baseUrl).toString();
}

function normalizePlaceholderBaseUrl(value: string): string {
  return value.trim().replace(/\/+$/, "") || PLACEHOLDER_BASE_URL;
}

function decodeHtml(value: string): string {
  return value
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ");
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function stripTags(value: string): string {
  return value.replace(/<[^>]+>/g, " ");
}

function normalizeWhitespace(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

function dedupeByValue<T extends { value: string }>(items: T[]): T[] {
  const seen = new Set<string>();
  return items.filter((item) => {
    if (seen.has(item.value)) return false;
    seen.add(item.value);
    return true;
  });
}

function matchAll(input: string, pattern: RegExp, group = 1): string[] {
  return Array.from(input.matchAll(pattern))
    .map((match) => match[group])
    .filter((value): value is string => Boolean(value));
}

function decodeURIComponentSafe(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return decodeHtml(value);
  }
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

function readErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "ismeretlen hiba";
}
