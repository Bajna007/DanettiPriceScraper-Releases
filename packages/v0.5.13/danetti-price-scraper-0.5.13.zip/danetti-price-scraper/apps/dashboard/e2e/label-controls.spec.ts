import { expect, test, type Page } from "@playwright/test";
import { readFile } from "node:fs/promises";
import {
  createBeanOnSeeds,
  createBlankBeanOnTemplateScene,
  createBlankUtopiaTemplateScene,
  type LabelScene,
  type TextNode,
} from "@danetti/label-engine";

async function fixture(page: Page, template?: LabelScene) {
  const seed = createBeanOnSeeds()[0]!;
  const name = seed.scene.nodes.find(
    (node): node is TextNode => node.type === "text" && node.id === "name"
  )!;
  const font = await readFile("C:/Windows/Fonts/arial.ttf");
  const boldFont = await readFile("C:/Windows/Fonts/arialbd.ttf");
  let scene: LabelScene = {
    ...structuredClone(seed.scene),
    fields: { name: "SUMATRA" },
    fieldSchema: [{ key: "name", label: "Terméknév", type: "text", required: true }],
    nodes: [
      {
        ...name,
        x: 5,
        y: 3,
        width: 42,
        maxWidth: 42,
        height: 9,
        fontFamily: "Arial",
        fontSizePt: 14,
        scaleX: 1,
        scaleY: 1,
        glyphXPt: undefined,
        glyphScaleX: undefined,
      },
      {
        ...name,
        id: "free-text",
        name: "Szabad szöveg",
        x: 55,
        y: 3,
        width: 46,
        maxWidth: 46,
        height: 9,
        fontFamily: "Arial",
        fontSizePt: 14,
        text: "FORGALMAZÓ",
        binding: undefined,
        scaleX: 1,
        scaleY: 1,
        glyphXPt: undefined,
        glyphScaleX: undefined,
      },
    ],
  };
  let revision = 1;
  if (template) scene = structuredClone(template);
  const assets = Array.from(
    new Map(
      scene.nodes
        .filter((node): node is TextNode => node.type === "text")
        .map((node) => [
          node.fontAssetId,
          {
            id: node.fontAssetId,
            family: node.fontFamily,
            style: node.fontStyle,
            weight: node.fontWeight,
            active: true,
            metadata: { isCompleteLatinAlphabet: true },
            filename: "arial.ttf",
            usages: [],
          },
        ])
    ).values()
  );
  await page.route("http://localhost:4000/**", async (route) => {
    const path = new URL(route.request().url()).pathname;
    const headers = {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET,PATCH,POST,OPTIONS",
      "access-control-allow-headers": "content-type",
    };
    if (route.request().method() === "OPTIONS") return route.fulfill({ status: 204, headers });
    if (path.endsWith("/download")) {
      if (assets.find((asset) => path.includes(asset.id))?.family === "Bean On Center Fixture")
        await new Promise((resolve) => setTimeout(resolve, 300));
      return route.fulfill({
        body: assets.find((asset) => path.includes(asset.id))?.weight === 700 ? boldFont : font,
        contentType: "font/ttf",
        headers,
      });
    }
    if (path === "/label-assets")
      return route.fulfill({
        json: {
          items: assets,
        },
        headers,
      });
    if (path === "/labels/control-fixture") {
      if (route.request().method() === "PATCH") {
        const input = route.request().postDataJSON() as {
          scene: LabelScene;
          expectedRevision: number;
        };
        expect(input.expectedRevision).toBe(revision);
        scene = input.scene;
        revision++;
      }
      return route.fulfill({
        json: {
          item: {
            ...seed,
            brand: scene.brand,
            id: "control-fixture",
            name: "Szerkesztő próba",
            scene,
            revision,
          },
        },
        headers,
      });
    }
    return route.fulfill({ json: { items: [], status: "ok" }, headers });
  });
  await page.goto(`/labels/${scene.brand === "utopia" ? "utopia" : "bean-on"}/control-fixture`);
  await expect(page.getByRole("toolbar", { name: "Címkeszerkesztő eszköztár" })).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
  return () => scene;
}

test("blend neve és többsoros összetétele a saját box közepén marad szerkesztés után is", async ({
  page,
}) => {
  await page.setViewportSize({ width: 1440, height: 900 });
  const initial = createBlankBeanOnTemplateScene("blend");
  initial.nodes = initial.nodes.map((node) =>
    node.type === "text" && ["name", "value-farm"].includes(node.id)
      ? { ...node, fontFamily: "Bean On Center Fixture" }
      : node
  );
  initial.fields.name = "SAJÁT\nBLEND";
  initial.fields.farm = "50% arabica\n50% robusta";
  const getScene = await fixture(page, initial);
  const canvas = page.locator('svg[role="img"]').first();
  for (const width of [1440, 390]) {
    await page.setViewportSize({ width, height: 900 });
    const divider = canvas.locator('[data-node-id="main-divider"]');
    const footer = canvas.locator('[data-node-id="footer-line"]');
    await expect(divider).toHaveAttribute("y2", (await footer.getAttribute("y1"))!);
    await page.screenshot({ path: `test-results/bean-on-divider-${width}.png` });
  }
  await page.setViewportSize({ width: 1440, height: 900 });
  const checkCenter = async () => {
    await page.evaluate(() => document.fonts.ready);
    await page.evaluate(
      () => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)))
    );
    for (const id of ["name", "value-farm"]) {
      const node = getScene().nodes.find((node) => node.id === id)!;
      expect(node).toMatchObject({ verticalAlign: "center", wrap: true });
      const delta = await canvas.locator(`[data-node-id="${id}"]`).evaluate(
        (group, box) => {
          // getBBox includes the font's line box; derive actual visible ink from its baseline.
          const context = document.createElement("canvas").getContext("2d")!;
          let top = Infinity,
            bottom = -Infinity;
          for (const text of group.querySelectorAll("text")) {
            if (!text.textContent?.trim()) continue;
            context.font = `${text.getAttribute("font-weight")} 128px "${text.getAttribute("font-family")}"`;
            const metrics = context.measureText(text.textContent);
            const size = Number(text.getAttribute("font-size"));
            const y = Number(text.getAttribute("y"));
            const matrix = (group as SVGGraphicsElement)
              .getCTM()!
              .inverse()
              .multiply(text.getCTM()!);
            const x = Number(text.getAttribute("x"));
            top = Math.min(
              top,
              new DOMPoint(x, y - (metrics.actualBoundingBoxAscent * size) / 128).matrixTransform(
                matrix
              ).y
            );
            bottom = Math.max(
              bottom,
              new DOMPoint(x, y + (metrics.actualBoundingBoxDescent * size) / 128).matrixTransform(
                matrix
              ).y
            );
          }
          return {
            center: Math.abs((top + bottom) / 2 - (box.y + box.height / 2)),
            fits: top >= box.y - 0.01 && bottom <= box.y + box.height + 0.01,
          };
        },
        { y: node.y, height: node.height }
      );
      expect(delta.center).toBeLessThan(0.01);
      expect(delta.fits).toBe(true);
    }
  };
  await checkCenter();
  await page
    .getByRole("textbox", { name: /Terméknév|Címkenév/ })
    .first()
    .fill("ÚJ\nSAJÁT\nBLEND");
  await page
    .getByRole("textbox", { name: /összetétel/i })
    .fill("50% saját arabica, 50% saját robusta – részletes összetétel. ".repeat(5));
  await saved(page);
  await checkCenter();
  await page.reload();
  await expect(canvas.locator('[data-node-id="name"]')).toContainText("SAJÁT");
  await checkCenter();
});

test("átlátható szerkesztőpult, összecsukható panelek és teljes címkenézet", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 720 });
  const getScene = await fixture(page, createBlankBeanOnTemplateScene("single_origin"));
  const before = structuredClone(getScene());
  const canvas = page.locator('svg[role="img"]').first();
  const viewBox = await canvas.getAttribute("viewBox");
  const width = (await canvas.boundingBox())!.width;
  const zoom = page.getByRole("slider");
  await zoom.focus();
  await zoom.press("End");
  await expect(zoom).toHaveValue("400");
  await page.getByRole("button", { name: "Teljes címke", exact: true }).click();
  await expect(zoom).toHaveValue("100");
  await expect(canvas).toHaveAttribute("viewBox", viewBox!);
  await page.getByRole("button", { name: "Címke adatai", exact: true }).click();
  await expect(page.getByRole("textbox", { name: /Címkenév|Terméknév/ })).toBeHidden();
  await page.getByRole("button", { name: "Elem tulajdonságai", exact: true }).click();
  expect((await canvas.boundingBox())!.width).toBeGreaterThan(width + 300);
  await page.getByRole("button", { name: "Címke adatai", exact: true }).click();
  await page.getByRole("button", { name: "Elem tulajdonságai", exact: true }).click();
  for (const viewport of [
    { width: 1280, height: 720 },
    { width: 1000, height: 800 },
    { width: 390, height: 844 },
  ]) {
    await page.setViewportSize(viewport);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
      true
    );
    for (const button of await page.getByRole("toolbar").getByRole("button").all()) {
      const box = (await button.boundingBox())!;
      expect(box.x).toBeGreaterThanOrEqual(0);
      expect(box.x + box.width).toBeLessThanOrEqual(viewport.width);
    }
    await page.screenshot({
      path: `../../tmp/label-cockpit-${viewport.width}.png`,
      fullPage: true,
    });
  }
  expect(getScene()).toEqual(before);
});

test("elfogadott K06-B, állítható ízjegyvonalak és 250 g kitöltés", async ({ page }) => {
  await page.setViewportSize({ width: 1440, height: 1000 });
  const initial = createBlankBeanOnTemplateScene("single_origin");
  initial.fields.name = "SUMATRA\nQUEEN\nKETIARA";
  const getScene = await fixture(page, initial);
  const canvas = page.locator('svg[role="img"]').first();
  await expect(canvas.locator('[data-node-id="qr-product"]')).toHaveAttribute("d", /^M/);
  const placeholderQr = await canvas.locator('[data-node-id="qr-product"]').getAttribute("d");
  await page.getByText("Ízjegyek elrendezése", { exact: true }).click();
  await expect(page.getByLabel("Függőleges elválasztók")).not.toBeChecked();
  await expect(page.getByLabel("Vízszintes elválasztó", { exact: true })).toHaveValue("none");
  await expect(page.getByLabel("Pörkölési dátum felirat")).toHaveCount(0);
  await page.getByLabel("Termékoldal linkje (QR)").fill("https://beanon.hu/products/sumatra");
  await expect(canvas.locator('[data-node-id="qr-product"]')).toHaveAttribute("d", /^M/);
  await expect(canvas.locator('[data-node-id="qr-product"]')).not.toHaveAttribute(
    "d",
    placeholderQr!
  );
  await page.getByLabel("Függőleges elválasztók").uncheck();
  await page.getByLabel("Vízszintes elválasztó", { exact: true }).selectOption("none");
  await page.getByLabel("Fehér QR-háttér").check();
  await expect(canvas.locator('[data-node-id="qr-paper"]')).toHaveCount(1);
  await page.getByLabel("Fehér QR-háttér").uncheck();
  await expect(page.getByLabel("250 g kifeketézése")).toBeChecked();
  await expect(canvas.locator('[data-node-id="weight-marker-0"]')).toHaveAttribute(
    "fill",
    "#000000"
  );
  await page.getByLabel("250 g kifeketézése").uncheck();
  await expect(canvas.locator('[data-node-id="weight-marker-0"]')).toHaveAttribute(
    "fill",
    "#FFFFFF"
  );
  await expect(canvas.locator('[data-node-id="weight-marker-1"]')).toHaveAttribute(
    "fill",
    "#FFFFFF"
  );
  await page
    .getByRole("textbox", { name: "Ízjegyek – magyar", exact: true })
    .fill("Füge, grapefruit, citrus");
  await page
    .getByRole("textbox", { name: "Ízjegyek – angol", exact: true })
    .fill("Fig, grapefruit, citrus, chocolate");
  await expect(canvas.locator('[data-node-id="value-notes"]')).toContainText(
    "Füge, grapefruit, citrus"
  );
  await expect(canvas.locator('[data-node-id^="taste-separator-"]')).toHaveCount(0);
  await page.getByLabel("Függőleges elválasztók").check();
  await expect(canvas.locator('[data-node-id^="taste-separator-v-"]')).toHaveCount(3);
  await expect(canvas.locator('[data-node-id="value-notes-en--part-3"]')).toContainText(
    "chocolate"
  );
  await page.getByLabel("Vízszintes elválasztó", { exact: true }).selectOption("words");
  await expect(canvas.locator('[data-node-id^="taste-separator-h-"]')).toHaveCount(4);
  await page.getByLabel("Vízszintes vonal helye").selectOption("above_hu");
  const above = Number(
    await canvas.locator('[data-node-id="taste-separator-h-0"]').getAttribute("y1")
  );
  await page.getByLabel("Vízszintes vonal helye").selectOption("below_en");
  expect(
    Number(await canvas.locator('[data-node-id="taste-separator-h-0"]').getAttribute("y1"))
  ).toBeGreaterThan(above);
  await page.getByLabel("Vízszintes elválasztó", { exact: true }).selectOption("full");
  await expect(canvas.locator('[data-node-id="taste-separator-full"]')).toHaveCount(1);
  const sizes = await canvas
    .locator(
      '[data-node-id^="label-"] text, [data-node-id^="value-"] text, [data-node-id="bestBefore"] text, [data-node-id^="company-"] text, [data-node-id="domain"] text, [data-node-id^="weight-"] text'
    )
    .evaluateAll((texts) => texts.map((text) => Number(text.getAttribute("font-size"))));
  expect(Math.max(...sizes) - Math.min(...sizes)).toBeLessThan(0.00001);
  await page.getByRole("button", { name: "Vonal: footer-line", exact: true }).click();
  await page.getByRole("button", { name: "Elválasztók színe: #FFFFFF", exact: true }).click();
  await expect(canvas.locator('[data-node-id="qr-product"]')).toHaveAttribute("fill", "#FFFFFF");
  await expect(canvas.locator('[data-node-id="taste-separator-full"]')).toHaveAttribute(
    "stroke",
    "#FFFFFF"
  );
  await expect(canvas.locator('[data-node-id="lower-divider"]')).toHaveAttribute(
    "stroke",
    "#FFFFFF"
  );
  await page.getByRole("button", { name: "Elválasztók színe: #000000", exact: true }).click();
  await expect(canvas.locator('[data-node-id="qr-product"]')).toHaveAttribute("fill", "#000000");
  await expect(canvas.locator('[data-node-id="taste-separator-full"]')).toHaveAttribute(
    "stroke",
    "#000000"
  );
  await canvas.locator('[data-node-id="value-notes-en--part-3"]').click();
  const tasteSelection = canvas.locator('[data-selection-id="taste-box"]');
  await expect(tasteSelection).toHaveCount(1);
  await expect(tasteSelection.locator("rect")).toHaveAttribute(
    "width",
    String(initial.nodes.find((node) => node.id === "taste-box")!.width)
  );
  await expect(page.getByRole("button", { name: "Ízjegyek", exact: true })).toHaveCount(1);
  const handle = tasteSelection.locator('[data-resize-handle="e"]');
  const handleBox = (await handle.boundingBox())!;
  await page.mouse.move(handleBox.x + handleBox.width / 2, handleBox.y + handleBox.height / 2);
  await page.mouse.down();
  await page.mouse.move(
    handleBox.x + handleBox.width / 2 - 20,
    handleBox.y + handleBox.height / 2,
    { steps: 3 }
  );
  await page.mouse.up();
  await expect(tasteSelection).toHaveCount(1);
  expect(getScene().nodes.find((node) => node.id === "value-notes")!.width).toBe(
    getScene().nodes.find((node) => node.id === "value-notes-en")!.width
  );
  await saved(page);
  await page.reload();
  await expect(page.getByLabel("Termékoldal linkje (QR)")).toHaveValue(
    "https://beanon.hu/products/sumatra"
  );
  await expect(page.getByLabel("Vízszintes elválasztó", { exact: true })).toHaveValue("full");
  await expect(page.getByLabel("250 g kifeketézése")).not.toBeChecked();
  expect(getScene().fields.fill250g).toBe(false);
  await page.getByText("Ízjegyek elrendezése", { exact: true }).click();
  await page.getByLabel("Függőleges elválasztók").uncheck();
  await page.getByLabel("Vízszintes elválasztó", { exact: true }).selectOption("none");
  await expect(canvas.locator('[data-node-id^="taste-separator-"]')).toHaveCount(0);
  await expect(canvas.locator('[data-node-id="value-notes-en"]')).toContainText(
    "Fig, grapefruit, citrus, chocolate"
  );
  await saved(page);
  await page.screenshot({ path: "../../tmp/label-k06-controls.png", fullPage: true });
  await canvas.locator('[data-node-id="value-notes-en"]').click();
  await page.keyboard.press("Control+c");
  await page.keyboard.press("Control+v");
  await expect(page.getByRole("button", { name: "Ízjegyek másolat", exact: true })).toHaveCount(1);
  await saved(page);
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true
  );
});

async function saved(page: Page) {
  await expect(page.locator('span[role="status"]')).toHaveText("Minden módosítás mentve");
}

for (const brand of ["bean_on", "utopia"] as const) {
  for (const width of [1440, 390]) {
    test(`csoportosított bal sáv és automatikus szövegmagasság ${brand} ${width}px`, async ({
      page,
    }) => {
      await page.setViewportSize({ width, height: 900 });
      const initial =
        brand === "bean_on"
          ? createBlankBeanOnTemplateScene("single_origin")
          : createBlankUtopiaTemplateScene();
      const getScene = await fixture(page, initial);
      const panel = page.getByRole("region", { name: "Tartalmi mezők" });
      const before = structuredClone(getScene());
      for (const title of ["Kávé adatai", "Ízjegyek"]) {
        const section = panel
          .locator("details")
          .filter({
            has: panel.locator("summary").filter({ hasText: new RegExp("^" + title + "$") }),
          })
          .first();
        for (const input of await section.getByRole("textbox").all())
          await expect(input).toHaveValue("");
      }
      for (const title of ["Kávé adatai", "Ízjegyek", "Csomagolás", "Termékoldal és QR"])
        await expect(
          panel.locator("summary").filter({ hasText: new RegExp(`^${title}$`) })
        ).toBeVisible();
      const shelfLife = panel.getByRole("textbox", { name: /Minőségmegőrzési szöveg/ });
      await shelfLife.scrollIntoViewIfNeeded();
      expect(
        await shelfLife.evaluate((input) => input.scrollHeight <= input.clientHeight + 1)
      ).toBe(true);
      const coffee = panel.getByText("Kávé adatai", { exact: true });
      const nameLabel = initial.fieldSchema.find((field) => field.key === "name")!.label;
      const name = panel.getByRole("textbox", { name: new RegExp(nameLabel) });
      await coffee.focus();
      await coffee.press("Enter");
      await expect(name).toBeHidden();
      await coffee.press("Enter");
      await expect(name).toHaveValue(String(initial.fields.name));
      expect(getScene()).toEqual(before);
      await name.fill("HOSSZABB CÍMKE\nMÁSODIK SOR\nHARMADIK SOR\nNEGYEDIK SOR");
      await expect
        .poll(() => name.evaluate((input) => input.scrollHeight <= input.clientHeight + 1))
        .toBe(true);
      await name.press("End");
      await name.press("Shift+Enter");
      await name.press("A");
      await expect(name).toHaveValue(/\nA$/);
      await saved(page);
      expect(getScene().fields.name).toContain("NEGYEDIK SOR\nA");
      for (const field of initial.fieldSchema.filter((field) => field.key !== "name"))
        expect(getScene().fields[field.key]).toEqual(before.fields[field.key]);
      await name.fill(String(initial.fields.name));
      await saved(page);
      await panel.getByLabel("250 g jelölés").scrollIntoViewIfNeeded();
      await expect(panel.getByLabel("250 g jelölés")).toBeChecked();
      if (brand === "utopia")
        await expect(panel.getByLabel("Pörkölési dátum háttere")).toBeChecked();
      const url = panel.getByRole("textbox", { name: /Termékoldal linkje/ });
      await url.fill("https://utopiacoffee.hu/termek/sajat-cimke/");
      await saved(page);
      await page.reload();
      await expect(panel.getByRole("textbox", { name: /Termékoldal linkje/ })).toHaveValue(
        "https://utopiacoffee.hu/termek/sajat-cimke/"
      );
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
        true
      );
      await panel.getByText("Kávé adatai", { exact: true }).scrollIntoViewIfNeeded();
      await page.screenshot({
        path: `../../tmp/label-0411-rail-${brand}-${width}.png`,
        fullPage: true,
      });
    });
  }
}

for (const viewport of [
  { width: 1440, height: 1000 },
  { width: 390, height: 844 },
]) {
  test(`háttér, kézi sortörés és szövegdoboz ${viewport.width}px`, async ({ page }) => {
    await page.setViewportSize(viewport);
    const getScene = await fixture(page);
    const canvas = page.locator('svg[role="img"]').first();
    const area = await canvas.boundingBox();
    if (!area) throw new Error("Missing canvas");
    await canvas.click({ position: { x: area.width * 0.88, y: area.height * 0.85 } });
    await expect(page.getByRole("heading", { name: "Háttér", exact: true })).toBeVisible();
    await expect(page.getByRole("button", { name: "Háttér", exact: true })).toHaveAttribute(
      "aria-pressed",
      "true"
    );
    const originalColor = getScene().background.rgb;
    await page.getByRole("button", { name: "Márkapaletta: #00BDB7" }).click();
    await expect(canvas.locator(":scope > rect").first()).toHaveAttribute("fill", "#00BDB7");
    await page.getByRole("button", { name: "Visszavonás", exact: true }).click();
    await expect(canvas.locator(":scope > rect").first()).toHaveAttribute("fill", originalColor);
    await page.getByRole("button", { name: "Újra", exact: true }).click();
    await saved(page);
    await page.reload();
    await expect(canvas.locator(":scope > rect").first()).toHaveAttribute("fill", "#00BDB7");
    await page.getByRole("button", { name: "Háttér", exact: true }).click();
    await page.getByLabel("HEX", { exact: true }).fill("#ECA8D9");
    await expect(canvas.locator(":scope > rect").first()).toHaveAttribute("fill", "#ECA8D9");
    await saved(page);
    const title = page.getByRole("textbox", { name: /Címkenév|Terméknév/ });
    await title.fill("ELSŐ");
    await title.press("End");
    await title.press("Enter");
    await title.pressSequentially("MÁSODIK");
    await title.press("Shift+Enter");
    await title.pressSequentially("HARMADIK");
    await expect(title).toHaveValue("ELSŐ\nMÁSODIK\nHARMADIK");
    await saved(page);
    expect(getScene().fields.name).toBe("ELSŐ\nMÁSODIK\nHARMADIK");
    await page.getByRole("button", { name: "Szöveg: name", exact: true }).click();
    const inspector = page
      .locator("section")
      .filter({ has: page.getByRole("heading", { name: "Tulajdonságok", exact: true }) });
    if (
      !(await inspector.getByRole("spinbutton", { name: "Szélesség mm", exact: true }).isVisible())
    )
      await inspector.getByText("Pozíció és méret", { exact: true }).click();
    await inspector.getByRole("spinbutton", { name: "Szélesség mm", exact: true }).fill("16");
    await inspector.getByRole("spinbutton", { name: "Magasság mm", exact: true }).fill("12");
    await inspector
      .getByLabel("Szöveg tartalma")
      .fill("NAGYON HOSSZÚ TERMÉKNÉV\nÁRVÍZTŰRŐ TÜKÖRFÚRÓGÉP");
    await expect
      .poll(async () => canvas.locator('[data-node-id="name"] > text').count())
      .toBeGreaterThan(2);
    await expect
      .poll(async () =>
        canvas.locator('[data-node-id="name"]').evaluate((group) => {
          const rect = group.querySelector("rect")!;
          const box = (rect as SVGGraphicsElement).getBBox();
          const details = Array.from(group.querySelectorAll("text")).map((element) => {
            const b = element.getBBox();
            return {
              text: element.textContent,
              x: b.x,
              y: b.y,
              width: b.width,
              height: b.height,
              fontSize: getComputedStyle(element).fontSize,
              fits:
                b.x >= box.x - 0.08 &&
                b.y >= box.y - 0.08 &&
                b.x + b.width <= box.x + box.width + 0.08 &&
                b.y + b.height <= box.y + box.height + 0.08,
            };
          });
          return details.every((item) => item.fits)
            ? "fits"
            : JSON.stringify({
                box: { x: box.x, y: box.y, width: box.width, height: box.height },
                details,
              });
        })
      )
      .toBe("fits");
    await saved(page);
    await page.getByRole("button", { name: "Szabad szöveg", exact: true }).click();
    const free = canvas.locator('[data-node-id="free-text"]');
    await free.dblclick();
    const inline = page.getByRole("textbox", { name: "Szabad szöveg szerkesztése" });
    await inline.fill("FORGALMAZÓ");
    await inline.press("End");
    await inline.press("Enter");
    await inline.pressSequentially("DANETTI");
    await inline.press("Shift+Enter");
    await inline.pressSequentially("PÉCS");
    await expect(inline).toHaveValue("FORGALMAZÓ\nDANETTI\nPÉCS");
    await inline.press("Control+Enter");
    await expect(inline).toBeHidden();
    await saved(page);
    expect(getScene().nodes.find((node) => node.id === "free-text")).toMatchObject({
      text: "FORGALMAZÓ\nDANETTI\nPÉCS",
      wrap: true,
    });
    await page.reload();
    await expect(title).toHaveValue("NAGYON HOSSZÚ TERMÉKNÉV\nÁRVÍZTŰRŐ TÜKÖRFÚRÓGÉP");
    await expect(canvas.locator('[data-node-id="free-text"]')).toContainText("DANETTI");
    await page.getByRole("button", { name: "Háttér", exact: true }).click();
    await page.screenshot({
      path: `../../tmp/label-controls-${viewport.width}.png`,
      fullPage: true,
    });
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
      true
    );
  });
}
