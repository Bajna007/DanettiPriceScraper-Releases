import { expect, test, type Locator, type Page } from "@playwright/test";
import {
  createBeanOnBalancedTemplateScene,
  createCustomLabelScene,
  createUtopiaSeeds,
  upgradeLabelScene,
  type LineNode,
  type LabelScene,
} from "@danetti/label-engine";
import { mkdir, readFile } from "node:fs/promises";
import path from "node:path";

const evidence = path.resolve("../../.impeccable/review/danetti-20261017");
const phase = process.env.LABEL_CAPTURE_PHASE ?? "after";
const headers = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "content-type",
  "access-control-allow-methods": "GET,OPTIONS",
};

async function fixture(page: Page, scene: LabelScene) {
  const catalog = JSON.parse(await readFile("../../assets/label-catalog/catalog.json", "utf8"));
  const item = {
    id: "trim-fixture",
    brand: scene.brand,
    name: scene.metadata.name,
    internal_code: "TRIM-FIXTURE",
    status: "approved",
    visible: true,
    scene,
    revision: 1,
    version: 1,
  };
  const writes: string[] = [];
  await page.route("http://localhost:4000/**", async (route) => {
    const request = route.request();
    const url = new URL(request.url());
    if (request.method() === "OPTIONS") return route.fulfill({ status: 204, headers });
    if (request.method() === "PATCH") writes.push(url.pathname);
    if (url.pathname.startsWith("/label-assets")) {
      if (url.pathname.endsWith("/download")) {
        const asset = catalog.assets.find(
          (candidate: { id: string }) => candidate.id === url.pathname.split("/")[2]
        );
        return route.fulfill({
          body: await readFile(path.resolve("../../assets/label-catalog", asset.file)),
          contentType: asset.mimeType,
          headers,
        });
      }
      return route.fulfill({ json: { items: catalog.assets }, headers });
    }
    return route.fulfill({
      json: url.pathname === "/labels/trim-fixture" ? { item } : { items: [item] },
      headers,
    });
  });
  return writes;
}

// Rasterize actual visible separator nodes with a margin around the physical label.
// Unlike a root overflow check, this catches artwork leaking when zoom/pan exposes
// scene coordinates outside the trim, without hiding editor handles or rulers.
async function separatorPaintOutsideTrim(svg: Locator) {
  return svg.evaluate(async (element) => {
    const source = element as SVGSVGElement;
    const background = source.querySelector(":scope > rect");
    const width = Number(background?.getAttribute("width"));
    const height = Number(background?.getAttribute("height"));
    const box = source.viewBox.baseVal;
    const w = width || box.width;
    const h = height || box.height;
    const ns = "http://www.w3.org/2000/svg";
    const proof = document.createElementNS(ns, "svg");
    const scale = 10;
    const margin = 4;
    proof.setAttribute("xmlns", ns);
    proof.setAttribute("viewBox", `${-margin} ${-margin} ${w + 2 * margin} ${h + 2 * margin}`);
    proof.setAttribute("width", String((w + 2 * margin) * scale));
    proof.setAttribute("height", String((h + 2 * margin) * scale));
    const definitions = source.querySelector("defs");
    if (definitions) proof.append(definitions.cloneNode(true));
    const artwork = source.querySelector("[data-label-artwork]");
    const group = artwork
      ? (artwork.cloneNode(true) as SVGElement)
      : document.createElementNS(ns, "g");
    if (!artwork)
      source
        .querySelectorAll("line[data-node-id]")
        .forEach((line) => group.append(line.cloneNode(true)));
    group.querySelectorAll("[data-node-id]").forEach((node) => {
      if (node.tagName !== "line") node.remove();
    });
    proof.append(group);
    const picture = new Image();
    picture.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(new XMLSerializer().serializeToString(proof))}`;
    await picture.decode();
    const canvas = document.createElement("canvas");
    canvas.width = (w + 2 * margin) * scale;
    canvas.height = (h + 2 * margin) * scale;
    const context = canvas.getContext("2d")!;
    context.drawImage(picture, 0, 0);
    const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let outside = 0;
    let inside = 0;
    for (let y = 0; y < canvas.height; y++)
      for (let x = 0; x < canvas.width; x++) {
        if (!pixels[(y * canvas.width + x) * 4 + 3]) continue;
        if (
          x < margin * scale ||
          y < margin * scale ||
          x >= (w + margin) * scale ||
          y >= (h + margin) * scale
        )
          outside++;
        else inside++;
      }
    return { outside, inside };
  });
}

for (const width of [1440, 390])
  for (const brand of ["bean_on", "utopia", "custom"] as const) {
    test(`${brand}: címkerajz a vágott méreten belül, ${width}px`, async ({ page }) => {
      await mkdir(evidence, { recursive: true });
      await page.setViewportSize({ width, height: 1000 });
      const scene =
        brand === "bean_on"
          ? createBeanOnBalancedTemplateScene()
          : brand === "utopia"
            ? upgradeLabelScene(createUtopiaSeeds()[0]!.scene)!
            : createCustomLabelScene(77, 42);
      if (brand === "custom") {
        const line = createBeanOnBalancedTemplateScene().nodes.find(
          (node): node is LineNode => node.type === "line" && node.id === "footer-line"
        )!;
        scene.nodes.push(
          { ...line, id: "wide-line", x: -2.5, y: 15, x2: 79.5, y2: 15 },
          { ...line, id: "tall-line", x: 30, y: -2.5, x2: 30, y2: 44.5 }
        );
      }
      const writes = await fixture(page, scene);
      const slug = brand === "bean_on" ? "bean-on" : brand;
      await page.goto(`/labels/${slug}`);
      const preview = page.locator('article svg[role="img"]').first();
      await expect(preview).toBeVisible();
      await page.evaluate(() => document.fonts.ready);
      const libraryPaint = await separatorPaintOutsideTrim(preview);
      expect(libraryPaint.inside).toBeGreaterThan(0);
      if (phase === "after") expect(libraryPaint.outside).toBe(0);
      await page.goto(`/labels/${slug}/trim-fixture`);
      const canvas = page.locator('svg[role="img"]').first();
      await expect(canvas).toBeVisible();
      await page.evaluate(() => document.fonts.ready);
      await page.screenshot({ path: path.join(evidence, `label-${brand}-${width}-${phase}.png`) });
      const paint = await separatorPaintOutsideTrim(canvas);
      expect(paint.inside).toBeGreaterThan(0);
      if (phase === "after") {
        expect(paint.outside).toBe(0);
        // The editor layer remains outside the artwork clip and stays selectable.
        if (brand === "custom")
          await canvas.locator("line[data-node-id]").first().click({ force: true });
        else await canvas.locator('g[data-node-id="name"] text').first().click({ force: true });
        await expect(canvas.locator("[data-selection-id]")).toBeVisible();
        expect(
          await canvas
            .locator("[data-selection-id]")
            .evaluate((node) => node.closest("[clip-path]") === null)
        ).toBe(true);
        // Zooming out exposes space around the label in the SVG viewBox.
        // Clipping must follow the physical document, not that viewport.
        await page.getByRole("slider", { name: "Nagyítás" }).fill("50");
        expect((await separatorPaintOutsideTrim(canvas)).outside).toBe(0);
      }
      expect(writes).toEqual([]);
      console.log(
        `${brand} ${width}px: library ${libraryPaint.outside}, editor ${paint.outside} separator pixels outside trim`
      );
    });
  }
