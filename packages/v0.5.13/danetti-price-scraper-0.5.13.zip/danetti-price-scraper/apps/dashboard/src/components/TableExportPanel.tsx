import { useState } from "react";
import { TablePrintSettings } from "./TablePrintSettings";
import type { TablePrintOptions } from "../products/table-print";

type Column<Id extends string> = { id: Id; label: string };

export function TableColumnChoices<Id extends string>({
  columns,
  selectedIds,
  onChange,
  fixedIds = [],
  disabled = false,
}: {
  columns: readonly Column<Id>[];
  selectedIds: readonly Id[];
  onChange: (ids: Id[]) => void;
  fixedIds?: readonly Id[];
  disabled?: boolean;
}) {
  return (
    <fieldset className="table-column-choices" disabled={disabled}>
      <legend>Oszlopok kiválasztása</legend>
      <div className="toolbar-group">
        <button
          className="button small secondary"
          type="button"
          onClick={() => onChange(columns.map((c) => c.id))}
        >
          Mind kijelölése
        </button>
        <button
          className="button small secondary"
          type="button"
          onClick={() => onChange([...fixedIds])}
        >
          Kijelölés törlése
        </button>
      </div>
      <div className="table-column-grid">
        {columns.map((column) => (
          <label className="column-toggle" key={column.id}>
            <input
              type="checkbox"
              checked={selectedIds.includes(column.id)}
              disabled={fixedIds.includes(column.id)}
              onChange={(event) =>
                onChange(
                  columns
                    .filter((c) =>
                      c.id === column.id ? event.target.checked : selectedIds.includes(c.id)
                    )
                    .map((c) => c.id)
                )
              }
            />
            <span>{column.label}</span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}

export function TableColumnPicker<Id extends string>({
  inline = false,
  ...props
}: Parameters<typeof TableColumnChoices<Id>>[0] & { inline?: boolean }) {
  if (inline) {
    return (
      <div className="table-column-picker table-column-picker--inline">
        <TableColumnChoices {...props} />
      </div>
    );
  }
  return (
    <details
      className="table-column-picker"
      onKeyDown={(event) => {
        if (event.key === "Escape") {
          event.currentTarget.open = false;
          event.currentTarget.querySelector("summary")?.focus();
        }
      }}
      onBlur={(event) => {
        if (
          event.relatedTarget instanceof Node &&
          !event.currentTarget.contains(event.relatedTarget)
        )
          event.currentTarget.open = false;
      }}
    >
      <summary className="button secondary">
        Oszlopok ({props.selectedIds.length}/{props.columns.length})
      </summary>
      <div className="table-column-panel">
        <p className="helper-text">
          A táblázat oszlopai, balról jobbra. Az export oszlopait külön választhatod ki.
        </p>
        <TableColumnChoices {...props} />
      </div>
    </details>
  );
}

export function TableExportPanel<Id extends string>({
  columns,
  selectedIds,
  onChange,
  visibleIds,
  total,
  orderLabel,
  options,
  onOptions,
  busy,
  disabled,
  status,
  onCsv,
  onPrint,
}: {
  columns: readonly Column<Id>[];
  selectedIds: readonly Id[];
  onChange: (ids: Id[]) => void;
  visibleIds: Id[];
  total: number;
  orderLabel: string;
  options: TablePrintOptions;
  onOptions: (value: TablePrintOptions) => void;
  busy: boolean;
  disabled: boolean;
  status: string;
  onCsv: () => void;
  onPrint: () => void;
}) {
  const [open, setOpen] = useState(false);
  const unavailable = disabled || busy || !selectedIds.length || !total;
  return (
    <div className="table-export">
      <button
        className="button secondary"
        type="button"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
      >
        Export / nyomtatás
      </button>
      {open && (
        <div className="table-export-panel">
          <div className="table-export-heading">
            <div>
              <strong>CSV és PDF export</strong>
              <p className="helper-text">
                Mind a {total.toLocaleString("hu-HU")} szűrt sor · Rendezés: {orderLabel}
              </p>
            </div>
            <button
              className="button small secondary"
              type="button"
              disabled={busy}
              onClick={() => onChange(visibleIds)}
            >
              Megjelenített oszlopok
            </button>
          </div>
          <p className="helper-text">
            A CSV és PDF sorai azonos sorrendben, az oszlopok a lenti sorrendben kerülnek a fájlba.
            A CSV-ben a számok számolhatók, a mértékegység a fejlécben szerepel.
          </p>
          <TableColumnChoices
            columns={columns}
            selectedIds={selectedIds}
            onChange={onChange}
            disabled={busy}
          />
          <TablePrintSettings value={options} onChange={onOptions} />
          <div className="toolbar-group">
            <button className="button" type="button" disabled={unavailable} onClick={onCsv}>
              {busy ? "Export készül…" : "CSV letöltése"}
            </button>
            <button
              className="button secondary"
              type="button"
              disabled={unavailable}
              onClick={onPrint}
            >
              Nyomtatás / PDF
            </button>
            <span className="helper-text">
              {selectedIds.length} / {columns.length} oszlop kiválasztva
            </span>
          </div>
          {!selectedIds.length && (
            <p className="helper-text">Válassz legalább egy oszlopot az exporthoz.</p>
          )}
        </div>
      )}
      <span className="helper-text table-export-status" role="status">
        {status}
      </span>
    </div>
  );
}
