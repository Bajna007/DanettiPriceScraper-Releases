import { useId, type ReactNode } from "react";
import type { TablePrintOptions } from "../products/table-print";
import styles from "./CatalogTableToolbar.module.css";

export type CatalogTableToolbarProps<Id extends string> = {
  columns: readonly { id: Id; label: string }[];
  selectedIds: readonly Id[];
  onSelectionChange: (ids: Id[]) => void;
  fixedIds?: readonly Id[];
  total: number;
  orderLabel?: string;
  printOptions: TablePrintOptions;
  onPrintOptionsChange: (value: TablePrintOptions) => void;
  busy: boolean;
  disabled: boolean;
  status: ReactNode;
  onCsv: () => void;
  onPrint: () => void;
  pagination?: ReactNode;
  children?: ReactNode;
};

export function CatalogTableToolbar<Id extends string>({
  columns,
  selectedIds,
  onSelectionChange,
  fixedIds = [],
  total,
  orderLabel,
  printOptions,
  onPrintOptionsChange,
  busy,
  disabled,
  status,
  onCsv,
  onPrint,
  pagination,
  children,
}: CatalogTableToolbarProps<Id>) {
  const id = useId();
  const selected = columns.filter(
    (column) => selectedIds.includes(column.id) || fixedIds.includes(column.id)
  );
  const unavailable = disabled || busy || !selected.length || !total;

  return (
    <div className={`catalog-table-toolbar ${styles.toolbar}`}>
      <div className={styles.actionRow}>
        <div className={styles.pagination}>
          {pagination ?? <strong>{total.toLocaleString("hu-HU")} találat</strong>}
        </div>
        <div className={styles.actions} role="group" aria-label="Export, import és nyomtatás">
          <button
            className={`button ${styles.action}`}
            type="button"
            disabled={unavailable}
            onClick={onCsv}
          >
            CSV letöltése
          </button>
          <button
            className={`button secondary ${styles.action}`}
            type="button"
            disabled={unavailable}
            onClick={onPrint}
          >
            Nyomtatás / PDF
          </button>
          {children}
        </div>
      </div>
      <p className={styles.exportScope}>
        CSV és PDF: mind a {total.toLocaleString("hu-HU")} szűrt sor, a táblázat oszlopaival.
        {orderLabel ? <span>Jelenlegi sorrend: {orderLabel}.</span> : null}
      </p>
      <div className={styles.status} role="status" aria-live="polite">
        {busy && !status ? "Export előkészítése…" : status}
      </div>

      <details
        className={styles.settings}
        onKeyDown={(event) => {
          if (event.key === "Escape" && event.currentTarget.open) {
            event.preventDefault();
            event.currentTarget.open = false;
            event.currentTarget.querySelector("summary")?.focus();
          }
        }}
      >
        <summary className={styles.summary}>
          <span>Oszlopok és nyomtatás</span>
          <span className={styles.count}>
            {selected.length} / {columns.length} oszlop
          </span>
          <svg
            className={styles.chevron}
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            aria-hidden="true"
          >
            <path d="m4 6 4 4 4-4" stroke="currentColor" strokeWidth="1.7" />
          </svg>
        </summary>
        <div className={styles.panel}>
          <fieldset
            className={styles.columnSettings}
            aria-label="Oszlopok kiválasztása"
            disabled={busy}
          >
            <legend>Oszlopok a táblázatban, CSV-ben és PDF-ben</legend>
            <div className={styles.selectionActions}>
              <button
                className={styles.textButton}
                type="button"
                onClick={() => onSelectionChange(columns.map((column) => column.id))}
              >
                Összes oszlop
              </button>
              <button
                className={styles.textButton}
                type="button"
                onClick={() =>
                  onSelectionChange(
                    columns
                      .filter((column) => fixedIds.includes(column.id))
                      .map((column) => column.id)
                  )
                }
              >
                {fixedIds.length ? "Csak azonosítók" : "Kijelölés törlése"}
              </button>
            </div>
            <div className={styles.columnGrid}>
              {columns.map((column) => (
                <label className={styles.columnChoice} key={column.id}>
                  <input
                    type="checkbox"
                    checked={selected.some((item) => item.id === column.id)}
                    disabled={fixedIds.includes(column.id)}
                    onChange={(event) =>
                      onSelectionChange(
                        columns
                          .filter(
                            (item) =>
                              fixedIds.includes(item.id) ||
                              (item.id === column.id
                                ? event.target.checked
                                : selectedIds.includes(item.id))
                          )
                          .map((item) => item.id)
                      )
                    }
                  />
                  <span>{column.label}</span>
                </label>
              ))}
            </div>
            {!selected.length ? (
              <p className={styles.note}>Válassz legalább egy oszlopot az exporthoz.</p>
            ) : null}
          </fieldset>

          <div className={styles.printSettings}>
            <fieldset className={styles.printGroup} disabled={busy}>
              <legend>Papírméret</legend>
              <div className={styles.segments}>
                {(["A4", "A3"] as const).map((paper) => (
                  <label className={styles.segment} key={paper}>
                    <input
                      type="radio"
                      name={`${id}-paper`}
                      value={paper}
                      checked={printOptions.paper === paper}
                      onChange={() => onPrintOptionsChange({ ...printOptions, paper })}
                    />
                    <span>{paper} fekvő</span>
                  </label>
                ))}
              </div>
            </fieldset>
            <fieldset className={styles.printGroup} disabled={busy}>
              <legend>PDF elrendezés</legend>
              <div className={styles.layoutChoices}>
                <label className={styles.segment}>
                  <input
                    type="radio"
                    name={`${id}-layout`}
                    value="columns"
                    checked={printOptions.layout === "columns"}
                    onChange={() => onPrintOptionsChange({ ...printOptions, layout: "columns" })}
                  />
                  <span>Oszlopcsoportok több lapon</span>
                </label>
                <label className={styles.segment}>
                  <input
                    type="radio"
                    name={`${id}-layout`}
                    value="records"
                    checked={printOptions.layout === "records"}
                    onChange={() => onPrintOptionsChange({ ...printOptions, layout: "records" })}
                  />
                  <span>Termékenkénti adatlap</span>
                </label>
              </div>
            </fieldset>
            <p className={styles.note}>
              Sok oszlop több lapra kerül, ismételt termékazonosítókkal és olvasható betűmérettel.
            </p>
          </div>
        </div>
      </details>
    </div>
  );
}
