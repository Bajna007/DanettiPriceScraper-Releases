"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef } from "react";

const navItems = [
  { href: "/", label: "Áttekintés" },
  { href: "/csv-import", label: "CSV import" },
  { href: "/products", label: "Termékek" },
  { href: "/supplier-price-changes", label: "Árváltozások" },
  { href: "/operator/dvg", label: "DVG operátor" },
  { href: "/dvg-diagrams", label: "DVG Robbantott ábrák" },
  { href: "/operator/lf", label: "LF operátor" },
  { href: "/labels/utopia", label: "Utopia címke" },
  { href: "/labels/bean-on", label: "Bean On címke" },
  { href: "/labels/custom", label: "Egyedi címkék" },
  { href: "/epr", label: "EPR" },
];

export function Navigation() {
  const pathname = usePathname();
  const navigation = useRef<HTMLElement>(null);

  useEffect(() => {
    const container = navigation.current;
    if (!container) return;
    const revealCurrent = () => {
      const current = container.querySelector<HTMLElement>('[aria-current="page"]');
      if (!current) return;
      const bounds = container.getBoundingClientRect();
      const item = current.getBoundingClientRect();
      if (item.left < bounds.left || item.right > bounds.right) {
        container.scrollBy({
          left: item.left - bounds.left - (bounds.width - item.width) / 2,
          behavior: "instant",
        });
      }
    };
    revealCurrent();
    const observer = new ResizeObserver(revealCurrent);
    observer.observe(container);
    return () => observer.disconnect();
  }, [pathname]);

  return (
    <nav className="app-nav" ref={navigation} aria-label="Fő navigáció">
      {navItems.map((item) => {
        const isActive =
          pathname === item.href || (item.href !== "/" && pathname.startsWith(`${item.href}/`));
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`nav-link${isActive ? " active" : ""}`}
            aria-current={isActive ? "page" : undefined}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
