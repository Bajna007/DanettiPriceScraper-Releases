:HL["/_next/static/chunks/39w860ykfbt2-.css","style"]
:HL["/_next/static/chunks/2vo7ga3__l6-v.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"epr","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"Sudt-4Szrb-RejQ8ugmD7"}
