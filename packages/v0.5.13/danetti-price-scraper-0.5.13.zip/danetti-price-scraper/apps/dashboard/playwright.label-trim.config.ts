import { defineConfig } from "@playwright/test";

// Fixture-only browser proof; API requests are fulfilled without database writes.
export default defineConfig({
  testDir: "./e2e",
  testMatch: "label-trim-boundary.spec.ts",
  workers: 1,
  retries: 0,
  timeout: 60_000,
  expect: { timeout: 15_000 },
  use: {
    baseURL: process.env.LABEL_TRIM_URL ?? "http://localhost:3017",
    trace: "retain-on-failure",
  },
});
