"use client";

import { readWooSkuArticleCandidates } from "@danetti/shared";
import { useDeferredValue, useEffect, useMemo, useRef, useState } from "react";
import {
  createSupplierMapping,
  exportLocalDatabaseBackup,
  formatApiErrorMessage,
  getPricingSettings,
  importLocalDatabaseBackup,
  listProducts,
  listSupplierMappings,
  listSuppliers,
  patchCatalogProduct,
  patchSupplierMapping,
  saveEurHufRate,
  searchExactLfProduct,
  type CatalogProductUpdateInput,
  type CatalogProduct,
  type ProductCalculabilityFilter,
  type PaginatedResponse,
  type ProductListParams,
  type ProductProfitBandMode,
  type ProductSortBy,
  type SupplierPriceChangeRoundingMode,
  type ProductWorklistView,
  type PricingSettingsCurrentResponse,
  type Supplier,
  type SupplierMapping,
} from "../../src/lib/api";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import { ColumnResizer, SortButton, useColumnResize } from "../../src/components/SheetHeader";
import { TablePagination } from "../../src/components/TablePagination";
import { CatalogTableToolbar } from "../../src/components/CatalogTableToolbar";
import { formatDate } from "../../src/lib/formatters";
import {
  PRODUCT_CSV_EXPORT_PAGE_SIZE,
  buildFilteredProductsCsvText,
  buildFilteredProductsPrintText,
  calculateLiveProductPricing,
  isLfSupplier,
  labelSupplierProductStatus,
  productColumns,
  readSupplierArticleNumber,
  readSupplierPricingView,
  supplierProductStatusTone,
  type ProductColumn,
  type ProductColumnId,
  type ProductTargetPricingSettings,
} from "../../src/products/csv";

import { defaultTablePrintOptions } from "../../src/products/table-print";
import "./products.css";

const DEFAULT_LIMIT = 50;
const MAPPING_PAGE_SIZE = 200;
const PRODUCT_CONTROL_STORAGE_KEY = "danetti:products:controls";
const PRODUCT_AUTO_REFRESH_MS = 10_000;
const PRODUCT_FOCUS_REFRESH_MIN_MS = 3_000;
const DEFAULT_TARGET_PROFIT_MIN_PERCENT = 20;
const DEFAULT_TARGET_PROFIT_MAX_PERCENT = 60;
const DEFAULT_VAT_PERCENT = 27;
const DEFAULT_ROUNDING_INCREMENT_HUF = 100;

type ProductEditableField = keyof CatalogProductUpdateInput;

type ProductRowEdit = Partial<Record<ProductEditableField, string>> & {
  supplierId?: string;
  supplierArticleNumber?: string;
  directUrl?: string;
};

const editableProductFields: ProductEditableField[] = [
  "sku",
  "name",
  "suggestedSupplierArticle",
  "internalSkuSuffix",
  "currentPrice",
  "regularPrice",
  "salePrice",
  "dvgPurchasePriceEur",
  "dvgPurchasePriceHuf",
  "dvgWooGrossHuf",
  "dvgWooNetHuf",
  "dvgProfitNetHuf",
  "dvgProfitPercent",
  "dvgSupplierArticleNumber",
  "lfPurchasePriceEur",
  "lfPurchasePriceHuf",
  "lfWooGrossHuf",
  "lfWooNetHuf",
  "lfProfitNetHuf",
  "lfProfitPercent",
  "lfSupplierArticleNumber",
];

const defaultColumnWidths = productColumns.reduce(
  (widths, column) => ({ ...widths, [column.id]: column.width }),
  {} as Record<ProductColumnId, number>
);

const productSortByColumn: Partial<Record<ProductColumnId, ProductSortBy>> = {
  supplier: "supplier",
  supplierArticle: "supplierArticle",
  url: "url",
  targetWooGross: "targetWooGross",
  dvgSupplierArticle: "dvgSupplierArticle",
  dvgWooGross: "dvgWooGross",
  currentPrice: "currentPrice",
  sku: "sku",
  name: "name",
  dvgPurchaseEur: "dvgPurchaseEur",
  dvgPurchaseHuf: "dvgPurchaseHuf",
  dvgWooNet: "dvgWooNet",
  dvgProfitHuf: "dvgProfitHuf",
  dvgProfitPercent: "dvgProfitPercent",
  dvgUpdated: "dvgUpdated",
  dvgStatus: "dvgStatus",
  suggestedArticle: "suggestedArticle",
  suffix: "suffix",
  regularPrice: "regularPrice",
  salePrice: "salePrice",
  lastSeen: "lastSeen",
};

type ProductFilters = {
  search: string;
  sortBy: ProductSortBy;
  sortDirection: "asc" | "desc";
  supplierId: "all" | "none" | string;
  articleStructure: "all" | "single" | "multiple";
  worklistView: "all" | ProductWorklistView;
  profitBandMode: "all" | ProductProfitBandMode;
  profitBandMinPercent: number | "";
  profitBandMaxPercent: number | "";
  calculability: "all" | ProductCalculabilityFilter;
  minProfitPercent: number | "";
  maxProfitPercent: number | "";
  minProfitHuf: number | "";
  maxProfitHuf: number | "";
  minDvgPurchaseHuf: number | "";
  maxDvgPurchaseHuf: number | "";
  minWooNetHuf: number | "";
  maxWooNetHuf: number | "";
  minRegularPrice: number | "";
  maxRegularPrice: number | "";
  hasDvgPrice: "all" | "yes" | "no";
  unifiedStatus: "all" | string;
};

type ProductControls = {
  limit: number;
  offset: number;
  vatPercent: number | "";
  targetProfitMultiplier: number | "";
  roundingEnabled: boolean;
  roundingIncrementHuf: number | "";
  roundingMode: SupplierPriceChangeRoundingMode;
  filters: ProductFilters;
  columnVisibility: Record<ProductColumnId, boolean>;
  columnWidths: Record<ProductColumnId, number>;
};

const defaultProductFilters: ProductFilters = {
  search: "",
  sortBy: "dvgProfitPercent",
  sortDirection: "asc",
  supplierId: "all",
  articleStructure: "all",
  worklistView: "all",
  profitBandMode: "all",
  profitBandMinPercent: DEFAULT_TARGET_PROFIT_MIN_PERCENT,
  profitBandMaxPercent: DEFAULT_TARGET_PROFIT_MAX_PERCENT,
  calculability: "all",
  minProfitPercent: "",
  maxProfitPercent: "",
  minProfitHuf: "",
  maxProfitHuf: "",
  minDvgPurchaseHuf: "",
  maxDvgPurchaseHuf: "",
  minWooNetHuf: "",
  maxWooNetHuf: "",
  minRegularPrice: "",
  maxRegularPrice: "",
  hasDvgPrice: "all",
  unifiedStatus: "all",
};

const sortOptions: Array<{ value: ProductSortBy; label: string }> = [
  { value: "suffix", label: "Belső utótag" },
  { value: "suggestedArticle", label: "Javasolt cikkszám" },
  { value: "currentPrice", label: "Aktuális ár" },
  { value: "dvgWooGross", label: "Woo bruttó" },
  { value: "dvgSupplierArticle", label: "Mentett besz. cikkszám" },
  { value: "targetWooGross", label: "Cél Woo bruttó" },
  { value: "url", label: "Beszállító URL" },
  { value: "supplierArticle", label: "Beszállítói cikkszám" },
  { value: "supplier", label: "Beszállító" },
  { value: "dvgProfitPercent", label: "Profit %" },
  { value: "dvgStatus", label: "Ár státusz" },
  { value: "dvgProfitHuf", label: "Profit HUF" },
  { value: "dvgPurchaseHuf", label: "Beszállító HUF" },
  { value: "dvgPurchaseEur", label: "Beszállító EUR" },
  { value: "dvgWooNet", label: "Woo nettó" },
  { value: "dvgUpdated", label: "Ár frissítve" },
  { value: "regularPrice", label: "Normál ár" },
  { value: "salePrice", label: "Akciós ár" },
  { value: "sku", label: "SKU" },
  { value: "name", label: "Név" },
  { value: "lastSeen", label: "Utoljára látva" },
];

const unifiedStatusFilterOptions: Array<{ value: string; label: string }> = [
  { value: "all", label: "Minden státusz" },
  { value: "ok", label: "OK, ár mentve" },
  { value: "not_ok", label: "Minden, ami nem OK" },
  { value: "missing_price", label: "Ár hiányzik" },
  { value: "no_product_page", label: "Nincs termékoldal" },
  { value: "article_changed", label: "Cikkszám változott" },
  { value: "unavailable", label: "Nem rendelhető / kifutott" },
  { value: "not_supplier_own_article", label: "Nem saját LF cikk" },
  { value: "ambiguous_match", label: "Nem egyértelmű találat" },
  { value: "login_required", label: "Login/session hiba" },
  { value: "timeout", label: "Timeout" },
  { value: "failed", label: "Hiba" },
  { value: "safety_stopped", label: "Safety stop" },
  { value: "skipped", label: "Kihagyva" },
  { value: "no_run", label: "Még nem futott" },
];

type ProductQuickViewId =
  | "all"
  | "profit_outside"
  | "missing_or_discontinued"
  | "dvg_faulty_or_not_found"
  | "not_price_paired";

const productQuickViews: Array<{ id: ProductQuickViewId; label: string; help: string }> = [
  { id: "all", label: "Összes termék", help: "Minden termék szűrés nélkül." },
  {
    id: "profit_outside",
    label: "Profit célzott zónán kívül",
    help: "Az alsó határ alatti vagy felső határ feletti profit.",
  },
  {
    id: "missing_or_discontinued",
    label: "Ár hiányzik",
    help: "A beszállítói termékoldal megvan, de nincs olvasható ár.",
  },
  {
    id: "dvg_faulty_or_not_found",
    label: "Nincs termékoldal",
    help: "A beszállítói cikkszám nem nyílik meg termékoldalként.",
  },
  {
    id: "not_price_paired",
    label: "Minden, ami nem OK",
    help: "Nem feltérképezett, hiányzó vagy nem létező; kivéve az OK státuszt.",
  },
];

const profitBandModeOptions: Array<{ value: ProductFilters["profitBandMode"]; label: string }> = [
  { value: "all", label: "Ne szűrjön profit zónára" },
  { value: "outside", label: "Célzónán kívül" },
  { value: "inside", label: "Célzónán belül" },
  { value: "below", label: "Minimum alatt" },
  { value: "above", label: "Maximum felett" },
];

const defaultColumnVisibility = productColumns.reduce(
  (visibility, column) => ({ ...visibility, [column.id]: true }),
  {} as Record<ProductColumnId, boolean>
);

const fixedProductColumnIds = new Set<ProductColumnId>(["sku", "name", "actions"]);
const selectableProductColumns = productColumns.filter((column) => column.id !== "actions");

export default function ProductsPage() {
  const [initialControls] = useState(readStoredProductControls);
  const [limit, setLimit] = useState(initialControls.limit);
  const [offset, setOffset] = useState(initialControls.offset);
  const [filters, setFilters] = useState<ProductFilters>(initialControls.filters);
  const deferredSearch = useDeferredValue(filters.search);
  const [columnVisibility, setColumnVisibility] = useState(initialControls.columnVisibility);
  const [pricingSettings, setPricingSettings] = useState<PricingSettingsCurrentResponse | null>(
    null
  );
  const [eurHufRate, setEurHufRate] = useState<number | "">("");
  const [vatPercent, setVatPercent] = useState<number | "">(initialControls.vatPercent);
  const [targetProfitMultiplier, setTargetProfitMultiplier] = useState<number | "">(
    initialControls.targetProfitMultiplier
  );
  const [roundingEnabled, setRoundingEnabled] = useState(initialControls.roundingEnabled);
  const [roundingIncrementHuf, setRoundingIncrementHuf] = useState<number | "">(
    initialControls.roundingIncrementHuf
  );
  const [roundingMode, setRoundingMode] = useState<SupplierPriceChangeRoundingMode>(
    initialControls.roundingMode
  );
  const [rateSaveStatus, setRateSaveStatus] = useState<"saved" | "saving" | "error" | null>(null);
  const [data, setData] = useState<PaginatedResponse<CatalogProduct> | null>(null);
  const [productRefreshStatus, setProductRefreshStatus] = useState<"idle" | "refreshing" | "error">(
    "idle"
  );
  const [productRefreshError, setProductRefreshError] = useState<string | null>(null);
  const [lastProductRefreshAt, setLastProductRefreshAt] = useState<string | null>(null);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [mappings, setMappings] = useState<SupplierMapping[]>([]);
  const [edits, setEdits] = useState<Record<string, ProductRowEdit>>({});
  const [rowMessages, setRowMessages] = useState<Record<string, string>>({});
  const [savingProductId, setSavingProductId] = useState<string | null>(null);
  const [databaseTransferStatus, setDatabaseTransferStatus] = useState<
    "idle" | "exporting" | "importing" | "success" | "error"
  >("idle");
  const [databaseTransferMessage, setDatabaseTransferMessage] = useState<string | null>(null);
  const [csvExportStatus, setCsvExportStatus] = useState<
    "idle" | "exporting" | "success" | "error"
  >("idle");
  const [csvExportMessage, setCsvExportMessage] = useState<string | null>(null);
  const [printOptions, setPrintOptions] = useState(defaultTablePrintOptions);
  const [printing, setPrinting] = useState(false);
  const [printMessage, setPrintMessage] = useState("");
  const [columnWidths, setColumnWidths] = useState(initialControls.columnWidths);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const databaseImportInputRef = useRef<HTMLInputElement | null>(null);
  const productRefreshRequestRef = useRef(0);
  const productRefreshInFlightRef = useRef(false);
  const lastProductRefreshStartedAtRef = useRef(0);
  const savingProductIdRef = useRef<string | null>(savingProductId);
  savingProductIdRef.current = savingProductId;

  const canGoBack = offset > 0;
  const canGoNext =
    data?.total !== undefined ? offset + (data?.items.length ?? 0) < data.total : false;
  const activeMappingByProductId = useMemo(() => buildActiveMappingIndex(mappings), [mappings]);
  const activeRate = readOptionalNumber(eurHufRate);
  const activeVatPercent = readVatPercent(vatPercent);
  const activeTargetProfitMultiplier = readOptionalMultiplier(targetProfitMultiplier);
  const activeRoundingIncrementHuf = readRoundingIncrementHuf(roundingIncrementHuf);
  const activeTargetPricing = useMemo(
    () => ({
      targetProfitMultiplier: activeTargetProfitMultiplier,
      roundingEnabled,
      roundingIncrementHuf: activeRoundingIncrementHuf,
      roundingMode,
    }),
    [activeRoundingIncrementHuf, activeTargetProfitMultiplier, roundingEnabled, roundingMode]
  );
  const effectiveFilters = useMemo(
    () => ({ ...filters, search: deferredSearch }),
    [deferredSearch, filters]
  );
  const productListParams = useMemo<ProductListParams>(
    () => ({
      limit,
      offset,
      ...toProductListParams(effectiveFilters),
      eurHufRate: activeRate ?? undefined,
      vatPercent: activeVatPercent,
      targetProfitMultiplier: activeTargetPricing.targetProfitMultiplier ?? undefined,
      roundingEnabled: activeTargetPricing.roundingEnabled,
      roundingIncrementHuf: activeTargetPricing.roundingIncrementHuf,
      roundingMode: activeTargetPricing.roundingMode,
    }),
    [activeRate, activeVatPercent, activeTargetPricing, effectiveFilters, limit, offset]
  );
  const productListParamsRef = useRef(productListParams);
  productListParamsRef.current = productListParams;
  const activeFilterCount = useMemo(() => countActiveFilters(filters), [filters]);
  const activeFilterChips = useMemo(
    () => buildActiveFilterChips(filters, suppliers),
    [filters, suppliers]
  );
  const visibleProductColumns = useMemo(
    () => productColumns.filter((column) => columnVisibility[column.id] !== false),
    [columnVisibility]
  );
  const exportProductColumns = visibleProductColumns.filter((column) => column.id !== "actions");
  const exportColumnIds = exportProductColumns.map((column) => column.id);
  const totalTableWidth = useMemo(
    () => visibleProductColumns.reduce((total, column) => total + columnWidths[column.id], 0),
    [columnWidths, visibleProductColumns]
  );

  const paginationLabel = useMemo(() => {
    const total = data?.total;
    if (!total && total !== 0) {
      return `Megjelenítve: ${offset + 1}-${offset + limit}`;
    }
    const start = total === 0 ? 0 : offset + 1;
    const end = Math.min(offset + limit, total);
    return `Megjelenítve: ${start}-${end} / ${total}`;
  }, [data?.total, limit, offset]);
  const csvExportTotal = data?.total ?? 0;
  const exportBusy = printing || csvExportStatus === "exporting";
  const exportUnavailable =
    exportBusy ||
    loading ||
    filters.search !== deferredSearch ||
    !exportColumnIds.length ||
    !csvExportTotal;
  const csvExportStatusLabel = useMemo(() => {
    if (csvExportStatus === "exporting") {
      return `CSV készül: ${csvExportTotal.toLocaleString("hu-HU")} találat`;
    }
    if (csvExportMessage) return csvExportMessage;
    return "";
  }, [csvExportMessage, csvExportStatus, csvExportTotal]);
  const productRefreshLabel = useMemo(() => {
    if (productRefreshStatus === "refreshing") return "Termékadatok frissítése...";
    if (productRefreshStatus === "error") {
      return productRefreshError ? `Frissítési hiba: ${productRefreshError}` : "Frissítési hiba";
    }
    if (lastProductRefreshAt)
      return `Beszállítói ár adatok frissítve: ${formatDate(lastProductRefreshAt)}`;
    return "Beszállítói ár adatok automatikusan frissülnek";
  }, [lastProductRefreshAt, productRefreshError, productRefreshStatus]);

  useEffect(() => {
    storeProductControls({
      limit,
      offset,
      vatPercent,
      targetProfitMultiplier,
      roundingEnabled,
      roundingIncrementHuf,
      roundingMode,
      filters,
      columnVisibility,
      columnWidths,
    });
  }, [
    columnVisibility,
    columnWidths,
    filters,
    limit,
    offset,
    roundingEnabled,
    roundingIncrementHuf,
    roundingMode,
    targetProfitMultiplier,
    vatPercent,
  ]);

  useEffect(() => {
    if (!data) return;
    const total = data.total;
    if (total === undefined) return;
    if (total === 0 && offset !== 0) {
      setOffset(0);
      return;
    }
    if (total > 0 && offset >= total) {
      setOffset(Math.floor((total - 1) / limit) * limit);
    }
  }, [data, limit, offset]);

  useEffect(() => {
    let active = true;

    Promise.all([
      listSuppliers({ limit: 100, offset: 0 }),
      listAllSupplierMappings(),
      getPricingSettings(),
    ])
      .then(([supplierResponse, mappingItems, pricing]) => {
        if (!active) return;
        setSuppliers(supplierResponse.items ?? []);
        setMappings(mappingItems);
        setPricingSettings(pricing);
        const pricingRate = pricing.eurHufRate;
        if (pricingRate !== null) {
          setEurHufRate((current) => (current === "" ? pricingRate : current));
        }
      })
      .catch((err) => {
        if (active) setError(formatApiErrorMessage(err));
      });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;
    const requestId = ++productRefreshRequestRef.current;
    productRefreshInFlightRef.current = true;
    lastProductRefreshStartedAtRef.current = Date.now();
    setLoading(true);
    setError(null);
    setProductRefreshStatus("refreshing");
    setProductRefreshError(null);

    listProducts(productListParams)
      .then((productResponse) => {
        if (!active || requestId !== productRefreshRequestRef.current) return;
        setData(productResponse);
        setLastProductRefreshAt(new Date().toISOString());
        setProductRefreshStatus("idle");
        setProductRefreshError(null);
      })
      .catch((err) => {
        if (!active || requestId !== productRefreshRequestRef.current) return;
        const message = formatApiErrorMessage(err);
        setError(message);
        setProductRefreshError(message);
        setProductRefreshStatus("error");
      })
      .finally(() => {
        if (!active || requestId !== productRefreshRequestRef.current) return;
        productRefreshInFlightRef.current = false;
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [productListParams]);

  useEffect(() => {
    function refreshVisibleProducts() {
      if (document.visibilityState !== "visible") return;
      if (Date.now() - lastProductRefreshStartedAtRef.current < PRODUCT_FOCUS_REFRESH_MIN_MS)
        return;
      void refreshProducts();
    }

    const interval = window.setInterval(refreshVisibleProducts, PRODUCT_AUTO_REFRESH_MS);
    window.addEventListener("focus", refreshVisibleProducts);
    document.addEventListener("visibilitychange", refreshVisibleProducts);

    return () => {
      window.clearInterval(interval);
      window.removeEventListener("focus", refreshVisibleProducts);
      document.removeEventListener("visibilitychange", refreshVisibleProducts);
    };
  }, []);

  useEffect(() => {
    const rate = readOptionalNumber(eurHufRate);
    if (rate === null) return;
    if (pricingSettings?.eurHufRate === rate) return;
    const timer = window.setTimeout(() => {
      setRateSaveStatus("saving");
      saveEurHufRate({ eurHufRate: rate })
        .then((next) => {
          setPricingSettings(next);
          setRateSaveStatus("saved");
        })
        .catch(() => setRateSaveStatus("error"));
    }, 700);
    return () => window.clearTimeout(timer);
  }, [eurHufRate, pricingSettings?.eurHufRate]);

  async function refreshMappings() {
    setMappings(await listAllSupplierMappings());
  }

  async function refreshProducts() {
    if (productRefreshInFlightRef.current) return;
    if (savingProductIdRef.current !== null) return;

    const requestId = ++productRefreshRequestRef.current;
    productRefreshInFlightRef.current = true;
    lastProductRefreshStartedAtRef.current = Date.now();
    setProductRefreshStatus("refreshing");
    setProductRefreshError(null);

    try {
      const productResponse = await listProducts(productListParamsRef.current);
      if (requestId !== productRefreshRequestRef.current) return;
      setData(productResponse);
      setLastProductRefreshAt(new Date().toISOString());
      setProductRefreshStatus("idle");
      setProductRefreshError(null);
      setError(null);
    } catch (err) {
      if (requestId !== productRefreshRequestRef.current) return;
      setProductRefreshError(formatApiErrorMessage(err));
      setProductRefreshStatus("error");
    } finally {
      if (requestId === productRefreshRequestRef.current) {
        productRefreshInFlightRef.current = false;
      }
    }
  }

  async function handleDatabaseExport() {
    setDatabaseTransferStatus("exporting");
    setDatabaseTransferMessage("Teljes helyi adatbázis mentése készül...");
    setError(null);
    try {
      const backup = await exportLocalDatabaseBackup();
      const url = URL.createObjectURL(backup.blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = backup.filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      setDatabaseTransferStatus("success");
      setDatabaseTransferMessage(`Backup letöltve: ${backup.filename}`);
    } catch (err) {
      const message = formatApiErrorMessage(err);
      setDatabaseTransferStatus("error");
      setDatabaseTransferMessage(message);
      setError(message);
    }
  }

  function openDatabaseImportPicker() {
    databaseImportInputRef.current?.click();
  }

  async function handleDatabaseImportFile(file: File | null) {
    if (!file) return;
    const confirmed = window.confirm(
      "A teljes helyi Danetti adatbázist visszaállítod ebből a backupból. A jelenlegi termékek, mappingek, árfigyelő előzmények és operátor állapotok felülíródnak. Folytatod?"
    );
    if (!confirmed) return;

    setDatabaseTransferStatus("importing");
    setDatabaseTransferMessage("Teljes helyi adatbázis visszaállítása...");
    setError(null);
    try {
      const result = await importLocalDatabaseBackup(file);
      setDatabaseTransferStatus("success");
      setDatabaseTransferMessage(
        `Backup import kész: ${result.tableCount} tábla, ${result.rowCount} sor.`
      );
      setOffset(0);
      const [supplierResponse, mappingItems, pricing, productResponse] = await Promise.all([
        listSuppliers({ limit: 100, offset: 0 }),
        listAllSupplierMappings(),
        getPricingSettings(),
        listProducts({ ...productListParamsRef.current, offset: 0 }),
      ]);
      setSuppliers(supplierResponse.items ?? []);
      setMappings(mappingItems);
      setPricingSettings(pricing);
      setData(productResponse);
      setLastProductRefreshAt(new Date().toISOString());
      setProductRefreshStatus("idle");
      setProductRefreshError(null);
    } catch (err) {
      const message = formatApiErrorMessage(err);
      setDatabaseTransferStatus("error");
      setDatabaseTransferMessage(message);
      setError(message);
    }
  }

  async function handleFilteredCsvExport() {
    if (csvExportStatus === "exporting" || csvExportTotal === 0) return;
    setCsvExportStatus("exporting");
    setCsvExportMessage(null);
    setError(null);

    try {
      const products = await listAllFilteredProductsForCsv(productListParamsRef.current);
      if (products.length === 0) {
        setCsvExportStatus("success");
        setCsvExportMessage("CSV: nincs letölthető találat.");
        return;
      }
      downloadFilteredProductsCsv({
        products,
        visibleColumns: exportProductColumns,
        activeMappingByProductId,
        suppliers,
        eurHufRate: activeRate,
        vatPercent: activeVatPercent,
        targetPricing: activeTargetPricing,
      });
      setCsvExportStatus("success");
      setCsvExportMessage(`CSV letöltve: ${products.length.toLocaleString("hu-HU")} találat.`);
    } catch (err) {
      const message = formatApiErrorMessage(err);
      setCsvExportStatus("error");
      setCsvExportMessage(`CSV export hiba: ${message}`);
      setError(message);
    }
  }

  function updateRowEdit(productId: string, patch: ProductRowEdit) {
    setEdits((current) => ({
      ...current,
      [productId]: { ...current[productId], ...patch },
    }));
    setRowMessages((current) => removeRecordKey(current, productId));
  }

  function updateFilters(patch: Partial<ProductFilters>) {
    setOffset(0);
    setFilters((current) => ({ ...current, ...patch }));
  }

  function resetFilters() {
    setOffset(0);
    setFilters(defaultProductFilters);
  }

  function applyQuickView(viewId: ProductQuickViewId) {
    setOffset(0);
    setFilters((current) => applyProductQuickView(current, viewId));
  }

  function applyStatusFilter(status: string) {
    setOffset(0);
    setFilters((current) => ({
      ...current,
      unifiedStatus: status,
      worklistView: "all",
      calculability: "all",
      hasDvgPrice: "all",
      minProfitPercent: "",
      maxProfitPercent: "",
      minProfitHuf: "",
      maxProfitHuf: "",
      minDvgPurchaseHuf: "",
      maxDvgPurchaseHuf: "",
      minWooNetHuf: "",
      maxWooNetHuf: "",
      minRegularPrice: "",
      maxRegularPrice: "",
    }));
  }

  async function handleProductPrint() {
    if (printing || csvExportTotal === 0) return;
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      setPrintMessage("Engedélyezd a felugró ablakot a nyomtatáshoz.");
      return;
    }
    printWindow.document.body.textContent = "Nyomtatás előkészítése…";
    setPrinting(true);
    setPrintMessage("Az összes szűrt termék betöltése…");
    try {
      const products = await listAllFilteredProductsForCsv(productListParamsRef.current);
      printWindow.document.open();
      printWindow.document.write(
        buildFilteredProductsPrintText(
          {
            products,
            visibleColumns: exportProductColumns,
            activeMappingByProductId,
            suppliers,
            eurHufRate: activeRate,
            vatPercent: activeVatPercent,
            targetPricing: activeTargetPricing,
          },
          printOptions
        )
      );
      printWindow.document.close();
      await printWindow.document.fonts.ready;
      printWindow.focus();
      printWindow.print();
      setPrintMessage(`${products.length} termék nyomtatásra előkészítve.`);
    } catch (error) {
      printWindow.close();
      setPrintMessage(formatApiErrorMessage(error));
    } finally {
      setPrinting(false);
    }
  }

  function toggleSort(columnId: ProductColumnId) {
    const sortBy = productSortByColumn[columnId];
    if (!sortBy) return;
    setOffset(0);
    setFilters((current) => ({
      ...current,
      sortBy,
      sortDirection: current.sortBy === sortBy && current.sortDirection === "asc" ? "desc" : "asc",
    }));
  }

  const beginColumnResize = useColumnResize(columnWidths, setColumnWidths, productColumns);

  async function saveProductRow(product: CatalogProduct) {
    const activeMapping = activeMappingByProductId.get(product.id) ?? null;
    const edit = edits[product.id] ?? {};
    const productPatch = buildProductUpdateInput(product, edit);
    const hasProductPatch = Object.keys(productPatch).length > 0;
    const hasMappingPatch =
      edit.supplierId !== undefined ||
      edit.supplierArticleNumber !== undefined ||
      edit.directUrl !== undefined;
    const supplierId = edit?.supplierId ?? activeMapping?.supplierId ?? "";
    const selectedSupplier = suppliers.find((supplier) => supplier.id === supplierId) ?? null;
    const selectedMapping = supplierId
      ? findMappingForProductSupplier(mappings, product.id, supplierId)
      : null;
    const initialDirectUrl = isLfSupplier(selectedSupplier)
      ? null
      : emptyToNull(edit?.directUrl ?? selectedMapping?.directUrl ?? "");

    if (!hasProductPatch && !hasMappingPatch) {
      setEdits((current) => removeRecordKey(current, product.id));
      setRowMessages((current) => ({ ...current, [product.id]: "Nincs változás" }));
      return;
    }
    if (hasMappingPatch && !supplierId) {
      setError("Válassz beszállítót a termékhez mentés előtt.");
      return;
    }

    setSavingProductId(product.id);
    setError(null);
    try {
      let nextProduct = product;
      if (hasProductPatch) {
        nextProduct = await patchCatalogProduct(product.id, productPatch);
        setData((current) =>
          current
            ? {
                ...current,
                items: current.items.map((item) =>
                  item.id === nextProduct.id ? nextProduct : item
                ),
              }
            : current
        );
      }

      if (hasMappingPatch) {
        const supplierArticleNumber = readSupplierArticleNumber(
          nextProduct,
          selectedMapping,
          selectedSupplier,
          edit
        );
        if (!supplierArticleNumber) {
          setError("Nincs menthető beszállítói cikkszám ehhez a termékhez.");
          return;
        }

        let verifiedSupplierArticleNumber = supplierArticleNumber;
        let mappingDirectUrl = initialDirectUrl;
        let lookupStrategy: SupplierMapping["lookupStrategy"] = initialDirectUrl
          ? "direct_url"
          : "search_result";
        let notes: string | null | undefined;

        if (isLfSupplier(selectedSupplier)) {
          setRowMessages((current) => ({ ...current, [product.id]: "LF exact keresés..." }));
          const exactSearch = await searchExactLfProduct({ supplierArticleNumber });
          if (!exactSearch.accepted || !exactSearch.supplierArticleNumber) {
            setError(labelLfExactSearchFailure(exactSearch.outcome));
            return;
          }
          if (!exactSearch.lfFinalUrl) {
            setError("LF exact keresés igazolta a találatot, de nem adott menthető detail URL-t.");
            return;
          }
          verifiedSupplierArticleNumber = exactSearch.supplierArticleNumber;
          mappingDirectUrl = exactSearch.lfFinalUrl;
          lookupStrategy = "search_then_detail";
          notes = `LF exact-search verified via ${exactSearch.lfAutocompleteId ?? verifiedSupplierArticleNumber}; detail URL observed.`;
        }

        let targetMapping = selectedMapping;

        if (targetMapping) {
          await patchSupplierMapping(targetMapping.id, {
            supplierArticleNumber: verifiedSupplierArticleNumber,
            lookupStrategy,
            directUrl: mappingDirectUrl,
            notes,
            enabled: true,
            isPrimary: true,
          });
        } else {
          targetMapping = await createSupplierMapping({
            catalogProductId: product.id,
            supplierId,
            supplierArticleNumber: verifiedSupplierArticleNumber,
            lookupStrategy,
            directUrl: mappingDirectUrl,
            notes,
            enabled: true,
            isPrimary: true,
          });
        }

        if (
          activeMapping &&
          activeMapping.supplierId === supplierId &&
          targetMapping.id !== activeMapping.id
        ) {
          await patchSupplierMapping(activeMapping.id, { enabled: false, isPrimary: false });
        }

        await refreshMappings();
      }

      setEdits((current) => removeRecordKey(current, product.id));
      setRowMessages((current) => ({ ...current, [product.id]: "Mentve" }));
    } catch (err) {
      setError(formatApiErrorMessage(err));
    } finally {
      setSavingProductId(null);
    }
  }

  return (
    <div className="page products-page">
      <div className="page-header">
        <h1 className="page-title">Termékek</h1>
      </div>

      <section
        className="card product-control-deck catalog-controls"
        aria-labelledby="product-controls-title"
      >
        <div className="product-control-header">
          <div>
            <h2 id="product-controls-title">Terméklista vezérlőpult</h2>
            <span>Keresés és szűrés a teljes katalógusban.</span>
          </div>
          <button
            className="button secondary product-filter-reset"
            type="button"
            onClick={resetFilters}
          >
            Szűrők törlése{activeFilterCount ? ` (${activeFilterCount})` : ""}
          </button>
        </div>

        <label className="field-label product-filter-search">
          Mit keresel?
          <input
            className="input"
            type="search"
            placeholder="SKU, terméknév vagy beszállítói cikkszám"
            value={filters.search}
            onChange={(event) => updateFilters({ search: event.target.value })}
          />
        </label>
        <div className="products-quick-views" role="group" aria-label="Gyors szűrők">
          {productQuickViews.map((view) => (
            <button
              className={`products-choice ${isProductQuickViewActive(filters, view.id) ? "is-active" : ""}`}
              key={view.id}
              type="button"
              title={view.help}
              aria-pressed={isProductQuickViewActive(filters, view.id)}
              onClick={() => applyQuickView(view.id)}
            >
              {view.label}
            </button>
          ))}
        </div>

        <div className="products-filter-layout">
          <div className="products-filter-stack">
            <ProductChoiceGroup
              label="Beszállító szűrő"
              value={filters.supplierId}
              options={[
                { value: "all", label: "Összes beszállító" },
                ...suppliers.map((supplier) => ({ value: supplier.id, label: supplier.name })),
                { value: "none", label: "Nincs aktív mapping" },
              ]}
              onChange={(value) => updateFilters({ supplierId: value })}
            />
            <ProductChoiceGroup
              label="Cikkszám felépítése"
              value={filters.articleStructure}
              options={[
                { value: "all", label: "Minden cikkszám" },
                { value: "single", label: "Egy beszállítói cikkszám" },
                { value: "multiple", label: "Dupla cikkszám (__)" },
              ]}
              onChange={(value) => updateFilters({ articleStructure: value })}
            />
            <p className="helper-text products-filter-note">
              A beszállítószűrő a mentett párosítást követi. Dupla cikkszámnál mindkét beszállítói
              jelöltre kereshetsz.
            </p>
          </div>
          <fieldset className="product-profit-zone-fieldset">
            <legend>Jó profit célzóna</legend>
            <div className="product-profit-zone-fields">
              <label className="field-label">
                Alsó határ (%)
                <input
                  className="input"
                  type="number"
                  value={filters.profitBandMinPercent}
                  onChange={(event) =>
                    updateFilters({ profitBandMinPercent: readNumberInput(event.target.value) })
                  }
                />
              </label>
              <label className="field-label">
                Felső határ (%)
                <input
                  className="input"
                  type="number"
                  value={filters.profitBandMaxPercent}
                  onChange={(event) =>
                    updateFilters({ profitBandMaxPercent: readNumberInput(event.target.value) })
                  }
                />
              </label>
            </div>
            <ProductChoiceGroup
              label="Profit szerinti szűrés"
              value={filters.profitBandMode}
              options={profitBandModeOptions}
              onChange={(value) => updateFilters({ profitBandMode: value })}
            />
          </fieldset>
        </div>
        <ProductChoiceGroup
          label="Termék státusz szerinti szűrés"
          value={filters.unifiedStatus}
          options={unifiedStatusFilterOptions}
          onChange={applyStatusFilter}
        />

        <section className="products-pricing" aria-labelledby="product-pricing-title">
          <div className="products-section-heading">
            <h2 id="product-pricing-title">Árszámítás beállításai</h2>
            <p className="helper-text">
              Célár számítás · az értékek változtatása azonnal frissíti a terméklistát.
            </p>
          </div>
          <div className="products-pricing-grid">
            <label className="field-label">
              EUR/HUF árfolyam
              <input
                className="input"
                type="number"
                min="100"
                max="1000"
                step="0.01"
                value={eurHufRate}
                onChange={(event) => setEurHufRate(readNumberInput(event.target.value))}
              />
              <span className="field-help" role="status">
                {rateSaveStatus === "saving"
                  ? "Mentés..."
                  : rateSaveStatus === "error"
                    ? "Mentési hiba"
                    : `Mentve: ${pricingSettings?.eurHufRate ?? "—"}`}
              </span>
            </label>
            <label className="field-label">
              ÁFA (%)
              <input
                className="input"
                type="number"
                min="0"
                max="50"
                step="0.1"
                value={vatPercent}
                onChange={(event) => setVatPercent(readNumberInput(event.target.value))}
              />
              <span className="field-help">Alapérték: {DEFAULT_VAT_PERCENT}%</span>
            </label>
            <label className="field-label">
              Profit szorzó
              <input
                className="input"
                type="number"
                min="1"
                max="20"
                step="0.01"
                value={targetProfitMultiplier}
                onChange={(event) => setTargetProfitMultiplier(readNumberInput(event.target.value))}
              />
              <span className="field-help">Példa: nettó beszerzés × 1,5 + ÁFA.</span>
            </label>
            <div className="products-rounding">
              <label className="column-toggle products-rounding-switch">
                <input
                  type="checkbox"
                  checked={roundingEnabled}
                  onChange={(event) => setRoundingEnabled(event.target.checked)}
                />
                <span>Kerekítés bekapcsolva</span>
              </label>
              <div className="products-rounding-options">
                <ProductChoiceGroup
                  label="Kerekítés összege"
                  value={String(roundingIncrementHuf)}
                  options={[50, 100, 500, 1000].map((amount) => ({
                    value: String(amount),
                    label: `${amount} Ft`,
                  }))}
                  disabled={!roundingEnabled}
                  onChange={(value) => setRoundingIncrementHuf(readNumberInput(value))}
                />
                <ProductChoiceGroup
                  label="Kerekítés módja"
                  value={roundingMode}
                  options={[
                    { value: "up", label: "Felfelé" },
                    { value: "nearest", label: "Legközelebbi" },
                  ]}
                  disabled={!roundingEnabled}
                  onChange={setRoundingMode}
                />
              </div>
            </div>
          </div>
          <p className="helper-text products-target-note">
            <strong>Cél Woo bruttó: </strong>
            {activeTargetProfitMultiplier === null
              ? "adj meg érvényes profit szorzót a célár megjelenítéséhez."
              : roundingEnabled
                ? `${formatMultiplier(activeTargetProfitMultiplier)}× szorzó, ${activeRoundingIncrementHuf.toLocaleString("hu-HU")} Ft-ra ${labelRoundingMode(roundingMode).toLowerCase()} kerekítve.`
                : `${formatMultiplier(activeTargetProfitMultiplier)}× szorzó, kerekítés nélkül.`}
          </p>
        </section>

        <div className="product-control-footer">
          <div className="product-control-status" aria-live="polite">
            <strong>{(data?.total ?? 0).toLocaleString("hu-HU")} találat</strong>
            {activeFilterChips.map((chip) => (
              <span className="product-filter-chip" key={chip}>
                {chip}
              </span>
            ))}
            <span
              className={`product-refresh-status ${productRefreshStatus === "error" ? "is-error" : ""}`}
            >
              {productRefreshLabel}
            </span>
          </div>
        </div>
      </section>

      <section className="card table-card">
        <CatalogTableToolbar
          columns={selectableProductColumns}
          selectedIds={exportColumnIds}
          fixedIds={["sku", "name"]}
          onSelectionChange={(ids) => {
            const selected = new Set<ProductColumnId>(ids);
            setColumnVisibility(
              normalizeStoredColumnVisibility(
                Object.fromEntries(
                  productColumns.map((column) => [column.id, selected.has(column.id)])
                )
              )
            );
          }}
          total={csvExportTotal}
          orderLabel={`${sortOptions.find((option) => option.value === filters.sortBy)?.label ?? ""} · ${filters.sortDirection === "asc" ? "növekvő" : "csökkenő"}`}
          printOptions={printOptions}
          onPrintOptionsChange={setPrintOptions}
          busy={exportBusy}
          disabled={exportUnavailable}
          onCsv={() => {
            setPrintMessage("");
            void handleFilteredCsvExport();
          }}
          onPrint={() => {
            setCsvExportMessage(null);
            void handleProductPrint();
          }}
          status={
            printMessage || csvExportStatusLabel || databaseTransferMessage ? (
              <>
                {printing || printMessage ? printMessage : csvExportStatusLabel}
                {databaseTransferMessage ? (
                  <p className={databaseTransferStatus === "error" ? "error-text" : ""}>
                    {databaseTransferMessage}
                  </p>
                ) : null}
              </>
            ) : undefined
          }
          pagination={
            <TablePagination
              canGoBack={canGoBack}
              canGoNext={canGoNext}
              label={paginationLabel}
              onBack={() => setOffset(Math.max(0, offset - limit))}
              onNext={() => setOffset(offset + limit)}
              compact
            />
          }
        >
          <a className="button secondary" href="/csv-import">
            WooCommerce CSV import
          </a>
          <div
            className="product-database-transfer"
            role="group"
            aria-label="Teljes helyi adatbázis mentés/import"
            title="Termékek, párosítások és árfigyelő előzmények mentése és visszaállítása."
          >
            <button
              className="button secondary"
              type="button"
              onClick={handleDatabaseExport}
              disabled={
                databaseTransferStatus === "exporting" || databaseTransferStatus === "importing"
              }
            >
              {databaseTransferStatus === "exporting" ? "Teljes export…" : "Teljes export"}
            </button>
            <button
              className="button secondary"
              type="button"
              onClick={openDatabaseImportPicker}
              disabled={
                databaseTransferStatus === "exporting" || databaseTransferStatus === "importing"
              }
            >
              {databaseTransferStatus === "importing" ? "Teljes import…" : "Teljes import"}
            </button>
            <input
              ref={databaseImportInputRef}
              className="visually-hidden"
              type="file"
              accept="application/json,.json"
              onChange={(event) => {
                const file = event.target.files?.[0] ?? null;
                event.target.value = "";
                void handleDatabaseImportFile(file);
              }}
            />
          </div>
        </CatalogTableToolbar>

        {loading ? <LoadingState /> : null}
        {error ? <ErrorState message={error} /> : null}
        {!loading && !error && data && data.items.length === 0 ? (
          activeFilterCount > 0 ? (
            <EmptyState title="Nincs találat a szűrőkkel">
              Töröld vagy módosítsd a szűrőket, hogy újra lásd a termékeket.
            </EmptyState>
          ) : (
            <EmptyState title="Még nincs termék">
              Importálj CSV-t a katalógus feltöltéséhez.
            </EmptyState>
          )
        ) : null}

        {data?.items?.length ? (
          <div className="table-scroll">
            <table
              className="table data-table data-table--wide data-table--sheet"
              style={{ width: totalTableWidth, minWidth: totalTableWidth }}
            >
              <colgroup>
                {visibleProductColumns.map((column) => (
                  <col key={column.id} style={{ width: columnWidths[column.id] }} />
                ))}
              </colgroup>
              <thead>
                <tr>
                  {visibleProductColumns.map((column) => (
                    <th
                      key={column.id}
                      aria-sort={
                        productSortByColumn[column.id] === filters.sortBy
                          ? filters.sortDirection === "asc"
                            ? "ascending"
                            : "descending"
                          : "none"
                      }
                      className={`resizable-header cell-nowrap ${"numeric" in column && column.numeric ? "numeric" : ""}`}
                    >
                      <SortButton
                        label={column.label}
                        direction={
                          productSortByColumn[column.id] === filters.sortBy
                            ? filters.sortDirection
                            : undefined
                        }
                        onClick={() => toggleSort(column.id)}
                        disabled={!productSortByColumn[column.id]}
                      />
                      <ColumnResizer
                        label={column.label}
                        width={columnWidths[column.id]}
                        minWidth={column.minWidth}
                        onResize={(event) => beginColumnResize(column.id, event)}
                        onWidth={(width) =>
                          setColumnWidths((current) => ({ ...current, [column.id]: width }))
                        }
                      />
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.items.map((product) => {
                  const activeMapping = activeMappingByProductId.get(product.id) ?? null;
                  const edit = edits[product.id];
                  const supplierId = edit?.supplierId ?? activeMapping?.supplierId ?? "";
                  const selectedSupplier =
                    suppliers.find((supplier) => supplier.id === supplierId) ?? null;
                  const selectedMapping = supplierId
                    ? findMappingForProductSupplier(mappings, product.id, supplierId)
                    : null;
                  const directUrl = isLfSupplier(selectedSupplier)
                    ? (selectedMapping?.directUrl ?? "")
                    : (edit?.directUrl ?? selectedMapping?.directUrl ?? "");
                  const rowSaving = savingProductId === product.id;
                  const rowHasEdits = hasPendingRowEdit(edit);
                  const livePricing = calculateLiveProductPricing(
                    product,
                    activeRate,
                    activeVatPercent,
                    selectedSupplier,
                    activeTargetPricing
                  );

                  return (
                    <tr key={product.id}>
                      {visibleProductColumns.map((column) =>
                        renderProductCell({
                          columnId: column.id,
                          product,
                          edit,
                          suppliers,
                          selectedSupplier,
                          selectedMapping,
                          supplierId,
                          directUrl,
                          livePricing,
                          rowSaving,
                          rowMessage: rowMessages[product.id] ?? null,
                          savingBlocked: savingProductId !== null || !rowHasEdits,
                          updateRowEdit,
                          saveProductRow,
                        })
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : null}
      </section>

      <TablePagination
        canGoBack={canGoBack}
        canGoNext={canGoNext}
        label={paginationLabel}
        onBack={() => setOffset(Math.max(0, offset - limit))}
        onNext={() => setOffset(offset + limit)}
      />
    </div>
  );
}

type ProductCellRenderInput = {
  columnId: ProductColumnId;
  product: CatalogProduct;
  edit: ProductRowEdit | undefined;
  suppliers: Supplier[];
  selectedSupplier: Supplier | null;
  selectedMapping: SupplierMapping | null;
  supplierId: string;
  directUrl: string;
  livePricing: ReturnType<typeof calculateLiveProductPricing>;
  rowSaving: boolean;
  rowMessage: string | null;
  savingBlocked: boolean;
  updateRowEdit: (productId: string, patch: ProductRowEdit) => void;
  saveProductRow: (product: CatalogProduct) => Promise<void>;
};

function renderProductCell(input: ProductCellRenderInput) {
  const {
    columnId,
    product,
    edit,
    suppliers,
    selectedSupplier,
    selectedMapping,
    supplierId,
    directUrl,
    livePricing,
    rowSaving,
    rowMessage,
    savingBlocked,
    updateRowEdit,
    saveProductRow,
  } = input;
  const supplierPricing = readSupplierPricingView(product, selectedSupplier);

  switch (columnId) {
    case "sku":
      return renderEditableTextCell({
        columnId,
        product,
        edit,
        field: "sku",
        fallback: product.sku,
        mono: true,
        updateRowEdit,
      });
    case "name":
      return renderEditableTextCell({
        columnId,
        product,
        edit,
        field: "name",
        fallback: product.name,
        updateRowEdit,
      });
    case "supplier":
      return (
        <td key={columnId}>
          <select
            className="input table-input"
            value={supplierId}
            aria-label={`${product.sku} beszállítója`}
            onChange={(event) => updateRowEdit(product.id, { supplierId: event.target.value })}
          >
            <option value="">Nincs beállítva</option>
            {suppliers.map((supplier) => (
              <option key={supplier.id} value={supplier.id}>
                {supplier.code} - {supplier.name}
              </option>
            ))}
          </select>
        </td>
      );
    case "supplierArticle":
      return (
        <td key={columnId}>
          <input
            className={`input table-input cell-mono ${edit?.supplierArticleNumber !== undefined ? "is-edited" : ""}`}
            placeholder={
              isLfSupplier(selectedSupplier) ? "LF saját cikkszám" : "Beszállítói cikkszám"
            }
            value={readSupplierArticleCellValue(product, selectedMapping, selectedSupplier, edit)}
            onChange={(event) =>
              updateRowEdit(product.id, { supplierArticleNumber: event.target.value })
            }
          />
        </td>
      );
    case "url":
      return (
        <td key={columnId}>
          <input
            className="input table-input cell-mono"
            type="url"
            placeholder={isLfSupplier(selectedSupplier) ? "LF keresésből nyílik" : "https://..."}
            value={directUrl}
            disabled={isLfSupplier(selectedSupplier)}
            onChange={(event) => updateRowEdit(product.id, { directUrl: event.target.value })}
          />
        </td>
      );
    case "dvgStatus":
      return (
        <td className="cell-nowrap" key={columnId} title={supplierPricing.lastRunMessage ?? ""}>
          <span className={`badge ${supplierProductStatusTone(supplierPricing, selectedSupplier)}`}>
            {labelSupplierProductStatus(supplierPricing, selectedSupplier)}
          </span>
          {supplierPricing.lastRunMessage ? (
            <span className="dvg-status-note">{supplierPricing.lastRunMessage}</span>
          ) : null}
        </td>
      );
    case "dvgPurchaseEur":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: supplierPricing.purchasePriceEurField,
        fallback: supplierPricing.purchasePriceEur,
        updateRowEdit,
      });
    case "dvgPurchaseHuf":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: supplierPricing.purchasePriceHufField,
        fallback: String(livePricing.dvgPurchaseHuf ?? supplierPricing.purchasePriceHuf ?? ""),
        updateRowEdit,
      });
    case "targetWooGross":
      return (
        <td className="numeric" key={columnId}>
          <span className="cell-computed-price">
            {formatDisplayHuf(livePricing.targetWooGrossHuf)}
          </span>
        </td>
      );
    case "dvgSupplierArticle":
      return renderEditableTextCell({
        columnId,
        product,
        edit,
        field: supplierPricing.supplierArticleField,
        fallback: supplierPricing.supplierArticleNumber ?? "",
        mono: true,
        updateRowEdit,
      });
    case "dvgWooGross":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: supplierPricing.wooGrossHufField,
        fallback: String(livePricing.wooGrossHuf ?? supplierPricing.wooGrossHuf ?? ""),
        updateRowEdit,
      });
    case "dvgWooNet":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: supplierPricing.wooNetHufField,
        fallback: String(livePricing.wooNetHuf ?? supplierPricing.wooNetHuf ?? ""),
        updateRowEdit,
      });
    case "dvgProfitHuf":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: supplierPricing.profitNetHufField,
        fallback: String(livePricing.profitHuf ?? supplierPricing.profitNetHuf ?? ""),
        updateRowEdit,
      });
    case "dvgProfitPercent":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: supplierPricing.profitPercentField,
        fallback: String(livePricing.profitPercent ?? supplierPricing.profitPercent ?? ""),
        updateRowEdit,
      });
    case "dvgUpdated":
      return (
        <td className="cell-nowrap" key={columnId}>
          {supplierPricing.pricingUpdatedAt ? formatDate(supplierPricing.pricingUpdatedAt) : "—"}
        </td>
      );
    case "suggestedArticle":
      return renderEditableTextCell({
        columnId,
        product,
        edit,
        field: "suggestedSupplierArticle",
        fallback: product.suggestedSupplierArticle ?? "",
        mono: true,
        updateRowEdit,
      });
    case "suffix":
      return renderEditableTextCell({
        columnId,
        product,
        edit,
        field: "internalSkuSuffix",
        fallback: product.internalSkuSuffix ?? "",
        mono: true,
        updateRowEdit,
      });
    case "currentPrice":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: "currentPrice",
        fallback: product.currentPrice ?? "",
        updateRowEdit,
      });
    case "regularPrice":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: "regularPrice",
        fallback: product.regularPrice,
        updateRowEdit,
      });
    case "salePrice":
      return renderEditableNumberCell({
        columnId,
        product,
        edit,
        field: "salePrice",
        fallback: product.salePrice,
        updateRowEdit,
      });
    case "lastSeen":
      return (
        <td className="cell-nowrap" key={columnId}>
          {formatDate(product.lastSeenInImportAt ?? product.createdAt)}
        </td>
      );
    case "actions":
      return (
        <td className="actions" key={columnId}>
          <button
            className="button small"
            onClick={() => void saveProductRow(product)}
            disabled={savingBlocked}
          >
            {rowSaving ? "Mentés..." : "Mentés"}
          </button>
          {rowMessage ? <span className="table-row-status">{rowMessage}</span> : null}
        </td>
      );
  }
  return null;
}

function renderEditableTextCell(input: {
  columnId: ProductColumnId;
  product: CatalogProduct;
  edit: ProductRowEdit | undefined;
  field: ProductEditableField;
  fallback: string | null | undefined;
  mono?: boolean;
  updateRowEdit: (productId: string, patch: ProductRowEdit) => void;
}) {
  const value = readEditedValue(input.edit, input.field, input.fallback);
  const edited = input.edit?.[input.field] !== undefined;
  return (
    <td key={input.columnId}>
      <input
        className={`input table-input ${input.mono ? "cell-mono" : ""} ${edited ? "is-edited" : ""}`}
        value={value}
        onChange={(event) =>
          input.updateRowEdit(input.product.id, { [input.field]: event.target.value })
        }
      />
      {input.field === "sku" && value.includes("__") && (
        <div
          className="product-article-candidates"
          title="Külön beszállítói cikkszámok; a teljes SKU azonosító marad."
        >
          {readWooSkuArticleCandidates(value).map((article) => (
            <code key={article}>{article}</code>
          ))}
        </div>
      )}
    </td>
  );
}

function renderEditableNumberCell(input: {
  columnId: ProductColumnId;
  product: CatalogProduct;
  edit: ProductRowEdit | undefined;
  field: ProductEditableField;
  fallback: string | number | null | undefined;
  updateRowEdit: (productId: string, patch: ProductRowEdit) => void;
}) {
  const value = readEditedValue(input.edit, input.field, input.fallback);
  const edited = input.edit?.[input.field] !== undefined;
  return (
    <td className="numeric" key={input.columnId}>
      <input
        className={`input table-input numeric ${edited ? "is-edited" : ""}`}
        type="number"
        step="0.01"
        value={value}
        onChange={(event) =>
          input.updateRowEdit(input.product.id, { [input.field]: event.target.value })
        }
      />
    </td>
  );
}

function readEditedValue(
  edit: ProductRowEdit | undefined,
  field: ProductEditableField,
  fallback: string | number | null | undefined
): string {
  const value = edit?.[field];
  if (value !== undefined) return value;
  return fallback === null || fallback === undefined ? "" : String(fallback);
}

function hasPendingRowEdit(edit: ProductRowEdit | undefined): boolean {
  return edit !== undefined && Object.keys(edit).length > 0;
}

function buildProductUpdateInput(
  product: CatalogProduct,
  edit: ProductRowEdit
): CatalogProductUpdateInput {
  const input: CatalogProductUpdateInput = {};
  for (const field of editableProductFields) {
    if (edit[field] === undefined) continue;
    const value = normalizeEditableProductValue(field, edit[field] ?? "");
    if (value !== readCatalogProductField(product, field)) {
      Object.assign(input, { [field]: value });
    }
  }
  return input;
}

function normalizeEditableProductValue(field: ProductEditableField, value: string): string | null {
  const trimmed = value.trim();
  if (field === "sku" || field === "name") return trimmed;
  return trimmed || null;
}

function readCatalogProductField(
  product: CatalogProduct,
  field: ProductEditableField
): string | null {
  const value = product[field as keyof CatalogProduct];
  return value === null || value === undefined ? null : String(value);
}

function buildActiveMappingIndex(mappings: SupplierMapping[]): Map<string, SupplierMapping> {
  const index = new Map<string, SupplierMapping>();
  for (const mapping of mappings) {
    const current = index.get(mapping.catalogProductId);
    if (!current || shouldPreferMapping(mapping, current)) {
      index.set(mapping.catalogProductId, mapping);
    }
  }
  return index;
}

async function listAllSupplierMappings(): Promise<SupplierMapping[]> {
  const mappings: SupplierMapping[] = [];
  let offset = 0;

  while (true) {
    const response = await listSupplierMappings({ limit: MAPPING_PAGE_SIZE, offset });
    const items = response.items ?? [];
    mappings.push(...items);
    if (items.length < MAPPING_PAGE_SIZE) break;
    offset += MAPPING_PAGE_SIZE;
  }

  return mappings;
}

function shouldPreferMapping(candidate: SupplierMapping, current: SupplierMapping): boolean {
  if (candidate.enabled !== current.enabled) return candidate.enabled;
  if (candidate.isPrimary !== current.isPrimary) return candidate.isPrimary;
  return Date.parse(candidate.createdAt) > Date.parse(current.createdAt);
}

function findMappingForProductSupplier(
  mappings: SupplierMapping[],
  catalogProductId: string,
  supplierId: string
): SupplierMapping | null {
  return (
    mappings.find(
      (mapping) =>
        mapping.catalogProductId === catalogProductId && mapping.supplierId === supplierId
    ) ?? null
  );
}

function readSupplierArticleCellValue(
  product: CatalogProduct,
  mapping: SupplierMapping | null,
  supplier: Supplier | null,
  edit?: ProductRowEdit
): string {
  const edited = edit?.supplierArticleNumber;
  if (edited !== undefined) return edited;
  return readSupplierArticleNumber(product, mapping, supplier) ?? "";
}

function labelLfExactSearchFailure(outcome: string): string {
  const labels: Record<string, string> = {
    login_timeout:
      "LF belépés nem lett kész időben. Nyisd meg az LF operátort és jelentkezz be kézzel.",
    redirected_to_login:
      "LF session lejárt vagy loginra dobott. Jelentkezz be újra az LF operátoron.",
    no_match: "LF exact keresés nem talált saját terméket ehhez a cikkszámhoz.",
    supplier_cross_reference_only:
      "LF csak cross-reference találatot adott erre a cikkszámra, saját LF cikkszámot nem.",
    ambiguous_lf_item: "LF több saját terméket adott erre a cikkszámra, kézi döntés kell.",
    ambiguous_supplier_cross_reference:
      "LF több cross-reference találatot adott, saját LF mapping nem menthető.",
    non_article_result: "LF nem termék találatot adott erre a keresésre.",
    article_mismatch: "LF találat nem egyezik exact módon a megadott cikkszámmal.",
  };
  return labels[outcome] ?? `LF exact keresés nem igazolta a mappinget: ${outcome}`;
}

type ProductsCsvInput = {
  products: CatalogProduct[];
  visibleColumns: ProductColumn[];
  activeMappingByProductId: Map<string, SupplierMapping>;
  suppliers: Supplier[];
  eurHufRate: number | null;
  vatPercent: number;
  targetPricing: ProductTargetPricingSettings;
};

async function listAllFilteredProductsForCsv(params: ProductListParams): Promise<CatalogProduct[]> {
  const exportParams: ProductListParams = {
    ...params,
    limit: PRODUCT_CSV_EXPORT_PAGE_SIZE,
    offset: 0,
  };
  const products: CatalogProduct[] = [];
  let total: number | null = null;

  while (true) {
    const response = await listProducts({ ...exportParams, offset: products.length });
    products.push(...response.items);
    total = response.total ?? total;

    if (response.items.length === 0) break;
    if (total !== null && products.length >= total) break;
    if (response.items.length < PRODUCT_CSV_EXPORT_PAGE_SIZE) break;
  }

  return products;
}

function downloadFilteredProductsCsv(input: ProductsCsvInput): void {
  const blob = new Blob([`\uFEFF${buildFilteredProductsCsvText(input)}`], {
    type: "text/csv;charset=utf-8",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `danetti-products-filtered-${new Date().toISOString().replace(/[:.]/g, "-")}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function formatDisplayHuf(value: number | null): string {
  if (value === null) return "—";
  return `${Math.round(value).toLocaleString("hu-HU")} Ft`;
}

function formatMultiplier(value: number): string {
  return value.toLocaleString("hu-HU", { maximumFractionDigits: 2 });
}

function labelRoundingMode(mode: SupplierPriceChangeRoundingMode): string {
  return mode === "nearest" ? "Legközelebbi" : "Felfelé";
}

function emptyToNull(value: string | null | undefined): string | null {
  const trimmed = value?.trim();
  return trimmed ? trimmed : null;
}

function toProductListParams(filters: ProductFilters) {
  const usesProfitBand = filters.profitBandMode !== "all";
  return {
    search: filters.search.trim() || undefined,
    sortBy: filters.sortBy,
    sortDirection: filters.sortDirection,
    supplierId: filters.supplierId === "all" ? undefined : filters.supplierId,
    articleStructure: filters.articleStructure === "all" ? undefined : filters.articleStructure,
    profitBandMode: filters.profitBandMode === "all" ? undefined : filters.profitBandMode,
    profitBandMinPercent: usesProfitBand
      ? numberOrUndefined(filters.profitBandMinPercent)
      : undefined,
    profitBandMaxPercent: usesProfitBand
      ? numberOrUndefined(filters.profitBandMaxPercent)
      : undefined,
    unifiedStatus: filters.unifiedStatus === "all" ? undefined : filters.unifiedStatus,
  };
}

function applyProductQuickView(
  filters: ProductFilters,
  viewId: ProductQuickViewId
): ProductFilters {
  const base: ProductFilters = {
    ...defaultProductFilters,
    search: filters.search,
    sortBy: filters.sortBy,
    sortDirection: filters.sortDirection,
    supplierId: filters.supplierId,
    articleStructure: filters.articleStructure,
    profitBandMinPercent: filters.profitBandMinPercent,
    profitBandMaxPercent: filters.profitBandMaxPercent,
    worklistView: "all",
    profitBandMode: "all",
    calculability: "all",
    unifiedStatus: "all",
    hasDvgPrice: "all",
  };

  switch (viewId) {
    case "profit_outside":
      return { ...base, profitBandMode: "outside" };
    case "missing_or_discontinued":
      return { ...base, unifiedStatus: "missing_price" };
    case "dvg_faulty_or_not_found":
      return { ...base, unifiedStatus: "no_product_page" };
    case "not_price_paired":
      return { ...base, unifiedStatus: "not_ok" };
    case "all":
      return { ...base, search: "", supplierId: "all" };
  }
}

function isProductQuickViewActive(filters: ProductFilters, viewId: ProductQuickViewId): boolean {
  switch (viewId) {
    case "profit_outside":
      return filters.profitBandMode === "outside";
    case "missing_or_discontinued":
      return filters.unifiedStatus === "missing_price";
    case "dvg_faulty_or_not_found":
      return filters.unifiedStatus === "no_product_page";
    case "not_price_paired":
      return filters.unifiedStatus === "not_ok";
    case "all":
      return countActiveFilters(filters) === 0;
  }
}

function buildActiveFilterChips(filters: ProductFilters, suppliers: Supplier[]): string[] {
  const chips: string[] = [];
  if (filters.search.trim()) chips.push(`Keresés: ${filters.search.trim()}`);
  if (filters.supplierId !== "all") {
    chips.push(`Beszállító: ${labelSupplierFilter(filters.supplierId, suppliers)}`);
  }
  if (filters.articleStructure !== "all")
    chips.push(
      filters.articleStructure === "multiple" ? "Dupla cikkszám (__)" : "Egy beszállítói cikkszám"
    );
  if (filters.profitBandMode !== "all") {
    chips.push(
      `Profit: ${labelProfitBandMode(filters.profitBandMode)} ${formatProfitBand(filters)}`
    );
  }
  if (filters.unifiedStatus !== "all")
    chips.push(
      `Státusz: ${unifiedStatusFilterOptions.find((o) => o.value === filters.unifiedStatus)?.label ?? filters.unifiedStatus}`
    );
  return chips.slice(0, 6);
}

function labelSupplierFilter(supplierId: string, suppliers: Supplier[]): string {
  if (supplierId === "none") return "Nincs aktív mapping";
  const supplier = suppliers.find((item) => item.id === supplierId);
  return supplier ? `${supplier.code} - ${supplier.name}` : supplierId;
}

function labelProfitBandMode(mode: ProductFilters["profitBandMode"]): string {
  const option = profitBandModeOptions.find((item) => item.value === mode);
  return option?.label.toLowerCase() ?? String(mode);
}

function formatProfitBand(filters: ProductFilters): string {
  const min = filters.profitBandMinPercent === "" ? "-" : `${filters.profitBandMinPercent}%`;
  const max = filters.profitBandMaxPercent === "" ? "-" : `${filters.profitBandMaxPercent}%`;
  return `${min}-${max}`;
}

function readNumberInput(value: string): number | "" {
  if (value.trim() === "") return "";
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : "";
}

function readOptionalNumber(value: number | ""): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function readVatPercent(value: number | ""): number {
  const parsed = readOptionalNumber(value);
  return parsed !== null && parsed >= 0 && parsed <= 50 ? parsed : DEFAULT_VAT_PERCENT;
}

function readOptionalMultiplier(value: number | ""): number | null {
  if (value === "") return null;
  return Number.isFinite(value) && value >= 1 && value <= 20 ? value : null;
}

function readRoundingIncrementHuf(value: number | ""): number {
  const parsed = readOptionalNumber(value);
  return parsed !== null && parsed >= 1 ? parsed : DEFAULT_ROUNDING_INCREMENT_HUF;
}

function readRoundingMode(value: unknown): SupplierPriceChangeRoundingMode {
  return value === "nearest" ? "nearest" : "up";
}

function numberOrUndefined(value: number | ""): number | undefined {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}

function countActiveFilters(filters: ProductFilters): number {
  return [
    filters.search.trim(),
    filters.supplierId === "all" ? "" : filters.supplierId,
    filters.articleStructure === "all" ? "" : filters.articleStructure,
    filters.profitBandMode === "all" ? "" : filters.profitBandMode,
    filters.unifiedStatus === "all" ? "" : filters.unifiedStatus,
  ].filter((value) => value !== "" && value !== null && value !== undefined).length;
}

function readStoredProductControls(): ProductControls {
  if (typeof window === "undefined") {
    return {
      limit: DEFAULT_LIMIT,
      offset: 0,
      vatPercent: DEFAULT_VAT_PERCENT,
      targetProfitMultiplier: "",
      roundingEnabled: true,
      roundingIncrementHuf: DEFAULT_ROUNDING_INCREMENT_HUF,
      roundingMode: "up",
      filters: defaultProductFilters,
      columnVisibility: defaultColumnVisibility,
      columnWidths: defaultColumnWidths,
    };
  }
  try {
    const parsed = JSON.parse(
      window.localStorage.getItem(PRODUCT_CONTROL_STORAGE_KEY) ?? "{}"
    ) as Partial<ProductControls>;
    return {
      limit: [25, 50, 100, 200].includes(Number(parsed.limit))
        ? Number(parsed.limit)
        : DEFAULT_LIMIT,
      offset:
        Number.isInteger(parsed.offset) && Number(parsed.offset) >= 0 ? Number(parsed.offset) : 0,
      vatPercent: readStoredNumberOrDefault(parsed.vatPercent, DEFAULT_VAT_PERCENT),
      targetProfitMultiplier: readStoredOptionalNumber(parsed.targetProfitMultiplier),
      roundingEnabled: parsed.roundingEnabled === false ? false : true,
      roundingIncrementHuf: readStoredNumberOrDefault(
        parsed.roundingIncrementHuf,
        DEFAULT_ROUNDING_INCREMENT_HUF
      ),
      roundingMode: readRoundingMode(parsed.roundingMode),
      filters: normalizeStoredProductFilters(parsed.filters),
      columnVisibility: normalizeStoredColumnVisibility(parsed.columnVisibility),
      columnWidths: normalizeStoredColumnWidths(parsed.columnWidths),
    };
  } catch {
    return {
      limit: DEFAULT_LIMIT,
      offset: 0,
      vatPercent: DEFAULT_VAT_PERCENT,
      targetProfitMultiplier: "",
      roundingEnabled: true,
      roundingIncrementHuf: DEFAULT_ROUNDING_INCREMENT_HUF,
      roundingMode: "up",
      filters: defaultProductFilters,
      columnVisibility: defaultColumnVisibility,
      columnWidths: defaultColumnWidths,
    };
  }
}

function storeProductControls(controls: ProductControls): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(PRODUCT_CONTROL_STORAGE_KEY, JSON.stringify(controls));
}

function normalizeStoredProductFilters(value: unknown): ProductFilters {
  if (!value || typeof value !== "object" || Array.isArray(value)) return defaultProductFilters;
  const record = value as Partial<ProductFilters>;
  return {
    ...defaultProductFilters,
    ...record,
    sortBy: isProductSortBy(record.sortBy) ? record.sortBy : defaultProductFilters.sortBy,
    sortDirection: record.sortDirection === "desc" ? "desc" : "asc",
    supplierId: readStoredSupplierFilter(record.supplierId),
    articleStructure:
      record.articleStructure === "single" || record.articleStructure === "multiple"
        ? record.articleStructure
        : "all",
    worklistView: "all",
    profitBandMode: isProfitBandMode(record.profitBandMode) ? record.profitBandMode : "all",
    profitBandMinPercent: readStoredNumberOrDefault(
      record.profitBandMinPercent,
      DEFAULT_TARGET_PROFIT_MIN_PERCENT
    ),
    profitBandMaxPercent: readStoredNumberOrDefault(
      record.profitBandMaxPercent,
      DEFAULT_TARGET_PROFIT_MAX_PERCENT
    ),
    calculability: "all",
    minProfitPercent: "",
    maxProfitPercent: "",
    minProfitHuf: "",
    maxProfitHuf: "",
    minDvgPurchaseHuf: "",
    maxDvgPurchaseHuf: "",
    minWooNetHuf: "",
    maxWooNetHuf: "",
    minRegularPrice: "",
    maxRegularPrice: "",
    hasDvgPrice: "all",
    unifiedStatus: isUnifiedStatusFilter(record.unifiedStatus) ? record.unifiedStatus : "all",
  };
}

function normalizeStoredColumnVisibility(value: unknown): Record<ProductColumnId, boolean> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return defaultColumnVisibility;
  const record = value as Partial<Record<ProductColumnId, boolean>>;
  return productColumns.reduce(
    (visibility, column) => ({
      ...visibility,
      [column.id]: fixedProductColumnIds.has(column.id) ? true : record[column.id] !== false,
    }),
    {} as Record<ProductColumnId, boolean>
  );
}

function normalizeStoredColumnWidths(value: unknown): Record<ProductColumnId, number> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return defaultColumnWidths;
  const record = value as Partial<Record<ProductColumnId, number>>;

  return productColumns.reduce(
    (widths, column) => {
      const storedWidth = record[column.id];
      const width =
        typeof storedWidth === "number" && Number.isFinite(storedWidth)
          ? Math.max(column.minWidth, storedWidth)
          : column.width;

      return { ...widths, [column.id]: width };
    },
    {} as Record<ProductColumnId, number>
  );
}

function isProductSortBy(value: unknown): value is ProductSortBy {
  return typeof value === "string" && sortOptions.some((option) => option.value === value);
}

function isProfitBandMode(value: unknown): value is ProductFilters["profitBandMode"] {
  return (
    typeof value === "string" && profitBandModeOptions.some((option) => option.value === value)
  );
}

function readStoredNumberOrDefault(value: unknown, fallback: number): number | "" {
  if (value === "") return "";
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function readStoredOptionalNumber(value: unknown): number | "" {
  if (value === "") return "";
  return typeof value === "number" && Number.isFinite(value) ? value : "";
}

function readStoredSupplierFilter(value: unknown): ProductFilters["supplierId"] {
  return typeof value === "string" && value.trim() ? value : "all";
}

function isUnifiedStatusFilter(value: unknown): value is string {
  return (
    typeof value === "string" && unifiedStatusFilterOptions.some((option) => option.value === value)
  );
}

function formatDecimal(value: string | number | null | undefined, suffix = ""): string {
  if (value === null || value === undefined || value === "") return "—";
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return String(value);
  return `${parsed.toLocaleString("hu-HU", { maximumFractionDigits: 4 })}${suffix}`;
}

function formatHuf(value: string | number | null | undefined): string {
  if (value === null || value === undefined || value === "") return "—";
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return String(value);
  return `${Math.round(parsed).toLocaleString("hu-HU")} HUF`;
}

function removeRecordKey<T>(record: Record<string, T>, key: string): Record<string, T> {
  if (!(key in record)) return record;
  const next = { ...record };
  delete next[key];
  return next;
}

function ProductChoiceGroup<Value extends string>({
  label,
  value,
  options,
  onChange,
  disabled = false,
}: {
  label: string;
  value: Value;
  options: readonly { value: Value; label: string }[];
  onChange: (value: Value) => void;
  disabled?: boolean;
}) {
  return (
    <fieldset className="products-choice-group" disabled={disabled}>
      <legend>{label}</legend>
      <div className="products-choice-options">
        {options.map((option) => (
          <button
            key={option.value}
            className={`products-choice ${value === option.value ? "is-active" : ""}`}
            type="button"
            aria-pressed={value === option.value}
            onClick={() => onChange(option.value)}
          >
            {option.label}
          </button>
        ))}
      </div>
    </fieldset>
  );
}
