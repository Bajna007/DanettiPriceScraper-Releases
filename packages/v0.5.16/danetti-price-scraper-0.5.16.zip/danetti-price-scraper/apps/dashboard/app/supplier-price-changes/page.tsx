"use client";

import { useEffect, useMemo, useState, useRef, type ReactNode } from "react";
import {
  formatApiErrorMessage,
  getPricingSettings,
  listSupplierPriceChanges,
  reviewSupplierPriceChange,
  saveEurHufRate,
  type SupplierPriceChangeDirection,
  type SupplierPriceChangeResponse,
  type SupplierPriceChangeRoundingMode,
  type SupplierPriceChangeRow,
  type SupplierPriceChangeSupplierScope,
} from "../../src/lib/api";
import { EmptyState, ErrorState, LoadingState } from "../../src/components/States";
import { TablePagination } from "../../src/components/TablePagination";
import { formatDate } from "../../src/lib/formatters";

import type { PriceChangeSortBy } from "@danetti/shared";
import {
  ColumnResizer,
  SortButton,
  useColumnResize,
  useSheetLayout,
  useStoredColumnWidths,
} from "../../src/components/SheetHeader";
import {
  priceChangeColumns,
  buildPriceChangesCsv,
  buildPriceChangesPrint,
} from "../../src/products/price-changes-export";

import { CatalogTableToolbar } from "../../src/components/CatalogTableToolbar";
import { defaultTablePrintOptions } from "../../src/products/table-print";

const DEFAULT_LIMIT = 50;

export default function SupplierPriceChangesPage() {
  const [data, setData] = useState<SupplierPriceChangeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const [sort, setSort] = useState<{ id: PriceChangeSortBy; direction: "asc" | "desc" }>({
    id: "newObservedAt",
    direction: "desc",
  });
  const [visibleColumns, setVisibleColumns] = useState<PriceChangeSortBy[]>(
    priceChangeColumns.map((c) => c.id)
  );
  const [exportStatus, setExportStatus] = useState("");
  const [printOptions, setPrintOptions] = useState(defaultTablePrintOptions);
  const [reload, setReload] = useState(0);
  const [view, setView] = useState<"pending" | "latest" | "all">("pending");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [reviewing, setReviewing] = useState<string | null>(null);
  const [reviewMessage, setReviewMessage] = useState("");
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("danetti:price-changes:view");
      if (saved === "pending" || saved === "latest" || saved === "all") setView(saved);
    } catch {
      /* The current view remains usable when storage is unavailable. */
    }
  }, []);
  useEffect(() => {
    const refresh = () => {
      if (document.visibilityState === "visible") setReload((n) => n + 1);
    };
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", refresh);
    return () => {
      window.removeEventListener("focus", refresh);
      document.removeEventListener("visibilitychange", refresh);
    };
  }, []);
  const [exporting, setExporting] = useState(false);
  const exportAlive = useRef(true);
  useEffect(() => {
    exportAlive.current = true;
    return () => {
      exportAlive.current = false;
    };
  }, []);
  const [eurHufRate, setEurHufRate] = useState<number | "">("");
  const [vatPercent, setVatPercent] = useState<number | "">(27);
  const [pricingMode, setPricingMode] = useState<"preserve" | "fixed">("preserve");
  const [fixedProfitPercent, setFixedProfitPercent] = useState<number | "">("");
  const [roundingEnabled, setRoundingEnabled] = useState(true);
  const [roundingIncrementHuf, setRoundingIncrementHuf] = useState<number | "">(100);
  const [roundingMode, setRoundingMode] = useState<SupplierPriceChangeRoundingMode>("up");
  const [direction, setDirection] = useState<SupplierPriceChangeDirection>("all");
  const [supplierScope, setSupplierScope] = useState<SupplierPriceChangeSupplierScope>("all");
  const [minChangePercent, setMinChangePercent] = useState<number | "">(0);
  const [rateSaveStatus, setRateSaveStatus] = useState<"saved" | "saving" | "error" | null>(null);
  const activeRate = readOptionalNumber(eurHufRate);
  const activeVat = readOptionalNumber(vatPercent) ?? 27;
  const activeFixedProfit = readOptionalNumber(fixedProfitPercent);
  const pricingValid =
    pricingMode === "preserve" ||
    (activeFixedProfit !== null && activeFixedProfit >= 0 && activeFixedProfit <= 1000);
  const activeRounding = readOptionalNumber(roundingIncrementHuf) ?? 100;
  const activeMinChange = readOptionalNumber(minChangePercent) ?? 0;

  const canGoBack = offset > 0;
  const canGoNext =
    data?.total !== undefined ? offset + (data?.items.length ?? 0) < data.total : false;
  const paginationLabel = useMemo(() => {
    const total = data?.total;
    if (total === undefined) return `Megjelenítve: ${offset + 1}-${offset + DEFAULT_LIMIT}`;
    const start = total === 0 ? 0 : offset + 1;
    const end = Math.min(offset + DEFAULT_LIMIT, total);
    return `Megjelenítve: ${start}-${end} / ${total}`;
  }, [data?.total, offset]);

  useEffect(() => {
    let active = true;
    getPricingSettings()
      .then((settings) => {
        if (!active) return;
        if (settings.eurHufRate !== null) setEurHufRate(settings.eurHufRate);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (activeRate === null || !pricingValid) {
      setData(null);
      setLoading(false);
      return;
    }
    let active = true;
    const controller = new AbortController();
    setLoading(true);
    setError(null);

    listSupplierPriceChanges({
      view,
      fromDate,
      toDate,
      signal: controller.signal,
      sortBy: sort.id,
      sortDirection: sort.direction,
      limit: DEFAULT_LIMIT,
      offset,
      eurHufRate: activeRate,
      vatPercent: activeVat,
      pricingMode,
      fixedProfitPercent: pricingMode === "fixed" ? (activeFixedProfit ?? undefined) : undefined,
      roundingEnabled,
      roundingIncrementHuf: activeRounding,
      roundingMode,
      direction,
      supplierScope,
      minChangePercent: activeMinChange,
    })
      .then((response) => {
        if (active) setData(response);
      })
      .catch((err) => {
        if (active) setError(formatApiErrorMessage(err));
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [
    view,
    fromDate,
    toDate,
    reload,
    activeMinChange,
    activeRate,
    activeRounding,
    activeVat,
    pricingMode,
    activeFixedProfit,
    pricingValid,
    direction,
    offset,
    roundingEnabled,
    roundingMode,
    supplierScope,
    sort,
  ]);

  useEffect(() => {
    if (!data) return;
    if (data.total === 0 && offset !== 0) {
      setOffset(0);
      return;
    }
    if (data.total > 0 && offset >= data.total) {
      setOffset(Math.floor((data.total - 1) / DEFAULT_LIMIT) * DEFAULT_LIMIT);
    }
  }, [data, offset]);

  useEffect(() => {
    const rate = readOptionalNumber(eurHufRate);
    if (rate === null) return;
    const timer = window.setTimeout(() => {
      setRateSaveStatus("saving");
      saveEurHufRate({ eurHufRate: rate })
        .then(() => setRateSaveStatus("saved"))
        .catch(() => setRateSaveStatus("error"));
    }, 700);
    return () => window.clearTimeout(timer);
  }, [eurHufRate]);

  function updateDirection(value: SupplierPriceChangeDirection) {
    setOffset(0);
    setDirection(value);
  }

  function updateSupplierScope(value: SupplierPriceChangeSupplierScope) {
    setOffset(0);
    setSupplierScope(value);
  }

  async function exportRows(mode: "csv" | "print") {
    if (exporting || activeRate === null || !visibleColumns.length || !data?.total) return;
    const printWindow = mode === "print" ? window.open("", "_blank") : null;
    if (mode === "print" && !printWindow) {
      setExportStatus("Engedélyezd a felugró ablakot a nyomtatáshoz.");
      return;
    }
    if (printWindow) printWindow.document.body.textContent = "Nyomtatás előkészítése…";
    setExporting(true);
    setExportStatus("Sorok betöltése…");
    const selectedColumns = [...visibleColumns];
    try {
      const rows: SupplierPriceChangeRow[] = [];
      const seen = new Set<string>();
      let total: number | null = null;
      while (total === null || rows.length < total) {
        if (!exportAlive.current) {
          printWindow?.close();
          return;
        }
        const response = await listSupplierPriceChanges({
          view,
          fromDate,
          toDate,
          limit: 200,
          offset: rows.length,
          eurHufRate: activeRate,
          vatPercent: activeVat,
          pricingMode,
          fixedProfitPercent:
            pricingMode === "fixed" ? (activeFixedProfit ?? undefined) : undefined,
          roundingEnabled,
          roundingIncrementHuf: activeRounding,
          roundingMode,
          direction,
          supplierScope,
          minChangePercent: activeMinChange,
          sortBy: sort.id,
          sortDirection: sort.direction,
        });
        if (total !== null && response.total !== total)
          throw new Error("A lista közben megváltozott. Indítsd újra az exportot.");
        total = response.total;
        if (!response.items.length && rows.length < total)
          throw new Error("Hiányos lista. Indítsd újra az exportot.");
        for (const row of response.items) {
          if (seen.has(row.newSnapshotId))
            throw new Error("A lista közben megváltozott. Indítsd újra az exportot.");
          seen.add(row.newSnapshotId);
          rows.push(row);
        }
        if (exportAlive.current) setExportStatus(`Betöltve: ${rows.length} / ${total}`);
      }
      if (!exportAlive.current) {
        printWindow?.close();
        return;
      }
      if (printWindow) {
        printWindow.document.open();
        printWindow.document.write(buildPriceChangesPrint(rows, selectedColumns, printOptions));
        printWindow.document.close();
        await printWindow.document.fonts.ready;
        printWindow.focus();
        printWindow.print();
      } else {
        const url = URL.createObjectURL(
          new Blob([buildPriceChangesCsv(rows, selectedColumns)], {
            type: "text/csv;charset=utf-8",
          })
        );
        const link = document.createElement("a");
        link.href = url;
        link.download = `danetti-arvaltozasok-${new Date().toISOString().slice(0, 10)}.csv`;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      }
      setExportStatus(
        `${rows.length} sor, ${selectedColumns.length} oszlop ${mode === "csv" ? "exportálva" : "nyomtatásra előkészítve"}.`
      );
    } catch (error) {
      printWindow?.close();
      if (exportAlive.current) setExportStatus(formatApiErrorMessage(error));
    } finally {
      if (exportAlive.current) setExporting(false);
    }
  }

  return (
    <div className="page supplier-changes-page">
      <div className="page-header">
        <h1 className="page-title">Beszállítói árváltozások</h1>
      </div>

      <section className="card supplier-changes-controls catalog-controls">
        <div className="supplier-changes-filter-grid">
          <label className="field-label">
            Nézet
            <select
              className="input"
              value={view}
              onChange={(event) => {
                setView(event.target.value as typeof view);
                try {
                  window.localStorage.setItem("danetti:price-changes:view", event.target.value);
                } catch {
                  /* Optional preference. */
                }
                setOffset(0);
              }}
            >
              <option value="pending">Teendők</option>
              <option value="latest">Legutóbbi két sikeres mérés</option>
              <option value="all">Teljes előzmény</option>
            </select>
          </label>
          <label className="field-label">
            Változás dátuma ettől
            <input
              className="input"
              type="date"
              value={fromDate}
              max={toDate || undefined}
              onChange={(event) => {
                setFromDate(event.target.value);
                setOffset(0);
              }}
            />
          </label>
          <label className="field-label">
            Változás dátuma eddig
            <input
              className="input"
              type="date"
              value={toDate}
              min={fromDate || undefined}
              onChange={(event) => {
                setToDate(event.target.value);
                setOffset(0);
              }}
            />
          </label>
        </div>
        <p className="muted-cell">
          A teendők a lezárásig megmaradnak. A legutóbbi két sikeres mérés nézetben a változatlan ár
          már nem jelenik meg. A teljes előzmény a lezárt és korábbi változásokat is megőrzi.
        </p>
        <p className="muted-cell">
          A Lezárás gomb vagy egy későbbi sikeres CSV-importban megváltoztatott saját ár lezárja a
          tételt. Bármilyen új ár elfogadott. Az árjavaslat rögzített korábbi saját árból indul;
          hiányzó régi adatnál az első megtekintéskori árat rögzítjük.
        </p>
        <button
          className="button secondary"
          onClick={() => setReload((n) => n + 1)}
          disabled={loading}
        >
          Lista frissítése
        </button>
        {reviewMessage && <p role="status">{reviewMessage}</p>}
        <div className="supplier-changes-control-header">
          <div>
            <strong>Árjavaslat vezérlőpult</strong>
          </div>
          <span className="supplier-changes-refresh">
            Frissítve: {data?.generatedAt ? formatDate(data.generatedAt) : "-"}
          </span>
        </div>

        <div className="supplier-changes-filter-grid">
          <label className="field-label">
            Beszállító
            <select
              className="input"
              value={supplierScope}
              onChange={(event) =>
                updateSupplierScope(event.target.value as SupplierPriceChangeSupplierScope)
              }
            >
              <option value="all">DVG + LF</option>
              <option value="dvg">Csak DVG</option>
              <option value="lf">Csak LF</option>
            </select>
          </label>
          <label className="field-label">
            Változás típusa
            <select
              className="input"
              value={direction}
              onChange={(event) =>
                updateDirection(event.target.value as SupplierPriceChangeDirection)
              }
            >
              <option value="all">Minden változás</option>
              <option value="increase">Csak drágult</option>
              <option value="decrease">Csak olcsóbb lett</option>
            </select>
          </label>
          <label className="field-label">
            Minimum változás %
            <input
              className="input"
              type="number"
              min="0"
              max="1000"
              step="0.1"
              value={minChangePercent}
              onChange={(event) => {
                setOffset(0);
                setMinChangePercent(readNumberInput(event.target.value));
              }}
            />
          </label>
        </div>
        <section className="catalog-disclosure" aria-labelledby="price-settings-title">
          <h2 className="section-title" id="price-settings-title">
            Árszámítás beállításai
          </h2>
          <fieldset className="price-pricing-mode">
            <legend>Javasolt ár számítása</legend>
            <label className="column-toggle">
              <input
                type="radio"
                name="pricing-mode"
                checked={pricingMode === "preserve"}
                onChange={() => {
                  setOffset(0);
                  setPricingMode("preserve");
                }}
              />{" "}
              Eddigi profit megtartása
            </label>
            <label className="column-toggle">
              <input
                type="radio"
                name="pricing-mode"
                checked={pricingMode === "fixed"}
                onChange={() => {
                  setOffset(0);
                  setPricingMode("fixed");
                }}
              />{" "}
              Fix profit megadása
            </label>
            {pricingMode === "fixed" && (
              <label className="field-label">
                Fix profit (%)
                <input
                  className="input"
                  type="number"
                  min="0"
                  max="1000"
                  step="0.1"
                  value={fixedProfitPercent}
                  placeholder="pl. 30"
                  onChange={(event) => {
                    setOffset(0);
                    setFixedProfitPercent(readNumberInput(event.target.value));
                  }}
                />
              </label>
            )}
          </fieldset>
          <p className="helper-text">
            {pricingMode === "preserve"
              ? "Termékenként az eddigi profit százalékával számolunk az új beszerzési árból."
              : "Minden termékre a megadott profitot használjuk a nettó beszerzési ár százalékában. Például 30%: 1000 Ft beszerzésből 1300 Ft nettó eladási ár."}{" "}
            Ezután kerül rá az ÁFA és a választott kerekítés.
          </p>
          <div className="catalog-disclosure-body supplier-changes-pricing-grid">
            <label className="field-label">
              EUR/HUF árfolyam
              <input
                className="input"
                type="number"
                min="100"
                max="1000"
                step="0.01"
                value={eurHufRate}
                onChange={(event) => setEurHufRate(readNumberInput(event.target.value))}
              />
              <span className="field-help">
                {rateSaveStatus === "saving"
                  ? "Mentés..."
                  : rateSaveStatus === "error"
                    ? "Mentési hiba"
                    : activeRate === null
                      ? "Adj meg árfolyamot."
                      : "Mentve"}
              </span>
            </label>
            <label className="field-label">
              ÁFA %
              <input
                className="input"
                type="number"
                min="0"
                max="100"
                step="0.01"
                value={vatPercent}
                onChange={(event) => setVatPercent(readNumberInput(event.target.value))}
              />
            </label>
            {roundingEnabled ? (
              <label className="field-label supplier-changes-rounding-detail">
                Kerekítés összege
                <select
                  className="input"
                  value={roundingIncrementHuf}
                  onChange={(event) => setRoundingIncrementHuf(readNumberInput(event.target.value))}
                >
                  <option value={50}>50 Ft</option>
                  <option value={100}>100 Ft</option>
                  <option value={500}>500 Ft</option>
                  <option value={1000}>1000 Ft</option>
                </select>
              </label>
            ) : null}
            {roundingEnabled ? (
              <label className="field-label supplier-changes-rounding-detail">
                Kerekítés módja
                <select
                  className="input"
                  value={roundingMode}
                  onChange={(event) =>
                    setRoundingMode(event.target.value === "nearest" ? "nearest" : "up")
                  }
                >
                  <option value="up">Felfelé</option>
                  <option value="nearest">Legközelebbi</option>
                </select>
              </label>
            ) : null}
            <div className="field-label supplier-changes-rounding-toggle-field">
              Kerekítés
              <label className="supplier-changes-toggle">
                <input
                  type="checkbox"
                  checked={roundingEnabled}
                  onChange={(event) => {
                    setOffset(0);
                    setRoundingEnabled(event.target.checked);
                  }}
                />
                <span>{roundingEnabled ? "Bekapcsolva" : "Kikapcsolva"}</span>
              </label>
            </div>
          </div>
        </section>
        <div className="product-control-footer">
          <span className="helper-text">
            {data?.total?.toLocaleString("hu-HU") ?? "—"} találat · Szűrés a teljes
            árváltozás-listában
          </span>
          <button
            className="button secondary"
            type="button"
            onClick={() => {
              setOffset(0);
              setDirection("all");
              setSupplierScope("all");
              setMinChangePercent(0);
              setFromDate("");
              setToDate("");
            }}
          >
            Szűrők törlése
          </button>
        </div>
      </section>

      {data ? <SupplierChangeSummary response={data} /> : null}
      {loading ? <LoadingState /> : null}
      {error ? (
        <>
          <ErrorState message={error} />
          <button
            className="button secondary"
            type="button"
            onClick={() => setReload((value) => value + 1)}
          >
            Újrapróbálás
          </button>
        </>
      ) : null}
      {!loading && !error && activeRate === null ? (
        <EmptyState title="Hiányzik az EUR/HUF árfolyam">
          Adj meg árfolyamot az Árjavaslat vezérlőpultban, utána betölt az árváltozás lista.
        </EmptyState>
      ) : null}
      {!loading && !error && activeRate !== null && !pricingValid ? (
        <EmptyState title="Adj meg fix profitot">
          A fix profit 0 és 1000% közötti szám lehet. A 0% is érvényes érték.
        </EmptyState>
      ) : null}
      {!loading && !error && data?.items.length === 0 ? (
        <EmptyState title="Nincs beszállítói árváltozás">
          Ebben a nézetben és időszakban nincs találat. Válaszd a teljes előzményt, vagy futtass új
          beszállítói lekérést.
        </EmptyState>
      ) : null}

      {data?.items.length ? (
        <SupplierChangeTable
          reviewing={loading ? "loading" : reviewing}
          onReview={async (row) => {
            if (!row.eventId || reviewing) return;
            setReviewing(row.eventId);
            setReviewMessage("");
            try {
              await reviewSupplierPriceChange(
                row.eventId,
                row.reviewStatus === "resolved" ? "open" : "resolved"
              );
              setReviewMessage(
                row.reviewStatus === "resolved"
                  ? "A változás újra teendő."
                  : "Lezárva. A teljes előzményben továbbra is elérhető."
              );
              setReload((n) => n + 1);
            } catch (error) {
              setReviewMessage(formatApiErrorMessage(error));
            } finally {
              setReviewing(null);
            }
          }}
          rows={data.items}
          sort={sort}
          onSort={(id, direction) => {
            setOffset(0);
            setSort({
              id,
              direction: direction ?? (sort.id === id && sort.direction === "asc" ? "desc" : "asc"),
            });
          }}
          visibleIds={visibleColumns}
          toolbar={
            <CatalogTableToolbar
              columns={priceChangeColumns}
              selectedIds={visibleColumns}
              onSelectionChange={setVisibleColumns}
              total={data.total}
              orderLabel={`${priceChangeColumns.find((c) => c.id === sort.id)?.label} · ${sort.direction === "asc" ? "növekvő" : "csökkenő"}`}
              printOptions={printOptions}
              onPrintOptionsChange={setPrintOptions}
              busy={exporting}
              disabled={loading}
              status={exportStatus}
              onCsv={() => void exportRows("csv")}
              onPrint={() => void exportRows("print")}
              pagination={
                <TablePagination
                  canGoBack={canGoBack}
                  canGoNext={canGoNext}
                  label={paginationLabel}
                  onBack={() => setOffset(Math.max(0, offset - DEFAULT_LIMIT))}
                  onNext={() => setOffset(offset + DEFAULT_LIMIT)}
                  compact
                />
              }
            />
          }
        />
      ) : null}

      <TablePagination
        canGoBack={canGoBack}
        canGoNext={canGoNext}
        label={paginationLabel}
        onBack={() => setOffset(Math.max(0, offset - DEFAULT_LIMIT))}
        onNext={() => setOffset(offset + DEFAULT_LIMIT)}
      />
    </div>
  );
}

function SupplierChangeSummary({ response }: { response: SupplierPriceChangeResponse }) {
  return (
    <section className="supplier-changes-summary" aria-label="Árváltozás összegzés">
      <SummaryItem label="Árváltozott" value={formatCount(response.summary.changedCount)} />
      <SummaryItem
        label="Drágult"
        value={formatCount(response.summary.increaseCount)}
        tone="warning"
      />
      <SummaryItem
        label="Olcsóbb lett"
        value={formatCount(response.summary.decreaseCount)}
        tone="success"
      />
      <SummaryItem
        label="Profit csökkenne"
        value={formatCount(response.summary.marginWouldDropCount)}
        tone="warning"
      />
      <SummaryItem
        label="Nincs előző ár"
        value={formatCount(response.summary.noPreviousPriceCount)}
      />
    </section>
  );
}

function SummaryItem({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string;
  tone?: "neutral" | "success" | "warning";
}) {
  return (
    <div className={`supplier-changes-summary-item tone-${tone}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function SupplierChangeTable({
  reviewing,
  onReview,
  rows,
  sort,
  onSort,
  toolbar,
  visibleIds,
}: {
  reviewing: string | null;
  onReview: (row: SupplierPriceChangeRow) => void;
  rows: SupplierPriceChangeRow[];
  sort: { id: PriceChangeSortBy; direction: "asc" | "desc" };
  onSort: (id: PriceChangeSortBy, direction?: "asc" | "desc") => void;
  toolbar: ReactNode;
  visibleIds: PriceChangeSortBy[];
}) {
  const columns = priceChangeColumns.filter((c) => visibleIds.includes(c.id));
  const [columnWidths, setColumnWidths] = useStoredColumnWidths(
    "danetti:price-changes:column-widths",
    priceChangeColumns
  );
  const {
    tableRef,
    totalTableWidth: totalWidth,
    columnWidths: layoutWidths,
    setColumnWidths: commitLayoutWidths,
  } = useSheetLayout(columns, columnWidths, setColumnWidths);
  const beginColumnResize = useColumnResize(layoutWidths, commitLayoutWidths, priceChangeColumns);
  return (
    <section className="card table-card supplier-changes-table-card">
      {toolbar}
      {columns.length ? (
        <div className="table-scroll">
          <table
            ref={tableRef}
            className="table data-table data-table--wide supplier-changes-table data-table--sheet"
            style={{ width: totalWidth, minWidth: totalWidth }}
          >
            <colgroup>
              {columns.map((column) => (
                <col key={column.id} style={{ width: layoutWidths[column.id] }} />
              ))}
            </colgroup>
            <thead>
              <tr>
                {columns.map((column) => (
                  <th
                    key={column.id}
                    className={`resizable-header ${column.numeric ? "numeric" : ""}`}
                    aria-sort={
                      sort.id === column.id
                        ? sort.direction === "asc"
                          ? "ascending"
                          : "descending"
                        : "none"
                    }
                  >
                    <SortButton
                      label={column.label}
                      direction={sort.id === column.id ? sort.direction : undefined}
                      onClick={() => onSort(column.id)}
                    />
                    <ColumnResizer
                      label={column.label}
                      width={layoutWidths[column.id]}
                      minWidth={column.minWidth}
                      onResize={(event) => beginColumnResize(column.id, event)}
                      onWidth={(width) =>
                        commitLayoutWidths((current) => ({ ...current, [column.id]: width }))
                      }
                    />
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.newSnapshotId}>
                  {columns.map((column) => (
                    <td key={column.id} className={column.numeric ? "numeric" : "cell-wrap"}>
                      {renderChangeValue(row, column.id)}
                      {column.id === "reviewStatusLabel" &&
                        row.eventId &&
                        row.reviewStatus !== "superseded" && (
                          <>
                            {row.baselineSource === "first_seen" && (
                              <span className="muted-cell">Áralap: első megtekintés</span>
                            )}
                            {row.resolvedAt && row.reviewStatus === "resolved" && (
                              <span className="muted-cell">{formatDate(row.resolvedAt)}</span>
                            )}
                            <div className="supplier-review-actions">
                              <button
                                className="button secondary"
                                disabled={reviewing !== null}
                                onClick={() => onReview(row)}
                              >
                                {reviewing === row.eventId
                                  ? "Mentés…"
                                  : row.reviewStatus === "resolved"
                                    ? "Újranyitás"
                                    : "Lezárás"}
                              </button>
                            </div>
                          </>
                        )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState title="Válassz legalább egy oszlopot">
          A táblázat fejlécében, az Oszlopok és nyomtatás résznél visszakapcsolhatod az oszlopokat.
        </EmptyState>
      )}
    </section>
  );
}

function renderChangeValue(row: SupplierPriceChangeRow, id: PriceChangeSortBy) {
  switch (id) {
    case "oldSupplierNetEur":
    case "newSupplierNetEur":
      return formatEur(row[id]);
    case "supplierChangePercent":
      return (
        <span className={row.supplierChangeEur > 0 ? "text-warning" : "text-success"}>
          {formatPercent(row[id])}
          <span className="muted-cell">{formatHuf(row.supplierChangeHuf)}</span>
        </span>
      );
    case "currentWooPriceHuf":
      return (
        <>
          {formatHuf(row[id])}
          <span className="muted-cell">{labelWooSource(row.currentWooPriceSource)}</span>
        </>
      );
    case "currentProfitPercentWithNewCost":
    case "preservedProfitPercent":
    case "appliedProfitPercent":
      return formatPercent(row[id]);
    case "suggestedGrossPriceRoundedHuf":
      return <strong>{formatHuf(row[id])}</strong>;
    case "suggestedPriceDeltaHuf":
      return formatSignedHuf(row[id]);
    case "newObservedAt":
    case "changeObservedAt":
    case "lastCheckedAt":
      return row[id] ? formatDate(row[id]!) : "-";
    default:
      return row[id] ?? "-";
  }
}

function readNumberInput(value: string): number | "" {
  if (value.trim() === "") return "";
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : "";
}

function readOptionalNumber(value: number | ""): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function formatCount(value: number): string {
  return value.toLocaleString("hu-HU");
}

function formatEur(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "-";
  return `${value.toLocaleString("hu-HU", { maximumFractionDigits: 4 })} EUR`;
}

function formatHuf(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "-";
  return `${Math.round(value).toLocaleString("hu-HU")} Ft`;
}

function formatSignedHuf(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "-";
  const prefix = value > 0 ? "+" : "";
  return `${prefix}${Math.round(value).toLocaleString("hu-HU")} Ft`;
}

function formatPercent(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return "-";
  return `${value.toLocaleString("hu-HU", { maximumFractionDigits: 2 })}%`;
}

function labelWooSource(source: SupplierPriceChangeRow["currentWooPriceSource"]): string {
  if (source === "currentPrice") return "aktuális ár";
  if (source === "salePrice") return "akciós ár";
  if (source === "regularPrice") return "normál ár";
  return "nincs Woo ár";
}
