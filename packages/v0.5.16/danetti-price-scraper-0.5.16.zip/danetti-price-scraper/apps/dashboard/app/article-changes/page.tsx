"use client";

import { isSupplierRunActive, supplierRunStatusLabels } from "@danetti/shared";

import { useEffect, useMemo, useState } from "react";
import {
  compareTableValues,
  labelArticleChangeItem,
  type SupplierArticleChangeItem,
  type SupplierArticleChangesState,
} from "@danetti/shared";
import {
  getSupplierArticleChanges,
  checkSupplierArticleChanges,
  cancelSupplierArticleChanges,
  reviewSupplierArticleChange,
  formatApiErrorMessage,
} from "../../src/lib/api";
import {
  ColumnResizer,
  SortButton,
  useColumnResize,
  useSheetLayout,
  useStoredColumnWidths,
} from "../../src/components/SheetHeader";
import { TablePagination } from "../../src/components/TablePagination";
import { CatalogTableToolbar } from "../../src/components/CatalogTableToolbar";
import { defaultTablePrintOptions, exportColumnLabel } from "../../src/products/table-print";
import {
  articleChangeColumns as columns,
  buildArticleChangesCsv,
  buildArticleChangesPrint,
  type ArticleChangeColumn as Column,
} from "../../src/products/article-changes-export";
import styles from "./page.module.css";

type Scope = "changes" | "discontinued" | "missing" | "all";
const scopes: { id: Scope; label: string }[] = [
  { id: "changes", label: "Cikkszámváltozások" },
  { id: "discontinued", label: "Megszűnt / nem rendelhető" },
  { id: "missing", label: "Hiányzó oldal" },
  { id: "all", label: "Összes" },
];
const inScope = (item: SupplierArticleChangeItem, scope: Scope) =>
  scope === "all" ||
  (scope === "discontinued" && item.status === "discontinued") ||
  (scope === "missing" && item.status === "missing") ||
  (scope === "changes" && item.status !== "discontinued" && item.status !== "missing");
const amount = (value: number | null, unit: string) =>
  value === null
    ? "—"
    : `${new Intl.NumberFormat("hu-HU", { maximumFractionDigits: 2 }).format(value)} ${unit}`;
const activeJob = isSupplierRunActive;
const reviewId = (item: SupplierArticleChangeItem) => `${item.supplier}:${item.catalogProductId}`;
const jobLabel: Record<string, string> = supplierRunStatusLabels;

export default function ArticleChangesPage() {
  const [data, setData] = useState<SupplierArticleChangesState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [requesting, setRequesting] = useState(false);
  const [reload, setReload] = useState(0);
  const [scope, setScope] = useState<Scope>("changes");
  const [supplier, setSupplier] = useState<"all" | "dvg" | "lf">("all");
  const [reviewView, setReviewView] = useState<"active" | "closed">("active");
  const [reviewNotice, setReviewNotice] = useState("");
  const viewItems = reviewView === "closed" ? (data?.closedItems ?? []) : (data?.items ?? []);
  const [query, setQuery] = useState("");
  const [pricedOnly, setPricedOnly] = useState(false);
  const [speed, setSpeed] = useState<"normal" | "fast" | "very_fast">("very_fast");
  const [offset, setOffset] = useState(0);
  const [visibleIds, setVisibleIds] = useState<Column[]>(columns.map((column) => column.id));
  const [printOptions, setPrintOptions] = useState(defaultTablePrintOptions);
  const [exporting, setExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState("");
  const visibleColumns = columns.filter((column) => visibleIds.includes(column.id));
  const [sort, setSort] = useState<{ id: Column; direction: "asc" | "desc" }>({
    id: "originalArticle",
    direction: "asc",
  });
  const [widths, setWidths] = useStoredColumnWidths<Column>(
    "danetti-dvg-article-changes-widths",
    columns
  );
  const {
    tableRef,
    totalTableWidth,
    columnWidths: layoutWidths,
    setColumnWidths: commitLayoutWidths,
  } = useSheetLayout(visibleColumns, widths, setWidths);
  const onResize = useColumnResize(layoutWidths, commitLayoutWidths, columns);
  const running = activeJob(data?.job?.status);
  useEffect(() => {
    let alive = true;
    const controller = new AbortController();
    const load = async () => {
      try {
        const next = await getSupplierArticleChanges(controller.signal);
        if (alive) {
          setData(next);
          setError(null);
        }
      } catch (cause) {
        if (alive) setError(formatApiErrorMessage(cause));
      } finally {
        if (alive) setLoading(false);
      }
    };
    void load();
    const timer = running ? setInterval(() => void load(), 5000) : null;
    return () => {
      alive = false;
      controller.abort();
      if (timer) clearInterval(timer);
    };
  }, [running, reload]);
  useEffect(() => {
    const refresh = () => setReload((value) => value + 1);
    const visible = () => {
      if (document.visibilityState === "visible") refresh();
    };
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", visible);
    return () => {
      window.removeEventListener("focus", refresh);
      document.removeEventListener("visibilitychange", visible);
    };
  }, []);
  const filtered = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase("hu");
    return viewItems
      .filter(
        (item) =>
          inScope(item, scope) &&
          (supplier === "all" || item.supplier === supplier) &&
          (!pricedOnly || item.priceEur !== null) &&
          (!needle ||
            [item.wooSku, item.wooName, item.originalArticle, item.newArticle ?? ""].some((value) =>
              value.toLocaleLowerCase("hu").includes(needle)
            ))
      )
      .sort(
        (a, b) =>
          compareTableValues(
            sort.id === "status" ? labelArticleChangeItem(a) : a[sort.id],
            sort.id === "status" ? labelArticleChangeItem(b) : b[sort.id],
            sort.direction
          ) || compareTableValues(a.wooSku, b.wooSku, "asc")
      );
  }, [data, scope, query, pricedOnly, sort, supplier, reviewView]);
  const page = filtered.slice(offset, offset + 50);
  useEffect(() => setOffset(0), [scope, query, pricedOnly, sort, supplier, reviewView]);
  useEffect(
    () =>
      setOffset((current) =>
        Math.min(current, Math.max(0, Math.floor((filtered.length - 1) / 50) * 50))
      ),
    [filtered.length]
  );
  const perform = async (ids?: string[]) => {
    setRequesting(true);
    setError(null);
    try {
      setData(
        ids ? await checkSupplierArticleChanges(ids, speed) : await cancelSupplierArticleChanges()
      );
      setReload((value) => value + 1);
    } catch (cause) {
      setError(formatApiErrorMessage(cause));
    } finally {
      setRequesting(false);
    }
  };

  const exportRows = async (mode: "csv" | "print") => {
    if (exporting || !filtered.length || !visibleIds.length) return;
    const rows = [...filtered];
    const selectedIds = [...visibleIds];
    const printWindow = mode === "print" ? window.open("", "_blank") : null;
    if (mode === "print" && !printWindow) {
      setExportStatus("Engedélyezd a felugró ablakot a nyomtatáshoz.");
      return;
    }
    setExporting(true);
    setExportStatus("");
    try {
      if (printWindow) {
        printWindow.document.open();
        printWindow.document.write(buildArticleChangesPrint(rows, selectedIds, printOptions));
        printWindow.document.close();
        await printWindow.document.fonts.ready;
        printWindow.focus();
        printWindow.print();
      } else {
        const url = URL.createObjectURL(
          new Blob([buildArticleChangesCsv(rows, selectedIds)], { type: "text/csv;charset=utf-8" })
        );
        const link = document.createElement("a");
        link.href = url;
        link.download = "cikkszamvaltozasok.csv";
        link.click();
        URL.revokeObjectURL(url);
      }
      setExportStatus(
        `${rows.length} sor, ${selectedIds.length} oszlop ${mode === "csv" ? "exportálva" : "nyomtatásra előkészítve"}.`
      );
    } catch {
      printWindow?.close();
      setExportStatus("Az export nem sikerült. Próbáld újra a lista frissítése után.");
    } finally {
      setExporting(false);
    }
  };

  const cell = (item: SupplierArticleChangeItem, id: Column) => {
    if (id === "supplier") return item.supplier.toUpperCase();
    if (id === "status")
      return (
        <>
          <strong className={item.priceEur !== null ? styles.success : undefined}>
            {labelArticleChangeItem(item)}
          </strong>
          <p className={styles.rowNote}>
            {item.resolution
              ? new Date(item.resolution.resolvedAt).toLocaleString("hu-HU")
              : reason(item)}
          </p>
          <div className="supplier-review-actions">
            {!item.resolution && (
              <button
                className="button secondary small"
                disabled={running || requesting}
                onClick={() => void perform([reviewId(item)])}
              >
                Ellenőrzés
              </button>
            )}
            <button
              className="button secondary small"
              disabled={running || requesting}
              onClick={async () => {
                setRequesting(true);
                setError(null);
                try {
                  setData(
                    await reviewSupplierArticleChange(
                      reviewId(item),
                      item.originalArticle,
                      item.resolution ? "open" : "resolved"
                    )
                  );
                  setReviewNotice(
                    item.resolution
                      ? "A tétel újra a teendők között van."
                      : "Tétel lezárva. A Lezártak nézetben elérhető."
                  );
                } catch (error) {
                  setError(formatApiErrorMessage(error));
                } finally {
                  setRequesting(false);
                }
              }}
            >
              {item.resolution ? "Újranyitás" : "Lezárás"}
            </button>
          </div>
        </>
      );
    if (id === "originalArticle")
      return item.originalUrl ? (
        <a className={styles.articleLink} href={item.originalUrl} target="_blank" rel="noreferrer">
          {item.originalArticle}
          <span>Régi termékoldal</span>
        </a>
      ) : (
        item.originalArticle
      );
    if (id === "newArticle")
      return item.newArticle && item.newUrl ? (
        <a className={styles.articleLink} href={item.newUrl} target="_blank" rel="noreferrer">
          {item.newArticle}
          <span>Utód megnyitása</span>
        </a>
      ) : (
        <span className={styles.muted}>{item.newArticle ?? "Még nincs igazolt utód"}</span>
      );
    if (id === "priceEur")
      return (
        <>
          <strong>{amount(item.priceEur, "EUR")}</strong>
          {item.priceEur !== null && (
            <span className={styles.rowNote}>
              {item.supplier === "dvg" ? "Kék darabár" : "LF nettó darabár"} · legkisebb mennyiség
            </span>
          )}
        </>
      );
    if (id === "priceHuf" || id === "wooGrossHuf" || id === "eurHufRate")
      return amount(item[id], "Ft");
    if (id === "profitPercent" || id === "profitNetHuf")
      return (
        <span
          className={
            item.profitPercent !== null && item.profitPercent < 0 ? styles.negative : undefined
          }
        >
          <strong>{amount(item[id], id === "profitPercent" ? "%" : "Ft")}</strong>
        </span>
      );
    if (id === "checkedAt")
      return item.checkedAt ? (
        <>
          <time dateTime={item.checkedAt}>{new Date(item.checkedAt).toLocaleString("hu-HU")}</time>
        </>
      ) : item.resolution ? (
        "—"
      ) : (
        "Még nem ellenőrzött"
      );
    return item[id];
  };
  return (
    <div className={`page ${styles.page}`}>
      <header className="page-header">
        <h1 className="page-title">Cikkszámváltozások</h1>
        <a className="button secondary" href="/operator/dvg">
          DVG operátor
        </a>
        <a className="button secondary" href="/operator/lf">
          LF operátor
        </a>
      </header>
      <section className={`card ${styles.controls}`} aria-label="Utódcikkek ellenőrzése">
        <div className={styles.intro}>
          <div>
            <h2>Régi cikkszámból ellenőrzött utódcikk</h2>
            <p>
              A DVG és az LF igazolt utódhivatkozását vagy cikkszámcseréjét követjük. Árat és
              profitot csak a pontos új cikkszám és a saját nettó darabár ellenőrzése után mutatunk.
              DVG-nél a kék ár a mérvadó.
            </p>
          </div>
          <label className="field-label">
            Sebesség
            <select
              className="input"
              value={speed}
              disabled={running || requesting}
              onChange={(event) => setSpeed(event.target.value as typeof speed)}
            >
              <option value="normal">Normál</option>
              <option value="fast">Gyors</option>
              <option value="very_fast">Nagyon gyors</option>
            </select>
          </label>
        </div>
        <div className={styles.actions}>
          <button
            className="button"
            disabled={
              running ||
              requesting ||
              !filtered.length ||
              filtered.length > 500 ||
              reviewView === "closed"
            }
            onClick={() => void perform(filtered.map(reviewId))}
          >
            {requesting ? "Művelet folyamatban…" : `Szűrt tételek ellenőrzése (${filtered.length})`}
          </button>
          {running && (
            <button
              className="button secondary"
              disabled={requesting}
              onClick={() => void perform()}
            >
              Ellenőrzés leállítása
            </button>
          )}
          <button
            className="button ghost"
            disabled={requesting}
            onClick={() => setReload((value) => value + 1)}
          >
            Lista frissítése
          </button>
        </div>
        <p className={styles.explanation}>
          A profit% a nettó profit és a nettó beszerzési ár aránya. A számításhoz a helyi katalógus
          eladási árát és az ellenőrzéskori EUR/HUF árfolyamot használjuk.
        </p>
        <p className={styles.explanation}>
          A tételt a Lezárás gomb vagy az azonos WooCommerce-termék új cikkszámát igazoló sikeres
          CSV-import zárja le. A többi tétel megmarad. A lezártak külön nézetben elérhetők és
          újranyithatók.
        </p>
        {data?.job && (
          <div className={styles.progress} role="status">
            <strong>{jobLabel[data.job.status] ?? "Ellenőrzés megszakadt"}</strong>
            {data.job.supplier && <span>{data.job.supplier.toUpperCase()}</span>}
            <span>
              {data.job.checked} / {data.job.total} termék
            </span>
            {running && (
              <progress
                value={data.job.checked}
                max={data.job.total}
                aria-label="Utódcikkek feldolgozása"
              />
            )}
            {data.job.currentArticle && <span>{data.job.currentArticle}</span>}
            {data.job.status === "waiting_for_manual_login" && (
              <p>
                A Managerben a „
                {data.job.supplier === "lf" ? "Danetti LF 724" : "Danetti DVG New Shop"}” profilba
                jelentkezz be. Az ellenőrzés utána folytatódik.
              </p>
            )}
            {data.job.message && <p>{data.job.message}</p>}
          </div>
        )}
      </section>
      {error && (
        <div className="notice error" role="alert">
          <p>{error}</p>
          <button className="button secondary" onClick={() => setReload((value) => value + 1)}>
            Újrapróbálás
          </button>
        </div>
      )}
      {reviewNotice && (
        <p className="notice" role="status">
          {reviewNotice}
        </p>
      )}
      <section
        className={`card table-card ${styles.results}`}
        aria-label="Cikkszámváltozások eredményei"
      >
        <nav className={styles.scopes} aria-label="Termékállapot szűrése">
          {scopes.map((tab) => (
            <button
              key={tab.id}
              className={`button ${scope === tab.id ? "" : "secondary"}`}
              aria-pressed={scope === tab.id}
              onClick={() => setScope(tab.id)}
            >
              {tab.label}
              <span>
                {viewItems.filter(
                  (item) =>
                    inScope(item, tab.id) && (supplier === "all" || item.supplier === supplier)
                ).length ?? 0}
              </span>
            </button>
          ))}
        </nav>
        <div className={styles.filters}>
          <label className="field-label">
            Nézet
            <select
              className="input"
              value={reviewView}
              onChange={(event) => setReviewView(event.target.value as typeof reviewView)}
            >
              <option value="active">Teendők</option>
              <option value="closed">Lezártak ({data?.closedItems?.length ?? 0})</option>
            </select>
          </label>
          <label className="field-label">
            Beszállító
            <select
              className="input"
              value={supplier}
              onChange={(event) => setSupplier(event.target.value as typeof supplier)}
            >
              <option value="all">DVG és LF</option>
              <option value="dvg">DVG</option>
              <option value="lf">LF</option>
            </select>
          </label>
          <label className="field-label">
            Keresés termékre vagy cikkszámra
            <input
              className="input"
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </label>
          <label className={styles.checkbox}>
            <input
              type="checkbox"
              checked={pricedOnly}
              onChange={(event) => setPricedOnly(event.target.checked)}
            />
            Csak érvényes árral
          </label>
        </div>
        <CatalogTableToolbar
          columns={columns.map((column) => ({ ...column, label: exportColumnLabel(column) }))}
          selectedIds={visibleIds}
          onSelectionChange={setVisibleIds}
          total={filtered.length}
          orderLabel={`${exportColumnLabel(columns.find((column) => column.id === sort.id)!)} · ${sort.direction === "asc" ? "növekvő" : "csökkenő"}`}
          printOptions={printOptions}
          onPrintOptionsChange={setPrintOptions}
          busy={exporting}
          disabled={loading}
          status={exportStatus}
          onCsv={() => void exportRows("csv")}
          onPrint={() => void exportRows("print")}
          pagination={
            <TablePagination
              canGoBack={offset > 0}
              canGoNext={offset + 50 < filtered.length}
              label={`${filtered.length ? offset + 1 : 0}–${Math.min(offset + 50, filtered.length)} / ${filtered.length} termék`}
              onBack={() => setOffset(Math.max(0, offset - 50))}
              onNext={() => setOffset(offset + 50)}
              compact
            />
          }
        />
        {loading ? (
          <p role="status">Cikkszámváltozások betöltése…</p>
        ) : !filtered.length ? (
          <div className={styles.empty}>
            <h2>
              {data?.items.length
                ? "Nincs a szűrésnek megfelelő termék"
                : "Még nincs ellenőrizendő cikkszámváltozás"}
            </h2>
            <p>
              {data?.items.length
                ? "Módosítsd a keresést vagy a termékállapot szűrését."
                : "A DVG vagy LF futása után itt jelennek meg az átkódolt és nem rendelhető termékek."}
            </p>
          </div>
        ) : (
          <>
            {!visibleColumns.length && (
              <p className={styles.explanation}>
                Válassz oszlopokat az „Oszlopok és nyomtatás” panelen.
              </p>
            )}
            {visibleColumns.length > 0 && (
              <div className="table-scroll">
                <table
                  ref={tableRef}
                  className="table data-table data-table--wide data-table--sheet"
                  style={{
                    width: totalTableWidth,
                    minWidth: totalTableWidth,
                    tableLayout: "fixed",
                  }}
                >
                  <colgroup>
                    {visibleColumns.map((column) => (
                      <col key={column.id} style={{ width: layoutWidths[column.id] }} />
                    ))}
                  </colgroup>
                  <thead>
                    <tr>
                      {visibleColumns.map((column) => (
                        <th
                          key={column.id}
                          scope="col"
                          aria-sort={
                            sort.id === column.id
                              ? sort.direction === "asc"
                                ? "ascending"
                                : "descending"
                              : "none"
                          }
                        >
                          <SortButton
                            label={exportColumnLabel(column)}
                            direction={sort.id === column.id ? sort.direction : undefined}
                            onClick={() =>
                              setSort({
                                id: column.id,
                                direction:
                                  sort.id === column.id && sort.direction === "asc"
                                    ? "desc"
                                    : "asc",
                              })
                            }
                          />
                          <ColumnResizer
                            label={exportColumnLabel(column)}
                            width={layoutWidths[column.id]}
                            minWidth={column.minWidth}
                            onResize={(event) => onResize(column.id, event)}
                            onWidth={(value) =>
                              commitLayoutWidths((previous) => ({
                                ...previous,
                                [column.id]: value,
                              }))
                            }
                          />
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {page.map((item) => (
                      <tr key={`${reviewId(item)}:${item.originalArticle}`}>
                        {visibleColumns.map((column) => (
                          <td key={column.id}>{cell(item, column.id)}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </section>
    </div>
  );
}

function reason(item: SupplierArticleChangeItem) {
  if (item.status === "priced")
    return item.productName ?? "Pontos új cikkszám és ellenőrzött alapár.";
  if (item.status === "discontinued")
    return `A ${item.supplier.toUpperCase()} nem rendelhetőnek jelöli; nincs elfogadott ár.`;
  if (item.status === "missing")
    return "A hiányzó oldal önmagában nem igazolja a termék megszűnését.";
  if (
    item.warnings.includes("dvg_replacement_cycle") ||
    item.warnings.includes("lf_replacement_cycle")
  )
    return "Az utódcikkek hivatkozása körbeér. Kézi ellenőrzés szükséges.";
  if (item.warnings.includes("dvg_price_confirmation_required")) return "A DVG ármegerősítést kér.";
  if (item.status === "needs_review")
    return "Nincs egyértelmű, pontos cikkszámmal igazolt utódcikk.";
  if (item.status === "pending") return "Az utód oldalát még ellenőrizni kell.";
  if (item.status === "failed") return "Az ellenőrzés újraindítható; árat nem fogadtunk el.";
  return "";
}
