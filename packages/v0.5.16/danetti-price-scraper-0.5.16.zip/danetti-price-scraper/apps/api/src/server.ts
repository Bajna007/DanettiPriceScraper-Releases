import { isIP } from "node:net";
import cors from "@fastify/cors";
import Fastify from "fastify";
import { registerAppUpdateRoutes } from "./modules/app-update/app-update.routes.js";
import { registerCatalogImportRoutes } from "./modules/catalog-import/catalog-import.routes.js";
import { registerCheckRoutes } from "./modules/checks/checks.routes.js";
import { registerConnectorRoutes } from "./modules/connectors/connectors.routes.js";
import { registerDvgDiagramRoutes } from "./modules/dvg-diagrams/dvg-diagrams.routes.js";
import { registerDvgProductsRoutes } from "./modules/dvg-products/dvg-products.routes.js";
import { registerSupplierArticleChangesRoutes } from "./modules/dvg-article-changes/article-changes.routes.js";
import { registerLfProductsRoutes } from "./modules/lf-products/lf-products.routes.js";
import { registerLabelRoutes } from "./modules/labels/labels.routes.js";
import { registerLocalDatabaseRoutes } from "./modules/local-database/local-database.routes.js";
import { registerRuntimeHealthRoutes } from "./modules/health/runtime-health.routes.js";
import { registerPricingSettingsRoutes } from "./modules/pricing-settings/pricing-settings.routes.js";
import { registerSetupRoutes } from "./modules/setup/setup.routes.js";
import { registerSupplierCredentialRoutes } from "./modules/supplier-credentials/supplier-credentials.routes.js";
import { registerSupplierMappingRoutes } from "./modules/supplier-mappings/supplier-mappings.routes.js";
import { registerSupplierPriceChangeRoutes } from "./modules/supplier-price-changes/supplier-price-changes.routes.js";
import { registerSupplierSessionRoutes } from "./modules/supplier-sessions/supplier-sessions.routes.js";
import { registerSupplierSnapshotRoutes } from "./modules/supplier-snapshots/supplier-snapshots.routes.js";
import { registerSupplierPortalAuditRoutes } from "./modules/supplier-portal-audits/supplier-portal-audits.routes.js";
import { registerSupplierRoutes } from "./modules/suppliers/suppliers.routes.js";
import { loadLocalEnv } from "./config/env.js";
import { registerEprRoutes } from "./modules/epr/epr.routes.js";

export function buildServer(options: { logger?: boolean } = {}) {
  loadLocalEnv();

  const server = Fastify({
    logger: options.logger ?? true,
  });

  server.addHook("onRequest", async (request, reply) => {
    if (isLoopbackIp(request.ip)) return;
    return reply.code(403).send({
      error: {
        code: "api_local_only",
        message: "Danetti API is local-only. Use http://localhost:4000 from this machine.",
      },
    });
  });

  server.get("/health", async () => ({
    status: "ok",
    service: "api",
  }));

  server.register(cors, {
    origin: (origin, callback) =>
      callback(null, origin === undefined || isAllowedLocalOrigin(origin)),
    methods: ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  });

  server.register(registerCatalogImportRoutes);
  server.register(registerEprRoutes);
  server.register(registerAppUpdateRoutes);
  server.register(registerCheckRoutes);
  server.register(registerConnectorRoutes);
  server.register(registerDvgDiagramRoutes);
  server.register(registerDvgProductsRoutes);
  server.register(registerSupplierArticleChangesRoutes);
  server.register(registerLfProductsRoutes);
  server.register(registerLabelRoutes);
  server.register(registerLocalDatabaseRoutes);
  server.register(registerRuntimeHealthRoutes);
  server.register(registerPricingSettingsRoutes);
  server.register(registerSetupRoutes);
  server.register(registerSupplierRoutes);
  server.register(registerSupplierCredentialRoutes);
  server.register(registerSupplierMappingRoutes);
  server.register(registerSupplierPriceChangeRoutes);
  server.register(registerSupplierSessionRoutes);
  server.register(registerSupplierSnapshotRoutes);
  server.register(registerSupplierPortalAuditRoutes);

  return server;
}

function isAllowedLocalOrigin(origin: string): boolean {
  try {
    const url = new URL(origin);
    return (
      url.protocol === "http:" &&
      url.port === "3000" &&
      (url.hostname === "localhost" ||
        url.hostname === "127.0.0.1" ||
        url.hostname === "::1" ||
        url.hostname === "[::1]")
    );
  } catch {
    return false;
  }
}

function isLoopbackIp(value: string): boolean {
  const normalized = value.toLowerCase();
  if (normalized === "::1" || normalized === "0:0:0:0:0:0:0:1") return true;

  const ipv4 = normalized.startsWith("::ffff:") ? normalized.slice("::ffff:".length) : normalized;
  return isIP(ipv4) === 4 && ipv4.startsWith("127.");
}
