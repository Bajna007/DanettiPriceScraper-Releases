import assert from "node:assert/strict";
import Fastify from "fastify";
import {
  calculateDvgManualBatchPricing,
  type DvgManualBatchState,
  type DvgManualBatchRow,
  type DvgManualBatchSettings,
  type DvgManualBatchCandidate,
} from "@danetti/connectors";
import type { SupplierArticleChangesState } from "@danetti/shared";
import {
  DvgArticleChangesService,
  articleChangeResult,
  type ReviewRunnerFactory,
} from "./dvg-article-changes.service.js";
import { registerDvgArticleChangesRoutes } from "./dvg-article-changes.routes.js";
import type { ArticleChangesRepository } from "./dvg-article-changes.repository.js";
import { acquireDvgSession, releaseDvgSession } from "../dvg-products/dvg-session-lock.js";

const id = "11111111-1111-4111-8111-111111111111";
const settings = {
  shopMode: "new_shop",
  speedMode: "very_fast",
  eurHufRate: 300,
  vatPercent: 27,
  wooPricesIncludeVat: true,
  markupPercent: 0,
  limit: 10,
  offset: 0,
  onlyMappedDvg: true,
  rerunPreviousNonOkOnly: false,
  allowSuggestedDvgArticle: false,
  allowSkuPrefixCandidate: false,
  dryRun: true,
  allowSnapshotWrite: false,
  itemTimeoutMs: 30000,
  detailFetchTimeoutMs: 10000,
  fallbackNavigationTimeoutMs: 20000,
  recoverAfterConsecutiveTimeouts: 0,
} satisfies DvgManualBatchSettings;
const candidate: DvgManualBatchCandidate = {
  catalogProductId: id,
  wooSku: "OLD123_X",
  wooName: "Test product",
  supplierArticleNumber: "OLD123",
  supplierId: "dvg",
  supplierMappingId: "original-mapping",
  candidateSource: "saved_mapping",
  matchConfidence: "saved_mapping",
  currentPrice: 15240,
  regularPrice: null,
  salePrice: null,
};
const originalUrl = "https://shop.dvgdevecchi.com/e-commerce/item-details/OLD123";
const newUrl = "https://shop.dvgdevecchi.com/e-commerce/item-details/NEW123";
const priced = {
  ...candidate,
  ...calculateDvgManualBatchPricing({
    ...candidate,
    supplierNetEur: 25,
    eurHufRate: 400,
    vatPercent: 27,
    wooPricesIncludeVat: true,
    markupPercent: 0,
  }),
  status: "ok",
  supplierArticleNumber: "NEW123",
  supplierMappingId: null,
  dvgDetailUrl: newUrl,
  dvgArticle: "NEW123",
  dvgProductName: "Successor",
  dvgOriginalCode: null,
  supplierNetEur: 25,
  supplierCrossedEur: 50,
  currency: "EUR",
  unit: "pz",
  eurHufRate: 400,
  markupPercent: 0,
  vatPercent: 27,
  matchConfidence: "exact_dvg_article",
  warnings: [],
  priceBasis: "blue_unit_price_lowest_quantity",
  replacementChain: [
    { article: "OLD123", url: originalUrl },
    { article: "NEW123", url: newUrl },
  ],
} satisfies DvgManualBatchRow;
const oldRow = {
  ...priced,
  status: "article_changed",
  supplierArticleNumber: "OLD123",
  supplierNetEur: null,
} satisfies DvgManualBatchRow;
const source = {
  runId: "original-run",
  status: "completed",
  completedAt: new Date().toISOString(),
  settings,
  rows: [
    oldRow,
    {
      ...oldRow,
      catalogProductId: "22222222-2222-4222-8222-222222222222",
      supplierArticleNumber: "OLD456",
      status: "item_not_available",
    },
    {
      ...oldRow,
      catalogProductId: "33333333-3333-4333-8333-333333333333",
      supplierArticleNumber: "OLD789",
      status: "article_not_found",
    },
  ],
} as unknown as DvgManualBatchState;
let saved: SupplierArticleChangesState | null = null;
const repository: ArticleChangesRepository = {
  load: async () => saved,
  save: async (state) => {
    saved = structuredClone(state);
  },
  source: async () => source,
  candidates: async () => [candidate],
  exchangeRate: async () => 400,
};
let lookups = 0;
const factory: ReviewRunnerFactory = (callbacks) => ({
  async openBrowser() {
    callbacks.onStatus?.("waiting_for_manual_login");
  },
  async waitForManualLogin() {
    return true;
  },
  async runCandidates(work, input) {
    lookups++;
    assert.equal(input.followReplacements, true);
    assert.equal(input.eurHufRate, 400);
    assert.equal(input.dryRun, true);
    assert.equal(input.allowSnapshotWrite, false);
    assert.equal(work[0]?.supplierMappingId, "original-mapping");
    callbacks.onStatus?.("running");
    callbacks.onRow?.(priced);
    callbacks.onStatus?.("completed");
  },
  async cancel() {
    callbacks.onStatus?.("cancelled");
  },
  async close() {},
});
const service = new DvgArticleChangesService(repository, factory);
const seeded = await service.list();
assert.deepEqual(
  seeded.items.map((item) => item.status),
  ["pending", "discontinued", "missing"]
);
assert.equal(lookups, 0); // Listing never contacts the supplier.
await service.start([id]);
await service.settled();
const result = await service.list();
assert.equal(result.job?.status, "completed");
assert.equal(result.job?.checked, 1);
assert.equal(result.items[0]?.status, "priced");
assert.equal(result.items[0]?.originalArticle, "OLD123");
assert.equal(result.items[0]?.newArticle, "NEW123");
assert.equal(result.items[0]?.priceEur, 25);
assert.equal(result.items[0]?.profitPercent, 20);
assert.equal(result.items[0]?.profitNetHuf, 2000);
assert.equal(candidate.supplierMappingId, "original-mapping");
assert.equal(candidate.supplierArticleNumber, "OLD123");
assert.equal(source.settings.eurHufRate, 300);
const original = seeded.items[0]!;
for (const bad of [
  { ...priced, dvgArticle: "WRONG123" },
  { ...priced, currency: "USD" },
  { ...priced, supplierNetEur: 0 },
  { ...priced, status: "article_changed" as const },
  {
    ...priced,
    replacementChain: [
      { article: "UNRELATED123", url: originalUrl },
      { article: "NEW123", url: newUrl },
    ],
  },
  {
    ...priced,
    replacementChain: [
      { article: "OLD123", url: originalUrl },
      { article: "NEW123", url: "https://evil.invalid/e-commerce/item-details/NEW123" },
    ],
  },
]) {
  const item = articleChangeResult(original, bad);
  assert.equal(item.priceEur, null);
  assert.equal(item.profitPercent, null);
}
assert.equal(
  articleChangeResult(original, { ...priced, status: "item_not_available" }).status,
  "discontinued"
);
assert.equal(
  articleChangeResult(original, { ...priced, status: "article_not_found" }).status,
  "missing"
);
assert.equal(
  articleChangeResult(original, { ...priced, status: "price_missing" }).status,
  "unpriced"
);
assert.ok(acquireDvgSession("other-dvg-run"));
await assert.rejects(service.start([id]), /Másik DVG futás/);
releaseDvgSession("other-dvg-run");
const restarted = new DvgArticleChangesService(
  { ...repository, load: async () => ({ ...result, job: { ...result.job!, status: "running" } }) },
  factory
);
assert.equal((await restarted.list()).job?.status, "interrupted");

const app = Fastify();
await registerDvgArticleChangesRoutes(app, { service });
assert.equal((await app.inject({ url: "/dvg-article-changes" })).statusCode, 403);
const headers = { "x-danetti-local-lab": "true" };
assert.equal(
  (
    await app.inject({
      url: "/dvg-article-changes",
      headers: { ...headers, origin: "https://evil.invalid" },
    })
  ).statusCode,
  403
);
for (const payload of [
  { catalogProductIds: [] },
  { catalogProductIds: [id, id] },
  { url: newUrl },
  { password: "never" },
  { speedMode: "unlimited" },
])
  assert.equal(
    (await app.inject({ method: "POST", url: "/dvg-article-changes/run", headers, payload }))
      .statusCode,
    400
  );
const routeRun = await app.inject({
  method: "POST",
  url: "/dvg-article-changes/run",
  headers,
  payload: { catalogProductIds: [id], speedMode: "very_fast" },
});
assert.equal(routeRun.statusCode, 202);
await service.settled();
assert.equal(
  (await app.inject({ url: "/dvg-article-changes", headers })).json().items[0].profitPercent,
  20
);
await app.close();
await service.close();
await restarted.close();
assert.ok(acquireDvgSession("after-review"));
releaseDvgSession("after-review");
let releaseCancelled!: () => void;
const cancelGate = new Promise<void>((resolve) => {
  releaseCancelled = resolve;
});
const cancelService = new DvgArticleChangesService(
  { ...repository, load: async () => null, save: async () => {} },
  (callbacks) => ({
    async openBrowser() {
      callbacks.onStatus?.("waiting_for_manual_login");
    },
    async waitForManualLogin() {
      return true;
    },
    async runCandidates() {
      callbacks.onStatus?.("running");
      await cancelGate;
      callbacks.onRow?.(priced);
      callbacks.onStatus?.("session_lost");
    },
    async cancel() {
      releaseCancelled();
    },
    async close() {},
  })
);
await cancelService.start([id]);
await new Promise((resolve) => setImmediate(resolve));
assert.equal(acquireDvgSession("overlapping-normal-run"), false);
await cancelService.cancel();
const cancelled = await cancelService.list();
assert.equal(cancelled.job?.status, "cancelled");
assert.equal(cancelled.job?.checked, 0);
assert.equal(cancelled.items[0]?.priceEur, null);
const failedStart = new DvgArticleChangesService(
  { ...repository, load: async () => null, save: async () => {} },
  () => {
    throw Error("fixture browser failure");
  }
);
await assert.rejects(failedStart.start([id]));
assert.equal((await failedStart.list()).job?.status, "failed");
assert.ok(acquireDvgSession("after-failed-start"));
releaseDvgSession("after-failed-start");
await cancelService.close();
await failedStart.close();
let rejectOpening!: (error: Error) => void;
const opening = new Promise<void>((_resolve, reject) => {
  rejectOpening = reject;
});
const cancelOpening = new DvgArticleChangesService(
  { ...repository, load: async () => null, save: async () => {} },
  () => ({
    openBrowser: async () => opening,
    waitForManualLogin: async () => false,
    runCandidates: async () => {},
    async cancel() {
      rejectOpening(Error("page closed by cancellation"));
    },
    async close() {},
  })
);
await cancelOpening.start([id]);
await cancelOpening.cancel();
assert.equal((await cancelOpening.list()).job?.status, "cancelled");
assert.ok(acquireDvgSession("after-opening-cancel"));
releaseDvgSession("after-opening-cancel");
await cancelOpening.close();
let corrected = false;
const evolvingSource = structuredClone(source);
evolvingSource.runId = "same-run-stream";
const retained = new DvgArticleChangesService({
  ...repository,
  load: async () => structuredClone(result),
  source: async () => evolvingSource,
  catalogCorrections: async () =>
    corrected ? [{ catalogProductId: id, newSku: "NEW123_X", importRunId: "completed-csv" }] : [],
});
assert.equal(
  (await retained.list()).items.find((item) => item.catalogProductId === id)?.priceEur,
  25
);
evolvingSource.rows.push({
  ...oldRow,
  catalogProductId: "44444444-4444-4444-8444-444444444444",
  supplierArticleNumber: "OLD999",
});
assert.ok((await retained.list()).items.some((item) => item.originalArticle === "OLD999"));
corrected = true;
assert.equal(
  (await retained.list()).items.some((item) => item.catalogProductId === id),
  false
);
evolvingSource.runId = "new-run-with-old-observation";
const kept = await retained.list();
assert.equal(
  kept.items.some((item) => item.catalogProductId === id),
  false
);
assert.equal(kept.items.length, 3);
assert.equal(kept.resolved?.length, 1);
assert.equal(kept.closedItems?.length, 1);
assert.equal(kept.closedItems?.[0]?.resolution?.reason, "csv");
corrected = false;
const reopened = await retained.review(id, "OLD123", "open");
assert.ok(reopened.items.some((item) => item.catalogProductId === id));
assert.equal(reopened.closedItems?.length, 0);
assert.ok(reopened.items.find((item) => item.catalogProductId === id)?.reviewOpenedAt);
const manual = await retained.review(id, "OLD123", "resolved");
assert.equal(
  manual.items.some((item) => item.catalogProductId === id),
  false
);
assert.equal(manual.closedItems?.[0]?.resolution?.reason, "manual");
assert.equal((await retained.list()).closedItems?.length, 1, "closed rows must not be reseeded");
await assert.rejects(retained.review(id, "WRONG", "open"), /állapota megváltozott/);
await retained.close();
console.log(
  "DVG article changes seeding, successor pricing/profit, isolation, restart, browser lease and route tests passed"
);
